extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285CA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285CC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285CE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285D00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285D20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285D40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285D60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285D80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x396eb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285DA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x398cc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56aefc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285DC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56aef0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285DE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285E00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56aef0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285E20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56aee8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285E40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285E60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285E80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285EA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285EC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285EE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56aef4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285F00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285F30() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285F60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285F80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285FA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x35bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56aef8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285FC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00285FE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56aef8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286000() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56aef8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286020() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286040() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286060() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286080() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56af30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002860A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afe4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002860C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b000 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002860E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286100() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286120() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afe8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286140() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286160() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56afe8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b020 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286180() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56afac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b008 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002861A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b038 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002861C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b024 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002861E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56b024 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b034 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286200() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56af98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286220() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56afac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b02c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286240() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56afac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afd4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286260() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56afac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56afd4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afb4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00286280() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56affc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002862A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002862C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56afc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002862E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56b014 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
