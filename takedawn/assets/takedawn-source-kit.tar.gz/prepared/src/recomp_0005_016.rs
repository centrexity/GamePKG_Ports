extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn log2(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    fn gamepkg_tls_g_fp_cmp() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_cc() -> *mut uint16_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001F5870();
    fn sub_001F5F00();
    fn sub_001F5F30();
    fn sub_001F64C0();
    fn sub_001F8B10();
    fn sub_001FA070();
    fn sub_001FA7D0();
    fn sub_001FABB0();
    fn sub_001FAE90();
    fn sub_001FD480();
    fn sub_001FD5A0();
    fn sub_001FD620();
    fn sub_001FE270();
    fn sub_001FE500();
    fn sub_001FED80();
    fn sub_001FEDC0();
    fn sub_001FEF90();
    fn sub_001FF050();
    fn sub_001FF360();
    fn sub_001FF3B0();
    fn sub_002021F0();
    fn sub_002022A0();
    fn sub_002022C0();
    fn sub_0020B450();
    fn sub_0020BCE0();
    fn sub_0020BD20();
    fn sub_0020BDB0();
    fn sub_0020BEB0();
    fn sub_0020C290();
    fn sub_0020C2B0();
    fn sub_0020DF70();
    fn sub_0020DFA0();
    fn sub_00244DF0();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn recomp_parity8(mut x: uint32_t) -> ::core::ffi::c_int {
    x = (x as ::core::ffi::c_uint & 0xff as ::core::ffi::c_uint) as uint32_t;
    x ^= x >> 4 as ::core::ffi::c_int;
    x ^= x >> 2 as ::core::ffi::c_int;
    x ^= x >> 1 as ::core::ffi::c_int;
    return (!x & 1 as uint32_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF470() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff485 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0020BCE0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF490() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x9c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_329: {
        if _fa != _fb {
            break 's_329;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_329;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x1ff4ad as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_001FF360();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_319: {
            if _fa != _fb {
                break 's_319;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_4: uint32_t = 0x1ff4c1 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_263: {
                's_214: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_214;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_263;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_222: {
                    if !_fn.is_none() {
                        break 's_222;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_228: {
                    if !_fn.is_none() {
                        break 's_228;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_234: {
                    if _fn.is_some() {
                        break 's_234;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_263;
                }
                _fn.expect("non-null function pointer")();
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x74 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xfffffffd as uint32_t;
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x74 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                0 as uint32_t,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) | 2 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF500() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1ff50b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001FF490();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_303: {
        if _fa != _fb {
            break 's_303;
        }
        let mut _pv_2: uint32_t = 0x1ff51a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001F5870();
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x1ff521 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_001FF050();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_289: {
            if _fa == _fb {
                break 's_289;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                .wrapping_add(0x10 as uint32_t);
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0x1ff531 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_002021F0();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            's_263: {
                if _fa == _fb {
                    break 's_263;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffef as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) | 0x10 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF560() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF570() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x90 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax)
        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(2 as uint32_t));
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_151: {
        if _fa != _fb {
            break 's_151;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x3c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
            .wrapping_add((*__gamepkg_tls_g_eax))
            .wrapping_add(-1 as ::core::ffi::c_int as uint32_t);
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _dividend: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
            << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
        (*__gamepkg_tls_g_eax) = _dividend
            .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
        (*__gamepkg_tls_g_edx) = _dividend
            .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx)
            .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(2 as uint32_t));
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_151;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF5B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_97: {
        if _fa == _fb {
            break 's_97;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x94 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x40 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(2 as uint32_t));
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
            | (if _fa == _fb {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint8_t as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF5E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x90 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x94 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x64 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        3 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x70 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        2 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xa8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xac as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x3f800000 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xbc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x5c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x74 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    's_214: {
        if _fa <= _fb {
            break 's_214;
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_0: uint32_t = ebp;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        loop {
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(ebp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(ebp).wrapping_add(4 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                3 as uint32_t,
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(ebp).wrapping_add(8 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add(ebp)
                        .wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                2 as uint32_t,
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add(ebp)
                        .wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add(ebp)
                        .wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x3c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add(0x18 as uint32_t);
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = ebp & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF6A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x98 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x5c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff6c0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0020BD20();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_389: {
        's_146: {
            if _fa == _fb {
                break 's_146;
            }
            _fa = (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                & 0xff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            if _fa == _fb {
                break 's_389;
            }
        }
        let mut _pv_3: uint32_t = 0x1ff6d5 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001F5870();
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1ff6dc as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_001FEF90();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_423: {
            if _fa == _fb {
                break 's_423;
            }
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                .wrapping_add(0x54 as uint32_t);
            let mut _pv_7: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = 0x1ff440 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            let mut _pv_10: uint32_t = 0x1ff6f2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            sub_001FF3B0();
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x18 as uint32_t);
            let mut _pv_11: uint32_t = (*__gamepkg_tls_g_edx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_11,
            );
            let mut _pv_12: uint32_t = 0x1ff470 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_12,
            );
            let mut _pv_13: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_13,
            );
            let mut _pv_14: uint32_t = 0x1ff702 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_14,
            );
            sub_001FF3B0();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x18 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffff7 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            break 's_389;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x50 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            4 as uint32_t,
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        6 as uint32_t,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF730() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x98 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x5c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff750 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0020BD20();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_251: {
        if _fa == _fb {
            break 's_251;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x98 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(0x5c as uint32_t);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1ff766 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_0020BDB0();
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1ff470 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        let mut _pv_8: uint32_t = 0x1ff779 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_001FF3B0();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        4 as uint32_t,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF790() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff470 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1ff7b2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001FF3B0();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = 8 as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF7D0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    enum C2Rust_Block_12 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_58,
        S_60,
        S_62,
        S_68,
        S_74,
        S_76,
        S_78,
        S_88,
        S_90,
        S_92,
        S_102,
        S_104,
        S_106,
        S_112,
        S_114,
        S_120,
        S_122,
        S_124,
        S_130,
        S_134,
        S_136,
        S_138,
        S_140,
        S_144,
        S_147,
        S_148,
        S_149,
        S_150,
        S_161,
        S_163,
        S_168,
        S_171,
        S_172,
        S_173,
        S_174,
        S_181,
        S_183,
        S_189,
        S_195,
        S_197,
        S_199,
        S_205,
        S_211,
        S_213,
        S_215,
        S_217,
        S_219,
        S_221,
        S_223,
        S_229,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_241,
        S_243,
        S_245,
        S_258,
        S_264,
        S_266,
        S_268,
        S_278,
        S_280,
        S_282,
        S_292,
        S_294,
        S_296,
        S_302,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_393,
        S_395,
        S_405,
        S_407,
        S_417,
        S_419,
        S_425,
        S_427,
        S_429,
        S_435,
        S_437,
        S_443,
        S_445,
        S_455,
        S_457,
        S_467,
        S_469,
        S_475,
        S_481,
        S_483,
        S_493,
        S_495,
        S_501,
        S_503,
    }
    let mut c2rust_current_block_12: C2Rust_Block_12;
    c2rust_current_block_12 = C2Rust_Block_12::S_0;
    loop {
        match c2rust_current_block_12 {
            C2Rust_Block_12::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_2;
            }
            C2Rust_Block_12::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_12 = C2Rust_Block_12::S_4;
            }
            C2Rust_Block_12::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_6;
            }
            C2Rust_Block_12::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_8;
            }
            C2Rust_Block_12::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_18;
            }
            C2Rust_Block_12::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_12 = C2Rust_Block_12::S_28;
            }
            C2Rust_Block_12::S_28 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_12 = C2Rust_Block_12::S_30;
            }
            C2Rust_Block_12::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_32;
            }
            C2Rust_Block_12::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_42;
            }
            C2Rust_Block_12::S_42 => {
                _pv_0 = ebp;
                c2rust_current_block_12 = C2Rust_Block_12::S_44;
            }
            C2Rust_Block_12::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_46;
            }
            C2Rust_Block_12::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_52;
            }
            C2Rust_Block_12::S_52 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_58;
            }
            C2Rust_Block_12::S_58 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_12 = C2Rust_Block_12::S_60;
            }
            C2Rust_Block_12::S_60 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_62;
            }
            C2Rust_Block_12::S_62 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_68;
            }
            C2Rust_Block_12::S_68 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_74;
            }
            C2Rust_Block_12::S_74 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_12 = C2Rust_Block_12::S_76;
            }
            C2Rust_Block_12::S_76 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_78;
            }
            C2Rust_Block_12::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_88;
            }
            C2Rust_Block_12::S_88 => {
                _pv_3 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_90;
            }
            C2Rust_Block_12::S_90 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_92;
            }
            C2Rust_Block_12::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_102;
            }
            C2Rust_Block_12::S_102 => {
                _pv_4 = 0x36e898 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_104;
            }
            C2Rust_Block_12::S_104 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_106;
            }
            C2Rust_Block_12::S_106 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_112;
            }
            C2Rust_Block_12::S_112 => {
                (*__gamepkg_tls_g_ecx) = 7 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_114;
            }
            C2Rust_Block_12::S_114 => {
                (*__gamepkg_tls_g_edi) = ebp;
                c2rust_current_block_12 = C2Rust_Block_12::S_120;
            }
            C2Rust_Block_12::S_120 => {
                _pv_5 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_122;
            }
            C2Rust_Block_12::S_122 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_124;
            }
            C2Rust_Block_12::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_130;
            }
            C2Rust_Block_12::S_130 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_12 = C2Rust_Block_12::S_134;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_168;
                }
            }
            C2Rust_Block_12::S_134 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_136;
            }
            C2Rust_Block_12::S_136 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_138;
            }
            C2Rust_Block_12::S_138 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_12 = C2Rust_Block_12::S_140;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_144;
                }
            }
            C2Rust_Block_12::S_140 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_161;
            }
            C2Rust_Block_12::S_144 => {
                _i = 0;
                c2rust_current_block_12 = C2Rust_Block_12::S_147;
            }
            C2Rust_Block_12::S_147 => {
                _i = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_148;
            }
            C2Rust_Block_12::S_148 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_12 = C2Rust_Block_12::S_149;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_161;
                }
            }
            C2Rust_Block_12::S_149 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_150;
            }
            C2Rust_Block_12::S_150 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_148;
            }
            C2Rust_Block_12::S_161 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_12 = C2Rust_Block_12::S_163;
            }
            C2Rust_Block_12::S_163 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_12 = C2Rust_Block_12::S_189;
            }
            C2Rust_Block_12::S_168 => {
                _i_0 = 0;
                c2rust_current_block_12 = C2Rust_Block_12::S_171;
            }
            C2Rust_Block_12::S_171 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_172;
            }
            C2Rust_Block_12::S_172 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_12 = C2Rust_Block_12::S_173;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_181;
                }
            }
            C2Rust_Block_12::S_173 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_174;
            }
            C2Rust_Block_12::S_174 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_172;
            }
            C2Rust_Block_12::S_181 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_12 = C2Rust_Block_12::S_183;
            }
            C2Rust_Block_12::S_183 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_12 = C2Rust_Block_12::S_189;
            }
            C2Rust_Block_12::S_189 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_195;
            }
            C2Rust_Block_12::S_195 => {
                _pv_6 = 0x1ff7f3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_197;
            }
            C2Rust_Block_12::S_197 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_199;
            }
            C2Rust_Block_12::S_199 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_205;
            }
            C2Rust_Block_12::S_205 => {
                sub_001F8B10();
                c2rust_current_block_12 = C2Rust_Block_12::S_211;
            }
            C2Rust_Block_12::S_211 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_213;
            }
            C2Rust_Block_12::S_213 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_215;
            }
            C2Rust_Block_12::S_215 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_217;
            }
            C2Rust_Block_12::S_217 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_219;
            }
            C2Rust_Block_12::S_219 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_221;
            }
            C2Rust_Block_12::S_221 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_223;
            }
            C2Rust_Block_12::S_223 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_229;
            }
            C2Rust_Block_12::S_229 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_231;
            }
            C2Rust_Block_12::S_231 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_233;
            }
            C2Rust_Block_12::S_233 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_235;
            }
            C2Rust_Block_12::S_235 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_237;
            }
            C2Rust_Block_12::S_237 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_239;
            }
            C2Rust_Block_12::S_239 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_241;
            }
            C2Rust_Block_12::S_241 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_243;
            }
            C2Rust_Block_12::S_243 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_245;
            }
            C2Rust_Block_12::S_245 => {
                if _fa <= _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_372;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_258;
                }
            }
            C2Rust_Block_12::S_258 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_264;
            }
            C2Rust_Block_12::S_264 => {
                _pv_7 = ebp;
                c2rust_current_block_12 = C2Rust_Block_12::S_266;
            }
            C2Rust_Block_12::S_266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_268;
            }
            C2Rust_Block_12::S_268 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_278;
            }
            C2Rust_Block_12::S_278 => {
                _pv_8 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_280;
            }
            C2Rust_Block_12::S_280 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_282;
            }
            C2Rust_Block_12::S_282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_292;
            }
            C2Rust_Block_12::S_292 => {
                _pv_9 = 0x1ff819 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_294;
            }
            C2Rust_Block_12::S_294 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_296;
            }
            C2Rust_Block_12::S_296 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_302;
            }
            C2Rust_Block_12::S_302 => {
                sub_001FA070();
                c2rust_current_block_12 = C2Rust_Block_12::S_308;
            }
            C2Rust_Block_12::S_308 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_310;
            }
            C2Rust_Block_12::S_310 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_312;
            }
            C2Rust_Block_12::S_312 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_314;
            }
            C2Rust_Block_12::S_314 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_316;
            }
            C2Rust_Block_12::S_316 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_318;
            }
            C2Rust_Block_12::S_318 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_320;
            }
            C2Rust_Block_12::S_320 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_322;
            }
            C2Rust_Block_12::S_322 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_324;
            }
            C2Rust_Block_12::S_324 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_326;
            }
            C2Rust_Block_12::S_326 => {
                if _fa != _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_455;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_335;
                }
            }
            C2Rust_Block_12::S_335 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_337;
            }
            C2Rust_Block_12::S_337 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_339;
            }
            C2Rust_Block_12::S_339 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_341;
            }
            C2Rust_Block_12::S_341 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_343;
            }
            C2Rust_Block_12::S_343 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_345;
            }
            C2Rust_Block_12::S_345 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_347;
            }
            C2Rust_Block_12::S_347 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_349;
            }
            C2Rust_Block_12::S_349 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_351;
            }
            C2Rust_Block_12::S_351 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_353;
            }
            C2Rust_Block_12::S_353 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_355;
            }
            C2Rust_Block_12::S_355 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_357;
            }
            C2Rust_Block_12::S_357 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_359;
            }
            C2Rust_Block_12::S_359 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_361;
            }
            C2Rust_Block_12::S_361 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_363;
            }
            C2Rust_Block_12::S_363 => {
                if _fa < _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_258;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_372;
                }
            }
            C2Rust_Block_12::S_372 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        (ebp.wrapping_add(0xd as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(0xd as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as uint8_t,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_374;
            }
            C2Rust_Block_12::S_374 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        (ebp.wrapping_add(0xd as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_376;
            }
            C2Rust_Block_12::S_376 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_378;
            }
            C2Rust_Block_12::S_378 => {
                _fb = (_fa == 0x7f as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_380;
            }
            C2Rust_Block_12::S_380 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_12 = C2Rust_Block_12::S_229;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_393;
                }
            }
            C2Rust_Block_12::S_393 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_395;
            }
            C2Rust_Block_12::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_405;
            }
            C2Rust_Block_12::S_405 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_407;
            }
            C2Rust_Block_12::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_417;
            }
            C2Rust_Block_12::S_417 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_419;
            }
            C2Rust_Block_12::S_419 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_425;
            }
            C2Rust_Block_12::S_425 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_427;
            }
            C2Rust_Block_12::S_427 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_429;
            }
            C2Rust_Block_12::S_429 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_435;
            }
            C2Rust_Block_12::S_435 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_437;
            }
            C2Rust_Block_12::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_443;
            }
            C2Rust_Block_12::S_443 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_445;
            }
            C2Rust_Block_12::S_445 => return,
            C2Rust_Block_12::S_455 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_457;
            }
            C2Rust_Block_12::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_467;
            }
            C2Rust_Block_12::S_467 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_469;
            }
            C2Rust_Block_12::S_469 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_475;
            }
            C2Rust_Block_12::S_475 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_12 = C2Rust_Block_12::S_481;
            }
            C2Rust_Block_12::S_481 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_483;
            }
            C2Rust_Block_12::S_483 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_493;
            }
            C2Rust_Block_12::S_493 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_495;
            }
            C2Rust_Block_12::S_495 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_501;
            }
            C2Rust_Block_12::S_501 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_503;
            }
            C2Rust_Block_12::S_503 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF840() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _dividend_0: uint64_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    let mut _pv_36: uint32_t = 0;
    let mut _pv_37: uint32_t = 0;
    let mut _pv_38: uint32_t = 0;
    let mut _pv_39: uint32_t = 0;
    let mut _pv_40: uint32_t = 0;
    let mut _pv_41: uint32_t = 0;
    let mut _pv_42: uint32_t = 0;
    let mut _pv_43: uint32_t = 0;
    let mut _pv_44: uint32_t = 0;
    let mut _pv_45: uint32_t = 0;
    let mut _pv_46: uint32_t = 0;
    let mut _pv_47: uint32_t = 0;
    enum C2Rust_Block_13 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_40,
        S_42,
        S_44,
        S_50,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_92,
        S_94,
        S_96,
        S_106,
        S_108,
        S_110,
        S_120,
        S_122,
        S_124,
        S_130,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_167,
        S_169,
        S_179,
        S_181,
        S_191,
        S_193,
        S_199,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_221,
        S_223,
        S_225,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_241,
        S_250,
        S_252,
        S_254,
        S_260,
        S_262,
        S_268,
        S_270,
        S_272,
        S_282,
        S_284,
        S_286,
        S_296,
        S_298,
        S_300,
        S_306,
        S_316,
        S_318,
        S_320,
        S_330,
        S_332,
        S_334,
        S_344,
        S_346,
        S_348,
        S_354,
        S_360,
        S_362,
        S_364,
        S_370,
        S_380,
        S_382,
        S_384,
        S_394,
        S_396,
        S_398,
        S_404,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_429,
        S_431,
        S_433,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_459,
        S_461,
        S_463,
        S_469,
        S_475,
        S_477,
        S_479,
        S_489,
        S_491,
        S_493,
        S_499,
        S_505,
        S_507,
        S_513,
        S_515,
        S_517,
        S_523,
        S_529,
        S_531,
        S_533,
        S_543,
        S_545,
        S_547,
        S_553,
        S_559,
        S_561,
        S_563,
        S_565,
        S_568,
        S_570,
        S_572,
        S_576,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_613,
        S_621,
        S_629,
        S_631,
        S_633,
        S_635,
        S_637,
        S_639,
        S_641,
        S_647,
        S_649,
        S_651,
        S_661,
        S_663,
        S_665,
        S_671,
        S_673,
        S_679,
        S_681,
        S_683,
        S_689,
        S_695,
        S_697,
        S_699,
        S_709,
        S_711,
        S_713,
        S_723,
        S_725,
        S_727,
        S_733,
        S_739,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_753,
        S_755,
        S_757,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_776,
        S_778,
        S_780,
        S_782,
        S_784,
        S_786,
        S_788,
        S_797,
        S_799,
        S_801,
        S_809,
        S_811,
        S_813,
        S_819,
        S_821,
        S_823,
        S_825,
        S_831,
        S_833,
        S_835,
        S_845,
        S_847,
        S_849,
        S_859,
        S_861,
        S_863,
        S_873,
        S_875,
        S_877,
        S_883,
        S_889,
        S_891,
        S_893,
        S_899,
        S_905,
        S_907,
        S_909,
        S_915,
        S_921,
        S_923,
        S_925,
        S_927,
        S_929,
        S_931,
        S_933,
        S_935,
        S_937,
        S_939,
        S_952,
        S_954,
        S_956,
        S_966,
        S_968,
        S_970,
        S_980,
        S_982,
        S_984,
        S_990,
        S_1000,
        S_1002,
        S_1004,
        S_1014,
        S_1016,
        S_1018,
        S_1028,
        S_1030,
        S_1032,
        S_1038,
        S_1044,
        S_1046,
        S_1048,
        S_1050,
        S_1052,
        S_1054,
        S_1056,
        S_1058,
        S_1060,
        S_1062,
        S_1064,
        S_1066,
        S_1068,
        S_1070,
        S_1072,
        S_1074,
        S_1076,
        S_1078,
        S_1080,
        S_1082,
        S_1084,
        S_1086,
        S_1088,
        S_1097,
        S_1099,
        S_1101,
        S_1103,
        S_1105,
        S_1114,
        S_1116,
        S_1118,
        S_1120,
        S_1122,
        S_1124,
        S_1130,
        S_1132,
        S_1134,
        S_1144,
        S_1146,
        S_1148,
        S_1158,
        S_1160,
        S_1162,
        S_1168,
        S_1174,
        S_1176,
        S_1178,
        S_1180,
        S_1182,
        S_1184,
        S_1190,
        S_1192,
        S_1194,
        S_1204,
        S_1206,
        S_1208,
        S_1218,
        S_1220,
        S_1222,
        S_1228,
        S_1234,
        S_1236,
        S_1238,
        S_1240,
        S_1242,
        S_1244,
        S_1246,
        S_1252,
        S_1254,
        S_1264,
        S_1266,
        S_1276,
        S_1278,
        S_1288,
        S_1290,
        S_1296,
        S_1298,
        S_1300,
        S_1302,
        S_1304,
        S_1306,
        S_1308,
        S_1318,
        S_1320,
        S_1330,
        S_1332,
        S_1342,
        S_1344,
        S_1350,
        S_1352,
        S_1354,
        S_1360,
        S_1362,
        S_1368,
        S_1370,
        S_1372,
        S_1374,
        S_1376,
        S_1378,
        S_1380,
        S_1386,
        S_1388,
        S_1390,
        S_1392,
        S_1394,
        S_1403,
        S_1405,
        S_1407,
        S_1409,
        S_1411,
        S_1413,
        S_1419,
        S_1421,
        S_1423,
        S_1433,
        S_1435,
        S_1437,
        S_1447,
        S_1449,
        S_1451,
        S_1457,
        S_1463,
        S_1465,
        S_1467,
        S_1469,
        S_1471,
        S_1477,
        S_1479,
        S_1485,
        S_1487,
        S_1497,
        S_1499,
        S_1509,
        S_1511,
        S_1521,
        S_1523,
        S_1529,
        S_1531,
        S_1533,
        S_1535,
        S_1537,
        S_1539,
        S_1541,
    }
    let mut c2rust_current_block_13: C2Rust_Block_13;
    c2rust_current_block_13 = C2Rust_Block_13::S_0;
    loop {
        match c2rust_current_block_13 {
            C2Rust_Block_13::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_2;
            }
            C2Rust_Block_13::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_13 = C2Rust_Block_13::S_4;
            }
            C2Rust_Block_13::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_13 = C2Rust_Block_13::S_6;
            }
            C2Rust_Block_13::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_8;
            }
            C2Rust_Block_13::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_18;
            }
            C2Rust_Block_13::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_13 = C2Rust_Block_13::S_24;
            }
            C2Rust_Block_13::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_26;
            }
            C2Rust_Block_13::S_26 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_28;
            }
            C2Rust_Block_13::S_28 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_30;
            }
            C2Rust_Block_13::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x30 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_32;
            }
            C2Rust_Block_13::S_32 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_34;
            }
            C2Rust_Block_13::S_34 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_40;
            }
            C2Rust_Block_13::S_40 => {
                _pv = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_42;
            }
            C2Rust_Block_13::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_44;
            }
            C2Rust_Block_13::S_44 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_50;
            }
            C2Rust_Block_13::S_50 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_56;
            }
            C2Rust_Block_13::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_13 = C2Rust_Block_13::S_58;
            }
            C2Rust_Block_13::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_60;
            }
            C2Rust_Block_13::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_66;
            }
            C2Rust_Block_13::S_66 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x1c as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_68;
            }
            C2Rust_Block_13::S_68 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_74;
            }
            C2Rust_Block_13::S_74 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_13 = C2Rust_Block_13::S_76;
            }
            C2Rust_Block_13::S_76 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_78;
            }
            C2Rust_Block_13::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_84;
            }
            C2Rust_Block_13::S_84 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_86;
            }
            C2Rust_Block_13::S_86 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_92;
            }
            C2Rust_Block_13::S_92 => {
                _pv_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_94;
            }
            C2Rust_Block_13::S_94 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_96;
            }
            C2Rust_Block_13::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_106;
            }
            C2Rust_Block_13::S_106 => {
                _pv_3 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_108;
            }
            C2Rust_Block_13::S_108 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_110;
            }
            C2Rust_Block_13::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_120;
            }
            C2Rust_Block_13::S_120 => {
                _pv_4 = 0x1ff862 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_122;
            }
            C2Rust_Block_13::S_122 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_124;
            }
            C2Rust_Block_13::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_130;
            }
            C2Rust_Block_13::S_130 => {
                sub_001FF7D0();
                c2rust_current_block_13 = C2Rust_Block_13::S_136;
            }
            C2Rust_Block_13::S_136 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_138;
            }
            C2Rust_Block_13::S_138 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_140;
            }
            C2Rust_Block_13::S_140 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_142;
            }
            C2Rust_Block_13::S_142 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_144;
            }
            C2Rust_Block_13::S_144 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_146;
            }
            C2Rust_Block_13::S_146 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_148;
            }
            C2Rust_Block_13::S_148 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_150;
            }
            C2Rust_Block_13::S_150 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_152;
            }
            C2Rust_Block_13::S_152 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_154;
            }
            C2Rust_Block_13::S_154 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_221;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_167;
                }
            }
            C2Rust_Block_13::S_167 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_169;
            }
            C2Rust_Block_13::S_169 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_179;
            }
            C2Rust_Block_13::S_179 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_181;
            }
            C2Rust_Block_13::S_181 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_191;
            }
            C2Rust_Block_13::S_191 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_193;
            }
            C2Rust_Block_13::S_193 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_199;
            }
            C2Rust_Block_13::S_199 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_201;
            }
            C2Rust_Block_13::S_201 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_203;
            }
            C2Rust_Block_13::S_203 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_205;
            }
            C2Rust_Block_13::S_205 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_207;
            }
            C2Rust_Block_13::S_207 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_209;
            }
            C2Rust_Block_13::S_209 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_211;
            }
            C2Rust_Block_13::S_211 => return,
            C2Rust_Block_13::S_221 => {
                _pv_5 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_223;
            }
            C2Rust_Block_13::S_223 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_225;
            }
            C2Rust_Block_13::S_225 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_231;
            }
            C2Rust_Block_13::S_231 => {
                (*__gamepkg_tls_g_ebx) = 1 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_233;
            }
            C2Rust_Block_13::S_233 => {
                _fa = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_235;
            }
            C2Rust_Block_13::S_235 => {
                _fb = ((*__gamepkg_tls_g_ebx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_237;
            }
            C2Rust_Block_13::S_237 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_239;
            }
            C2Rust_Block_13::S_239 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_241;
            }
            C2Rust_Block_13::S_241 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_260;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_250;
                }
            }
            C2Rust_Block_13::S_250 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x31 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_252;
            }
            C2Rust_Block_13::S_252 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_254;
            }
            C2Rust_Block_13::S_254 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xd as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_260;
            }
            C2Rust_Block_13::S_260 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_262;
            }
            C2Rust_Block_13::S_262 => {
                (*__gamepkg_tls_g_ecx) = ((*__gamepkg_tls_g_ecx) as int32_t
                    * 0x218 as ::core::ffi::c_int as int32_t) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_268;
            }
            C2Rust_Block_13::S_268 => {
                _pv_6 = 0x30809 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_270;
            }
            C2Rust_Block_13::S_270 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_272;
            }
            C2Rust_Block_13::S_272 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_282;
            }
            C2Rust_Block_13::S_282 => {
                _pv_7 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_284;
            }
            C2Rust_Block_13::S_284 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_286;
            }
            C2Rust_Block_13::S_286 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_296;
            }
            C2Rust_Block_13::S_296 => {
                _pv_8 = 0x1ff89a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_298;
            }
            C2Rust_Block_13::S_298 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_300;
            }
            C2Rust_Block_13::S_300 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_306;
            }
            C2Rust_Block_13::S_306 => {
                sub_001FED80();
                c2rust_current_block_13 = C2Rust_Block_13::S_316;
            }
            C2Rust_Block_13::S_316 => {
                _pv_9 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_318;
            }
            C2Rust_Block_13::S_318 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_320;
            }
            C2Rust_Block_13::S_320 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_330;
            }
            C2Rust_Block_13::S_330 => {
                _pv_10 = 0x36ea4c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_332;
            }
            C2Rust_Block_13::S_332 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_334;
            }
            C2Rust_Block_13::S_334 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_344;
            }
            C2Rust_Block_13::S_344 => {
                _pv_11 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_346;
            }
            C2Rust_Block_13::S_346 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_348;
            }
            C2Rust_Block_13::S_348 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_354;
            }
            C2Rust_Block_13::S_354 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_360;
            }
            C2Rust_Block_13::S_360 => {
                _pv_12 = 0x1ff8ae as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_362;
            }
            C2Rust_Block_13::S_362 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_364;
            }
            C2Rust_Block_13::S_364 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_370;
            }
            C2Rust_Block_13::S_370 => {
                sub_001F8B10();
                c2rust_current_block_13 = C2Rust_Block_13::S_380;
            }
            C2Rust_Block_13::S_380 => {
                _pv_13 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_382;
            }
            C2Rust_Block_13::S_382 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_384;
            }
            C2Rust_Block_13::S_384 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_394;
            }
            C2Rust_Block_13::S_394 => {
                _pv_14 = 0x1ff8b4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_396;
            }
            C2Rust_Block_13::S_396 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_398;
            }
            C2Rust_Block_13::S_398 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_404;
            }
            C2Rust_Block_13::S_404 => {
                sub_001F5F00();
                c2rust_current_block_13 = C2Rust_Block_13::S_410;
            }
            C2Rust_Block_13::S_410 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x6c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_412;
            }
            C2Rust_Block_13::S_412 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_414;
            }
            C2Rust_Block_13::S_414 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_416;
            }
            C2Rust_Block_13::S_416 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x68 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_418;
            }
            C2Rust_Block_13::S_418 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_420;
            }
            C2Rust_Block_13::S_420 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_422;
            }
            C2Rust_Block_13::S_422 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_424;
            }
            C2Rust_Block_13::S_424 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_426;
            }
            C2Rust_Block_13::S_426 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_429;
            }
            C2Rust_Block_13::S_429 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_431;
            }
            C2Rust_Block_13::S_431 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_433;
            }
            C2Rust_Block_13::S_433 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_437;
            }
            C2Rust_Block_13::S_437 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_439;
            }
            C2Rust_Block_13::S_439 => {
                (*__gamepkg_tls_g_ecx) = ((*__gamepkg_tls_g_ecx) as int32_t
                    * (*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_441;
            }
            C2Rust_Block_13::S_441 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xa0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_443;
            }
            C2Rust_Block_13::S_443 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_445;
            }
            C2Rust_Block_13::S_445 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint8_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_447;
            }
            C2Rust_Block_13::S_447 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_449;
            }
            C2Rust_Block_13::S_449 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xd as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_451;
            }
            C2Rust_Block_13::S_451 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_453;
            }
            C2Rust_Block_13::S_453 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_459;
            }
            C2Rust_Block_13::S_459 => {
                _pv_15 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_461;
            }
            C2Rust_Block_13::S_461 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_463;
            }
            C2Rust_Block_13::S_463 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_469;
            }
            C2Rust_Block_13::S_469 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x40 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_475;
            }
            C2Rust_Block_13::S_475 => {
                _pv_16 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_477;
            }
            C2Rust_Block_13::S_477 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_479;
            }
            C2Rust_Block_13::S_479 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_489;
            }
            C2Rust_Block_13::S_489 => {
                _pv_17 = 0x1ff8fd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_491;
            }
            C2Rust_Block_13::S_491 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_493;
            }
            C2Rust_Block_13::S_493 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_499;
            }
            C2Rust_Block_13::S_499 => {
                sub_001FA7D0();
                c2rust_current_block_13 = C2Rust_Block_13::S_505;
            }
            C2Rust_Block_13::S_505 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_507;
            }
            C2Rust_Block_13::S_507 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_513;
            }
            C2Rust_Block_13::S_513 => {
                _pv_18 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_515;
            }
            C2Rust_Block_13::S_515 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_517;
            }
            C2Rust_Block_13::S_517 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_523;
            }
            C2Rust_Block_13::S_523 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x48 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_529;
            }
            C2Rust_Block_13::S_529 => {
                _pv_19 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_531;
            }
            C2Rust_Block_13::S_531 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_533;
            }
            C2Rust_Block_13::S_533 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_543;
            }
            C2Rust_Block_13::S_543 => {
                _pv_20 = 0x1ff90e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_545;
            }
            C2Rust_Block_13::S_545 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_547;
            }
            C2Rust_Block_13::S_547 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_553;
            }
            C2Rust_Block_13::S_553 => {
                sub_001FA7D0();
                c2rust_current_block_13 = C2Rust_Block_13::S_559;
            }
            C2Rust_Block_13::S_559 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_561;
            }
            C2Rust_Block_13::S_561 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_563;
            }
            C2Rust_Block_13::S_563 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_565;
            }
            C2Rust_Block_13::S_565 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_568;
            }
            C2Rust_Block_13::S_568 => {
                _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_570;
            }
            C2Rust_Block_13::S_570 => {
                (*__gamepkg_tls_g_eax) = _dividend_0
                    .wrapping_div((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_572;
            }
            C2Rust_Block_13::S_572 => {
                (*__gamepkg_tls_g_edx) = _dividend_0
                    .wrapping_rem((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_576;
            }
            C2Rust_Block_13::S_576 => {
                _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_578;
            }
            C2Rust_Block_13::S_578 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_580;
            }
            C2Rust_Block_13::S_580 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_582;
            }
            C2Rust_Block_13::S_582 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_584;
            }
            C2Rust_Block_13::S_584 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_586;
            }
            C2Rust_Block_13::S_586 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_588;
            }
            C2Rust_Block_13::S_588 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_590;
            }
            C2Rust_Block_13::S_590 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_592;
            }
            C2Rust_Block_13::S_592 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_594;
            }
            C2Rust_Block_13::S_594 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_596;
            }
            C2Rust_Block_13::S_596 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_598;
            }
            C2Rust_Block_13::S_598 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_600;
            }
            C2Rust_Block_13::S_600 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_602;
            }
            C2Rust_Block_13::S_602 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_604;
            }
            C2Rust_Block_13::S_604 => {
                if _fa <= _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1097;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_613;
                }
            }
            C2Rust_Block_13::S_613 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_629;
            }
            C2Rust_Block_13::S_621 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_629;
            }
            C2Rust_Block_13::S_629 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_631;
            }
            C2Rust_Block_13::S_631 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_633;
            }
            C2Rust_Block_13::S_633 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_635;
            }
            C2Rust_Block_13::S_635 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_13 = C2Rust_Block_13::S_637;
            }
            C2Rust_Block_13::S_637 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_639;
            }
            C2Rust_Block_13::S_639 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_641;
            }
            C2Rust_Block_13::S_641 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x34 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_647;
            }
            C2Rust_Block_13::S_647 => {
                _pv_21 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_13 = C2Rust_Block_13::S_649;
            }
            C2Rust_Block_13::S_649 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_651;
            }
            C2Rust_Block_13::S_651 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_661;
            }
            C2Rust_Block_13::S_661 => {
                _pv_22 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_663;
            }
            C2Rust_Block_13::S_663 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_665;
            }
            C2Rust_Block_13::S_665 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_671;
            }
            C2Rust_Block_13::S_671 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_673;
            }
            C2Rust_Block_13::S_673 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x2c as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_679;
            }
            C2Rust_Block_13::S_679 => {
                _pv_23 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_681;
            }
            C2Rust_Block_13::S_681 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_683;
            }
            C2Rust_Block_13::S_683 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_689;
            }
            C2Rust_Block_13::S_689 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_695;
            }
            C2Rust_Block_13::S_695 => {
                _pv_24 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_697;
            }
            C2Rust_Block_13::S_697 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_699;
            }
            C2Rust_Block_13::S_699 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_709;
            }
            C2Rust_Block_13::S_709 => {
                _pv_25 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_711;
            }
            C2Rust_Block_13::S_711 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_713;
            }
            C2Rust_Block_13::S_713 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_723;
            }
            C2Rust_Block_13::S_723 => {
                _pv_26 = 0x1ff961 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_725;
            }
            C2Rust_Block_13::S_725 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_727;
            }
            C2Rust_Block_13::S_727 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_733;
            }
            C2Rust_Block_13::S_733 => {
                sub_0020DF70();
                c2rust_current_block_13 = C2Rust_Block_13::S_739;
            }
            C2Rust_Block_13::S_739 => {
                _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_741;
            }
            C2Rust_Block_13::S_741 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_743;
            }
            C2Rust_Block_13::S_743 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_745;
            }
            C2Rust_Block_13::S_745 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_747;
            }
            C2Rust_Block_13::S_747 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_749;
            }
            C2Rust_Block_13::S_749 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_751;
            }
            C2Rust_Block_13::S_751 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_753;
            }
            C2Rust_Block_13::S_753 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_755;
            }
            C2Rust_Block_13::S_755 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_757;
            }
            C2Rust_Block_13::S_757 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1318;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_766;
                }
            }
            C2Rust_Block_13::S_766 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_768;
            }
            C2Rust_Block_13::S_768 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) | 0x20 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_770;
            }
            C2Rust_Block_13::S_770 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_772;
            }
            C2Rust_Block_13::S_772 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_774;
            }
            C2Rust_Block_13::S_774 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_776;
            }
            C2Rust_Block_13::S_776 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x30 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_778;
            }
            C2Rust_Block_13::S_778 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_780;
            }
            C2Rust_Block_13::S_780 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_782;
            }
            C2Rust_Block_13::S_782 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_784;
            }
            C2Rust_Block_13::S_784 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_786;
            }
            C2Rust_Block_13::S_786 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_788;
            }
            C2Rust_Block_13::S_788 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_809;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_797;
                }
            }
            C2Rust_Block_13::S_797 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0x40 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_799;
            }
            C2Rust_Block_13::S_799 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_801;
            }
            C2Rust_Block_13::S_801 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_819;
            }
            C2Rust_Block_13::S_809 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffffbf as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_811;
            }
            C2Rust_Block_13::S_811 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_813;
            }
            C2Rust_Block_13::S_813 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_819;
            }
            C2Rust_Block_13::S_819 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_821;
            }
            C2Rust_Block_13::S_821 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_823;
            }
            C2Rust_Block_13::S_823 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_825;
            }
            C2Rust_Block_13::S_825 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_831;
            }
            C2Rust_Block_13::S_831 => {
                _pv_27 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_833;
            }
            C2Rust_Block_13::S_833 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_835;
            }
            C2Rust_Block_13::S_835 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_845;
            }
            C2Rust_Block_13::S_845 => {
                _pv_28 = 0x1ff0c0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_847;
            }
            C2Rust_Block_13::S_847 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_849;
            }
            C2Rust_Block_13::S_849 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_859;
            }
            C2Rust_Block_13::S_859 => {
                _pv_29 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_861;
            }
            C2Rust_Block_13::S_861 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_863;
            }
            C2Rust_Block_13::S_863 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_873;
            }
            C2Rust_Block_13::S_873 => {
                _pv_30 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_875;
            }
            C2Rust_Block_13::S_875 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_877;
            }
            C2Rust_Block_13::S_877 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_883;
            }
            C2Rust_Block_13::S_883 => {
                ebp = (*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_889;
            }
            C2Rust_Block_13::S_889 => {
                _pv_31 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_891;
            }
            C2Rust_Block_13::S_891 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_893;
            }
            C2Rust_Block_13::S_893 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_899;
            }
            C2Rust_Block_13::S_899 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_905;
            }
            C2Rust_Block_13::S_905 => {
                _pv_32 = 0x1ff9ab as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_907;
            }
            C2Rust_Block_13::S_907 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_909;
            }
            C2Rust_Block_13::S_909 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_915;
            }
            C2Rust_Block_13::S_915 => {
                sub_0020B450();
                c2rust_current_block_13 = C2Rust_Block_13::S_921;
            }
            C2Rust_Block_13::S_921 => {
                _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_923;
            }
            C2Rust_Block_13::S_923 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_925;
            }
            C2Rust_Block_13::S_925 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_927;
            }
            C2Rust_Block_13::S_927 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_929;
            }
            C2Rust_Block_13::S_929 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_931;
            }
            C2Rust_Block_13::S_931 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_933;
            }
            C2Rust_Block_13::S_933 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_935;
            }
            C2Rust_Block_13::S_935 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_937;
            }
            C2Rust_Block_13::S_937 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_939;
            }
            C2Rust_Block_13::S_939 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1318;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_952;
                }
            }
            C2Rust_Block_13::S_952 => {
                _pv_33 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_13 = C2Rust_Block_13::S_954;
            }
            C2Rust_Block_13::S_954 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_956;
            }
            C2Rust_Block_13::S_956 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_966;
            }
            C2Rust_Block_13::S_966 => {
                _pv_34 = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_968;
            }
            C2Rust_Block_13::S_968 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_970;
            }
            C2Rust_Block_13::S_970 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_980;
            }
            C2Rust_Block_13::S_980 => {
                _pv_35 = 0x1ff9b9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_982;
            }
            C2Rust_Block_13::S_982 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_984;
            }
            C2Rust_Block_13::S_984 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_35,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_990;
            }
            C2Rust_Block_13::S_990 => {
                sub_0020BEB0();
                c2rust_current_block_13 = C2Rust_Block_13::S_1000;
            }
            C2Rust_Block_13::S_1000 => {
                _pv_36 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1002;
            }
            C2Rust_Block_13::S_1002 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1004;
            }
            C2Rust_Block_13::S_1004 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_36,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1014;
            }
            C2Rust_Block_13::S_1014 => {
                _pv_37 = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_1016;
            }
            C2Rust_Block_13::S_1016 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1018;
            }
            C2Rust_Block_13::S_1018 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_37,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1028;
            }
            C2Rust_Block_13::S_1028 => {
                _pv_38 = 0x1ff9c1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1030;
            }
            C2Rust_Block_13::S_1030 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1032;
            }
            C2Rust_Block_13::S_1032 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_38,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1038;
            }
            C2Rust_Block_13::S_1038 => {
                sub_0020C2B0();
                c2rust_current_block_13 = C2Rust_Block_13::S_1044;
            }
            C2Rust_Block_13::S_1044 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1046;
            }
            C2Rust_Block_13::S_1046 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1048;
            }
            C2Rust_Block_13::S_1048 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1050;
            }
            C2Rust_Block_13::S_1050 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1052;
            }
            C2Rust_Block_13::S_1052 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1054;
            }
            C2Rust_Block_13::S_1054 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1056;
            }
            C2Rust_Block_13::S_1056 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1058;
            }
            C2Rust_Block_13::S_1058 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_1060;
            }
            C2Rust_Block_13::S_1060 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1062;
            }
            C2Rust_Block_13::S_1062 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1064;
            }
            C2Rust_Block_13::S_1064 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1066;
            }
            C2Rust_Block_13::S_1066 => {
                _fb = 0x218 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1068;
            }
            C2Rust_Block_13::S_1068 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1070;
            }
            C2Rust_Block_13::S_1070 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(0x218 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1072;
            }
            C2Rust_Block_13::S_1072 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1074;
            }
            C2Rust_Block_13::S_1074 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1076;
            }
            C2Rust_Block_13::S_1076 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1078;
            }
            C2Rust_Block_13::S_1078 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1080;
            }
            C2Rust_Block_13::S_1080 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1082;
            }
            C2Rust_Block_13::S_1082 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1084;
            }
            C2Rust_Block_13::S_1084 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1086;
            }
            C2Rust_Block_13::S_1086 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1088;
            }
            C2Rust_Block_13::S_1088 => {
                if _fa < _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_621;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1097;
                }
            }
            C2Rust_Block_13::S_1097 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1099;
            }
            C2Rust_Block_13::S_1099 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1101;
            }
            C2Rust_Block_13::S_1101 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1103;
            }
            C2Rust_Block_13::S_1103 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1105;
            }
            C2Rust_Block_13::S_1105 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1386;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1114;
                }
            }
            C2Rust_Block_13::S_1114 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1116;
            }
            C2Rust_Block_13::S_1116 => {
                _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1118;
            }
            C2Rust_Block_13::S_1118 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1120;
            }
            C2Rust_Block_13::S_1120 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1122;
            }
            C2Rust_Block_13::S_1122 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1124;
            }
            C2Rust_Block_13::S_1124 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1130;
            }
            C2Rust_Block_13::S_1130 => {
                _pv_39 = 0xbf800000 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1132;
            }
            C2Rust_Block_13::S_1132 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1134;
            }
            C2Rust_Block_13::S_1134 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_39,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1144;
            }
            C2Rust_Block_13::S_1144 => {
                _pv_40 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_1146;
            }
            C2Rust_Block_13::S_1146 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1148;
            }
            C2Rust_Block_13::S_1148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_40,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1158;
            }
            C2Rust_Block_13::S_1158 => {
                _pv_41 = 0x1ff9fc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1160;
            }
            C2Rust_Block_13::S_1160 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1162;
            }
            C2Rust_Block_13::S_1162 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_41,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1168;
            }
            C2Rust_Block_13::S_1168 => {
                sub_0020C290();
                c2rust_current_block_13 = C2Rust_Block_13::S_1174;
            }
            C2Rust_Block_13::S_1174 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1176;
            }
            C2Rust_Block_13::S_1176 => {
                _fb = 0x274 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1178;
            }
            C2Rust_Block_13::S_1178 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1180;
            }
            C2Rust_Block_13::S_1180 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x274 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1182;
            }
            C2Rust_Block_13::S_1182 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1184;
            }
            C2Rust_Block_13::S_1184 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1190;
            }
            C2Rust_Block_13::S_1190 => {
                _pv_42 = 0x3f800000 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1192;
            }
            C2Rust_Block_13::S_1192 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1194;
            }
            C2Rust_Block_13::S_1194 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_42,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1204;
            }
            C2Rust_Block_13::S_1204 => {
                _pv_43 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_1206;
            }
            C2Rust_Block_13::S_1206 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1208;
            }
            C2Rust_Block_13::S_1208 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_43,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1218;
            }
            C2Rust_Block_13::S_1218 => {
                _pv_44 = 0x1ffa13 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1220;
            }
            C2Rust_Block_13::S_1220 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1222;
            }
            C2Rust_Block_13::S_1222 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_44,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1228;
            }
            C2Rust_Block_13::S_1228 => {
                sub_0020C290();
                c2rust_current_block_13 = C2Rust_Block_13::S_1234;
            }
            C2Rust_Block_13::S_1234 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1236;
            }
            C2Rust_Block_13::S_1236 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1238;
            }
            C2Rust_Block_13::S_1238 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1240;
            }
            C2Rust_Block_13::S_1240 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1242;
            }
            C2Rust_Block_13::S_1242 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1244;
            }
            C2Rust_Block_13::S_1244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1246;
            }
            C2Rust_Block_13::S_1246 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_1252;
            }
            C2Rust_Block_13::S_1252 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1254;
            }
            C2Rust_Block_13::S_1254 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1264;
            }
            C2Rust_Block_13::S_1264 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1266;
            }
            C2Rust_Block_13::S_1266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1276;
            }
            C2Rust_Block_13::S_1276 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1278;
            }
            C2Rust_Block_13::S_1278 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1288;
            }
            C2Rust_Block_13::S_1288 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1290;
            }
            C2Rust_Block_13::S_1290 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1296;
            }
            C2Rust_Block_13::S_1296 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1298;
            }
            C2Rust_Block_13::S_1298 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1300;
            }
            C2Rust_Block_13::S_1300 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1302;
            }
            C2Rust_Block_13::S_1302 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1304;
            }
            C2Rust_Block_13::S_1304 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1306;
            }
            C2Rust_Block_13::S_1306 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1308;
            }
            C2Rust_Block_13::S_1308 => return,
            C2Rust_Block_13::S_1318 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1320;
            }
            C2Rust_Block_13::S_1320 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1330;
            }
            C2Rust_Block_13::S_1330 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1332;
            }
            C2Rust_Block_13::S_1332 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1342;
            }
            C2Rust_Block_13::S_1342 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1344;
            }
            C2Rust_Block_13::S_1344 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1350;
            }
            C2Rust_Block_13::S_1350 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1352;
            }
            C2Rust_Block_13::S_1352 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1354;
            }
            C2Rust_Block_13::S_1354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1360;
            }
            C2Rust_Block_13::S_1360 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1362;
            }
            C2Rust_Block_13::S_1362 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1368;
            }
            C2Rust_Block_13::S_1368 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1370;
            }
            C2Rust_Block_13::S_1370 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1372;
            }
            C2Rust_Block_13::S_1372 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1374;
            }
            C2Rust_Block_13::S_1374 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1376;
            }
            C2Rust_Block_13::S_1376 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1378;
            }
            C2Rust_Block_13::S_1378 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1380;
            }
            C2Rust_Block_13::S_1380 => return,
            C2Rust_Block_13::S_1386 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1388;
            }
            C2Rust_Block_13::S_1388 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1390;
            }
            C2Rust_Block_13::S_1390 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1392;
            }
            C2Rust_Block_13::S_1392 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1394;
            }
            C2Rust_Block_13::S_1394 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1477;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_1403;
                }
            }
            C2Rust_Block_13::S_1403 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1405;
            }
            C2Rust_Block_13::S_1405 => {
                _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1407;
            }
            C2Rust_Block_13::S_1407 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1409;
            }
            C2Rust_Block_13::S_1409 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1411;
            }
            C2Rust_Block_13::S_1411 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1413;
            }
            C2Rust_Block_13::S_1413 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1419;
            }
            C2Rust_Block_13::S_1419 => {
                _pv_45 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1421;
            }
            C2Rust_Block_13::S_1421 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1423;
            }
            C2Rust_Block_13::S_1423 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_45,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1433;
            }
            C2Rust_Block_13::S_1433 => {
                _pv_46 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_1435;
            }
            C2Rust_Block_13::S_1435 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1437;
            }
            C2Rust_Block_13::S_1437 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_46,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1447;
            }
            C2Rust_Block_13::S_1447 => {
                _pv_47 = 0x1ffa46 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1449;
            }
            C2Rust_Block_13::S_1449 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1451;
            }
            C2Rust_Block_13::S_1451 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_47,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1457;
            }
            C2Rust_Block_13::S_1457 => {
                sub_0020C290();
                c2rust_current_block_13 = C2Rust_Block_13::S_1463;
            }
            C2Rust_Block_13::S_1463 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1465;
            }
            C2Rust_Block_13::S_1465 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1467;
            }
            C2Rust_Block_13::S_1467 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1469;
            }
            C2Rust_Block_13::S_1469 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1471;
            }
            C2Rust_Block_13::S_1471 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1477;
            }
            C2Rust_Block_13::S_1477 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1479;
            }
            C2Rust_Block_13::S_1479 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_1485;
            }
            C2Rust_Block_13::S_1485 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1487;
            }
            C2Rust_Block_13::S_1487 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1497;
            }
            C2Rust_Block_13::S_1497 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1499;
            }
            C2Rust_Block_13::S_1499 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1509;
            }
            C2Rust_Block_13::S_1509 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1511;
            }
            C2Rust_Block_13::S_1511 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1521;
            }
            C2Rust_Block_13::S_1521 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1523;
            }
            C2Rust_Block_13::S_1523 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1529;
            }
            C2Rust_Block_13::S_1529 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1531;
            }
            C2Rust_Block_13::S_1531 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1533;
            }
            C2Rust_Block_13::S_1533 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1535;
            }
            C2Rust_Block_13::S_1535 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1537;
            }
            C2Rust_Block_13::S_1537 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1539;
            }
            C2Rust_Block_13::S_1539 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1541;
            }
            C2Rust_Block_13::S_1541 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFA60() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    enum C2Rust_Block_14 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_38,
        S_44,
        S_46,
        S_48,
        S_54,
        S_60,
        S_62,
        S_64,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_103,
        S_105,
        S_107,
        S_113,
        S_119,
        S_121,
        S_123,
        S_129,
        S_135,
        S_137,
        S_139,
        S_141,
        S_143,
        S_145,
        S_147,
        S_153,
        S_155,
        S_157,
        S_167,
        S_169,
        S_171,
        S_181,
        S_183,
        S_185,
        S_191,
        S_201,
        S_203,
        S_205,
        S_215,
        S_217,
        S_219,
        S_229,
        S_231,
        S_233,
        S_239,
        S_245,
        S_251,
        S_253,
        S_255,
        S_265,
        S_267,
        S_269,
        S_279,
        S_281,
        S_283,
        S_289,
        S_295,
        S_297,
        S_299,
        S_305,
        S_315,
        S_317,
        S_319,
        S_329,
        S_331,
        S_333,
        S_339,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_400,
        S_402,
        S_412,
        S_414,
        S_424,
        S_430,
        S_432,
        S_434,
        S_444,
        S_446,
        S_448,
        S_454,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_474,
        S_476,
        S_482,
        S_488,
        S_490,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
    }
    let mut c2rust_current_block_14: C2Rust_Block_14;
    c2rust_current_block_14 = C2Rust_Block_14::S_0;
    loop {
        match c2rust_current_block_14 {
            C2Rust_Block_14::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_2;
            }
            C2Rust_Block_14::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_14 = C2Rust_Block_14::S_4;
            }
            C2Rust_Block_14::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_6;
            }
            C2Rust_Block_14::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_8;
            }
            C2Rust_Block_14::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_18;
            }
            C2Rust_Block_14::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_14 = C2Rust_Block_14::S_24;
            }
            C2Rust_Block_14::S_24 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_26;
            }
            C2Rust_Block_14::S_26 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_28;
            }
            C2Rust_Block_14::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_30;
            }
            C2Rust_Block_14::S_30 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_32;
            }
            C2Rust_Block_14::S_32 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_34;
            }
            C2Rust_Block_14::S_34 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_36;
            }
            C2Rust_Block_14::S_36 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_38;
            }
            C2Rust_Block_14::S_38 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_44;
            }
            C2Rust_Block_14::S_44 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_14 = C2Rust_Block_14::S_46;
            }
            C2Rust_Block_14::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_48;
            }
            C2Rust_Block_14::S_48 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_54;
            }
            C2Rust_Block_14::S_54 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_60;
            }
            C2Rust_Block_14::S_60 => {
                _pv_0 = ebp;
                c2rust_current_block_14 = C2Rust_Block_14::S_62;
            }
            C2Rust_Block_14::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_64;
            }
            C2Rust_Block_14::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_70;
            }
            C2Rust_Block_14::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_72;
            }
            C2Rust_Block_14::S_72 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_74;
            }
            C2Rust_Block_14::S_74 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_76;
            }
            C2Rust_Block_14::S_76 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_78;
            }
            C2Rust_Block_14::S_78 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_80;
            }
            C2Rust_Block_14::S_80 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_82;
            }
            C2Rust_Block_14::S_82 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_84;
            }
            C2Rust_Block_14::S_84 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_86;
            }
            C2Rust_Block_14::S_86 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_88;
            }
            C2Rust_Block_14::S_88 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_90;
            }
            C2Rust_Block_14::S_90 => {
                if _fa <= _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_424;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_103;
                }
            }
            C2Rust_Block_14::S_103 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_14 = C2Rust_Block_14::S_105;
            }
            C2Rust_Block_14::S_105 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_107;
            }
            C2Rust_Block_14::S_107 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_113;
            }
            C2Rust_Block_14::S_113 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_119;
            }
            C2Rust_Block_14::S_119 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_14 = C2Rust_Block_14::S_121;
            }
            C2Rust_Block_14::S_121 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_123;
            }
            C2Rust_Block_14::S_123 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_129;
            }
            C2Rust_Block_14::S_129 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_14 = C2Rust_Block_14::S_135;
            }
            C2Rust_Block_14::S_135 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_137;
            }
            C2Rust_Block_14::S_137 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_139;
            }
            C2Rust_Block_14::S_139 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_141;
            }
            C2Rust_Block_14::S_141 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_14 = C2Rust_Block_14::S_143;
            }
            C2Rust_Block_14::S_143 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_145;
            }
            C2Rust_Block_14::S_145 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_147;
            }
            C2Rust_Block_14::S_147 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_153;
            }
            C2Rust_Block_14::S_153 => {
                _pv_3 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_155;
            }
            C2Rust_Block_14::S_155 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_157;
            }
            C2Rust_Block_14::S_157 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_167;
            }
            C2Rust_Block_14::S_167 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_14 = C2Rust_Block_14::S_169;
            }
            C2Rust_Block_14::S_169 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_171;
            }
            C2Rust_Block_14::S_171 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_181;
            }
            C2Rust_Block_14::S_181 => {
                _pv_5 = 0x1ffaa5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_183;
            }
            C2Rust_Block_14::S_183 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_185;
            }
            C2Rust_Block_14::S_185 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_191;
            }
            C2Rust_Block_14::S_191 => {
                sub_0020BCE0();
                c2rust_current_block_14 = C2Rust_Block_14::S_201;
            }
            C2Rust_Block_14::S_201 => {
                _pv_6 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_203;
            }
            C2Rust_Block_14::S_203 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_205;
            }
            C2Rust_Block_14::S_205 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_215;
            }
            C2Rust_Block_14::S_215 => {
                _pv_7 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_14 = C2Rust_Block_14::S_217;
            }
            C2Rust_Block_14::S_217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_219;
            }
            C2Rust_Block_14::S_219 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_229;
            }
            C2Rust_Block_14::S_229 => {
                _pv_8 = 0x1ffaad as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_231;
            }
            C2Rust_Block_14::S_231 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_233;
            }
            C2Rust_Block_14::S_233 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_239;
            }
            C2Rust_Block_14::S_239 => {
                sub_0020BEB0();
                c2rust_current_block_14 = C2Rust_Block_14::S_245;
            }
            C2Rust_Block_14::S_245 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_251;
            }
            C2Rust_Block_14::S_251 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_253;
            }
            C2Rust_Block_14::S_253 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_255;
            }
            C2Rust_Block_14::S_255 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_265;
            }
            C2Rust_Block_14::S_265 => {
                _pv_10 = 0x1ff120 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_267;
            }
            C2Rust_Block_14::S_267 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_269;
            }
            C2Rust_Block_14::S_269 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_279;
            }
            C2Rust_Block_14::S_279 => {
                _pv_11 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_14 = C2Rust_Block_14::S_281;
            }
            C2Rust_Block_14::S_281 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_283;
            }
            C2Rust_Block_14::S_283 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_289;
            }
            C2Rust_Block_14::S_289 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_295;
            }
            C2Rust_Block_14::S_295 => {
                _pv_12 = 0x1ffac1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_297;
            }
            C2Rust_Block_14::S_297 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_299;
            }
            C2Rust_Block_14::S_299 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_305;
            }
            C2Rust_Block_14::S_305 => {
                sub_001F5F30();
                c2rust_current_block_14 = C2Rust_Block_14::S_315;
            }
            C2Rust_Block_14::S_315 => {
                _pv_13 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_14 = C2Rust_Block_14::S_317;
            }
            C2Rust_Block_14::S_317 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_319;
            }
            C2Rust_Block_14::S_319 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_329;
            }
            C2Rust_Block_14::S_329 => {
                _pv_14 = 0x1ffac7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_331;
            }
            C2Rust_Block_14::S_331 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_333;
            }
            C2Rust_Block_14::S_333 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_339;
            }
            C2Rust_Block_14::S_339 => {
                sub_0020DFA0();
                c2rust_current_block_14 = C2Rust_Block_14::S_345;
            }
            C2Rust_Block_14::S_345 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_347;
            }
            C2Rust_Block_14::S_347 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_349;
            }
            C2Rust_Block_14::S_349 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_351;
            }
            C2Rust_Block_14::S_351 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_353;
            }
            C2Rust_Block_14::S_353 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_355;
            }
            C2Rust_Block_14::S_355 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_357;
            }
            C2Rust_Block_14::S_357 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_359;
            }
            C2Rust_Block_14::S_359 => {
                ebp = ebp.wrapping_add(1);
                c2rust_current_block_14 = C2Rust_Block_14::S_361;
            }
            C2Rust_Block_14::S_361 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_363;
            }
            C2Rust_Block_14::S_363 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_365;
            }
            C2Rust_Block_14::S_365 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_367;
            }
            C2Rust_Block_14::S_367 => {
                _fb = 0x218 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_369;
            }
            C2Rust_Block_14::S_369 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_371;
            }
            C2Rust_Block_14::S_371 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x218 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_373;
            }
            C2Rust_Block_14::S_373 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_375;
            }
            C2Rust_Block_14::S_375 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_377;
            }
            C2Rust_Block_14::S_377 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_379;
            }
            C2Rust_Block_14::S_379 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_381;
            }
            C2Rust_Block_14::S_381 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_383;
            }
            C2Rust_Block_14::S_383 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_385;
            }
            C2Rust_Block_14::S_385 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_387;
            }
            C2Rust_Block_14::S_387 => {
                if _fa < _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_135;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_400;
                }
            }
            C2Rust_Block_14::S_400 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_402;
            }
            C2Rust_Block_14::S_402 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_412;
            }
            C2Rust_Block_14::S_412 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_414;
            }
            C2Rust_Block_14::S_414 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_424;
            }
            C2Rust_Block_14::S_424 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_430;
            }
            C2Rust_Block_14::S_430 => {
                _pv_15 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_14 = C2Rust_Block_14::S_432;
            }
            C2Rust_Block_14::S_432 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_434;
            }
            C2Rust_Block_14::S_434 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_444;
            }
            C2Rust_Block_14::S_444 => {
                _pv_16 = 0x1ffaf1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_446;
            }
            C2Rust_Block_14::S_446 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_448;
            }
            C2Rust_Block_14::S_448 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_454;
            }
            C2Rust_Block_14::S_454 => {
                sub_001FEDC0();
                c2rust_current_block_14 = C2Rust_Block_14::S_460;
            }
            C2Rust_Block_14::S_460 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_462;
            }
            C2Rust_Block_14::S_462 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_464;
            }
            C2Rust_Block_14::S_464 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_466;
            }
            C2Rust_Block_14::S_466 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_468;
            }
            C2Rust_Block_14::S_468 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_474;
            }
            C2Rust_Block_14::S_474 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_476;
            }
            C2Rust_Block_14::S_476 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_482;
            }
            C2Rust_Block_14::S_482 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_488;
            }
            C2Rust_Block_14::S_488 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_490;
            }
            C2Rust_Block_14::S_490 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_496;
            }
            C2Rust_Block_14::S_496 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_498;
            }
            C2Rust_Block_14::S_498 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_500;
            }
            C2Rust_Block_14::S_500 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_502;
            }
            C2Rust_Block_14::S_502 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_504;
            }
            C2Rust_Block_14::S_504 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_506;
            }
            C2Rust_Block_14::S_506 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_508;
            }
            C2Rust_Block_14::S_508 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFB10() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    enum C2Rust_Block_15 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_91,
        S_93,
        S_95,
        S_97,
        S_99,
        S_105,
        S_107,
        S_109,
        S_119,
        S_121,
        S_123,
        S_129,
        S_131,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_196,
        S_198,
        S_200,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_248,
        S_250,
        S_258,
        S_260,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_283,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_345,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_365,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_394,
        S_396,
        S_398,
        S_406,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_428,
        S_430,
        S_432,
        S_442,
        S_444,
        S_446,
        S_452,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_485,
        S_487,
        S_489,
        S_495,
        S_497,
        S_499,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_521,
        S_523,
        S_525,
        S_535,
        S_537,
        S_539,
        S_549,
        S_551,
        S_553,
        S_563,
        S_565,
        S_567,
        S_573,
        S_579,
        S_581,
        S_583,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_624,
        S_626,
        S_628,
        S_630,
        S_632,
        S_634,
        S_636,
        S_638,
        S_640,
        S_642,
        S_644,
        S_646,
        S_648,
        S_650,
        S_652,
        S_667,
        S_673,
        S_675,
        S_677,
        S_679,
        S_685,
        S_687,
        S_689,
        S_691,
        S_693,
        S_695,
        S_704,
        S_706,
        S_708,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_731,
        S_733,
        S_735,
        S_737,
        S_739,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_753,
        S_755,
        S_757,
        S_759,
        S_761,
        S_763,
        S_765,
        S_767,
        S_769,
        S_771,
        S_773,
        S_775,
        S_777,
        S_779,
        S_781,
        S_783,
        S_785,
        S_787,
        S_789,
        S_798,
        S_800,
        S_802,
        S_808,
        S_810,
        S_812,
        S_814,
        S_816,
        S_818,
        S_820,
        S_829,
        S_831,
        S_833,
        S_835,
        S_837,
        S_839,
        S_841,
        S_843,
        S_845,
        S_847,
        S_853,
        S_855,
        S_861,
        S_863,
        S_865,
        S_871,
        S_873,
        S_883,
        S_885,
        S_891,
        S_893,
        S_895,
        S_901,
        S_903,
        S_909,
        S_911,
        S_913,
        S_915,
        S_917,
        S_919,
        S_921,
        S_927,
        S_929,
        S_931,
        S_933,
        S_935,
        S_937,
        S_946,
        S_948,
        S_950,
        S_952,
        S_954,
        S_963,
        S_965,
        S_967,
        S_969,
        S_971,
        S_973,
        S_975,
        S_981,
        S_987,
        S_989,
        S_995,
        S_1001,
        S_1003,
        S_1013,
        S_1015,
        S_1025,
        S_1027,
        S_1033,
        S_1035,
        S_1037,
        S_1039,
        S_1041,
        S_1043,
        S_1045,
        S_1055,
        S_1057,
        S_1063,
        S_1065,
        S_1067,
        S_1073,
        S_1075,
        S_1081,
        S_1083,
        S_1085,
        S_1087,
        S_1089,
        S_1091,
        S_1093,
    }
    let mut c2rust_current_block_15: C2Rust_Block_15;
    c2rust_current_block_15 = C2Rust_Block_15::S_0;
    loop {
        match c2rust_current_block_15 {
            C2Rust_Block_15::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_2;
            }
            C2Rust_Block_15::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_15 = C2Rust_Block_15::S_4;
            }
            C2Rust_Block_15::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_15 = C2Rust_Block_15::S_6;
            }
            C2Rust_Block_15::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_8;
            }
            C2Rust_Block_15::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_18;
            }
            C2Rust_Block_15::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_15 = C2Rust_Block_15::S_24;
            }
            C2Rust_Block_15::S_24 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_26;
            }
            C2Rust_Block_15::S_26 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_28;
            }
            C2Rust_Block_15::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x10 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_30;
            }
            C2Rust_Block_15::S_30 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_32;
            }
            C2Rust_Block_15::S_32 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_38;
            }
            C2Rust_Block_15::S_38 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_15 = C2Rust_Block_15::S_40;
            }
            C2Rust_Block_15::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_42;
            }
            C2Rust_Block_15::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_48;
            }
            C2Rust_Block_15::S_48 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_50;
            }
            C2Rust_Block_15::S_50 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_56;
            }
            C2Rust_Block_15::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_15 = C2Rust_Block_15::S_58;
            }
            C2Rust_Block_15::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_60;
            }
            C2Rust_Block_15::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_66;
            }
            C2Rust_Block_15::S_66 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_68;
            }
            C2Rust_Block_15::S_68 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_70;
            }
            C2Rust_Block_15::S_70 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_72;
            }
            C2Rust_Block_15::S_72 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x12 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_74;
            }
            C2Rust_Block_15::S_74 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_76;
            }
            C2Rust_Block_15::S_76 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_78;
            }
            C2Rust_Block_15::S_78 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_80;
            }
            C2Rust_Block_15::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_82;
            }
            C2Rust_Block_15::S_82 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_1055;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_91;
                }
            }
            C2Rust_Block_15::S_91 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_93;
            }
            C2Rust_Block_15::S_93 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_95;
            }
            C2Rust_Block_15::S_95 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_97;
            }
            C2Rust_Block_15::S_97 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_99;
            }
            C2Rust_Block_15::S_99 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_105;
            }
            C2Rust_Block_15::S_105 => {
                _pv_1 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_15 = C2Rust_Block_15::S_107;
            }
            C2Rust_Block_15::S_107 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_109;
            }
            C2Rust_Block_15::S_109 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_119;
            }
            C2Rust_Block_15::S_119 => {
                _pv_2 = ebp;
                c2rust_current_block_15 = C2Rust_Block_15::S_121;
            }
            C2Rust_Block_15::S_121 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_123;
            }
            C2Rust_Block_15::S_123 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_129;
            }
            C2Rust_Block_15::S_129 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_131;
            }
            C2Rust_Block_15::S_131 => {
                if _fa == _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_208;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_140;
                }
            }
            C2Rust_Block_15::S_140 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_142;
            }
            C2Rust_Block_15::S_142 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_144;
            }
            C2Rust_Block_15::S_144 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_146;
            }
            C2Rust_Block_15::S_146 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_148;
            }
            C2Rust_Block_15::S_148 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_150;
            }
            C2Rust_Block_15::S_150 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_152;
            }
            C2Rust_Block_15::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_154;
            }
            C2Rust_Block_15::S_154 => {
                if _fa == _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_177;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_163;
                }
            }
            C2Rust_Block_15::S_163 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 1 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_165;
            }
            C2Rust_Block_15::S_165 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_167;
            }
            C2Rust_Block_15::S_167 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_169;
            }
            C2Rust_Block_15::S_169 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_171;
            }
            C2Rust_Block_15::S_171 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x90 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_177;
            }
            C2Rust_Block_15::S_177 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_179;
            }
            C2Rust_Block_15::S_179 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_181;
            }
            C2Rust_Block_15::S_181 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_183;
            }
            C2Rust_Block_15::S_183 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_185;
            }
            C2Rust_Block_15::S_185 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_187;
            }
            C2Rust_Block_15::S_187 => {
                if _fa == _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_371;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_196;
                }
            }
            C2Rust_Block_15::S_196 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffb as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_198;
            }
            C2Rust_Block_15::S_198 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_200;
            }
            C2Rust_Block_15::S_200 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_365;
            }
            C2Rust_Block_15::S_208 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_210;
            }
            C2Rust_Block_15::S_210 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_212;
            }
            C2Rust_Block_15::S_212 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_214;
            }
            C2Rust_Block_15::S_214 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_216;
            }
            C2Rust_Block_15::S_216 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x78 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_218;
            }
            C2Rust_Block_15::S_218 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_220;
            }
            C2Rust_Block_15::S_220 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_222;
            }
            C2Rust_Block_15::S_222 => {
                if _fa == _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_258;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_231;
                }
            }
            C2Rust_Block_15::S_231 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x40 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_233;
            }
            C2Rust_Block_15::S_233 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_235;
            }
            C2Rust_Block_15::S_235 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_237;
            }
            C2Rust_Block_15::S_237 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_239;
            }
            C2Rust_Block_15::S_239 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_258;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_248;
                }
            }
            C2Rust_Block_15::S_248 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_250;
            }
            C2Rust_Block_15::S_250 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_266;
            }
            C2Rust_Block_15::S_258 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_260;
            }
            C2Rust_Block_15::S_260 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_266;
            }
            C2Rust_Block_15::S_266 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_268;
            }
            C2Rust_Block_15::S_268 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_270;
            }
            C2Rust_Block_15::S_270 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_272;
            }
            C2Rust_Block_15::S_272 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_274;
            }
            C2Rust_Block_15::S_274 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_289;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_283;
                }
            }
            C2Rust_Block_15::S_283 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_289;
            }
            C2Rust_Block_15::S_289 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_291;
            }
            C2Rust_Block_15::S_291 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_15 = C2Rust_Block_15::S_293;
            }
            C2Rust_Block_15::S_293 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_295;
            }
            C2Rust_Block_15::S_295 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_297;
            }
            C2Rust_Block_15::S_297 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_299;
            }
            C2Rust_Block_15::S_299 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(2 as uint32_t));
                c2rust_current_block_15 = C2Rust_Block_15::S_301;
            }
            C2Rust_Block_15::S_301 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t));
                c2rust_current_block_15 = C2Rust_Block_15::S_303;
            }
            C2Rust_Block_15::S_303 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_305;
            }
            C2Rust_Block_15::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x94 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_307;
            }
            C2Rust_Block_15::S_307 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_309;
            }
            C2Rust_Block_15::S_309 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_311;
            }
            C2Rust_Block_15::S_311 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_313;
            }
            C2Rust_Block_15::S_313 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_315;
            }
            C2Rust_Block_15::S_315 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_317;
            }
            C2Rust_Block_15::S_317 => {
                if _fa == _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_345;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_326;
                }
            }
            C2Rust_Block_15::S_326 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_328;
            }
            C2Rust_Block_15::S_328 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_330;
            }
            C2Rust_Block_15::S_330 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_332;
            }
            C2Rust_Block_15::S_332 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_334;
            }
            C2Rust_Block_15::S_334 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_336;
            }
            C2Rust_Block_15::S_336 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_351;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_345;
                }
            }
            C2Rust_Block_15::S_345 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_351;
            }
            C2Rust_Block_15::S_351 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_353;
            }
            C2Rust_Block_15::S_353 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_355;
            }
            C2Rust_Block_15::S_355 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 4 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_357;
            }
            C2Rust_Block_15::S_357 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_359;
            }
            C2Rust_Block_15::S_359 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_365;
            }
            C2Rust_Block_15::S_365 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_371;
            }
            C2Rust_Block_15::S_371 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_373;
            }
            C2Rust_Block_15::S_373 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_375;
            }
            C2Rust_Block_15::S_375 => {
                ebp = (ebp as int32_t * (*__gamepkg_tls_g_ecx) as int32_t) as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_377;
            }
            C2Rust_Block_15::S_377 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_379;
            }
            C2Rust_Block_15::S_379 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_381;
            }
            C2Rust_Block_15::S_381 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_383;
            }
            C2Rust_Block_15::S_383 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_385;
            }
            C2Rust_Block_15::S_385 => {
                if _fa >= _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_685;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_394;
                }
            }
            C2Rust_Block_15::S_394 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_15 = C2Rust_Block_15::S_396;
            }
            C2Rust_Block_15::S_396 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    * 0x218 as ::core::ffi::c_int as int32_t) as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_398;
            }
            C2Rust_Block_15::S_398 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_412;
            }
            C2Rust_Block_15::S_406 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_412;
            }
            C2Rust_Block_15::S_412 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_414;
            }
            C2Rust_Block_15::S_414 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_416;
            }
            C2Rust_Block_15::S_416 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_418;
            }
            C2Rust_Block_15::S_418 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_15 = C2Rust_Block_15::S_420;
            }
            C2Rust_Block_15::S_420 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_422;
            }
            C2Rust_Block_15::S_422 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_428;
            }
            C2Rust_Block_15::S_428 => {
                _pv_3 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_15 = C2Rust_Block_15::S_430;
            }
            C2Rust_Block_15::S_430 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_432;
            }
            C2Rust_Block_15::S_432 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_442;
            }
            C2Rust_Block_15::S_442 => {
                _pv_4 = 0x1ffc0e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_444;
            }
            C2Rust_Block_15::S_444 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_446;
            }
            C2Rust_Block_15::S_446 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_452;
            }
            C2Rust_Block_15::S_452 => {
                sub_001FABB0();
                c2rust_current_block_15 = C2Rust_Block_15::S_458;
            }
            C2Rust_Block_15::S_458 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_460;
            }
            C2Rust_Block_15::S_460 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_462;
            }
            C2Rust_Block_15::S_462 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_464;
            }
            C2Rust_Block_15::S_464 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_466;
            }
            C2Rust_Block_15::S_466 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_468;
            }
            C2Rust_Block_15::S_468 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_470;
            }
            C2Rust_Block_15::S_470 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_472;
            }
            C2Rust_Block_15::S_472 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_474;
            }
            C2Rust_Block_15::S_474 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_476;
            }
            C2Rust_Block_15::S_476 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_667;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_485;
                }
            }
            C2Rust_Block_15::S_485 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_487;
            }
            C2Rust_Block_15::S_487 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_489;
            }
            C2Rust_Block_15::S_489 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_495;
            }
            C2Rust_Block_15::S_495 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_15 = C2Rust_Block_15::S_497;
            }
            C2Rust_Block_15::S_497 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_499;
            }
            C2Rust_Block_15::S_499 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_505;
            }
            C2Rust_Block_15::S_505 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    * (*__gamepkg_tls_g_ebx) as int32_t) as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_507;
            }
            C2Rust_Block_15::S_507 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_509;
            }
            C2Rust_Block_15::S_509 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_511;
            }
            C2Rust_Block_15::S_511 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_15 = C2Rust_Block_15::S_513;
            }
            C2Rust_Block_15::S_513 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_515;
            }
            C2Rust_Block_15::S_515 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_521;
            }
            C2Rust_Block_15::S_521 => {
                _pv_6 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_15 = C2Rust_Block_15::S_523;
            }
            C2Rust_Block_15::S_523 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_525;
            }
            C2Rust_Block_15::S_525 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_535;
            }
            C2Rust_Block_15::S_535 => {
                _pv_7 = ebp;
                c2rust_current_block_15 = C2Rust_Block_15::S_537;
            }
            C2Rust_Block_15::S_537 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_539;
            }
            C2Rust_Block_15::S_539 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_549;
            }
            C2Rust_Block_15::S_549 => {
                _pv_8 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_15 = C2Rust_Block_15::S_551;
            }
            C2Rust_Block_15::S_551 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_553;
            }
            C2Rust_Block_15::S_553 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_563;
            }
            C2Rust_Block_15::S_563 => {
                _pv_9 = 0x1ffc30 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_565;
            }
            C2Rust_Block_15::S_565 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_567;
            }
            C2Rust_Block_15::S_567 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_573;
            }
            C2Rust_Block_15::S_573 => {
                sub_001FAE90();
                c2rust_current_block_15 = C2Rust_Block_15::S_579;
            }
            C2Rust_Block_15::S_579 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_581;
            }
            C2Rust_Block_15::S_581 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_583;
            }
            C2Rust_Block_15::S_583 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_585;
            }
            C2Rust_Block_15::S_585 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_587;
            }
            C2Rust_Block_15::S_587 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_589;
            }
            C2Rust_Block_15::S_589 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_591;
            }
            C2Rust_Block_15::S_591 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_593;
            }
            C2Rust_Block_15::S_593 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_595;
            }
            C2Rust_Block_15::S_595 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_597;
            }
            C2Rust_Block_15::S_597 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_599;
            }
            C2Rust_Block_15::S_599 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_601;
            }
            C2Rust_Block_15::S_601 => {
                if _fa >= _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_673;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_610;
                }
            }
            C2Rust_Block_15::S_610 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_612;
            }
            C2Rust_Block_15::S_612 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_15 = C2Rust_Block_15::S_614;
            }
            C2Rust_Block_15::S_614 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_616;
            }
            C2Rust_Block_15::S_616 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_618;
            }
            C2Rust_Block_15::S_618 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_620;
            }
            C2Rust_Block_15::S_620 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_622;
            }
            C2Rust_Block_15::S_622 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_624;
            }
            C2Rust_Block_15::S_624 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                c2rust_current_block_15 = C2Rust_Block_15::S_626;
            }
            C2Rust_Block_15::S_626 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_628;
            }
            C2Rust_Block_15::S_628 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_630;
            }
            C2Rust_Block_15::S_630 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_632;
            }
            C2Rust_Block_15::S_632 => {
                _fb = 0x218 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_634;
            }
            C2Rust_Block_15::S_634 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_636;
            }
            C2Rust_Block_15::S_636 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x218 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_638;
            }
            C2Rust_Block_15::S_638 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_640;
            }
            C2Rust_Block_15::S_640 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_642;
            }
            C2Rust_Block_15::S_642 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_644;
            }
            C2Rust_Block_15::S_644 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_646;
            }
            C2Rust_Block_15::S_646 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_648;
            }
            C2Rust_Block_15::S_648 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_650;
            }
            C2Rust_Block_15::S_650 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_652;
            }
            C2Rust_Block_15::S_652 => {
                if _fa < _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_406;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_673;
                }
            }
            C2Rust_Block_15::S_667 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_673;
            }
            C2Rust_Block_15::S_673 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_675;
            }
            C2Rust_Block_15::S_675 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_677;
            }
            C2Rust_Block_15::S_677 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_679;
            }
            C2Rust_Block_15::S_679 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_685;
            }
            C2Rust_Block_15::S_685 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_687;
            }
            C2Rust_Block_15::S_687 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_689;
            }
            C2Rust_Block_15::S_689 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_691;
            }
            C2Rust_Block_15::S_691 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_693;
            }
            C2Rust_Block_15::S_693 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_695;
            }
            C2Rust_Block_15::S_695 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_714;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_704;
                }
            }
            C2Rust_Block_15::S_704 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_706;
            }
            C2Rust_Block_15::S_706 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_708;
            }
            C2Rust_Block_15::S_708 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_714;
            }
            C2Rust_Block_15::S_714 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_716;
            }
            C2Rust_Block_15::S_716 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_718;
            }
            C2Rust_Block_15::S_718 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_720;
            }
            C2Rust_Block_15::S_720 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_722;
            }
            C2Rust_Block_15::S_722 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_981;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_731;
                }
            }
            C2Rust_Block_15::S_731 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_733;
            }
            C2Rust_Block_15::S_733 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_735;
            }
            C2Rust_Block_15::S_735 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_737;
            }
            C2Rust_Block_15::S_737 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_739;
            }
            C2Rust_Block_15::S_739 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(2 as uint32_t));
                c2rust_current_block_15 = C2Rust_Block_15::S_741;
            }
            C2Rust_Block_15::S_741 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_15 = C2Rust_Block_15::S_743;
            }
            C2Rust_Block_15::S_743 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_745;
            }
            C2Rust_Block_15::S_745 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_747;
            }
            C2Rust_Block_15::S_747 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_749;
            }
            C2Rust_Block_15::S_749 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_751;
            }
            C2Rust_Block_15::S_751 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_15 = C2Rust_Block_15::S_753;
            }
            C2Rust_Block_15::S_753 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_755;
            }
            C2Rust_Block_15::S_755 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_757;
            }
            C2Rust_Block_15::S_757 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_759;
            }
            C2Rust_Block_15::S_759 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_761;
            }
            C2Rust_Block_15::S_761 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_763;
            }
            C2Rust_Block_15::S_763 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_765;
            }
            C2Rust_Block_15::S_765 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_767;
            }
            C2Rust_Block_15::S_767 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_769;
            }
            C2Rust_Block_15::S_769 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_771;
            }
            C2Rust_Block_15::S_771 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_773;
            }
            C2Rust_Block_15::S_773 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_15 = C2Rust_Block_15::S_775;
            }
            C2Rust_Block_15::S_775 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_777;
            }
            C2Rust_Block_15::S_777 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_779;
            }
            C2Rust_Block_15::S_779 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_781;
            }
            C2Rust_Block_15::S_781 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_783;
            }
            C2Rust_Block_15::S_783 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_785;
            }
            C2Rust_Block_15::S_785 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_787;
            }
            C2Rust_Block_15::S_787 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_789;
            }
            C2Rust_Block_15::S_789 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_808;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_798;
                }
            }
            C2Rust_Block_15::S_798 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_800;
            }
            C2Rust_Block_15::S_800 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_802;
            }
            C2Rust_Block_15::S_802 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_808;
            }
            C2Rust_Block_15::S_808 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_810;
            }
            C2Rust_Block_15::S_810 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_812;
            }
            C2Rust_Block_15::S_812 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_814;
            }
            C2Rust_Block_15::S_814 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_816;
            }
            C2Rust_Block_15::S_816 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_818;
            }
            C2Rust_Block_15::S_818 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_820;
            }
            C2Rust_Block_15::S_820 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_927;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_829;
                }
            }
            C2Rust_Block_15::S_829 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_831;
            }
            C2Rust_Block_15::S_831 => {
                (*__gamepkg_tls_g_ecx) = 1 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_833;
            }
            C2Rust_Block_15::S_833 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add((*__gamepkg_tls_g_edx))
                            .wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_835;
            }
            C2Rust_Block_15::S_835 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_837;
            }
            C2Rust_Block_15::S_837 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_839;
            }
            C2Rust_Block_15::S_839 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_841;
            }
            C2Rust_Block_15::S_841 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_843;
            }
            C2Rust_Block_15::S_843 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_15 = C2Rust_Block_15::S_845;
            }
            C2Rust_Block_15::S_845 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_847;
            }
            C2Rust_Block_15::S_847 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_853;
            }
            C2Rust_Block_15::S_853 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_855;
            }
            C2Rust_Block_15::S_855 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_861;
            }
            C2Rust_Block_15::S_861 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_863;
            }
            C2Rust_Block_15::S_863 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_865;
            }
            C2Rust_Block_15::S_865 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_871;
            }
            C2Rust_Block_15::S_871 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_873;
            }
            C2Rust_Block_15::S_873 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_883;
            }
            C2Rust_Block_15::S_883 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_885;
            }
            C2Rust_Block_15::S_885 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_891;
            }
            C2Rust_Block_15::S_891 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_893;
            }
            C2Rust_Block_15::S_893 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_895;
            }
            C2Rust_Block_15::S_895 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_15 = C2Rust_Block_15::S_901;
            }
            C2Rust_Block_15::S_901 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_903;
            }
            C2Rust_Block_15::S_903 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_909;
            }
            C2Rust_Block_15::S_909 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_911;
            }
            C2Rust_Block_15::S_911 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_913;
            }
            C2Rust_Block_15::S_913 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_915;
            }
            C2Rust_Block_15::S_915 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_917;
            }
            C2Rust_Block_15::S_917 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_919;
            }
            C2Rust_Block_15::S_919 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_921;
            }
            C2Rust_Block_15::S_921 => return,
            C2Rust_Block_15::S_927 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_929;
            }
            C2Rust_Block_15::S_929 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_931;
            }
            C2Rust_Block_15::S_931 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_933;
            }
            C2Rust_Block_15::S_933 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_935;
            }
            C2Rust_Block_15::S_935 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_937;
            }
            C2Rust_Block_15::S_937 => {
                if _fa == _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_981;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_946;
                }
            }
            C2Rust_Block_15::S_946 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x40 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_948;
            }
            C2Rust_Block_15::S_948 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_950;
            }
            C2Rust_Block_15::S_950 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_952;
            }
            C2Rust_Block_15::S_952 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_954;
            }
            C2Rust_Block_15::S_954 => {
                if _fa != _fb {
                    c2rust_current_block_15 = C2Rust_Block_15::S_981;
                } else {
                    c2rust_current_block_15 = C2Rust_Block_15::S_963;
                }
            }
            C2Rust_Block_15::S_963 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_965;
            }
            C2Rust_Block_15::S_965 => {
                (*__gamepkg_tls_g_ecx) = 1 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_967;
            }
            C2Rust_Block_15::S_967 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add((*__gamepkg_tls_g_edx))
                            .wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_969;
            }
            C2Rust_Block_15::S_969 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0x40 as uint32_t,
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_971;
            }
            C2Rust_Block_15::S_971 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_973;
            }
            C2Rust_Block_15::S_973 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_975;
            }
            C2Rust_Block_15::S_975 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_981;
            }
            C2Rust_Block_15::S_981 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_987;
            }
            C2Rust_Block_15::S_987 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_989;
            }
            C2Rust_Block_15::S_989 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_995;
            }
            C2Rust_Block_15::S_995 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_1001;
            }
            C2Rust_Block_15::S_1001 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_1003;
            }
            C2Rust_Block_15::S_1003 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1013;
            }
            C2Rust_Block_15::S_1013 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_1015;
            }
            C2Rust_Block_15::S_1015 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1025;
            }
            C2Rust_Block_15::S_1025 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_1027;
            }
            C2Rust_Block_15::S_1027 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1033;
            }
            C2Rust_Block_15::S_1033 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1035;
            }
            C2Rust_Block_15::S_1035 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1037;
            }
            C2Rust_Block_15::S_1037 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1039;
            }
            C2Rust_Block_15::S_1039 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1041;
            }
            C2Rust_Block_15::S_1041 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1043;
            }
            C2Rust_Block_15::S_1043 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1045;
            }
            C2Rust_Block_15::S_1045 => return,
            C2Rust_Block_15::S_1055 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_1057;
            }
            C2Rust_Block_15::S_1057 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1063;
            }
            C2Rust_Block_15::S_1063 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1065;
            }
            C2Rust_Block_15::S_1065 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1067;
            }
            C2Rust_Block_15::S_1067 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1073;
            }
            C2Rust_Block_15::S_1073 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_15 = C2Rust_Block_15::S_1075;
            }
            C2Rust_Block_15::S_1075 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1081;
            }
            C2Rust_Block_15::S_1081 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1083;
            }
            C2Rust_Block_15::S_1083 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1085;
            }
            C2Rust_Block_15::S_1085 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1087;
            }
            C2Rust_Block_15::S_1087 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1089;
            }
            C2Rust_Block_15::S_1089 => {
                _fas = _fa as int32_t;
                c2rust_current_block_15 = C2Rust_Block_15::S_1091;
            }
            C2Rust_Block_15::S_1091 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_15 = C2Rust_Block_15::S_1093;
            }
            C2Rust_Block_15::S_1093 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFD40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b169c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        )
            != ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b169c as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        < ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b169c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double
    {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        > ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b169c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double
    {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t as uint32_t;
    _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as ::core::ffi::c_int & 5 as ::core::ffi::c_int) as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_57: {
        if recomp_parity8(_fa.wrapping_sub(_fb)) == 0 {
            break 's_57;
        }
        let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
        let mut _fp_value_1: ::core::ffi::c_double = 0.30102999566398119521f64;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
        let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = _t;
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
            * log2((*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]);
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
            as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
        {
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b1740 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double
        } else {
            recomp_fp_round24(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1740 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double,
            )
        };
        let mut _pv: uint32_t = 0x1ffd6c as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        sub_00244DF0();
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | (if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                > if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint8_t as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_ecx);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0xffffd8f0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFD80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    's_37: {
        if _fa != 0 as uint32_t {
            break 's_37;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    's_68: {
        if _fa != 0 as uint32_t {
            break 's_68;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffff0000 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(1 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t as uint16_t as uint32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffff00ff as uint32_t
            | (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t) << 8 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(2 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_add(-2 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(2 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_193: {
        if _fa != 0 as uint32_t {
            break 's_193;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) << 0x10 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xff00 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff00ff as uint32_t
            | (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x16 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t) << 8 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) << 8 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(3 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edi),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFE00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value_0: ::core::ffi::c_double = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize],
        )
    };
    let mut _fp_value_1: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top) + 2 as ::core::ffi::c_int
        & 7 as ::core::ffi::c_int) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    let mut _fp_value_2: ::core::ffi::c_double = _t_0;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                    + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize],
        )
    };
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
                + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        )
    };
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _fp_value_3: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
                + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        )
    };
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _t_1: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value_4: ::core::ffi::c_double = _t_1;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_4;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            as ::core::ffi::c_float,
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _fp_value_5: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x3b16e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_5;
    let mut _t_2: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t_2;
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
            != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t as uint32_t;
    _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as ::core::ffi::c_int & 0x44 as ::core::ffi::c_int) as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_304: {
        if recomp_parity8(_fa.wrapping_sub(_fb)) == 0 {
            break 's_304;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 0x17 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = 0x7f as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(0x7f as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0x7fffff as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
            as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        's_258: {
            if _fa == _fb {
                break 's_258;
            }
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 0x800000 as uint32_t;
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(2 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            int16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                int16_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_mul(2 as uint32_t)
                    .wrapping_add(0x3c2040 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as int32_t as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as int16_t
                as int32_t >> (1 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                as uint32_t as uint16_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
            & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t)
            as uint16_t as int16_t as int32_t as uint32_t;
        _fb = 0x7f as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x7f as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) << 0x10 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << 0x17 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFE80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    enum C2Rust_Block_19 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_26,
        S_28,
        S_30,
        S_40,
        S_42,
        S_44,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_85,
        S_87,
        S_89,
        S_91,
        S_93,
        S_95,
        S_97,
        S_99,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_141,
        S_143,
        S_145,
        S_147,
        S_149,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_225,
        S_227,
        S_229,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_368,
        S_370,
        S_380,
        S_382,
        S_388,
        S_390,
    }
    let mut c2rust_current_block_19: C2Rust_Block_19;
    c2rust_current_block_19 = C2Rust_Block_19::S_0;
    loop {
        match c2rust_current_block_19 {
            C2Rust_Block_19::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_2;
            }
            C2Rust_Block_19::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_4;
            }
            C2Rust_Block_19::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_18;
            }
            C2Rust_Block_19::S_18 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_20;
            }
            C2Rust_Block_19::S_20 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_26;
            }
            C2Rust_Block_19::S_26 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_19 = C2Rust_Block_19::S_28;
            }
            C2Rust_Block_19::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_30;
            }
            C2Rust_Block_19::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_40;
            }
            C2Rust_Block_19::S_40 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_19 = C2Rust_Block_19::S_42;
            }
            C2Rust_Block_19::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_44;
            }
            C2Rust_Block_19::S_44 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_50;
            }
            C2Rust_Block_19::S_50 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_52;
            }
            C2Rust_Block_19::S_52 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_54;
            }
            C2Rust_Block_19::S_54 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_56;
            }
            C2Rust_Block_19::S_56 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_58;
            }
            C2Rust_Block_19::S_58 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_60;
            }
            C2Rust_Block_19::S_60 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_62;
            }
            C2Rust_Block_19::S_62 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_64;
            }
            C2Rust_Block_19::S_64 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_66;
            }
            C2Rust_Block_19::S_66 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_68;
            }
            C2Rust_Block_19::S_68 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xfffffffe as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_70;
            }
            C2Rust_Block_19::S_70 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_72;
            }
            C2Rust_Block_19::S_72 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_74;
            }
            C2Rust_Block_19::S_74 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_76;
            }
            C2Rust_Block_19::S_76 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_225;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_85;
                }
            }
            C2Rust_Block_19::S_85 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    << 1 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_87;
            }
            C2Rust_Block_19::S_87 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_89;
            }
            C2Rust_Block_19::S_89 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_91;
            }
            C2Rust_Block_19::S_91 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_93;
            }
            C2Rust_Block_19::S_93 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_95;
            }
            C2Rust_Block_19::S_95 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_97;
            }
            C2Rust_Block_19::S_97 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_99;
            }
            C2Rust_Block_19::S_99 => {
                if _fa.wrapping_sub(_fb) >> 31 as ::core::ffi::c_int == 0 as uint32_t {
                    c2rust_current_block_19 = C2Rust_Block_19::S_124;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_108;
                }
            }
            C2Rust_Block_19::S_108 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 1 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_110;
            }
            C2Rust_Block_19::S_110 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_112;
            }
            C2Rust_Block_19::S_112 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_114;
            }
            C2Rust_Block_19::S_114 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7fffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_116;
            }
            C2Rust_Block_19::S_116 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_118;
            }
            C2Rust_Block_19::S_118 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_124;
            }
            C2Rust_Block_19::S_124 => {
                _fa = (((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_126;
            }
            C2Rust_Block_19::S_126 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_128;
            }
            C2Rust_Block_19::S_128 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_130;
            }
            C2Rust_Block_19::S_130 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_132;
            }
            C2Rust_Block_19::S_132 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_196;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_141;
                }
            }
            C2Rust_Block_19::S_141 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_143;
            }
            C2Rust_Block_19::S_143 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_145;
            }
            C2Rust_Block_19::S_145 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_19 = C2Rust_Block_19::S_147;
            }
            C2Rust_Block_19::S_147 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_149;
            }
            C2Rust_Block_19::S_149 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_151;
            }
            C2Rust_Block_19::S_151 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_153;
            }
            C2Rust_Block_19::S_153 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_155;
            }
            C2Rust_Block_19::S_155 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_19 = C2Rust_Block_19::S_157;
            }
            C2Rust_Block_19::S_157 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_159;
            }
            C2Rust_Block_19::S_159 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_161;
            }
            C2Rust_Block_19::S_161 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_163;
            }
            C2Rust_Block_19::S_163 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_165;
            }
            C2Rust_Block_19::S_165 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_167;
            }
            C2Rust_Block_19::S_167 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_169;
            }
            C2Rust_Block_19::S_169 => {
                if _fa.wrapping_sub(_fb) >> 31 as ::core::ffi::c_int == 0 as uint32_t {
                    c2rust_current_block_19 = C2Rust_Block_19::S_196;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_178;
                }
            }
            C2Rust_Block_19::S_178 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_19 = C2Rust_Block_19::S_180;
            }
            C2Rust_Block_19::S_180 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_182;
            }
            C2Rust_Block_19::S_182 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_184;
            }
            C2Rust_Block_19::S_184 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_186;
            }
            C2Rust_Block_19::S_186 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) & 0x7fffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_188;
            }
            C2Rust_Block_19::S_188 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_190;
            }
            C2Rust_Block_19::S_190 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_196;
            }
            C2Rust_Block_19::S_196 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    >> 1 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_198;
            }
            C2Rust_Block_19::S_198 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_200;
            }
            C2Rust_Block_19::S_200 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_202;
            }
            C2Rust_Block_19::S_202 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 1 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_204;
            }
            C2Rust_Block_19::S_204 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_206;
            }
            C2Rust_Block_19::S_206 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_208;
            }
            C2Rust_Block_19::S_208 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xfffffffe as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_210;
            }
            C2Rust_Block_19::S_210 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_212;
            }
            C2Rust_Block_19::S_212 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_214;
            }
            C2Rust_Block_19::S_214 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_216;
            }
            C2Rust_Block_19::S_216 => {
                if _fa != _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_85;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_225;
                }
            }
            C2Rust_Block_19::S_225 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    << 1 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_227;
            }
            C2Rust_Block_19::S_227 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_229;
            }
            C2Rust_Block_19::S_229 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_231;
            }
            C2Rust_Block_19::S_231 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_233;
            }
            C2Rust_Block_19::S_233 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_235;
            }
            C2Rust_Block_19::S_235 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_237;
            }
            C2Rust_Block_19::S_237 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_239;
            }
            C2Rust_Block_19::S_239 => {
                if _fa.wrapping_sub(_fb) >> 31 as ::core::ffi::c_int == 0 as uint32_t {
                    c2rust_current_block_19 = C2Rust_Block_19::S_264;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_248;
                }
            }
            C2Rust_Block_19::S_248 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 1 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_250;
            }
            C2Rust_Block_19::S_250 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_252;
            }
            C2Rust_Block_19::S_252 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_254;
            }
            C2Rust_Block_19::S_254 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7fffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_256;
            }
            C2Rust_Block_19::S_256 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_258;
            }
            C2Rust_Block_19::S_258 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_264;
            }
            C2Rust_Block_19::S_264 => {
                _fa = (((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_266;
            }
            C2Rust_Block_19::S_266 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_268;
            }
            C2Rust_Block_19::S_268 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_270;
            }
            C2Rust_Block_19::S_270 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_272;
            }
            C2Rust_Block_19::S_272 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_336;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_281;
                }
            }
            C2Rust_Block_19::S_281 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_283;
            }
            C2Rust_Block_19::S_283 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_285;
            }
            C2Rust_Block_19::S_285 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_19 = C2Rust_Block_19::S_287;
            }
            C2Rust_Block_19::S_287 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_289;
            }
            C2Rust_Block_19::S_289 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_291;
            }
            C2Rust_Block_19::S_291 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_293;
            }
            C2Rust_Block_19::S_293 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_295;
            }
            C2Rust_Block_19::S_295 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_19 = C2Rust_Block_19::S_297;
            }
            C2Rust_Block_19::S_297 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_299;
            }
            C2Rust_Block_19::S_299 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_301;
            }
            C2Rust_Block_19::S_301 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_303;
            }
            C2Rust_Block_19::S_303 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_305;
            }
            C2Rust_Block_19::S_305 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_307;
            }
            C2Rust_Block_19::S_307 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_309;
            }
            C2Rust_Block_19::S_309 => {
                if _fa.wrapping_sub(_fb) >> 31 as ::core::ffi::c_int == 0 as uint32_t {
                    c2rust_current_block_19 = C2Rust_Block_19::S_336;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_318;
                }
            }
            C2Rust_Block_19::S_318 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_19 = C2Rust_Block_19::S_320;
            }
            C2Rust_Block_19::S_320 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_322;
            }
            C2Rust_Block_19::S_322 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_324;
            }
            C2Rust_Block_19::S_324 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_326;
            }
            C2Rust_Block_19::S_326 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) & 0x7fffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_328;
            }
            C2Rust_Block_19::S_328 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_330;
            }
            C2Rust_Block_19::S_330 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_336;
            }
            C2Rust_Block_19::S_336 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_338;
            }
            C2Rust_Block_19::S_338 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_340;
            }
            C2Rust_Block_19::S_340 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_19 = C2Rust_Block_19::S_342;
            }
            C2Rust_Block_19::S_342 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    << 0x1f as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_344;
            }
            C2Rust_Block_19::S_344 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_346;
            }
            C2Rust_Block_19::S_346 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_348;
            }
            C2Rust_Block_19::S_348 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | (*__gamepkg_tls_g_esi);
                c2rust_current_block_19 = C2Rust_Block_19::S_350;
            }
            C2Rust_Block_19::S_350 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_352;
            }
            C2Rust_Block_19::S_352 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_354;
            }
            C2Rust_Block_19::S_354 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 1 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_356;
            }
            C2Rust_Block_19::S_356 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_358;
            }
            C2Rust_Block_19::S_358 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_360;
            }
            C2Rust_Block_19::S_360 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_362;
            }
            C2Rust_Block_19::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_368;
            }
            C2Rust_Block_19::S_368 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_370;
            }
            C2Rust_Block_19::S_370 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_380;
            }
            C2Rust_Block_19::S_380 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_382;
            }
            C2Rust_Block_19::S_382 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_388;
            }
            C2Rust_Block_19::S_388 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_390;
            }
            C2Rust_Block_19::S_390 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFF00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | 0 as ::core::ffi::c_int as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    loop {
        (*__gamepkg_tls_g_esi) = 1 as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edx) & (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fb = (_fa == 0x80 as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa >= _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFF20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41c5d0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fff2a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD5A0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_79: {
        if _fa == _fb {
            break 's_79;
        }
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x36e0b0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x41c5d0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fff43 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001F64C0();
        let mut _pv_5: uint32_t = 6 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x3c26a8 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3c2640 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x41c5d0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x1fff5b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001FD480();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0x41c5d0 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFF70() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41c5d0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fff7a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD620();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFF80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41c5f8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fff8a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD5A0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_79: {
        if _fa == _fb {
            break 's_79;
        }
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x36e170 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x41c5f8 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fffa3 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001F64C0();
        let mut _pv_5: uint32_t = 9 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x3c27c0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3c2720 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x41c5f8 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x1fffbb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001FD480();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0x41c5f8 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFFD0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41c5f8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fffda as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD620();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FFFE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_1: uint32_t = 0x1ffffc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001FE500();
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x200002 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001FEDC0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200010() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0020001F() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200030() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200070() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_129: {
        if _fa == _fb {
            break 's_129;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        loop {
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx)
                .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_sub(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002000B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(-32 as ::core::ffi::c_int as uint32_t)
                as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
    let mut _pv_3: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x2000cf as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001FE270();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_273: {
        if _fa == _fb {
            break 's_273;
        }
        loop {
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_194: {
                if _fa != _fb {
                    break 's_194;
                }
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi)
                        .wrapping_add(-32 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
            let mut _pv_6: uint32_t = ebp;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = 0x2000e9 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            sub_001FE270();
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_273;
            }
        }
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200100() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
        .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_167: {
        's_81: {
            if _fa == _fb {
                break 's_167;
            }
        }
        's_81: loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_153: {
                if _fa == _fb {
                    break 's_153;
                }
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
                if _fa != _fb {
                    continue 's_81;
                }
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_167;
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200130() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_231: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            > if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_231;
        }
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_231;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
            .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
        's_165: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                <= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_165;
            }
            loop {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_134: {
                    if _fa != _fb {
                        break 's_134;
                    }
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    return;
                }
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_165;
                }
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200170() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41c620 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x20017a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD5A0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_79: {
        if _fa == _fb {
            break 's_79;
        }
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x36e290 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x41c620 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x200193 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001F64C0();
        let mut _pv_5: uint32_t = 0xa as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x3c28f0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 6 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3c2878 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x41c620 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x2001ab as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001FD480();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0x41c620 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002001C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41c620 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2001ca as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD620();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002001D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x2001e0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_002022C0();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_126: {
        if _fa != _fb {
            break 's_126;
        }
        (*__gamepkg_tls_g_edx) = 1 as uint32_t;
        let mut _old: uint32_t = {
            let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let __gamepkg_atomic_value = (*__gamepkg_tls_g_edx);
            ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
                .fetch_add(
                    __gamepkg_atomic_value,
                    ::core::sync::atomic::Ordering::SeqCst,
                )
        };
        (*__gamepkg_tls_g_edx) = _old;
    }
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _old_0: uint32_t = {
        let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let __gamepkg_atomic_value = (*__gamepkg_tls_g_ecx);
        ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
            .fetch_add(__gamepkg_atomic_value, ::core::sync::atomic::Ordering::SeqCst)
    };
    (*__gamepkg_tls_g_ecx) = _old_0;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200200() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    enum C2Rust_Block_36 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_54,
        S_56,
        S_58,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_95,
        S_97,
        S_99,
        S_105,
        S_111,
        S_113,
        S_115,
        S_125,
        S_127,
        S_129,
        S_139,
        S_141,
        S_147,
        S_149,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_170,
        S_176,
        S_178,
        S_180,
        S_190,
        S_192,
        S_194,
        S_204,
        S_206,
        S_208,
        S_214,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_264,
        S_267,
        S_273,
        S_275,
        S_277,
        S_287,
        S_289,
        S_291,
        S_298,
        S_304,
        S_306,
        S_308,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_329,
        S_331,
        S_333,
        S_341,
        S_343,
        S_345,
        S_349,
        S_351,
        S_355,
        S_361,
        S_368,
        S_370,
        S_372,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_429,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_481,
        S_487,
        S_489,
        S_499,
        S_501,
        S_511,
        S_513,
        S_527,
        S_529,
        S_539,
        S_541,
        S_547,
        S_549,
    }
    let mut c2rust_current_block_36: C2Rust_Block_36;
    c2rust_current_block_36 = C2Rust_Block_36::S_0;
    loop {
        match c2rust_current_block_36 {
            C2Rust_Block_36::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_2;
            }
            C2Rust_Block_36::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_36 = C2Rust_Block_36::S_4;
            }
            C2Rust_Block_36::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_6;
            }
            C2Rust_Block_36::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_8;
            }
            C2Rust_Block_36::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_18;
            }
            C2Rust_Block_36::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_36 = C2Rust_Block_36::S_28;
            }
            C2Rust_Block_36::S_28 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_36 = C2Rust_Block_36::S_30;
            }
            C2Rust_Block_36::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_32;
            }
            C2Rust_Block_36::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_38;
            }
            C2Rust_Block_36::S_38 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_40;
            }
            C2Rust_Block_36::S_40 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_42;
            }
            C2Rust_Block_36::S_42 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_44;
            }
            C2Rust_Block_36::S_44 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_46;
            }
            C2Rust_Block_36::S_46 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_48;
            }
            C2Rust_Block_36::S_48 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_54;
            }
            C2Rust_Block_36::S_54 => {
                _pv_0 = ebp;
                c2rust_current_block_36 = C2Rust_Block_36::S_56;
            }
            C2Rust_Block_36::S_56 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_58;
            }
            C2Rust_Block_36::S_58 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_64;
            }
            C2Rust_Block_36::S_64 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_66;
            }
            C2Rust_Block_36::S_66 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_68;
            }
            C2Rust_Block_36::S_68 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_70;
            }
            C2Rust_Block_36::S_70 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_72;
            }
            C2Rust_Block_36::S_72 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_74;
            }
            C2Rust_Block_36::S_74 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_76;
            }
            C2Rust_Block_36::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_78;
            }
            C2Rust_Block_36::S_78 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_80;
            }
            C2Rust_Block_36::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_82;
            }
            C2Rust_Block_36::S_82 => {
                if _fa == _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_527;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_95;
                }
            }
            C2Rust_Block_36::S_95 => {
                _pv_1 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_36 = C2Rust_Block_36::S_97;
            }
            C2Rust_Block_36::S_97 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_99;
            }
            C2Rust_Block_36::S_99 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_105;
            }
            C2Rust_Block_36::S_105 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_111;
            }
            C2Rust_Block_36::S_111 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_36 = C2Rust_Block_36::S_113;
            }
            C2Rust_Block_36::S_113 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_115;
            }
            C2Rust_Block_36::S_115 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_125;
            }
            C2Rust_Block_36::S_125 => {
                _pv_3 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_36 = C2Rust_Block_36::S_127;
            }
            C2Rust_Block_36::S_127 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_129;
            }
            C2Rust_Block_36::S_129 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_139;
            }
            C2Rust_Block_36::S_139 => {
                (*__gamepkg_tls_g_esi) = ebp
                    .wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_141;
            }
            C2Rust_Block_36::S_141 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t)
                            as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_147;
            }
            C2Rust_Block_36::S_147 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_149;
            }
            C2Rust_Block_36::S_149 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_151;
            }
            C2Rust_Block_36::S_151 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_153;
            }
            C2Rust_Block_36::S_153 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_155;
            }
            C2Rust_Block_36::S_155 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_157;
            }
            C2Rust_Block_36::S_157 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_159;
            }
            C2Rust_Block_36::S_159 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_161;
            }
            C2Rust_Block_36::S_161 => {
                if _fa == _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_429;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_170;
                }
            }
            C2Rust_Block_36::S_170 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_176;
            }
            C2Rust_Block_36::S_176 => {
                _pv_4 = 0x36e8a8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_178;
            }
            C2Rust_Block_36::S_178 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_180;
            }
            C2Rust_Block_36::S_180 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_190;
            }
            C2Rust_Block_36::S_190 => {
                _pv_5 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_36 = C2Rust_Block_36::S_192;
            }
            C2Rust_Block_36::S_192 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_194;
            }
            C2Rust_Block_36::S_194 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_204;
            }
            C2Rust_Block_36::S_204 => {
                _pv_6 = 0x200241 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_206;
            }
            C2Rust_Block_36::S_206 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_208;
            }
            C2Rust_Block_36::S_208 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_214;
            }
            C2Rust_Block_36::S_214 => {
                sub_001FE270();
                c2rust_current_block_36 = C2Rust_Block_36::S_220;
            }
            C2Rust_Block_36::S_220 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_222;
            }
            C2Rust_Block_36::S_222 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_224;
            }
            C2Rust_Block_36::S_224 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_226;
            }
            C2Rust_Block_36::S_226 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_228;
            }
            C2Rust_Block_36::S_228 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_230;
            }
            C2Rust_Block_36::S_230 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_232;
            }
            C2Rust_Block_36::S_232 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_234;
            }
            C2Rust_Block_36::S_234 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_236;
            }
            C2Rust_Block_36::S_236 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_238;
            }
            C2Rust_Block_36::S_238 => {
                if _fa == _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_429;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_247;
                }
            }
            C2Rust_Block_36::S_247 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_249;
            }
            C2Rust_Block_36::S_249 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_251;
            }
            C2Rust_Block_36::S_251 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_253;
            }
            C2Rust_Block_36::S_253 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_255;
            }
            C2Rust_Block_36::S_255 => {
                if _fa == _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_404;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_264;
                }
            }
            C2Rust_Block_36::S_264 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_267;
            }
            C2Rust_Block_36::S_267 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_36 = C2Rust_Block_36::S_273;
            }
            C2Rust_Block_36::S_273 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_36 = C2Rust_Block_36::S_275;
            }
            C2Rust_Block_36::S_275 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_277;
            }
            C2Rust_Block_36::S_277 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_287;
            }
            C2Rust_Block_36::S_287 => {
                _pv_8 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_36 = C2Rust_Block_36::S_289;
            }
            C2Rust_Block_36::S_289 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_291;
            }
            C2Rust_Block_36::S_291 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_298;
            }
            C2Rust_Block_36::S_298 => {
                _icall_target = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_36 = C2Rust_Block_36::S_304;
            }
            C2Rust_Block_36::S_304 => {
                _pv_9 = 0x200254 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_306;
            }
            C2Rust_Block_36::S_306 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_308;
            }
            C2Rust_Block_36::S_308 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_318;
            }
            C2Rust_Block_36::S_318 => {
                _va = _icall_target;
                c2rust_current_block_36 = C2Rust_Block_36::S_320;
            }
            C2Rust_Block_36::S_320 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_322;
            }
            C2Rust_Block_36::S_322 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_324;
            }
            C2Rust_Block_36::S_324 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_326;
            }
            C2Rust_Block_36::S_326 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_36 = C2Rust_Block_36::S_329;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_341;
                }
            }
            C2Rust_Block_36::S_329 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_36 = C2Rust_Block_36::S_331;
            }
            C2Rust_Block_36::S_331 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_36 = C2Rust_Block_36::S_333;
            }
            C2Rust_Block_36::S_333 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_390;
            }
            C2Rust_Block_36::S_341 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_36 = C2Rust_Block_36::S_343;
            }
            C2Rust_Block_36::S_343 => {
                if _fn.is_none() {
                    c2rust_current_block_36 = C2Rust_Block_36::S_345;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_349;
                }
            }
            C2Rust_Block_36::S_345 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_36 = C2Rust_Block_36::S_349;
            }
            C2Rust_Block_36::S_349 => {
                if _fn.is_none() {
                    c2rust_current_block_36 = C2Rust_Block_36::S_351;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_355;
                }
            }
            C2Rust_Block_36::S_351 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_36 = C2Rust_Block_36::S_355;
            }
            C2Rust_Block_36::S_355 => {
                if _fn.is_some() {
                    c2rust_current_block_36 = C2Rust_Block_36::S_361;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_368;
                }
            }
            C2Rust_Block_36::S_361 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_36 = C2Rust_Block_36::S_390;
            }
            C2Rust_Block_36::S_368 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_36 = C2Rust_Block_36::S_370;
            }
            C2Rust_Block_36::S_370 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_36 = C2Rust_Block_36::S_372;
            }
            C2Rust_Block_36::S_372 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_390;
            }
            C2Rust_Block_36::S_390 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_392;
            }
            C2Rust_Block_36::S_392 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_394;
            }
            C2Rust_Block_36::S_394 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_396;
            }
            C2Rust_Block_36::S_396 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_398;
            }
            C2Rust_Block_36::S_398 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_404;
            }
            C2Rust_Block_36::S_404 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_406;
            }
            C2Rust_Block_36::S_406 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_408;
            }
            C2Rust_Block_36::S_408 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_410;
            }
            C2Rust_Block_36::S_410 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_412;
            }
            C2Rust_Block_36::S_412 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_36 = C2Rust_Block_36::S_414;
            }
            C2Rust_Block_36::S_414 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_147;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_435;
                }
            }
            C2Rust_Block_36::S_429 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_435;
            }
            C2Rust_Block_36::S_435 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_437;
            }
            C2Rust_Block_36::S_437 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_439;
            }
            C2Rust_Block_36::S_439 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_441;
            }
            C2Rust_Block_36::S_441 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_443;
            }
            C2Rust_Block_36::S_443 => {
                if _fa == _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_481;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_452;
                }
            }
            C2Rust_Block_36::S_452 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_454;
            }
            C2Rust_Block_36::S_454 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_456;
            }
            C2Rust_Block_36::S_456 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_458;
            }
            C2Rust_Block_36::S_458 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_460;
            }
            C2Rust_Block_36::S_460 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_462;
            }
            C2Rust_Block_36::S_462 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_464;
            }
            C2Rust_Block_36::S_464 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_466;
            }
            C2Rust_Block_36::S_466 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_468;
            }
            C2Rust_Block_36::S_468 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_470;
            }
            C2Rust_Block_36::S_470 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_472;
            }
            C2Rust_Block_36::S_472 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_139;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_481;
                }
            }
            C2Rust_Block_36::S_481 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_487;
            }
            C2Rust_Block_36::S_487 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_489;
            }
            C2Rust_Block_36::S_489 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_499;
            }
            C2Rust_Block_36::S_499 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_501;
            }
            C2Rust_Block_36::S_501 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_511;
            }
            C2Rust_Block_36::S_511 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_513;
            }
            C2Rust_Block_36::S_513 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_527;
            }
            C2Rust_Block_36::S_527 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_529;
            }
            C2Rust_Block_36::S_529 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_539;
            }
            C2Rust_Block_36::S_539 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_541;
            }
            C2Rust_Block_36::S_541 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_547;
            }
            C2Rust_Block_36::S_547 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_549;
            }
            C2Rust_Block_36::S_549 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0020021B() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    loop {
        (*__gamepkg_tls_g_esi) = ebp.wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >((ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t) as usize),
        );
        's_338: {
            loop {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                if _fa == _fb {
                    break;
                }
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_0: uint32_t = 0x36e8a8 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                let mut _pv_2: uint32_t = 0x200241 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                sub_001FE270();
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break;
                }
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_307: {
                    if _fa == _fb {
                        break 's_307;
                    }
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
                    let mut _icall_target: uint32_t = (*__gamepkg_tls_g_ebx);
                    let mut _pv_5: uint32_t = 0x200254 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    let mut _va: uint32_t = _icall_target;
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va,
                    );
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    's_293: {
                        's_244: {
                            if _va >= 0xfe000000 as uint32_t
                                || g_xbox_code_hi == 0 as uint32_t
                                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                            {
                                break 's_244;
                            }
                            recomp_icall_not_code_log(_va);
                            (*__gamepkg_tls_g_esp) = _icall_esp;
                            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                            break 's_293;
                        }
                        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                        's_252: {
                            if !_fn.is_none() {
                                break 's_252;
                            }
                            _fn = recomp_lookup(_va);
                        }
                        's_258: {
                            if !_fn.is_none() {
                                break 's_258;
                            }
                            _fn = recomp_lookup_kernel(_va);
                        }
                        's_264: {
                            if _fn.is_some() {
                                break 's_264;
                            }
                            recomp_icall_fail_log(_va);
                            (*__gamepkg_tls_g_esp) = _icall_esp;
                            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                            break 's_293;
                        }
                        _fn.expect("non-null function pointer")();
                    }
                    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                }
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi);
                if _fa == _fb {
                    break 's_338;
                }
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
        }
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = ebp & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200280() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_306: {
        if _fa == _fb {
            break 's_306;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = ebp;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                .wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _icall_target: uint32_t = ebp;
            let mut _pv_5: uint32_t = 0x2002a9 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_247: {
                's_198: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_198;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_247;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_206: {
                    if !_fn.is_none() {
                        break 's_206;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_212: {
                    if !_fn.is_none() {
                        break 's_212;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_218: {
                    if _fn.is_some() {
                        break 's_218;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_247;
                }
                _fn.expect("non-null function pointer")();
            }
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
        }
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002002C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x2002e7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F5F30();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002002F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2002c0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x2002fc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00200200();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_254: {
        if _fa == _fb {
            break 's_254;
        }
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0x200326 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_001F5F30();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
            if _fa == _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 0x2002c0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = 0x20033c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_00200280();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200340() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _jt: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    enum C2Rust_Block_41 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_30,
        S_32,
        S_34,
        S_44,
        S_46,
        S_48,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_76,
        S_78,
        S_80,
        S_90,
        S_92,
        S_94,
        S_100,
        S_110,
        S_112,
        S_117,
        S_122,
        S_127,
        S_133,
        S_135,
        S_137,
        S_139,
        S_143,
        S_145,
        S_149,
        S_155,
        S_162,
        S_164,
        S_166,
        S_176,
        S_187,
        S_189,
        S_195,
        S_201,
        S_203,
        S_209,
        S_215,
        S_217,
        S_227,
        S_229,
        S_235,
        S_237,
        S_243,
        S_245,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_323,
        S_325,
        S_331,
        S_333,
        S_335,
        S_345,
        S_347,
        S_349,
        S_359,
        S_361,
        S_363,
        S_373,
        S_375,
        S_377,
        S_383,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_439,
        S_441,
        S_451,
        S_453,
        S_459,
        S_465,
        S_467,
        S_477,
        S_479,
        S_485,
        S_487,
        S_497,
        S_499,
        S_505,
        S_511,
        S_513,
        S_519,
        S_525,
        S_527,
        S_537,
        S_539,
        S_545,
        S_547,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_563,
        S_565,
        S_574,
        S_580,
        S_582,
        S_588,
        S_590,
        S_592,
        S_602,
        S_604,
        S_606,
        S_616,
        S_618,
        S_620,
        S_630,
        S_632,
        S_634,
        S_640,
        S_646,
        S_648,
        S_650,
        S_652,
        S_654,
        S_656,
        S_658,
        S_660,
        S_662,
        S_664,
        S_673,
        S_675,
        S_677,
        S_679,
        S_681,
        S_690,
        S_692,
        S_694,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_710,
        S_719,
        S_721,
        S_723,
        S_725,
        S_727,
        S_740,
        S_742,
        S_748,
        S_754,
        S_756,
        S_762,
        S_768,
        S_770,
        S_780,
        S_782,
        S_788,
        S_790,
        S_800,
        S_802,
        S_808,
        S_814,
        S_816,
        S_822,
        S_828,
        S_830,
        S_840,
        S_842,
        S_848,
        S_850,
        S_856,
        S_858,
        S_860,
        S_862,
        S_864,
        S_866,
        S_879,
        S_881,
        S_887,
        S_889,
        S_891,
        S_901,
        S_903,
        S_905,
        S_915,
        S_917,
        S_919,
        S_929,
        S_931,
        S_933,
        S_939,
        S_945,
        S_947,
        S_949,
        S_951,
        S_953,
        S_955,
        S_957,
        S_959,
        S_961,
        S_963,
        S_972,
        S_974,
        S_976,
        S_978,
        S_980,
        S_982,
        S_995,
        S_997,
        S_1007,
        S_1009,
        S_1015,
        S_1021,
        S_1023,
        S_1033,
        S_1035,
        S_1041,
        S_1043,
        S_1053,
        S_1055,
        S_1061,
        S_1067,
        S_1069,
        S_1075,
        S_1081,
        S_1083,
        S_1093,
        S_1095,
        S_1101,
        S_1103,
        S_1109,
        S_1111,
        S_1113,
        S_1123,
        S_1125,
        S_1135,
        S_1137,
        S_1143,
        S_1149,
        S_1151,
        S_1161,
        S_1163,
        S_1169,
        S_1171,
    }
    let mut c2rust_current_block_41: C2Rust_Block_41;
    c2rust_current_block_41 = C2Rust_Block_41::S_0;
    loop {
        match c2rust_current_block_41 {
            C2Rust_Block_41::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_2;
            }
            C2Rust_Block_41::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_41 = C2Rust_Block_41::S_4;
            }
            C2Rust_Block_41::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_41 = C2Rust_Block_41::S_6;
            }
            C2Rust_Block_41::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_8;
            }
            C2Rust_Block_41::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_18;
            }
            C2Rust_Block_41::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_41 = C2Rust_Block_41::S_24;
            }
            C2Rust_Block_41::S_24 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_30;
            }
            C2Rust_Block_41::S_30 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_41 = C2Rust_Block_41::S_32;
            }
            C2Rust_Block_41::S_32 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_34;
            }
            C2Rust_Block_41::S_34 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_44;
            }
            C2Rust_Block_41::S_44 => {
                _pv_0 = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_46;
            }
            C2Rust_Block_41::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_48;
            }
            C2Rust_Block_41::S_48 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_54;
            }
            C2Rust_Block_41::S_54 => {
                _fb = 0xfffffffe as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_56;
            }
            C2Rust_Block_41::S_56 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_58;
            }
            C2Rust_Block_41::S_58 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0xfffffffe as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_60;
            }
            C2Rust_Block_41::S_60 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_62;
            }
            C2Rust_Block_41::S_62 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_64;
            }
            C2Rust_Block_41::S_64 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_66;
            }
            C2Rust_Block_41::S_66 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_68;
            }
            C2Rust_Block_41::S_68 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_70;
            }
            C2Rust_Block_41::S_70 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_76;
            }
            C2Rust_Block_41::S_76 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_41 = C2Rust_Block_41::S_78;
            }
            C2Rust_Block_41::S_78 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_80;
            }
            C2Rust_Block_41::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_90;
            }
            C2Rust_Block_41::S_90 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_41 = C2Rust_Block_41::S_92;
            }
            C2Rust_Block_41::S_92 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_94;
            }
            C2Rust_Block_41::S_94 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_100;
            }
            C2Rust_Block_41::S_100 => {
                if _fa > _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1109;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_110;
                }
            }
            C2Rust_Block_41::S_110 => {
                _jt = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_mul(4 as uint32_t)
                            .wrapping_add(0x20045c as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_112;
            }
            C2Rust_Block_41::S_112 => {
                if _jt == 0x20035a as uint32_t {
                    c2rust_current_block_41 = C2Rust_Block_41::S_187;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_117;
                }
            }
            C2Rust_Block_41::S_117 => {
                if _jt == 0x200366 as uint32_t {
                    c2rust_current_block_41 = C2Rust_Block_41::S_243;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_122;
                }
            }
            C2Rust_Block_41::S_122 => {
                if _jt == 0x200450 as uint32_t {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1109;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_127;
                }
            }
            C2Rust_Block_41::S_127 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_133;
            }
            C2Rust_Block_41::S_133 => {
                _va = _jt;
                c2rust_current_block_41 = C2Rust_Block_41::S_135;
            }
            C2Rust_Block_41::S_135 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_41 = C2Rust_Block_41::S_137;
            }
            C2Rust_Block_41::S_137 => {
                if _fn.is_none() {
                    c2rust_current_block_41 = C2Rust_Block_41::S_139;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_143;
                }
            }
            C2Rust_Block_41::S_139 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_41 = C2Rust_Block_41::S_143;
            }
            C2Rust_Block_41::S_143 => {
                if _fn.is_none() {
                    c2rust_current_block_41 = C2Rust_Block_41::S_145;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_149;
                }
            }
            C2Rust_Block_41::S_145 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_41 = C2Rust_Block_41::S_149;
            }
            C2Rust_Block_41::S_149 => {
                if _fn.is_some() {
                    c2rust_current_block_41 = C2Rust_Block_41::S_155;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_162;
                }
            }
            C2Rust_Block_41::S_155 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_41 = C2Rust_Block_41::S_176;
            }
            C2Rust_Block_41::S_162 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_41 = C2Rust_Block_41::S_164;
            }
            C2Rust_Block_41::S_164 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_166;
            }
            C2Rust_Block_41::S_166 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_176;
            }
            C2Rust_Block_41::S_176 => return,
            C2Rust_Block_41::S_187 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_189;
            }
            C2Rust_Block_41::S_189 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_195;
            }
            C2Rust_Block_41::S_195 => {
                ebp = 2 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_201;
            }
            C2Rust_Block_41::S_201 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_203;
            }
            C2Rust_Block_41::S_203 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_209;
            }
            C2Rust_Block_41::S_209 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_215;
            }
            C2Rust_Block_41::S_215 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_217;
            }
            C2Rust_Block_41::S_217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_227;
            }
            C2Rust_Block_41::S_227 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_229;
            }
            C2Rust_Block_41::S_229 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_235;
            }
            C2Rust_Block_41::S_235 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_237;
            }
            C2Rust_Block_41::S_237 => return,
            C2Rust_Block_41::S_243 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_245;
            }
            C2Rust_Block_41::S_245 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_247;
            }
            C2Rust_Block_41::S_247 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_249;
            }
            C2Rust_Block_41::S_249 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_41 = C2Rust_Block_41::S_251;
            }
            C2Rust_Block_41::S_251 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_253;
            }
            C2Rust_Block_41::S_253 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_255;
            }
            C2Rust_Block_41::S_255 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_257;
            }
            C2Rust_Block_41::S_257 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_41 = C2Rust_Block_41::S_856;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_266;
                }
            }
            C2Rust_Block_41::S_266 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_41 = C2Rust_Block_41::S_268;
            }
            C2Rust_Block_41::S_268 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_270;
            }
            C2Rust_Block_41::S_270 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_272;
            }
            C2Rust_Block_41::S_272 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_274;
            }
            C2Rust_Block_41::S_274 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_41 = C2Rust_Block_41::S_553;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_283;
                }
            }
            C2Rust_Block_41::S_283 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_41 = C2Rust_Block_41::S_285;
            }
            C2Rust_Block_41::S_285 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_287;
            }
            C2Rust_Block_41::S_287 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_289;
            }
            C2Rust_Block_41::S_289 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_291;
            }
            C2Rust_Block_41::S_291 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1109;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_300;
                }
            }
            C2Rust_Block_41::S_300 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_302;
            }
            C2Rust_Block_41::S_302 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_304;
            }
            C2Rust_Block_41::S_304 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_306;
            }
            C2Rust_Block_41::S_306 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_308;
            }
            C2Rust_Block_41::S_308 => {
                ebp = 5 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_310;
            }
            C2Rust_Block_41::S_310 => {
                if _fa == _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1123;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_323;
                }
            }
            C2Rust_Block_41::S_323 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_325;
            }
            C2Rust_Block_41::S_325 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_331;
            }
            C2Rust_Block_41::S_331 => {
                _pv_3 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_333;
            }
            C2Rust_Block_41::S_333 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_335;
            }
            C2Rust_Block_41::S_335 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_345;
            }
            C2Rust_Block_41::S_345 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_41 = C2Rust_Block_41::S_347;
            }
            C2Rust_Block_41::S_347 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_349;
            }
            C2Rust_Block_41::S_349 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_359;
            }
            C2Rust_Block_41::S_359 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_41 = C2Rust_Block_41::S_361;
            }
            C2Rust_Block_41::S_361 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_363;
            }
            C2Rust_Block_41::S_363 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_373;
            }
            C2Rust_Block_41::S_373 => {
                _pv_6 = 0x20039f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_375;
            }
            C2Rust_Block_41::S_375 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_377;
            }
            C2Rust_Block_41::S_377 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_383;
            }
            C2Rust_Block_41::S_383 => {
                sub_002022C0();
                c2rust_current_block_41 = C2Rust_Block_41::S_389;
            }
            C2Rust_Block_41::S_389 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_391;
            }
            C2Rust_Block_41::S_391 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_393;
            }
            C2Rust_Block_41::S_393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_395;
            }
            C2Rust_Block_41::S_395 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_397;
            }
            C2Rust_Block_41::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_399;
            }
            C2Rust_Block_41::S_399 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_401;
            }
            C2Rust_Block_41::S_401 => {
                _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_403;
            }
            C2Rust_Block_41::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_405;
            }
            C2Rust_Block_41::S_405 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_407;
            }
            C2Rust_Block_41::S_407 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_497;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_416;
                }
            }
            C2Rust_Block_41::S_416 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_418;
            }
            C2Rust_Block_41::S_418 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_420;
            }
            C2Rust_Block_41::S_420 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_422;
            }
            C2Rust_Block_41::S_422 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_424;
            }
            C2Rust_Block_41::S_424 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_426;
            }
            C2Rust_Block_41::S_426 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_323;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_439;
                }
            }
            C2Rust_Block_41::S_439 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_441;
            }
            C2Rust_Block_41::S_441 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_451;
            }
            C2Rust_Block_41::S_451 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_453;
            }
            C2Rust_Block_41::S_453 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_459;
            }
            C2Rust_Block_41::S_459 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_465;
            }
            C2Rust_Block_41::S_465 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_467;
            }
            C2Rust_Block_41::S_467 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_477;
            }
            C2Rust_Block_41::S_477 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_479;
            }
            C2Rust_Block_41::S_479 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_485;
            }
            C2Rust_Block_41::S_485 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_487;
            }
            C2Rust_Block_41::S_487 => return,
            C2Rust_Block_41::S_497 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_499;
            }
            C2Rust_Block_41::S_499 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_505;
            }
            C2Rust_Block_41::S_505 => {
                ebp = 4 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_511;
            }
            C2Rust_Block_41::S_511 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_513;
            }
            C2Rust_Block_41::S_513 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_519;
            }
            C2Rust_Block_41::S_519 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_525;
            }
            C2Rust_Block_41::S_525 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_527;
            }
            C2Rust_Block_41::S_527 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_537;
            }
            C2Rust_Block_41::S_537 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_539;
            }
            C2Rust_Block_41::S_539 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_545;
            }
            C2Rust_Block_41::S_545 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_547;
            }
            C2Rust_Block_41::S_547 => return,
            C2Rust_Block_41::S_553 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_555;
            }
            C2Rust_Block_41::S_555 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_557;
            }
            C2Rust_Block_41::S_557 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_559;
            }
            C2Rust_Block_41::S_559 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_561;
            }
            C2Rust_Block_41::S_561 => {
                (*__gamepkg_tls_g_ebx) = 1 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_563;
            }
            C2Rust_Block_41::S_563 => {
                ebp = 6 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_565;
            }
            C2Rust_Block_41::S_565 => {
                if _fa == _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_740;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_574;
                }
            }
            C2Rust_Block_41::S_574 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_41 = C2Rust_Block_41::S_580;
            }
            C2Rust_Block_41::S_580 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_582;
            }
            C2Rust_Block_41::S_582 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_588;
            }
            C2Rust_Block_41::S_588 => {
                _pv_7 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_590;
            }
            C2Rust_Block_41::S_590 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_592;
            }
            C2Rust_Block_41::S_592 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_602;
            }
            C2Rust_Block_41::S_602 => {
                _pv_8 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_41 = C2Rust_Block_41::S_604;
            }
            C2Rust_Block_41::S_604 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_606;
            }
            C2Rust_Block_41::S_606 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_616;
            }
            C2Rust_Block_41::S_616 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_41 = C2Rust_Block_41::S_618;
            }
            C2Rust_Block_41::S_618 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_620;
            }
            C2Rust_Block_41::S_620 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_630;
            }
            C2Rust_Block_41::S_630 => {
                _pv_10 = 0x2003df as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_632;
            }
            C2Rust_Block_41::S_632 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_634;
            }
            C2Rust_Block_41::S_634 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_640;
            }
            C2Rust_Block_41::S_640 => {
                sub_002022C0();
                c2rust_current_block_41 = C2Rust_Block_41::S_646;
            }
            C2Rust_Block_41::S_646 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_648;
            }
            C2Rust_Block_41::S_648 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_650;
            }
            C2Rust_Block_41::S_650 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_652;
            }
            C2Rust_Block_41::S_652 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_654;
            }
            C2Rust_Block_41::S_654 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_656;
            }
            C2Rust_Block_41::S_656 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_658;
            }
            C2Rust_Block_41::S_658 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_660;
            }
            C2Rust_Block_41::S_660 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_662;
            }
            C2Rust_Block_41::S_662 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_664;
            }
            C2Rust_Block_41::S_664 => {
                if _fa == _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_800;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_673;
                }
            }
            C2Rust_Block_41::S_673 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_675;
            }
            C2Rust_Block_41::S_675 => {
                _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_677;
            }
            C2Rust_Block_41::S_677 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_679;
            }
            C2Rust_Block_41::S_679 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_681;
            }
            C2Rust_Block_41::S_681 => {
                if _fa == _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_700;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_690;
                }
            }
            C2Rust_Block_41::S_690 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_692;
            }
            C2Rust_Block_41::S_692 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_694;
            }
            C2Rust_Block_41::S_694 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_700;
            }
            C2Rust_Block_41::S_700 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_702;
            }
            C2Rust_Block_41::S_702 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_704;
            }
            C2Rust_Block_41::S_704 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_706;
            }
            C2Rust_Block_41::S_706 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_708;
            }
            C2Rust_Block_41::S_708 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_710;
            }
            C2Rust_Block_41::S_710 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_580;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_719;
                }
            }
            C2Rust_Block_41::S_719 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_721;
            }
            C2Rust_Block_41::S_721 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_723;
            }
            C2Rust_Block_41::S_723 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_725;
            }
            C2Rust_Block_41::S_725 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_727;
            }
            C2Rust_Block_41::S_727 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1123;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_740;
                }
            }
            C2Rust_Block_41::S_740 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_742;
            }
            C2Rust_Block_41::S_742 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_748;
            }
            C2Rust_Block_41::S_748 => {
                ebp = 3 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_754;
            }
            C2Rust_Block_41::S_754 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_756;
            }
            C2Rust_Block_41::S_756 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_762;
            }
            C2Rust_Block_41::S_762 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_768;
            }
            C2Rust_Block_41::S_768 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_770;
            }
            C2Rust_Block_41::S_770 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_780;
            }
            C2Rust_Block_41::S_780 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_782;
            }
            C2Rust_Block_41::S_782 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_788;
            }
            C2Rust_Block_41::S_788 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_790;
            }
            C2Rust_Block_41::S_790 => return,
            C2Rust_Block_41::S_800 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_802;
            }
            C2Rust_Block_41::S_802 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_808;
            }
            C2Rust_Block_41::S_808 => {
                ebp = 7 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_814;
            }
            C2Rust_Block_41::S_814 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_816;
            }
            C2Rust_Block_41::S_816 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_822;
            }
            C2Rust_Block_41::S_822 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_828;
            }
            C2Rust_Block_41::S_828 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_830;
            }
            C2Rust_Block_41::S_830 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_840;
            }
            C2Rust_Block_41::S_840 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_842;
            }
            C2Rust_Block_41::S_842 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_848;
            }
            C2Rust_Block_41::S_848 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_850;
            }
            C2Rust_Block_41::S_850 => return,
            C2Rust_Block_41::S_856 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_858;
            }
            C2Rust_Block_41::S_858 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_860;
            }
            C2Rust_Block_41::S_860 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_862;
            }
            C2Rust_Block_41::S_862 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_864;
            }
            C2Rust_Block_41::S_864 => {
                ebp = 3 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_866;
            }
            C2Rust_Block_41::S_866 => {
                if _fa == _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1123;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_879;
                }
            }
            C2Rust_Block_41::S_879 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_881;
            }
            C2Rust_Block_41::S_881 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_887;
            }
            C2Rust_Block_41::S_887 => {
                _pv_11 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_889;
            }
            C2Rust_Block_41::S_889 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_891;
            }
            C2Rust_Block_41::S_891 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_901;
            }
            C2Rust_Block_41::S_901 => {
                _pv_12 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_41 = C2Rust_Block_41::S_903;
            }
            C2Rust_Block_41::S_903 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_905;
            }
            C2Rust_Block_41::S_905 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_915;
            }
            C2Rust_Block_41::S_915 => {
                _pv_13 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_41 = C2Rust_Block_41::S_917;
            }
            C2Rust_Block_41::S_917 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_919;
            }
            C2Rust_Block_41::S_919 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_929;
            }
            C2Rust_Block_41::S_929 => {
                _pv_14 = 0x20042f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_931;
            }
            C2Rust_Block_41::S_931 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_933;
            }
            C2Rust_Block_41::S_933 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_939;
            }
            C2Rust_Block_41::S_939 => {
                sub_002022C0();
                c2rust_current_block_41 = C2Rust_Block_41::S_945;
            }
            C2Rust_Block_41::S_945 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_947;
            }
            C2Rust_Block_41::S_947 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_949;
            }
            C2Rust_Block_41::S_949 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_951;
            }
            C2Rust_Block_41::S_951 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_953;
            }
            C2Rust_Block_41::S_953 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_955;
            }
            C2Rust_Block_41::S_955 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_957;
            }
            C2Rust_Block_41::S_957 => {
                _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_959;
            }
            C2Rust_Block_41::S_959 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_961;
            }
            C2Rust_Block_41::S_961 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_963;
            }
            C2Rust_Block_41::S_963 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_1053;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_972;
                }
            }
            C2Rust_Block_41::S_972 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_974;
            }
            C2Rust_Block_41::S_974 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_976;
            }
            C2Rust_Block_41::S_976 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_978;
            }
            C2Rust_Block_41::S_978 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_980;
            }
            C2Rust_Block_41::S_980 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_982;
            }
            C2Rust_Block_41::S_982 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_879;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_995;
                }
            }
            C2Rust_Block_41::S_995 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_997;
            }
            C2Rust_Block_41::S_997 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1007;
            }
            C2Rust_Block_41::S_1007 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1009;
            }
            C2Rust_Block_41::S_1009 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1015;
            }
            C2Rust_Block_41::S_1015 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_1021;
            }
            C2Rust_Block_41::S_1021 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1023;
            }
            C2Rust_Block_41::S_1023 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1033;
            }
            C2Rust_Block_41::S_1033 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1035;
            }
            C2Rust_Block_41::S_1035 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1041;
            }
            C2Rust_Block_41::S_1041 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1043;
            }
            C2Rust_Block_41::S_1043 => return,
            C2Rust_Block_41::S_1053 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1055;
            }
            C2Rust_Block_41::S_1055 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1061;
            }
            C2Rust_Block_41::S_1061 => {
                ebp = 8 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_1067;
            }
            C2Rust_Block_41::S_1067 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1069;
            }
            C2Rust_Block_41::S_1069 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1075;
            }
            C2Rust_Block_41::S_1075 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_1081;
            }
            C2Rust_Block_41::S_1081 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1083;
            }
            C2Rust_Block_41::S_1083 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1093;
            }
            C2Rust_Block_41::S_1093 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1095;
            }
            C2Rust_Block_41::S_1095 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1101;
            }
            C2Rust_Block_41::S_1101 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1103;
            }
            C2Rust_Block_41::S_1103 => return,
            C2Rust_Block_41::S_1109 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_1111;
            }
            C2Rust_Block_41::S_1111 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_1113;
            }
            C2Rust_Block_41::S_1113 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_1123;
            }
            C2Rust_Block_41::S_1123 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1125;
            }
            C2Rust_Block_41::S_1125 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1135;
            }
            C2Rust_Block_41::S_1135 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1137;
            }
            C2Rust_Block_41::S_1137 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1143;
            }
            C2Rust_Block_41::S_1143 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_1149;
            }
            C2Rust_Block_41::S_1149 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1151;
            }
            C2Rust_Block_41::S_1151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1161;
            }
            C2Rust_Block_41::S_1161 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_1163;
            }
            C2Rust_Block_41::S_1163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1169;
            }
            C2Rust_Block_41::S_1169 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_1171;
            }
            C2Rust_Block_41::S_1171 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200400() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200470() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xfffffffe as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0xfffffffe as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_206: {
        if _fa > _fb {
            break 's_206;
        }
        let mut _jt: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x200498 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_61: {
            if _jt != 0x200482 as uint32_t {
                break 's_61;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv: uint32_t = 3 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv,
            );
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = 0x200491 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            sub_002022C0();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        if _jt == 0x200495 as uint32_t {
            break 's_206;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _va: uint32_t = _jt;
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_82: {
            if !_fn.is_none() {
                break 's_82;
            }
            _fn = recomp_lookup(_va);
        }
        's_88: {
            if !_fn.is_none() {
                break 's_88;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_115: {
            's_94: {
                if _fn.is_some() {
                    break 's_94;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_115;
            }
            _fn.expect("non-null function pointer")();
        }
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002004B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _jt: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    enum C2Rust_Block_44 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_64,
        S_66,
        S_68,
        S_74,
        S_84,
        S_86,
        S_91,
        S_96,
        S_101,
        S_107,
        S_109,
        S_111,
        S_113,
        S_117,
        S_119,
        S_123,
        S_129,
        S_136,
        S_138,
        S_140,
        S_150,
        S_161,
        S_163,
        S_169,
        S_175,
        S_177,
        S_183,
        S_185,
        S_195,
        S_197,
        S_203,
        S_209,
        S_211,
        S_217,
        S_219,
        S_225,
        S_231,
        S_233,
        S_235,
        S_241,
        S_247,
        S_249,
        S_255,
        S_257,
        S_259,
        S_265,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_375,
        S_381,
        S_383,
        S_393,
        S_395,
        S_401,
        S_403,
        S_413,
        S_415,
        S_421,
        S_427,
        S_429,
        S_435,
        S_437,
        S_443,
        S_449,
        S_451,
        S_461,
        S_463,
        S_469,
        S_471,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_515,
        S_517,
        S_527,
        S_529,
        S_535,
        S_537,
        S_547,
        S_549,
        S_555,
        S_561,
        S_563,
        S_569,
        S_571,
        S_581,
        S_583,
        S_589,
        S_591,
        S_593,
        S_599,
        S_601,
        S_607,
        S_609,
    }
    let mut c2rust_current_block_44: C2Rust_Block_44;
    c2rust_current_block_44 = C2Rust_Block_44::S_0;
    loop {
        match c2rust_current_block_44 {
            C2Rust_Block_44::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_2;
            }
            C2Rust_Block_44::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_44 = C2Rust_Block_44::S_4;
            }
            C2Rust_Block_44::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_6;
            }
            C2Rust_Block_44::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_8;
            }
            C2Rust_Block_44::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_18;
            }
            C2Rust_Block_44::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_44 = C2Rust_Block_44::S_28;
            }
            C2Rust_Block_44::S_28 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_30;
            }
            C2Rust_Block_44::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_32;
            }
            C2Rust_Block_44::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_38;
            }
            C2Rust_Block_44::S_38 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_44 = C2Rust_Block_44::S_40;
            }
            C2Rust_Block_44::S_40 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_42;
            }
            C2Rust_Block_44::S_42 => {
                _fb = 0xfffffffe as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_44;
            }
            C2Rust_Block_44::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_46;
            }
            C2Rust_Block_44::S_46 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0xfffffffe as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_48;
            }
            C2Rust_Block_44::S_48 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_50;
            }
            C2Rust_Block_44::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_52;
            }
            C2Rust_Block_44::S_52 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_54;
            }
            C2Rust_Block_44::S_54 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_56;
            }
            C2Rust_Block_44::S_56 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_58;
            }
            C2Rust_Block_44::S_58 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_64;
            }
            C2Rust_Block_44::S_64 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_66;
            }
            C2Rust_Block_44::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_68;
            }
            C2Rust_Block_44::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_74;
            }
            C2Rust_Block_44::S_74 => {
                if _fa > _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_581;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_84;
                }
            }
            C2Rust_Block_44::S_84 => {
                _jt = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_mul(4 as uint32_t)
                            .wrapping_add(0x20052c as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_86;
            }
            C2Rust_Block_44::S_86 => {
                if _jt == 0x2004c6 as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_161;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_91;
                }
            }
            C2Rust_Block_44::S_91 => {
                if _jt == 0x2004ce as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_195;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_96;
                }
            }
            C2Rust_Block_44::S_96 => {
                if _jt == 0x2004d6 as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_225;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_101;
                }
            }
            C2Rust_Block_44::S_101 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_107;
            }
            C2Rust_Block_44::S_107 => {
                _va = _jt;
                c2rust_current_block_44 = C2Rust_Block_44::S_109;
            }
            C2Rust_Block_44::S_109 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_44 = C2Rust_Block_44::S_111;
            }
            C2Rust_Block_44::S_111 => {
                if _fn.is_none() {
                    c2rust_current_block_44 = C2Rust_Block_44::S_113;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_117;
                }
            }
            C2Rust_Block_44::S_113 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_44 = C2Rust_Block_44::S_117;
            }
            C2Rust_Block_44::S_117 => {
                if _fn.is_none() {
                    c2rust_current_block_44 = C2Rust_Block_44::S_119;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_123;
                }
            }
            C2Rust_Block_44::S_119 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_44 = C2Rust_Block_44::S_123;
            }
            C2Rust_Block_44::S_123 => {
                if _fn.is_some() {
                    c2rust_current_block_44 = C2Rust_Block_44::S_129;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_136;
                }
            }
            C2Rust_Block_44::S_129 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_44 = C2Rust_Block_44::S_150;
            }
            C2Rust_Block_44::S_136 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_44 = C2Rust_Block_44::S_138;
            }
            C2Rust_Block_44::S_138 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_140;
            }
            C2Rust_Block_44::S_140 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_150;
            }
            C2Rust_Block_44::S_150 => return,
            C2Rust_Block_44::S_161 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_163;
            }
            C2Rust_Block_44::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_169;
            }
            C2Rust_Block_44::S_169 => {
                (*__gamepkg_tls_g_eax) = 9 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_175;
            }
            C2Rust_Block_44::S_175 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_177;
            }
            C2Rust_Block_44::S_177 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_183;
            }
            C2Rust_Block_44::S_183 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_185;
            }
            C2Rust_Block_44::S_185 => return,
            C2Rust_Block_44::S_195 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_197;
            }
            C2Rust_Block_44::S_197 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_203;
            }
            C2Rust_Block_44::S_203 => {
                (*__gamepkg_tls_g_eax) = 2 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_209;
            }
            C2Rust_Block_44::S_209 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_211;
            }
            C2Rust_Block_44::S_211 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_217;
            }
            C2Rust_Block_44::S_217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_219;
            }
            C2Rust_Block_44::S_219 => return,
            C2Rust_Block_44::S_225 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_231;
            }
            C2Rust_Block_44::S_231 => {
                _pv_1 = 0x2004dd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_233;
            }
            C2Rust_Block_44::S_233 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_235;
            }
            C2Rust_Block_44::S_235 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_241;
            }
            C2Rust_Block_44::S_241 => {
                sub_00200340();
                c2rust_current_block_44 = C2Rust_Block_44::S_247;
            }
            C2Rust_Block_44::S_247 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_249;
            }
            C2Rust_Block_44::S_249 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_44 = C2Rust_Block_44::S_255;
            }
            C2Rust_Block_44::S_255 => {
                _pv_2 = 0x2004e6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_257;
            }
            C2Rust_Block_44::S_257 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_259;
            }
            C2Rust_Block_44::S_259 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_265;
            }
            C2Rust_Block_44::S_265 => {
                sub_00200470();
                c2rust_current_block_44 = C2Rust_Block_44::S_271;
            }
            C2Rust_Block_44::S_271 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_273;
            }
            C2Rust_Block_44::S_273 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_sub(1);
                c2rust_current_block_44 = C2Rust_Block_44::S_275;
            }
            C2Rust_Block_44::S_275 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_277;
            }
            C2Rust_Block_44::S_277 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_279;
            }
            C2Rust_Block_44::S_279 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_281;
            }
            C2Rust_Block_44::S_281 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_477;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_290;
                }
            }
            C2Rust_Block_44::S_290 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_sub(1);
                c2rust_current_block_44 = C2Rust_Block_44::S_292;
            }
            C2Rust_Block_44::S_292 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_294;
            }
            C2Rust_Block_44::S_294 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_296;
            }
            C2Rust_Block_44::S_296 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_298;
            }
            C2Rust_Block_44::S_298 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_443;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_307;
                }
            }
            C2Rust_Block_44::S_307 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_sub(1);
                c2rust_current_block_44 = C2Rust_Block_44::S_309;
            }
            C2Rust_Block_44::S_309 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_311;
            }
            C2Rust_Block_44::S_311 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_313;
            }
            C2Rust_Block_44::S_313 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_315;
            }
            C2Rust_Block_44::S_315 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_581;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_324;
                }
            }
            C2Rust_Block_44::S_324 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_326;
            }
            C2Rust_Block_44::S_326 => {
                _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_328;
            }
            C2Rust_Block_44::S_328 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_330;
            }
            C2Rust_Block_44::S_330 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_332;
            }
            C2Rust_Block_44::S_332 => {
                if _fa == _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_358;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_341;
                }
            }
            C2Rust_Block_44::S_341 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_343;
            }
            C2Rust_Block_44::S_343 => {
                _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_345;
            }
            C2Rust_Block_44::S_345 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_347;
            }
            C2Rust_Block_44::S_347 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_349;
            }
            C2Rust_Block_44::S_349 => {
                if _fa != _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_413;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_358;
                }
            }
            C2Rust_Block_44::S_358 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_360;
            }
            C2Rust_Block_44::S_360 => {
                _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_362;
            }
            C2Rust_Block_44::S_362 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_364;
            }
            C2Rust_Block_44::S_364 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_366;
            }
            C2Rust_Block_44::S_366 => {
                if _fa != _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_413;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_375;
                }
            }
            C2Rust_Block_44::S_375 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_381;
            }
            C2Rust_Block_44::S_381 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_383;
            }
            C2Rust_Block_44::S_383 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_393;
            }
            C2Rust_Block_44::S_393 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_395;
            }
            C2Rust_Block_44::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_401;
            }
            C2Rust_Block_44::S_401 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_403;
            }
            C2Rust_Block_44::S_403 => return,
            C2Rust_Block_44::S_413 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_415;
            }
            C2Rust_Block_44::S_415 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_421;
            }
            C2Rust_Block_44::S_421 => {
                (*__gamepkg_tls_g_eax) = 4 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_427;
            }
            C2Rust_Block_44::S_427 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_429;
            }
            C2Rust_Block_44::S_429 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_435;
            }
            C2Rust_Block_44::S_435 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_437;
            }
            C2Rust_Block_44::S_437 => return,
            C2Rust_Block_44::S_443 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_449;
            }
            C2Rust_Block_44::S_449 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_451;
            }
            C2Rust_Block_44::S_451 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_461;
            }
            C2Rust_Block_44::S_461 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_463;
            }
            C2Rust_Block_44::S_463 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_469;
            }
            C2Rust_Block_44::S_469 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_471;
            }
            C2Rust_Block_44::S_471 => return,
            C2Rust_Block_44::S_477 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_479;
            }
            C2Rust_Block_44::S_479 => {
                _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_481;
            }
            C2Rust_Block_44::S_481 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_483;
            }
            C2Rust_Block_44::S_483 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_485;
            }
            C2Rust_Block_44::S_485 => {
                if _fa != _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_547;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_494;
                }
            }
            C2Rust_Block_44::S_494 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_496;
            }
            C2Rust_Block_44::S_496 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_498;
            }
            C2Rust_Block_44::S_498 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_500;
            }
            C2Rust_Block_44::S_500 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_502;
            }
            C2Rust_Block_44::S_502 => {
                if _fa != _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_547;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_515;
                }
            }
            C2Rust_Block_44::S_515 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_517;
            }
            C2Rust_Block_44::S_517 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_527;
            }
            C2Rust_Block_44::S_527 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_529;
            }
            C2Rust_Block_44::S_529 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_535;
            }
            C2Rust_Block_44::S_535 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_537;
            }
            C2Rust_Block_44::S_537 => return,
            C2Rust_Block_44::S_547 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_549;
            }
            C2Rust_Block_44::S_549 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_555;
            }
            C2Rust_Block_44::S_555 => {
                (*__gamepkg_tls_g_eax) = 8 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_561;
            }
            C2Rust_Block_44::S_561 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_563;
            }
            C2Rust_Block_44::S_563 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_569;
            }
            C2Rust_Block_44::S_569 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_571;
            }
            C2Rust_Block_44::S_571 => return,
            C2Rust_Block_44::S_581 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_583;
            }
            C2Rust_Block_44::S_583 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_589;
            }
            C2Rust_Block_44::S_589 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_591;
            }
            C2Rust_Block_44::S_591 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_593;
            }
            C2Rust_Block_44::S_593 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_599;
            }
            C2Rust_Block_44::S_599 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_601;
            }
            C2Rust_Block_44::S_601 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_607;
            }
            C2Rust_Block_44::S_607 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_609;
            }
            C2Rust_Block_44::S_609 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002004FF() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    's_27: {
        if _flags == 0 {
            break 's_27;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 4 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200540() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    let mut _pv_1: uint32_t = 0x20054d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_002004B0();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xfffffffe as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0xfffffffe as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_312: {
        if _fa > _fb {
            break 's_312;
        }
        let mut _jt: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x20059c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_117: {
            if _jt != 0x200565 as uint32_t {
                break 's_117;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = 3 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x200574 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_002022C0();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
            let mut _pv_6: uint32_t = 0x200581 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_00200340();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        if _jt == 0x200587 as uint32_t {
            break 's_312;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _va: uint32_t = _jt;
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_138: {
            if !_fn.is_none() {
                break 's_138;
            }
            _fn = recomp_lookup(_va);
        }
        's_144: {
            if !_fn.is_none() {
                break 's_144;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_171: {
            's_150: {
                if _fn.is_some() {
                    break 's_150;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_171;
            }
            _fn.expect("non-null function pointer")();
        }
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    let mut _pv_7: uint32_t = 0x200593 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_00200340();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002005B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x2005c5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_002022A0();
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002005D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_274: {
        if _fa <= _fb {
            break 's_274;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
        _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t);
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ebx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                .wrapping_add(-44 as ::core::ffi::c_int as uint32_t);
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0x200602 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_002022A0();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x10 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200620() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x200635 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_002022A0();
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200640() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_56: {
        if _fa != _fb {
            break 's_56;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax).wrapping_add(0x3c as uint32_t);
        let mut _tmp: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        (*__gamepkg_tls_g_edx) = _tmp;
    }
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x200620 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x200659 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00200200();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    loop {
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x200670 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_002022A0();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        if _fa == _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00200653() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x200659 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_00200200();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    loop {
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x200670 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_002022A0();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        if _fa == _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
