extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm1() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm2() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm3() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm7() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm5() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm6() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm4() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261140() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549230 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261160() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9414 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261180() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549238 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002611A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d941c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002611C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549238 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x54924c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002611E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d941c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549244 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261200() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x54925c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261220() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549250 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261240() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549250 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549258 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261260() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9418 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261280() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d941c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549254 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002612A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d941c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d942c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002612C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d941c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d942c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9424 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002612E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x54923c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261300() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9420 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261320() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2158 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9428 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261340() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2158 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549248 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261360() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let __gamepkg_tls_g_xmm3 = unsafe { gamepkg_tls_g_xmm3() };
    let __gamepkg_tls_g_xmm4 = unsafe { gamepkg_tls_g_xmm4() };
    let __gamepkg_tls_g_xmm5 = unsafe { gamepkg_tls_g_xmm5() };
    let __gamepkg_tls_g_xmm6 = unsafe { gamepkg_tls_g_xmm6() };
    let __gamepkg_tls_g_xmm7 = unsafe { gamepkg_tls_g_xmm7() };
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    enum C2Rust_Block_19 {
        S_0,
        S_2,
        S_16,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
    }
    let mut c2rust_current_block_19: C2Rust_Block_19;
    c2rust_current_block_19 = C2Rust_Block_19::S_0;
    loop {
        match c2rust_current_block_19 {
            C2Rust_Block_19::S_0 => {
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_2;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_16;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_18;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_20;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2188 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_22;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_24;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_19 = C2Rust_Block_19::S_26;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_28;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_30;
                };
                {
                    (*__gamepkg_tls_g_xmm4) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_32;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_34;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2184 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_36;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_38;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2180 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_40;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_42;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b217c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_44;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_46;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_48;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_50;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_52;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_54;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_56;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_58;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_60;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ef4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_62;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388054 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_64;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_66;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_68;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_70;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2178 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_72;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_74;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39d064 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_76;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ef8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_78;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_80;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_82;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_84;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_86;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_88;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_90;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_92;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2174 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_94;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x3aafc0 as uint32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_96;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418efc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_98;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_100;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_102;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_104;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_106;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_108;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_110;
                };
                {
                    (*__gamepkg_tls_g_edx) = 0x50 as uint32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_112;
                };
                {
                    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_114;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_116;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_19 = C2Rust_Block_19::S_118;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_120;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_122;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ef0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_124;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x258 as uint32_t,
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_126;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418f04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xbb8 as uint32_t,
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_128;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_130;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_132;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_134;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_136;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_138;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_140;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_142;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_144;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_146;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_148;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_150;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_152;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_154;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_156;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418f7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_158;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418f80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418f84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_162;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_164;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f8c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_166;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_168;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418f98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_170;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fa0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_172;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fa4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_174;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fa8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_176;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_178;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fb4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_180;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_182;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2170 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_184;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_186;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_188;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_190;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_192;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fcc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_194;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_196;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_198;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_200;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fdc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_202;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_204;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ff0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_206;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_208;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ff4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_210;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419010 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_214;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1b28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_216;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41901c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_218;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b216c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_220;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419024 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_222;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_224;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419028 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_226;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2168 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_228;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419034 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_230;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_232;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419038 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_234;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_236;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41903c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_238;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2168 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_240;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419044 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_242;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2164 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_244;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41904c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_246;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_248;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419054 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_250;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_252;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419058 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_254;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_256;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41906c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_258;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_260;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419070 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_262;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_264;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41908c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_266;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_268;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419098 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_270;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1b88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_272;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_274;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fc4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_276;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fd0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_278;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fd4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_280;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fe0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_282;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fe4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_284;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fe8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_286;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418fec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_288;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418ff8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418ffc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_292;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x419000 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_294;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419004 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_296;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419008 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_298;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41900c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_300;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419014 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_302;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419018 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_304;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419020 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_306;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41902c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_308;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419030 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_310;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419040 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_312;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419048 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_314;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419050 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_316;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41905c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_318;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419060 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_320;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419064 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_322;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419068 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_324;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x419074 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_326;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x419078 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_328;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41907c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_330;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419080 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_332;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419084 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_334;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419088 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_336;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419090 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_338;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419094 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_340;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41909c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_342;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_344;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_346;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_348;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2160 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_350;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_352;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_354;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_356;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2160 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_358;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_360;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b215c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_362;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_364;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_366;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_368;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_370;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_372;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_374;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_376;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_378;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_380;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_382;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_384;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_386;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_388;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419128 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_390;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39b2b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_392;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41910c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_394;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_396;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419130 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_398;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_400;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_402;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_404;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419134 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_406;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419140 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_408;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1b94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_410;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_412;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_414;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419114 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_416;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_418;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41912c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_420;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41913c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_422;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419144 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_424;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_426;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419154 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_428;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_430;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_432;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_434;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_436;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419104 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_438;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419118 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_440;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41911c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_442;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_444;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419124 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_446;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419138 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_448;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419148 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_450;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41914c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_452;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_454;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419164 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_456;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x386dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_458;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419180 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_460;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_462;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_464;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_466;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_468;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_470;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4190f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_472;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4190f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_474;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4190f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_476;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4190fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_478;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419100 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_480;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419120 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_482;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419150 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_484;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419158 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_486;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41915c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_488;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419160 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_490;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419168 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_492;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41916c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_494;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x419170 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_496;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x419174 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_498;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419178 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_500;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41917c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_502;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x419184 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_19 = C2Rust_Block_19::S_504;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_19 = C2Rust_Block_19::S_506;
                };
                return;
            }
            C2Rust_Block_19::S_100
            | C2Rust_Block_19::S_102
            | C2Rust_Block_19::S_104
            | C2Rust_Block_19::S_106
            | C2Rust_Block_19::S_108
            | C2Rust_Block_19::S_110
            | C2Rust_Block_19::S_112
            | C2Rust_Block_19::S_114
            | C2Rust_Block_19::S_116
            | C2Rust_Block_19::S_118
            | C2Rust_Block_19::S_120
            | C2Rust_Block_19::S_122
            | C2Rust_Block_19::S_124
            | C2Rust_Block_19::S_126
            | C2Rust_Block_19::S_128
            | C2Rust_Block_19::S_130
            | C2Rust_Block_19::S_132
            | C2Rust_Block_19::S_134
            | C2Rust_Block_19::S_136
            | C2Rust_Block_19::S_138
            | C2Rust_Block_19::S_140
            | C2Rust_Block_19::S_142
            | C2Rust_Block_19::S_144
            | C2Rust_Block_19::S_146
            | C2Rust_Block_19::S_148
            | C2Rust_Block_19::S_150
            | C2Rust_Block_19::S_152
            | C2Rust_Block_19::S_154
            | C2Rust_Block_19::S_156
            | C2Rust_Block_19::S_158
            | C2Rust_Block_19::S_16
            | C2Rust_Block_19::S_160
            | C2Rust_Block_19::S_162
            | C2Rust_Block_19::S_164
            | C2Rust_Block_19::S_166
            | C2Rust_Block_19::S_168
            | C2Rust_Block_19::S_170
            | C2Rust_Block_19::S_172
            | C2Rust_Block_19::S_174
            | C2Rust_Block_19::S_176
            | C2Rust_Block_19::S_178
            | C2Rust_Block_19::S_18
            | C2Rust_Block_19::S_180
            | C2Rust_Block_19::S_182
            | C2Rust_Block_19::S_184
            | C2Rust_Block_19::S_186
            | C2Rust_Block_19::S_188
            | C2Rust_Block_19::S_190
            | C2Rust_Block_19::S_192
            | C2Rust_Block_19::S_194
            | C2Rust_Block_19::S_196
            | C2Rust_Block_19::S_198
            | C2Rust_Block_19::S_2
            | C2Rust_Block_19::S_20
            | C2Rust_Block_19::S_200
            | C2Rust_Block_19::S_202
            | C2Rust_Block_19::S_204
            | C2Rust_Block_19::S_206
            | C2Rust_Block_19::S_208
            | C2Rust_Block_19::S_210
            | C2Rust_Block_19::S_212
            | C2Rust_Block_19::S_214
            | C2Rust_Block_19::S_216
            | C2Rust_Block_19::S_218
            | C2Rust_Block_19::S_22
            | C2Rust_Block_19::S_220
            | C2Rust_Block_19::S_222
            | C2Rust_Block_19::S_224
            | C2Rust_Block_19::S_226
            | C2Rust_Block_19::S_228
            | C2Rust_Block_19::S_230
            | C2Rust_Block_19::S_232
            | C2Rust_Block_19::S_234
            | C2Rust_Block_19::S_236
            | C2Rust_Block_19::S_238
            | C2Rust_Block_19::S_24
            | C2Rust_Block_19::S_240
            | C2Rust_Block_19::S_242
            | C2Rust_Block_19::S_244
            | C2Rust_Block_19::S_246
            | C2Rust_Block_19::S_248
            | C2Rust_Block_19::S_250
            | C2Rust_Block_19::S_252
            | C2Rust_Block_19::S_254
            | C2Rust_Block_19::S_256
            | C2Rust_Block_19::S_258
            | C2Rust_Block_19::S_26
            | C2Rust_Block_19::S_260
            | C2Rust_Block_19::S_262
            | C2Rust_Block_19::S_264
            | C2Rust_Block_19::S_266
            | C2Rust_Block_19::S_268
            | C2Rust_Block_19::S_270
            | C2Rust_Block_19::S_272
            | C2Rust_Block_19::S_274
            | C2Rust_Block_19::S_276
            | C2Rust_Block_19::S_278
            | C2Rust_Block_19::S_28
            | C2Rust_Block_19::S_280
            | C2Rust_Block_19::S_282
            | C2Rust_Block_19::S_284
            | C2Rust_Block_19::S_286
            | C2Rust_Block_19::S_288
            | C2Rust_Block_19::S_290
            | C2Rust_Block_19::S_292
            | C2Rust_Block_19::S_294
            | C2Rust_Block_19::S_296
            | C2Rust_Block_19::S_298
            | C2Rust_Block_19::S_30
            | C2Rust_Block_19::S_300
            | C2Rust_Block_19::S_302
            | C2Rust_Block_19::S_304
            | C2Rust_Block_19::S_306
            | C2Rust_Block_19::S_308
            | C2Rust_Block_19::S_310
            | C2Rust_Block_19::S_312
            | C2Rust_Block_19::S_314
            | C2Rust_Block_19::S_316
            | C2Rust_Block_19::S_318
            | C2Rust_Block_19::S_32
            | C2Rust_Block_19::S_320
            | C2Rust_Block_19::S_322
            | C2Rust_Block_19::S_324
            | C2Rust_Block_19::S_326
            | C2Rust_Block_19::S_328
            | C2Rust_Block_19::S_330
            | C2Rust_Block_19::S_332
            | C2Rust_Block_19::S_334
            | C2Rust_Block_19::S_336
            | C2Rust_Block_19::S_338
            | C2Rust_Block_19::S_34
            | C2Rust_Block_19::S_340
            | C2Rust_Block_19::S_342
            | C2Rust_Block_19::S_344
            | C2Rust_Block_19::S_346
            | C2Rust_Block_19::S_348
            | C2Rust_Block_19::S_350
            | C2Rust_Block_19::S_352
            | C2Rust_Block_19::S_354
            | C2Rust_Block_19::S_356
            | C2Rust_Block_19::S_358
            | C2Rust_Block_19::S_36
            | C2Rust_Block_19::S_360
            | C2Rust_Block_19::S_362
            | C2Rust_Block_19::S_364
            | C2Rust_Block_19::S_366
            | C2Rust_Block_19::S_368
            | C2Rust_Block_19::S_370
            | C2Rust_Block_19::S_372
            | C2Rust_Block_19::S_374
            | C2Rust_Block_19::S_376
            | C2Rust_Block_19::S_378
            | C2Rust_Block_19::S_38
            | C2Rust_Block_19::S_380
            | C2Rust_Block_19::S_382
            | C2Rust_Block_19::S_384
            | C2Rust_Block_19::S_386
            | C2Rust_Block_19::S_388
            | C2Rust_Block_19::S_390
            | C2Rust_Block_19::S_392
            | C2Rust_Block_19::S_394
            | C2Rust_Block_19::S_396
            | C2Rust_Block_19::S_398
            | C2Rust_Block_19::S_40
            | C2Rust_Block_19::S_400
            | C2Rust_Block_19::S_402
            | C2Rust_Block_19::S_404
            | C2Rust_Block_19::S_406
            | C2Rust_Block_19::S_408
            | C2Rust_Block_19::S_410
            | C2Rust_Block_19::S_412
            | C2Rust_Block_19::S_414
            | C2Rust_Block_19::S_416
            | C2Rust_Block_19::S_418
            | C2Rust_Block_19::S_42
            | C2Rust_Block_19::S_420
            | C2Rust_Block_19::S_422
            | C2Rust_Block_19::S_424
            | C2Rust_Block_19::S_426
            | C2Rust_Block_19::S_428
            | C2Rust_Block_19::S_430
            | C2Rust_Block_19::S_432
            | C2Rust_Block_19::S_434
            | C2Rust_Block_19::S_436
            | C2Rust_Block_19::S_438
            | C2Rust_Block_19::S_44
            | C2Rust_Block_19::S_440
            | C2Rust_Block_19::S_442
            | C2Rust_Block_19::S_444
            | C2Rust_Block_19::S_446
            | C2Rust_Block_19::S_448
            | C2Rust_Block_19::S_450
            | C2Rust_Block_19::S_452
            | C2Rust_Block_19::S_454
            | C2Rust_Block_19::S_456
            | C2Rust_Block_19::S_458
            | C2Rust_Block_19::S_46
            | C2Rust_Block_19::S_460
            | C2Rust_Block_19::S_462
            | C2Rust_Block_19::S_464
            | C2Rust_Block_19::S_466
            | C2Rust_Block_19::S_468
            | C2Rust_Block_19::S_470
            | C2Rust_Block_19::S_472
            | C2Rust_Block_19::S_474
            | C2Rust_Block_19::S_476
            | C2Rust_Block_19::S_478
            | C2Rust_Block_19::S_48
            | C2Rust_Block_19::S_480
            | C2Rust_Block_19::S_482
            | C2Rust_Block_19::S_484
            | C2Rust_Block_19::S_486
            | C2Rust_Block_19::S_488
            | C2Rust_Block_19::S_490
            | C2Rust_Block_19::S_492
            | C2Rust_Block_19::S_494
            | C2Rust_Block_19::S_496
            | C2Rust_Block_19::S_498
            | C2Rust_Block_19::S_50
            | C2Rust_Block_19::S_500
            | C2Rust_Block_19::S_502
            | C2Rust_Block_19::S_504
            | C2Rust_Block_19::S_506
            | C2Rust_Block_19::S_52
            | C2Rust_Block_19::S_54
            | C2Rust_Block_19::S_56
            | C2Rust_Block_19::S_58
            | C2Rust_Block_19::S_60
            | C2Rust_Block_19::S_62
            | C2Rust_Block_19::S_64
            | C2Rust_Block_19::S_66
            | C2Rust_Block_19::S_68
            | C2Rust_Block_19::S_70
            | C2Rust_Block_19::S_72
            | C2Rust_Block_19::S_74
            | C2Rust_Block_19::S_76
            | C2Rust_Block_19::S_78
            | C2Rust_Block_19::S_80
            | C2Rust_Block_19::S_82
            | C2Rust_Block_19::S_84
            | C2Rust_Block_19::S_86
            | C2Rust_Block_19::S_88
            | C2Rust_Block_19::S_90
            | C2Rust_Block_19::S_92
            | C2Rust_Block_19::S_94
            | C2Rust_Block_19::S_96
            | C2Rust_Block_19::S_98 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261AC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549294 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261AE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5492a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261B00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549290 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261B20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549260 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261B40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549298 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261B60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549268 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261B80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549298 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549df0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261BA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549268 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5492a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261BC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261BE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549df4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261C00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549df4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549dfc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261C20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549264 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261C40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549268 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549df8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261C60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549268 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549274 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261C80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549268 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549274 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549270 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261CA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x54929c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261CC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x54926c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261CE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261D00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261D20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261D40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261D60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261D80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261DA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261DC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261DE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549e38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261E00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549e20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261E20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261E40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261E60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549e3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261E80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261EA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x549e20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549e14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
