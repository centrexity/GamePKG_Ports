extern "C" {
    fn sqrtf(__x: ::core::ffi::c_float) -> ::core::ffi::c_float;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm1() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm3() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm2() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm4() -> *mut RecompXmm;
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_00020CD0();
    fn sub_001D94A0();
    fn sub_001DAC40();
    fn sub_001DD220();
    fn sub_001DEA90();
    fn sub_001DEBE0();
    fn sub_001E04E0();
    fn sub_001E0950();
    fn sub_001E09E0();
    fn sub_001E0C80();
    fn sub_001E0FD0();
    fn sub_001E11A0();
    fn sub_001E1200();
    fn sub_001E1300();
    fn sub_001E1320();
    fn sub_001E1710();
    fn sub_001E18F0();
    fn sub_001E1B50();
    fn sub_001E1C70();
    fn sub_001E2D90();
    fn sub_001E4460();
    fn sub_001E85D0();
    fn sub_001E8640();
    fn sub_001E8760();
    fn sub_001EB320();
    fn sub_001EB6F0();
    fn sub_001EB800();
    fn sub_001ED1A0();
    fn sub_001ED1D0();
    fn sub_001ED7C0();
    fn sub_001ED800();
    fn sub_001ED850();
    fn sub_001ED920();
    fn sub_001ED950();
    fn sub_001ED980();
    fn sub_001EDBA0();
    fn sub_001EDBD0();
    fn sub_001EDD00();
    fn sub_001F01B0();
    fn sub_001F3870();
    fn sub_001F3940();
    fn sub_001F3A60();
    fn sub_001F3D30();
    fn sub_001F4150();
    fn sub_001F4A40();
    fn sub_002087B0();
    fn sub_0024D5A0();
    fn sub_0034FC10();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_MEM(mut addr: uint32_t) -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.u[0usize] = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >((addr as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t) as usize),
    );
    r.u[1usize] = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (addr.wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    r.u[2usize] = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (addr.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    r.u[3usize] = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (addr.wrapping_add(12 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    return r;
}
#[inline]
unsafe extern "C" fn XMM_STORE(mut addr: uint32_t, mut v: RecompXmm) {
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >((addr as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t) as usize),
        v.u[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (addr.wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        v.u[1usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (addr.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        v.u[2usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (addr.wrapping_add(12 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        v.u[3usize],
    );
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F02E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b308 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_eax)) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_137: {
        if _fa == _fb {
            break 's_137;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f02fd as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001F01B0();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0310() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b300 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_esi));
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_153: {
        if _fa == _fb {
            break 's_153;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f032b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001DD220();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0350() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b308 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_esi)) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(1 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fb = 0x80 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_152: {
        's_71: {
            if _fa < _fb {
                break 's_71;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_146: {
                if _fa == _fb {
                    break 's_146;
                }
                let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                let mut _pv_2: uint32_t = 0x1f037a as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                sub_001DD220();
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi)
                .wrapping_add(0x34 as uint32_t);
            break 's_152;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi).wrapping_add(0x3c as uint32_t);
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F03A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b2fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_esi));
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_153: {
        if _fa == _fb {
            break 's_153;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f03bb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001DD220();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F03E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b304 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ebp = (*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_edi));
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    let mut _pv_4: uint32_t = 0x1f0310 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >((ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t) as usize),
        (*__gamepkg_tls_g_esi),
    );
    let mut _pv_6: uint32_t = 0x1f0423 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001ED7C0();
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f0350 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = 0x1f042f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_001ED850();
    let mut _pv_11: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    let mut _pv_12: uint32_t = 0x1f03a0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_12,
    );
    let mut _pv_13: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_13,
    );
    let mut _pv_14: uint32_t = 0x1f043b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_14,
    );
    sub_001ED800();
    _fb = 0x24 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_431: {
        if _fa == _fb {
            break 's_431;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx).wrapping_add(0x10 as uint32_t);
        let mut _pv_15: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_15,
        );
        let mut _pv_16: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_16,
        );
        let mut _pv_17: uint32_t = 0x1f044d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_17,
        );
        sub_001E04E0();
        let mut _pv_18: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_18,
        );
        let mut _pv_19: uint32_t = 0x1f0453 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_19,
        );
        sub_001DD220();
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b2d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592a8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0470() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b304 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_eax)) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_137: {
        if _fa == _fb {
            break 's_137;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f048d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001F03E0();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F04A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    let mut _pv_36: uint32_t = 0;
    let mut _pv_37: uint32_t = 0;
    let mut _pv_38: uint32_t = 0;
    let mut _pv_39: uint32_t = 0;
    let mut _pv_40: uint32_t = 0;
    let mut _pv_41: uint32_t = 0;
    let mut _pv_42: uint32_t = 0;
    let mut _pv_43: uint32_t = 0;
    let mut _pv_44: uint32_t = 0;
    let mut _pv_45: uint32_t = 0;
    let mut _pv_46: uint32_t = 0;
    let mut _pv_47: uint32_t = 0;
    let mut _pv_48: uint32_t = 0;
    let mut _pv_49: uint32_t = 0;
    let mut _pv_50: uint32_t = 0;
    let mut _pv_51: uint32_t = 0;
    let mut _pv_52: uint32_t = 0;
    let mut _pv_53: uint32_t = 0;
    let mut _pv_54: uint32_t = 0;
    let mut _pv_55: uint32_t = 0;
    let mut _pv_56: uint32_t = 0;
    let mut _pv_57: uint32_t = 0;
    let mut _pv_58: uint32_t = 0;
    let mut _pv_59: uint32_t = 0;
    let mut _pv_60: uint32_t = 0;
    let mut _pv_61: uint32_t = 0;
    let mut _pv_62: uint32_t = 0;
    let mut _pv_63: uint32_t = 0;
    let mut _pv_64: uint32_t = 0;
    let mut _pv_65: uint32_t = 0;
    let mut _pv_66: uint32_t = 0;
    let mut _pv_67: uint32_t = 0;
    let mut _pv_68: uint32_t = 0;
    let mut _pv_69: uint32_t = 0;
    let mut _pv_70: uint32_t = 0;
    let mut _pv_71: uint32_t = 0;
    let mut _pv_72: uint32_t = 0;
    let mut _pv_73: uint32_t = 0;
    let mut _pv_74: uint32_t = 0;
    let mut _pv_75: uint32_t = 0;
    let mut _pv_76: uint32_t = 0;
    let mut _pv_77: uint32_t = 0;
    let mut _pv_78: uint32_t = 0;
    let mut _pv_79: uint32_t = 0;
    let mut _pv_80: uint32_t = 0;
    let mut _pv_81: uint32_t = 0;
    let mut _pv_82: uint32_t = 0;
    let mut _pv_83: uint32_t = 0;
    let mut _pv_84: uint32_t = 0;
    let mut _pv_85: uint32_t = 0;
    let mut _pv_86: uint32_t = 0;
    let mut _pv_87: uint32_t = 0;
    let mut _pv_88: uint32_t = 0;
    let mut _pv_89: uint32_t = 0;
    let mut _pv_90: uint32_t = 0;
    let mut _pv_91: uint32_t = 0;
    let mut _pv_92: uint32_t = 0;
    let mut _pv_93: uint32_t = 0;
    let mut _pv_94: uint32_t = 0;
    let mut _pv_95: uint32_t = 0;
    let mut _pv_96: uint32_t = 0;
    let mut _pv_97: uint32_t = 0;
    let mut _pv_98: uint32_t = 0;
    let mut _pv_99: uint32_t = 0;
    let mut _pv_100: uint32_t = 0;
    let mut _pv_101: uint32_t = 0;
    let mut _pv_102: uint32_t = 0;
    let mut _pv_103: uint32_t = 0;
    let mut _pv_104: uint32_t = 0;
    let mut _pv_105: uint32_t = 0;
    let mut _pv_106: uint32_t = 0;
    let mut _pv_107: uint32_t = 0;
    let mut _pv_108: uint32_t = 0;
    let mut _pv_109: uint32_t = 0;
    let mut _pv_110: uint32_t = 0;
    let mut _pv_111: uint32_t = 0;
    let mut _pv_112: uint32_t = 0;
    let mut _pv_113: uint32_t = 0;
    let mut _pv_114: uint32_t = 0;
    let mut _pv_115: uint32_t = 0;
    let mut _pv_116: uint32_t = 0;
    let mut _pv_117: uint32_t = 0;
    enum C2Rust_Block_10 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_24,
        S_26,
        S_28,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_70,
        S_80,
        S_82,
        S_84,
        S_94,
        S_96,
        S_98,
        S_104,
        S_114,
        S_116,
        S_118,
        S_128,
        S_130,
        S_132,
        S_142,
        S_144,
        S_146,
        S_156,
        S_158,
        S_160,
        S_170,
        S_172,
        S_174,
        S_180,
        S_186,
        S_188,
        S_190,
        S_196,
        S_206,
        S_208,
        S_210,
        S_220,
        S_222,
        S_224,
        S_234,
        S_236,
        S_238,
        S_248,
        S_250,
        S_252,
        S_262,
        S_264,
        S_266,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_286,
        S_288,
        S_290,
        S_296,
        S_306,
        S_308,
        S_310,
        S_320,
        S_322,
        S_324,
        S_334,
        S_336,
        S_338,
        S_348,
        S_350,
        S_352,
        S_362,
        S_364,
        S_366,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_386,
        S_388,
        S_390,
        S_396,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_418,
        S_420,
        S_422,
        S_432,
        S_434,
        S_436,
        S_446,
        S_448,
        S_450,
        S_460,
        S_462,
        S_464,
        S_474,
        S_476,
        S_478,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_498,
        S_500,
        S_502,
        S_508,
        S_518,
        S_520,
        S_522,
        S_532,
        S_534,
        S_536,
        S_546,
        S_548,
        S_550,
        S_560,
        S_562,
        S_564,
        S_574,
        S_576,
        S_578,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_598,
        S_600,
        S_602,
        S_608,
        S_618,
        S_620,
        S_622,
        S_632,
        S_634,
        S_636,
        S_646,
        S_648,
        S_650,
        S_660,
        S_662,
        S_664,
        S_674,
        S_676,
        S_678,
        S_684,
        S_686,
        S_688,
        S_690,
        S_696,
        S_698,
        S_700,
        S_706,
        S_716,
        S_718,
        S_720,
        S_730,
        S_732,
        S_734,
        S_744,
        S_746,
        S_748,
        S_758,
        S_760,
        S_762,
        S_768,
        S_770,
        S_772,
        S_774,
        S_780,
        S_782,
        S_784,
        S_790,
        S_796,
        S_798,
        S_800,
        S_802,
        S_804,
        S_806,
        S_812,
        S_814,
        S_816,
        S_826,
        S_828,
        S_830,
        S_840,
        S_842,
        S_844,
        S_854,
        S_856,
        S_858,
        S_864,
        S_866,
        S_868,
        S_870,
        S_876,
        S_878,
        S_880,
        S_886,
        S_896,
        S_898,
        S_900,
        S_910,
        S_912,
        S_914,
        S_924,
        S_926,
        S_928,
        S_938,
        S_940,
        S_942,
        S_952,
        S_954,
        S_956,
        S_962,
        S_964,
        S_966,
        S_968,
        S_974,
        S_976,
        S_978,
        S_984,
        S_994,
        S_996,
        S_998,
        S_1008,
        S_1010,
        S_1012,
        S_1022,
        S_1024,
        S_1026,
        S_1036,
        S_1038,
        S_1040,
        S_1050,
        S_1052,
        S_1054,
        S_1060,
        S_1062,
        S_1064,
        S_1066,
        S_1072,
        S_1074,
        S_1076,
        S_1082,
        S_1088,
        S_1090,
        S_1092,
        S_1094,
        S_1100,
        S_1102,
        S_1104,
        S_1114,
        S_1116,
        S_1118,
        S_1128,
        S_1130,
        S_1132,
        S_1142,
        S_1144,
        S_1146,
        S_1156,
        S_1158,
        S_1160,
        S_1166,
        S_1172,
        S_1174,
        S_1176,
        S_1178,
        S_1180,
        S_1182,
        S_1188,
        S_1190,
        S_1192,
        S_1202,
        S_1204,
        S_1206,
        S_1216,
        S_1218,
        S_1220,
        S_1230,
        S_1232,
        S_1234,
        S_1240,
        S_1242,
        S_1244,
        S_1246,
        S_1252,
        S_1254,
        S_1256,
        S_1262,
        S_1272,
        S_1274,
        S_1276,
        S_1286,
        S_1288,
        S_1290,
        S_1300,
        S_1302,
        S_1304,
        S_1314,
        S_1316,
        S_1318,
        S_1328,
        S_1330,
        S_1332,
        S_1338,
        S_1340,
        S_1342,
        S_1344,
        S_1350,
        S_1352,
        S_1354,
        S_1360,
        S_1370,
        S_1372,
        S_1374,
        S_1384,
        S_1386,
        S_1388,
        S_1398,
        S_1400,
        S_1402,
        S_1412,
        S_1414,
        S_1416,
        S_1422,
        S_1424,
        S_1426,
        S_1428,
        S_1434,
        S_1436,
        S_1438,
        S_1444,
        S_1454,
        S_1456,
        S_1458,
        S_1468,
        S_1470,
        S_1472,
        S_1482,
        S_1484,
        S_1486,
        S_1496,
        S_1498,
        S_1500,
        S_1510,
        S_1512,
        S_1514,
        S_1520,
        S_1522,
        S_1524,
        S_1526,
        S_1532,
        S_1534,
        S_1536,
        S_1542,
        S_1548,
        S_1550,
        S_1552,
        S_1554,
        S_1556,
        S_1558,
        S_1564,
        S_1566,
        S_1568,
        S_1578,
        S_1580,
        S_1582,
        S_1592,
        S_1594,
        S_1596,
        S_1606,
        S_1608,
        S_1610,
        S_1616,
        S_1618,
        S_1620,
        S_1622,
        S_1628,
        S_1630,
        S_1632,
        S_1638,
        S_1648,
        S_1650,
        S_1652,
        S_1662,
        S_1664,
        S_1666,
        S_1676,
        S_1678,
        S_1680,
        S_1690,
        S_1692,
        S_1694,
        S_1704,
        S_1706,
        S_1708,
        S_1714,
        S_1716,
        S_1718,
        S_1720,
        S_1726,
        S_1728,
        S_1730,
        S_1736,
        S_1746,
        S_1748,
        S_1750,
        S_1760,
        S_1762,
        S_1764,
        S_1774,
        S_1776,
        S_1778,
        S_1788,
        S_1790,
        S_1792,
        S_1798,
        S_1800,
        S_1802,
        S_1804,
        S_1810,
        S_1812,
        S_1814,
        S_1820,
        S_1830,
        S_1832,
        S_1834,
        S_1844,
        S_1846,
        S_1848,
        S_1858,
        S_1860,
        S_1862,
        S_1872,
        S_1874,
        S_1876,
        S_1886,
        S_1888,
        S_1890,
        S_1896,
        S_1898,
        S_1900,
        S_1902,
        S_1908,
        S_1910,
        S_1912,
        S_1918,
        S_1924,
        S_1926,
        S_1928,
        S_1930,
        S_1932,
        S_1934,
        S_1940,
        S_1942,
        S_1944,
        S_1954,
        S_1956,
        S_1958,
        S_1968,
        S_1970,
        S_1972,
        S_1982,
        S_1984,
        S_1986,
        S_1992,
        S_1994,
        S_1996,
        S_1998,
        S_2004,
        S_2006,
        S_2008,
        S_2014,
        S_2020,
        S_2022,
        S_2024,
        S_2026,
        S_2028,
        S_2030,
        S_2032,
        S_2034,
        S_2036,
        S_2038,
        S_2044,
        S_2046,
        S_2052,
        S_2061,
        S_2063,
        S_2065,
        S_2067,
        S_2069,
        S_2071,
        S_2081,
        S_2083,
        S_2085,
        S_2091,
        S_2097,
        S_2099,
        S_2101,
        S_2103,
        S_2105,
        S_2107,
        S_2109,
        S_2111,
        S_2113,
        S_2115,
        S_2117,
        S_2119,
        S_2121,
    }
    let mut c2rust_current_block_10: C2Rust_Block_10;
    c2rust_current_block_10 = C2Rust_Block_10::S_0;
    loop {
        match c2rust_current_block_10 {
            C2Rust_Block_10::S_0 => {
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_4;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_14;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_24;
                };
                {
                    _pv = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_10 = C2Rust_Block_10::S_26;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_28;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_38;
                };
                {
                    _pv_0 = 0x1ef7f0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_40;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_42;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_52;
                };
                {
                    _pv_1 = 0x1ef730 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_54;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_56;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_66;
                };
                {
                    _pv_2 = 0x509 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_68;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_70;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_80;
                };
                {
                    _pv_3 = 0xc as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_82;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_84;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_94;
                };
                {
                    _pv_4 = 0x1f04b7 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_96;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_98;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_104;
                };
                {
                    sub_001DAC40();
                    c2rust_current_block_10 = C2Rust_Block_10::S_114;
                };
                {
                    _pv_5 = 0x1f02a0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_116;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_118;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_128;
                };
                {
                    _pv_6 = 0x1ef8a0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_130;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_132;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_142;
                };
                {
                    _pv_7 = 0x1f0250 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_144;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_146;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_156;
                };
                {
                    _pv_8 = 0x509 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_158;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_170;
                };
                {
                    _pv_9 = 0x1c as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_172;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_174;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_180;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_186;
                };
                {
                    _pv_10 = 0x1f04d4 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_188;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_190;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_196;
                };
                {
                    sub_001D94A0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_206;
                };
                {
                    _pv_11 = 0x2087b0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_208;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_210;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_220;
                };
                {
                    _pv_12 = 0x1efb10 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_222;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_224;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_234;
                };
                {
                    _pv_13 = 0x1efae0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_236;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_238;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_248;
                };
                {
                    _pv_14 = 0x509 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_250;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_252;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_14,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_262;
                };
                {
                    _pv_15 = 8 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_264;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_266;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_15,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_272;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41b2fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_274;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_276;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_278;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_280;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_286;
                };
                {
                    _pv_16 = 0x1f04f6 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_288;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_16,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_296;
                };
                {
                    sub_001ED920();
                    c2rust_current_block_10 = C2Rust_Block_10::S_306;
                };
                {
                    _pv_17 = 0x1f0470 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_308;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_310;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_17,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_320;
                };
                {
                    _pv_18 = 0x2087b0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_322;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_324;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_18,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_334;
                };
                {
                    _pv_19 = 0x1efb30 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_336;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_338;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_19,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_348;
                };
                {
                    _pv_20 = 0x509 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_350;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_352;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_20,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_362;
                };
                {
                    _pv_21 = 8 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_364;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_366;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_21,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_372;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41b300 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_374;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_376;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_378;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_380;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_386;
                };
                {
                    _pv_22 = 0x1f0518 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_388;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_390;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_22,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_396;
                };
                {
                    sub_001ED950();
                    c2rust_current_block_10 = C2Rust_Block_10::S_402;
                };
                {
                    _fb = 0x4c as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_404;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_406;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x4c as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_408;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x4c as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_410;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_412;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_418;
                };
                {
                    _pv_23 = 0x1f02e0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_420;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_422;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_23,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_432;
                };
                {
                    _pv_24 = 0x1efdb0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_434;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_436;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_24,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_446;
                };
                {
                    _pv_25 = 0x1efd90 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_448;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_450;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_25,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_460;
                };
                {
                    _pv_26 = 0x509 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_462;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_464;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_26,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_474;
                };
                {
                    _pv_27 = 8 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_476;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_478;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_27,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_484;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41b304 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_486;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_488;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_490;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_492;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_498;
                };
                {
                    _pv_28 = 0x1f053d as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_500;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_502;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_28,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_508;
                };
                {
                    sub_001F0DE0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_518;
                };
                {
                    _pv_29 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_520;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_522;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_29,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_532;
                };
                {
                    _pv_30 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_534;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_536;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_30,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_546;
                };
                {
                    _pv_31 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_548;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_550;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_31,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_560;
                };
                {
                    _pv_32 = 0x50e as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_562;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_564;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_32,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_574;
                };
                {
                    _pv_33 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_576;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_578;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_33,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_584;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41b308 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_586;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_588;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_590;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_592;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_598;
                };
                {
                    _pv_34 = 0x1f0556 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_600;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_602;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_34,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_608;
                };
                {
                    sub_001F0F50();
                    c2rust_current_block_10 = C2Rust_Block_10::S_618;
                };
                {
                    _pv_35 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_620;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_622;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_35,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_632;
                };
                {
                    _pv_36 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_634;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_636;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_36,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_646;
                };
                {
                    _pv_37 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_648;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_650;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_37,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_660;
                };
                {
                    _pv_38 = 0x50e as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_662;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_664;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_38,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_674;
                };
                {
                    _pv_39 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_676;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_678;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_39,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_684;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_686;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_688;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_690;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_696;
                };
                {
                    _pv_40 = 0x1f056a as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_698;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_700;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_40,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_706;
                };
                {
                    sub_001EDBA0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_716;
                };
                {
                    _pv_41 = 0x1f0060 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_718;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_720;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_41,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_730;
                };
                {
                    _pv_42 = 0x1f0010 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_732;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_734;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_42,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_744;
                };
                {
                    _pv_43 = 0x1f0030 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_746;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_748;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_43,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_758;
                };
                {
                    _pv_44 = 0x50e as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_760;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_762;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_44,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_768;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_770;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_772;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_774;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_780;
                };
                {
                    _pv_45 = 0x1f0585 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_782;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_784;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_45,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_790;
                };
                {
                    sub_001F0F80();
                    c2rust_current_block_10 = C2Rust_Block_10::S_796;
                };
                {
                    _fb = 0x4c as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_798;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_800;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x4c as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_802;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x4c as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_804;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_806;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_812;
                };
                {
                    _pv_46 = 0x1f0180 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_814;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_816;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_46,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_826;
                };
                {
                    _pv_47 = 0x1f0120 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_828;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_830;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_47,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_840;
                };
                {
                    _pv_48 = 0x1f0150 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_842;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_844;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_48,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_854;
                };
                {
                    _pv_49 = 0x50e as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_856;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_858;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_49,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_864;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_866;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_868;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_870;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_876;
                };
                {
                    _pv_50 = 0x1f05a3 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_878;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_880;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_50,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_886;
                };
                {
                    sub_001EDBD0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_896;
                };
                {
                    _pv_51 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_898;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_900;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_51,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_910;
                };
                {
                    _pv_52 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_912;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_914;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_52,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_924;
                };
                {
                    _pv_53 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_926;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_928;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_53,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_938;
                };
                {
                    _pv_54 = 0x510 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_940;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_942;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_54,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_952;
                };
                {
                    _pv_55 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_954;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_956;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_55,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_962;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_964;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_966;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_968;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_974;
                };
                {
                    _pv_56 = 0x1f05b7 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_976;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_978;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_56,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_984;
                };
                {
                    sub_001F0F50();
                    c2rust_current_block_10 = C2Rust_Block_10::S_994;
                };
                {
                    _pv_57 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_996;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_998;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_57,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1008;
                };
                {
                    _pv_58 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1010;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1012;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_58,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1022;
                };
                {
                    _pv_59 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1024;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1026;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_59,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1036;
                };
                {
                    _pv_60 = 0x510 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1038;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1040;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_60,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1050;
                };
                {
                    _pv_61 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1052;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1054;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_61,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1060;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1062;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1064;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1066;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1072;
                };
                {
                    _pv_62 = 0x1f05cb as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1074;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1076;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_62,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1082;
                };
                {
                    sub_001EDBA0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1088;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1090;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1092;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1094;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1100;
                };
                {
                    _pv_63 = 0x1f00c0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1102;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1104;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_63,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1114;
                };
                {
                    _pv_64 = 0x1f0080 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1116;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1118;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_64,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1128;
                };
                {
                    _pv_65 = 0x1f00a0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1130;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1132;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_65,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1142;
                };
                {
                    _pv_66 = 0x510 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1144;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1146;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_66,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1156;
                };
                {
                    _pv_67 = 0x1f05e6 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1158;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_67,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1166;
                };
                {
                    sub_001F0F80();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1172;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1174;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1176;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x48 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1178;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1180;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1182;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1188;
                };
                {
                    _pv_68 = 0x1f0110 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1190;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1192;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_68,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1202;
                };
                {
                    _pv_69 = 0x1f00d0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1204;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1206;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_69,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1216;
                };
                {
                    _pv_70 = 0x1f00f0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1218;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1220;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_70,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1230;
                };
                {
                    _pv_71 = 0x510 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1232;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1234;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_71,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1240;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1242;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1244;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1246;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1252;
                };
                {
                    _pv_72 = 0x1f0604 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1254;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1256;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_72,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1262;
                };
                {
                    sub_001EDBD0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1272;
                };
                {
                    _pv_73 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1274;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1276;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_73,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1286;
                };
                {
                    _pv_74 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1288;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_74,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1300;
                };
                {
                    _pv_75 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1302;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1304;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_75,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1314;
                };
                {
                    _pv_76 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1316;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1318;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_76,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1328;
                };
                {
                    _pv_77 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1330;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1332;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_77,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1338;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1340;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1342;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1344;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1350;
                };
                {
                    _pv_78 = 0x1f0615 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1352;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1354;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_78,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1360;
                };
                {
                    sub_001ED920();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1370;
                };
                {
                    _pv_79 = 0x1ed3b0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1372;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1374;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_79,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1384;
                };
                {
                    _pv_80 = 0x1f09b0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1386;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1388;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_80,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1398;
                };
                {
                    _pv_81 = 0x1ed370 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1400;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1402;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_81,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1412;
                };
                {
                    _pv_82 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1414;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1416;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_82,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1422;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1424;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1426;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1428;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1434;
                };
                {
                    _pv_83 = 0x1f062d as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1436;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1438;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_83,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1444;
                };
                {
                    sub_001ED980();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1454;
                };
                {
                    _pv_84 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1456;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1458;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_84,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1468;
                };
                {
                    _pv_85 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1470;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1472;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_85,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1482;
                };
                {
                    _pv_86 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1484;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1486;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_86,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1496;
                };
                {
                    _pv_87 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1498;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1500;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_87,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1510;
                };
                {
                    _pv_88 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1512;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1514;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_88,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1520;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1522;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1524;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1526;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1532;
                };
                {
                    _pv_89 = 0x1f063e as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1534;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1536;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_89,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1542;
                };
                {
                    sub_001ED1A0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1548;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1550;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1552;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x48 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1554;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1556;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1558;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1564;
                };
                {
                    _pv_90 = 0x1ed3b0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1566;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1568;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_90,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1578;
                };
                {
                    _pv_91 = 0x1f09b0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1580;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1582;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_91,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1592;
                };
                {
                    _pv_92 = 0x1f0970 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1594;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1596;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_92,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1606;
                };
                {
                    _pv_93 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1608;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1610;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_93,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1616;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1618;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1620;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1622;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1628;
                };
                {
                    _pv_94 = 0x1f0659 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1630;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1632;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_94,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1638;
                };
                {
                    sub_001ED1D0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1648;
                };
                {
                    _pv_95 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1650;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1652;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_95,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1662;
                };
                {
                    _pv_96 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1664;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1666;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_96,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1676;
                };
                {
                    _pv_97 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1678;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1680;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_97,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1690;
                };
                {
                    _pv_98 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1692;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1694;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_98,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1704;
                };
                {
                    _pv_99 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1706;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1708;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_99,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1714;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1716;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1718;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1720;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1726;
                };
                {
                    _pv_100 = 0x1f066a as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1728;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1730;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_100,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1736;
                };
                {
                    sub_001EDBA0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1746;
                };
                {
                    _pv_101 = 0x1f0a70 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1748;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1750;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_101,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1760;
                };
                {
                    _pv_102 = 0x1f0a30 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1762;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1764;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_102,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1774;
                };
                {
                    _pv_103 = 0x1f09f0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1776;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1778;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_103,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1788;
                };
                {
                    _pv_104 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1790;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1792;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_104,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1798;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1800;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1802;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1804;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1810;
                };
                {
                    _pv_105 = 0x1f0682 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1812;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1814;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_105,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1820;
                };
                {
                    sub_001EDBD0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1830;
                };
                {
                    _pv_106 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1832;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1834;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_106,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1844;
                };
                {
                    _pv_107 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1846;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1848;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_107,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1858;
                };
                {
                    _pv_108 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1860;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1862;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_108,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1872;
                };
                {
                    _pv_109 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1874;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1876;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_109,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1886;
                };
                {
                    _pv_110 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1888;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1890;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_110,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1896;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1898;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1900;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1902;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1908;
                };
                {
                    _pv_111 = 0x1f0693 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1910;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1912;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_111,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1918;
                };
                {
                    sub_001F1190();
                    c2rust_current_block_10 = C2Rust_Block_10::S_1924;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1926;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1928;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x48 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1930;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1932;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1934;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1940;
                };
                {
                    _pv_112 = 0x1f10e0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1942;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1944;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_112,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1954;
                };
                {
                    _pv_113 = 0x1f10a0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1956;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1958;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_113,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1968;
                };
                {
                    _pv_114 = 0x1f1060 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1970;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1972;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_114,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1982;
                };
                {
                    _pv_115 = 0x1f as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1984;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1986;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_115,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_1992;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1994;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        | (*__gamepkg_tls_g_eax);
                    c2rust_current_block_10 = C2Rust_Block_10::S_1996;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_1998;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2004;
                };
                {
                    _pv_116 = 0x1f06ae as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2006;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2008;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_116,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_2014;
                };
                {
                    sub_001F11C0();
                    c2rust_current_block_10 = C2Rust_Block_10::S_2020;
                };
                {
                    _fb = 0x10 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2022;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2024;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x10 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2026;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2028;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2030;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2032;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2034;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        | (*__gamepkg_tls_g_esi);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2036;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2038;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2044;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_2046;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2052;
                };
                {
                    if _fas >= 0 as int32_t {
                        c2rust_current_block_10 = C2Rust_Block_10::S_2081;
                    } else {
                        c2rust_current_block_10 = C2Rust_Block_10::S_2061;
                    }
                };
            }
            C2Rust_Block_10::S_2061 => {
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2063;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2065;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2067;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2069;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2071;
                };
                return;
            }
            C2Rust_Block_10::S_2081 => {
                {
                    _pv_117 = 0x1f06be as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2083;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2085;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_117,
                    );
                    c2rust_current_block_10 = C2Rust_Block_10::S_2091;
                };
                {
                    sub_001E8760();
                    c2rust_current_block_10 = C2Rust_Block_10::S_2097;
                };
                {
                    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2099;
                };
                {
                    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                        as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2101;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2103;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2105;
                };
                {
                    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                        0xffffffff as ::core::ffi::c_uint
                    } else {
                        0 as ::core::ffi::c_uint
                    }) as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2107;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2109;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2111;
                };
                {
                    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2113;
                };
                {
                    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                        as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2115;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2117;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_10 = C2Rust_Block_10::S_2119;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_10 = C2Rust_Block_10::S_2121;
                };
                return;
            }
            C2Rust_Block_10::S_1008
            | C2Rust_Block_10::S_1010
            | C2Rust_Block_10::S_1012
            | C2Rust_Block_10::S_1022
            | C2Rust_Block_10::S_1024
            | C2Rust_Block_10::S_1026
            | C2Rust_Block_10::S_1036
            | C2Rust_Block_10::S_1038
            | C2Rust_Block_10::S_104
            | C2Rust_Block_10::S_1040
            | C2Rust_Block_10::S_1050
            | C2Rust_Block_10::S_1052
            | C2Rust_Block_10::S_1054
            | C2Rust_Block_10::S_1060
            | C2Rust_Block_10::S_1062
            | C2Rust_Block_10::S_1064
            | C2Rust_Block_10::S_1066
            | C2Rust_Block_10::S_1072
            | C2Rust_Block_10::S_1074
            | C2Rust_Block_10::S_1076
            | C2Rust_Block_10::S_1082
            | C2Rust_Block_10::S_1088
            | C2Rust_Block_10::S_1090
            | C2Rust_Block_10::S_1092
            | C2Rust_Block_10::S_1094
            | C2Rust_Block_10::S_1100
            | C2Rust_Block_10::S_1102
            | C2Rust_Block_10::S_1104
            | C2Rust_Block_10::S_1114
            | C2Rust_Block_10::S_1116
            | C2Rust_Block_10::S_1118
            | C2Rust_Block_10::S_1128
            | C2Rust_Block_10::S_1130
            | C2Rust_Block_10::S_1132
            | C2Rust_Block_10::S_114
            | C2Rust_Block_10::S_1142
            | C2Rust_Block_10::S_1144
            | C2Rust_Block_10::S_1146
            | C2Rust_Block_10::S_1156
            | C2Rust_Block_10::S_1158
            | C2Rust_Block_10::S_116
            | C2Rust_Block_10::S_1160
            | C2Rust_Block_10::S_1166
            | C2Rust_Block_10::S_1172
            | C2Rust_Block_10::S_1174
            | C2Rust_Block_10::S_1176
            | C2Rust_Block_10::S_1178
            | C2Rust_Block_10::S_118
            | C2Rust_Block_10::S_1180
            | C2Rust_Block_10::S_1182
            | C2Rust_Block_10::S_1188
            | C2Rust_Block_10::S_1190
            | C2Rust_Block_10::S_1192
            | C2Rust_Block_10::S_1202
            | C2Rust_Block_10::S_1204
            | C2Rust_Block_10::S_1206
            | C2Rust_Block_10::S_1216
            | C2Rust_Block_10::S_1218
            | C2Rust_Block_10::S_1220
            | C2Rust_Block_10::S_1230
            | C2Rust_Block_10::S_1232
            | C2Rust_Block_10::S_1234
            | C2Rust_Block_10::S_1240
            | C2Rust_Block_10::S_1242
            | C2Rust_Block_10::S_1244
            | C2Rust_Block_10::S_1246
            | C2Rust_Block_10::S_1252
            | C2Rust_Block_10::S_1254
            | C2Rust_Block_10::S_1256
            | C2Rust_Block_10::S_1262
            | C2Rust_Block_10::S_1272
            | C2Rust_Block_10::S_1274
            | C2Rust_Block_10::S_1276
            | C2Rust_Block_10::S_128
            | C2Rust_Block_10::S_1286
            | C2Rust_Block_10::S_1288
            | C2Rust_Block_10::S_1290
            | C2Rust_Block_10::S_130
            | C2Rust_Block_10::S_1300
            | C2Rust_Block_10::S_1302
            | C2Rust_Block_10::S_1304
            | C2Rust_Block_10::S_1314
            | C2Rust_Block_10::S_1316
            | C2Rust_Block_10::S_1318
            | C2Rust_Block_10::S_132
            | C2Rust_Block_10::S_1328
            | C2Rust_Block_10::S_1330
            | C2Rust_Block_10::S_1332
            | C2Rust_Block_10::S_1338
            | C2Rust_Block_10::S_1340
            | C2Rust_Block_10::S_1342
            | C2Rust_Block_10::S_1344
            | C2Rust_Block_10::S_1350
            | C2Rust_Block_10::S_1352
            | C2Rust_Block_10::S_1354
            | C2Rust_Block_10::S_1360
            | C2Rust_Block_10::S_1370
            | C2Rust_Block_10::S_1372
            | C2Rust_Block_10::S_1374
            | C2Rust_Block_10::S_1384
            | C2Rust_Block_10::S_1386
            | C2Rust_Block_10::S_1388
            | C2Rust_Block_10::S_1398
            | C2Rust_Block_10::S_14
            | C2Rust_Block_10::S_1400
            | C2Rust_Block_10::S_1402
            | C2Rust_Block_10::S_1412
            | C2Rust_Block_10::S_1414
            | C2Rust_Block_10::S_1416
            | C2Rust_Block_10::S_142
            | C2Rust_Block_10::S_1422
            | C2Rust_Block_10::S_1424
            | C2Rust_Block_10::S_1426
            | C2Rust_Block_10::S_1428
            | C2Rust_Block_10::S_1434
            | C2Rust_Block_10::S_1436
            | C2Rust_Block_10::S_1438
            | C2Rust_Block_10::S_144
            | C2Rust_Block_10::S_1444
            | C2Rust_Block_10::S_1454
            | C2Rust_Block_10::S_1456
            | C2Rust_Block_10::S_1458
            | C2Rust_Block_10::S_146
            | C2Rust_Block_10::S_1468
            | C2Rust_Block_10::S_1470
            | C2Rust_Block_10::S_1472
            | C2Rust_Block_10::S_1482
            | C2Rust_Block_10::S_1484
            | C2Rust_Block_10::S_1486
            | C2Rust_Block_10::S_1496
            | C2Rust_Block_10::S_1498
            | C2Rust_Block_10::S_1500
            | C2Rust_Block_10::S_1510
            | C2Rust_Block_10::S_1512
            | C2Rust_Block_10::S_1514
            | C2Rust_Block_10::S_1520
            | C2Rust_Block_10::S_1522
            | C2Rust_Block_10::S_1524
            | C2Rust_Block_10::S_1526
            | C2Rust_Block_10::S_1532
            | C2Rust_Block_10::S_1534
            | C2Rust_Block_10::S_1536
            | C2Rust_Block_10::S_1542
            | C2Rust_Block_10::S_1548
            | C2Rust_Block_10::S_1550
            | C2Rust_Block_10::S_1552
            | C2Rust_Block_10::S_1554
            | C2Rust_Block_10::S_1556
            | C2Rust_Block_10::S_1558
            | C2Rust_Block_10::S_156
            | C2Rust_Block_10::S_1564
            | C2Rust_Block_10::S_1566
            | C2Rust_Block_10::S_1568
            | C2Rust_Block_10::S_1578
            | C2Rust_Block_10::S_158
            | C2Rust_Block_10::S_1580
            | C2Rust_Block_10::S_1582
            | C2Rust_Block_10::S_1592
            | C2Rust_Block_10::S_1594
            | C2Rust_Block_10::S_1596
            | C2Rust_Block_10::S_160
            | C2Rust_Block_10::S_1606
            | C2Rust_Block_10::S_1608
            | C2Rust_Block_10::S_1610
            | C2Rust_Block_10::S_1616
            | C2Rust_Block_10::S_1618
            | C2Rust_Block_10::S_1620
            | C2Rust_Block_10::S_1622
            | C2Rust_Block_10::S_1628
            | C2Rust_Block_10::S_1630
            | C2Rust_Block_10::S_1632
            | C2Rust_Block_10::S_1638
            | C2Rust_Block_10::S_1648
            | C2Rust_Block_10::S_1650
            | C2Rust_Block_10::S_1652
            | C2Rust_Block_10::S_1662
            | C2Rust_Block_10::S_1664
            | C2Rust_Block_10::S_1666
            | C2Rust_Block_10::S_1676
            | C2Rust_Block_10::S_1678
            | C2Rust_Block_10::S_1680
            | C2Rust_Block_10::S_1690
            | C2Rust_Block_10::S_1692
            | C2Rust_Block_10::S_1694
            | C2Rust_Block_10::S_170
            | C2Rust_Block_10::S_1704
            | C2Rust_Block_10::S_1706
            | C2Rust_Block_10::S_1708
            | C2Rust_Block_10::S_1714
            | C2Rust_Block_10::S_1716
            | C2Rust_Block_10::S_1718
            | C2Rust_Block_10::S_172
            | C2Rust_Block_10::S_1720
            | C2Rust_Block_10::S_1726
            | C2Rust_Block_10::S_1728
            | C2Rust_Block_10::S_1730
            | C2Rust_Block_10::S_1736
            | C2Rust_Block_10::S_174
            | C2Rust_Block_10::S_1746
            | C2Rust_Block_10::S_1748
            | C2Rust_Block_10::S_1750
            | C2Rust_Block_10::S_1760
            | C2Rust_Block_10::S_1762
            | C2Rust_Block_10::S_1764
            | C2Rust_Block_10::S_1774
            | C2Rust_Block_10::S_1776
            | C2Rust_Block_10::S_1778
            | C2Rust_Block_10::S_1788
            | C2Rust_Block_10::S_1790
            | C2Rust_Block_10::S_1792
            | C2Rust_Block_10::S_1798
            | C2Rust_Block_10::S_180
            | C2Rust_Block_10::S_1800
            | C2Rust_Block_10::S_1802
            | C2Rust_Block_10::S_1804
            | C2Rust_Block_10::S_1810
            | C2Rust_Block_10::S_1812
            | C2Rust_Block_10::S_1814
            | C2Rust_Block_10::S_1820
            | C2Rust_Block_10::S_1830
            | C2Rust_Block_10::S_1832
            | C2Rust_Block_10::S_1834
            | C2Rust_Block_10::S_1844
            | C2Rust_Block_10::S_1846
            | C2Rust_Block_10::S_1848
            | C2Rust_Block_10::S_1858
            | C2Rust_Block_10::S_186
            | C2Rust_Block_10::S_1860
            | C2Rust_Block_10::S_1862
            | C2Rust_Block_10::S_1872
            | C2Rust_Block_10::S_1874
            | C2Rust_Block_10::S_1876
            | C2Rust_Block_10::S_188
            | C2Rust_Block_10::S_1886
            | C2Rust_Block_10::S_1888
            | C2Rust_Block_10::S_1890
            | C2Rust_Block_10::S_1896
            | C2Rust_Block_10::S_1898
            | C2Rust_Block_10::S_190
            | C2Rust_Block_10::S_1900
            | C2Rust_Block_10::S_1902
            | C2Rust_Block_10::S_1908
            | C2Rust_Block_10::S_1910
            | C2Rust_Block_10::S_1912
            | C2Rust_Block_10::S_1918
            | C2Rust_Block_10::S_1924
            | C2Rust_Block_10::S_1926
            | C2Rust_Block_10::S_1928
            | C2Rust_Block_10::S_1930
            | C2Rust_Block_10::S_1932
            | C2Rust_Block_10::S_1934
            | C2Rust_Block_10::S_1940
            | C2Rust_Block_10::S_1942
            | C2Rust_Block_10::S_1944
            | C2Rust_Block_10::S_1954
            | C2Rust_Block_10::S_1956
            | C2Rust_Block_10::S_1958
            | C2Rust_Block_10::S_196
            | C2Rust_Block_10::S_1968
            | C2Rust_Block_10::S_1970
            | C2Rust_Block_10::S_1972
            | C2Rust_Block_10::S_1982
            | C2Rust_Block_10::S_1984
            | C2Rust_Block_10::S_1986
            | C2Rust_Block_10::S_1992
            | C2Rust_Block_10::S_1994
            | C2Rust_Block_10::S_1996
            | C2Rust_Block_10::S_1998
            | C2Rust_Block_10::S_2
            | C2Rust_Block_10::S_2004
            | C2Rust_Block_10::S_2006
            | C2Rust_Block_10::S_2008
            | C2Rust_Block_10::S_2014
            | C2Rust_Block_10::S_2020
            | C2Rust_Block_10::S_2022
            | C2Rust_Block_10::S_2024
            | C2Rust_Block_10::S_2026
            | C2Rust_Block_10::S_2028
            | C2Rust_Block_10::S_2030
            | C2Rust_Block_10::S_2032
            | C2Rust_Block_10::S_2034
            | C2Rust_Block_10::S_2036
            | C2Rust_Block_10::S_2038
            | C2Rust_Block_10::S_2044
            | C2Rust_Block_10::S_2046
            | C2Rust_Block_10::S_2052
            | C2Rust_Block_10::S_206
            | C2Rust_Block_10::S_2063
            | C2Rust_Block_10::S_2065
            | C2Rust_Block_10::S_2067
            | C2Rust_Block_10::S_2069
            | C2Rust_Block_10::S_2071
            | C2Rust_Block_10::S_208
            | C2Rust_Block_10::S_2083
            | C2Rust_Block_10::S_2085
            | C2Rust_Block_10::S_2091
            | C2Rust_Block_10::S_2097
            | C2Rust_Block_10::S_2099
            | C2Rust_Block_10::S_210
            | C2Rust_Block_10::S_2101
            | C2Rust_Block_10::S_2103
            | C2Rust_Block_10::S_2105
            | C2Rust_Block_10::S_2107
            | C2Rust_Block_10::S_2109
            | C2Rust_Block_10::S_2111
            | C2Rust_Block_10::S_2113
            | C2Rust_Block_10::S_2115
            | C2Rust_Block_10::S_2117
            | C2Rust_Block_10::S_2119
            | C2Rust_Block_10::S_2121
            | C2Rust_Block_10::S_220
            | C2Rust_Block_10::S_222
            | C2Rust_Block_10::S_224
            | C2Rust_Block_10::S_234
            | C2Rust_Block_10::S_236
            | C2Rust_Block_10::S_238
            | C2Rust_Block_10::S_24
            | C2Rust_Block_10::S_248
            | C2Rust_Block_10::S_250
            | C2Rust_Block_10::S_252
            | C2Rust_Block_10::S_26
            | C2Rust_Block_10::S_262
            | C2Rust_Block_10::S_264
            | C2Rust_Block_10::S_266
            | C2Rust_Block_10::S_272
            | C2Rust_Block_10::S_274
            | C2Rust_Block_10::S_276
            | C2Rust_Block_10::S_278
            | C2Rust_Block_10::S_28
            | C2Rust_Block_10::S_280
            | C2Rust_Block_10::S_286
            | C2Rust_Block_10::S_288
            | C2Rust_Block_10::S_290
            | C2Rust_Block_10::S_296
            | C2Rust_Block_10::S_306
            | C2Rust_Block_10::S_308
            | C2Rust_Block_10::S_310
            | C2Rust_Block_10::S_320
            | C2Rust_Block_10::S_322
            | C2Rust_Block_10::S_324
            | C2Rust_Block_10::S_334
            | C2Rust_Block_10::S_336
            | C2Rust_Block_10::S_338
            | C2Rust_Block_10::S_348
            | C2Rust_Block_10::S_350
            | C2Rust_Block_10::S_352
            | C2Rust_Block_10::S_362
            | C2Rust_Block_10::S_364
            | C2Rust_Block_10::S_366
            | C2Rust_Block_10::S_372
            | C2Rust_Block_10::S_374
            | C2Rust_Block_10::S_376
            | C2Rust_Block_10::S_378
            | C2Rust_Block_10::S_38
            | C2Rust_Block_10::S_380
            | C2Rust_Block_10::S_386
            | C2Rust_Block_10::S_388
            | C2Rust_Block_10::S_390
            | C2Rust_Block_10::S_396
            | C2Rust_Block_10::S_4
            | C2Rust_Block_10::S_40
            | C2Rust_Block_10::S_402
            | C2Rust_Block_10::S_404
            | C2Rust_Block_10::S_406
            | C2Rust_Block_10::S_408
            | C2Rust_Block_10::S_410
            | C2Rust_Block_10::S_412
            | C2Rust_Block_10::S_418
            | C2Rust_Block_10::S_42
            | C2Rust_Block_10::S_420
            | C2Rust_Block_10::S_422
            | C2Rust_Block_10::S_432
            | C2Rust_Block_10::S_434
            | C2Rust_Block_10::S_436
            | C2Rust_Block_10::S_446
            | C2Rust_Block_10::S_448
            | C2Rust_Block_10::S_450
            | C2Rust_Block_10::S_460
            | C2Rust_Block_10::S_462
            | C2Rust_Block_10::S_464
            | C2Rust_Block_10::S_474
            | C2Rust_Block_10::S_476
            | C2Rust_Block_10::S_478
            | C2Rust_Block_10::S_484
            | C2Rust_Block_10::S_486
            | C2Rust_Block_10::S_488
            | C2Rust_Block_10::S_490
            | C2Rust_Block_10::S_492
            | C2Rust_Block_10::S_498
            | C2Rust_Block_10::S_500
            | C2Rust_Block_10::S_502
            | C2Rust_Block_10::S_508
            | C2Rust_Block_10::S_518
            | C2Rust_Block_10::S_52
            | C2Rust_Block_10::S_520
            | C2Rust_Block_10::S_522
            | C2Rust_Block_10::S_532
            | C2Rust_Block_10::S_534
            | C2Rust_Block_10::S_536
            | C2Rust_Block_10::S_54
            | C2Rust_Block_10::S_546
            | C2Rust_Block_10::S_548
            | C2Rust_Block_10::S_550
            | C2Rust_Block_10::S_56
            | C2Rust_Block_10::S_560
            | C2Rust_Block_10::S_562
            | C2Rust_Block_10::S_564
            | C2Rust_Block_10::S_574
            | C2Rust_Block_10::S_576
            | C2Rust_Block_10::S_578
            | C2Rust_Block_10::S_584
            | C2Rust_Block_10::S_586
            | C2Rust_Block_10::S_588
            | C2Rust_Block_10::S_590
            | C2Rust_Block_10::S_592
            | C2Rust_Block_10::S_598
            | C2Rust_Block_10::S_600
            | C2Rust_Block_10::S_602
            | C2Rust_Block_10::S_608
            | C2Rust_Block_10::S_618
            | C2Rust_Block_10::S_620
            | C2Rust_Block_10::S_622
            | C2Rust_Block_10::S_632
            | C2Rust_Block_10::S_634
            | C2Rust_Block_10::S_636
            | C2Rust_Block_10::S_646
            | C2Rust_Block_10::S_648
            | C2Rust_Block_10::S_650
            | C2Rust_Block_10::S_66
            | C2Rust_Block_10::S_660
            | C2Rust_Block_10::S_662
            | C2Rust_Block_10::S_664
            | C2Rust_Block_10::S_674
            | C2Rust_Block_10::S_676
            | C2Rust_Block_10::S_678
            | C2Rust_Block_10::S_68
            | C2Rust_Block_10::S_684
            | C2Rust_Block_10::S_686
            | C2Rust_Block_10::S_688
            | C2Rust_Block_10::S_690
            | C2Rust_Block_10::S_696
            | C2Rust_Block_10::S_698
            | C2Rust_Block_10::S_70
            | C2Rust_Block_10::S_700
            | C2Rust_Block_10::S_706
            | C2Rust_Block_10::S_716
            | C2Rust_Block_10::S_718
            | C2Rust_Block_10::S_720
            | C2Rust_Block_10::S_730
            | C2Rust_Block_10::S_732
            | C2Rust_Block_10::S_734
            | C2Rust_Block_10::S_744
            | C2Rust_Block_10::S_746
            | C2Rust_Block_10::S_748
            | C2Rust_Block_10::S_758
            | C2Rust_Block_10::S_760
            | C2Rust_Block_10::S_762
            | C2Rust_Block_10::S_768
            | C2Rust_Block_10::S_770
            | C2Rust_Block_10::S_772
            | C2Rust_Block_10::S_774
            | C2Rust_Block_10::S_780
            | C2Rust_Block_10::S_782
            | C2Rust_Block_10::S_784
            | C2Rust_Block_10::S_790
            | C2Rust_Block_10::S_796
            | C2Rust_Block_10::S_798
            | C2Rust_Block_10::S_80
            | C2Rust_Block_10::S_800
            | C2Rust_Block_10::S_802
            | C2Rust_Block_10::S_804
            | C2Rust_Block_10::S_806
            | C2Rust_Block_10::S_812
            | C2Rust_Block_10::S_814
            | C2Rust_Block_10::S_816
            | C2Rust_Block_10::S_82
            | C2Rust_Block_10::S_826
            | C2Rust_Block_10::S_828
            | C2Rust_Block_10::S_830
            | C2Rust_Block_10::S_84
            | C2Rust_Block_10::S_840
            | C2Rust_Block_10::S_842
            | C2Rust_Block_10::S_844
            | C2Rust_Block_10::S_854
            | C2Rust_Block_10::S_856
            | C2Rust_Block_10::S_858
            | C2Rust_Block_10::S_864
            | C2Rust_Block_10::S_866
            | C2Rust_Block_10::S_868
            | C2Rust_Block_10::S_870
            | C2Rust_Block_10::S_876
            | C2Rust_Block_10::S_878
            | C2Rust_Block_10::S_880
            | C2Rust_Block_10::S_886
            | C2Rust_Block_10::S_896
            | C2Rust_Block_10::S_898
            | C2Rust_Block_10::S_900
            | C2Rust_Block_10::S_910
            | C2Rust_Block_10::S_912
            | C2Rust_Block_10::S_914
            | C2Rust_Block_10::S_924
            | C2Rust_Block_10::S_926
            | C2Rust_Block_10::S_928
            | C2Rust_Block_10::S_938
            | C2Rust_Block_10::S_94
            | C2Rust_Block_10::S_940
            | C2Rust_Block_10::S_942
            | C2Rust_Block_10::S_952
            | C2Rust_Block_10::S_954
            | C2Rust_Block_10::S_956
            | C2Rust_Block_10::S_96
            | C2Rust_Block_10::S_962
            | C2Rust_Block_10::S_964
            | C2Rust_Block_10::S_966
            | C2Rust_Block_10::S_968
            | C2Rust_Block_10::S_974
            | C2Rust_Block_10::S_976
            | C2Rust_Block_10::S_978
            | C2Rust_Block_10::S_98
            | C2Rust_Block_10::S_984
            | C2Rust_Block_10::S_994
            | C2Rust_Block_10::S_996
            | C2Rust_Block_10::S_998 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F06D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_45: {
        if _fa != _fb {
            break 's_45;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592f8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592e0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F06F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_45: {
        if _fa != _fb {
            break 's_45;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592f4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592dc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0710() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0x1f0715 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001F0880();
    let mut _pv_0: uint32_t = 0x1f071a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001F0930();
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00020CD0();
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0720() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x1f0725 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001E8760();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_143: {
        if _fa == _fb {
            break 's_143;
        }
        let mut _pv_0: uint32_t = 0x1f072e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_001F08C0();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_143;
        }
        let mut _pv_1: uint32_t = 0x1f0737 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_001F0810();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_143;
        }
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_2: uint32_t = 0x1f0746 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F0880();
    let mut _pv_3: uint32_t = 0x1f074b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001F0930();
    let mut _pv_4: uint32_t = 0x1f0750 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_00020CD0();
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0760() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >((ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t) as usize),
    );
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_353: {
        if _fa == _fb {
            break 's_353;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_esi) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_204: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                <= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_204;
            }
            loop {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                let mut _pv_4: uint32_t = 0x1f0789 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                sub_001F11F0();
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_204;
                }
            }
        }
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_6: uint32_t = 0x1f079f as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_313: {
            's_264: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_264;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_313;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_272: {
                if !_fn.is_none() {
                    break 's_272;
                }
                _fn = recomp_lookup(_va);
            }
            's_278: {
                if !_fn.is_none() {
                    break 's_278;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_284: {
                if _fn.is_some() {
                    break 's_284;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_313;
            }
            _fn.expect("non-null function pointer")();
        }
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >((ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t) as usize),
            0 as uint32_t,
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F07C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t))
                as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F07D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    's_133: {
        's_117: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                <= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_117;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
            loop {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub(4 as uint32_t);
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_133;
                }
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    <= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_117;
                }
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0800() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = 0x1f0805 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001F3A60();
    let mut _pv_0: uint32_t = 0x1f080a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001F3870();
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0810() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f0817 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001E85D0();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_441: {
        if _fa == _fb {
            break 's_441;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint32_t,
        );
        let mut _pv_3: uint32_t = 0x1f082a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001EB6F0();
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_393: {
            if _fa == _fb {
                break 's_393;
            }
            let mut _pv_4: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x1f083a as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_001F3D30();
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = 0x1f0843 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            sub_001EB800();
            let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            let mut _pv_11: uint32_t = 0x1f0849 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_11,
            );
            sub_001EB320();
            _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x14 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_393;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_12: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_12,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x7592f8 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
            let mut _pv_13: uint32_t = 0x1f0861 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_13,
            );
            sub_001F06D0();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        let mut _pv_14: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_14,
        );
        let mut _pv_15: uint32_t = 0x1f0872 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_15,
        );
        sub_001E8640();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0880() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1f0887 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001F06D0();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7592f8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_139: {
        if _fa == _fb {
            break 's_139;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f089f as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001E8640();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592f8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    let mut _pv_3: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f08bb as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001F4150();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F08C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f08c7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001E85D0();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_441: {
        if _fa == _fb {
            break 's_441;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint32_t,
        );
        let mut _pv_3: uint32_t = 0x1f08da as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001EB6F0();
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_393: {
            if _fa == _fb {
                break 's_393;
            }
            let mut _pv_4: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x1f08ea as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_001F4A40();
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = 0x1f08f3 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            sub_001EB800();
            let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            let mut _pv_11: uint32_t = 0x1f08f9 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_11,
            );
            sub_001EB320();
            _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x14 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_393;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_12: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_12,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x7592f4 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
            let mut _pv_13: uint32_t = 0x1f0911 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_13,
            );
            sub_001F06F0();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        let mut _pv_14: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_14,
        );
        let mut _pv_15: uint32_t = 0x1f0922 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_15,
        );
        sub_001E8640();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0930() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x1f0935 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001F3940();
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f093c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001F06F0();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7592f4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_155: {
        if _fa == _fb {
            break 's_155;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x1f0954 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001E8640();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7591d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592f4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0970() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x41b310 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f0982 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001E1320();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_255: {
            if _fa != _fb {
                break 's_255;
            }
            let mut _pv_4: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x41b318 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0x1f099d as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_001E1320();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_229;
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F09B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0x2c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
        .wrapping_add(0x2c as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f09c9 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001E1300();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_191: {
        if _fa != _fb {
            break 's_191;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_5: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
        .wrapping_add(0x30 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(0x30 as uint32_t);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f09e2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_001E1300();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F09F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x41b30c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f0a02 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001E1320();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_255: {
            if _fa != _fb {
                break 's_255;
            }
            let mut _pv_4: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x41b314 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0x1f0a1d as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_001E1320();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_229;
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0A30() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0x2c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
        .wrapping_add(0x2c as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f0a49 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001E1300();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_191: {
        if _fa != _fb {
            break 's_191;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_5: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
        .wrapping_add(0x30 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(0x30 as uint32_t);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f0a62 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_001E1300();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0A70() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_68: {
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_eax) = 8 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0A90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_sub(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0AA0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0AB0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let __gamepkg_tls_g_xmm3 = unsafe { gamepkg_tls_g_xmm3() };
    let __gamepkg_tls_g_xmm4 = unsafe { gamepkg_tls_g_xmm4() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _fp_value_3: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_36 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_95,
        S_97,
        S_99,
        S_101,
        S_103,
        S_112,
        S_114,
        S_120,
        S_122,
        S_124,
        S_130,
        S_136,
        S_138,
        S_144,
        S_146,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_186,
        S_188,
        S_194,
        S_196,
        S_198,
        S_204,
        S_210,
        S_212,
        S_218,
        S_220,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_292,
        S_294,
        S_296,
        S_302,
        S_308,
        S_310,
        S_316,
        S_318,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_423,
        S_429,
        S_431,
        S_433,
        S_439,
        S_445,
        S_447,
        S_453,
        S_455,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_473,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_497,
        S_499,
        S_501,
        S_503,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_517,
        S_519,
        S_521,
        S_523,
        S_525,
        S_527,
        S_529,
        S_531,
        S_533,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_567,
        S_569,
        S_571,
        S_577,
        S_583,
        S_585,
        S_591,
        S_593,
    }
    let mut c2rust_current_block_36: C2Rust_Block_36;
    c2rust_current_block_36 = C2Rust_Block_36::S_0;
    loop {
        match c2rust_current_block_36 {
            C2Rust_Block_36::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_36 = C2Rust_Block_36::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_36 = C2Rust_Block_36::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_26;
                };
                {
                    _pv = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_30;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_36;
                };
                {
                    ebp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_36 = C2Rust_Block_36::S_38;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_40;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_42;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        & 0xfffffff0 as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_44;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_46;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_48;
                };
                {
                    _fb = 0x20 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_50;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_52;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x20 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_54;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_56;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_58;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_60;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
                    c2rust_current_block_36 = C2Rust_Block_36::S_62;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_64;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_66;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_68;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_70;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_36 = C2Rust_Block_36::S_72;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0x7fffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_74;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_76;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_78;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_80;
                };
                {
                    _fb = 0x3f800000 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_82;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_84;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_86;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        < if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_36 = C2Rust_Block_36::S_152;
                    } else {
                        c2rust_current_block_36 = C2Rust_Block_36::S_95;
                    }
                };
            }
            C2Rust_Block_36::S_95 => {
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_97;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_99;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_101;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_103;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        > if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_36 = C2Rust_Block_36::S_423;
                    } else {
                        c2rust_current_block_36 = C2Rust_Block_36::S_112;
                    }
                };
            }
            C2Rust_Block_36::S_112 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_114;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_120;
                };
                {
                    _fp_value = ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_36 = C2Rust_Block_36::S_122;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_36 = C2Rust_Block_36::S_124;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                    c2rust_current_block_36 = C2Rust_Block_36::S_130;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_136;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_138;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_144;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_146;
                };
                return;
            }
            C2Rust_Block_36::S_152 => {
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_154;
                };
                {
                    _fb = 0x3f000000 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_156;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_158;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_160;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_36 = C2Rust_Block_36::S_324;
                    } else {
                        c2rust_current_block_36 = C2Rust_Block_36::S_169;
                    }
                };
            }
            C2Rust_Block_36::S_169 => {
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_171;
                };
                {
                    _fb = 0x23000000 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_173;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_175;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_177;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        > if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_36 = C2Rust_Block_36::S_226;
                    } else {
                        c2rust_current_block_36 = C2Rust_Block_36::S_186;
                    }
                };
            }
            C2Rust_Block_36::S_186 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_188;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_194;
                };
                {
                    _fp_value_0 = ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_36 = C2Rust_Block_36::S_196;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_36 = C2Rust_Block_36::S_198;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                    c2rust_current_block_36 = C2Rust_Block_36::S_204;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_210;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_212;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_218;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_220;
                };
                return;
            }
            C2Rust_Block_36::S_226 => {
                {
                    (*__gamepkg_tls_g_xmm0) = (*__gamepkg_tls_g_xmm1);
                    c2rust_current_block_36 = C2Rust_Block_36::S_228;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        * (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_230;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_232;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_234;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_236;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_238;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_240;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_242;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_244;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_246;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_248;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_250;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_252;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d69c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_254;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_256;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_258;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_260;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b19f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_262;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_264;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_266;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_268;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_270;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_272;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_274;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        / (*__gamepkg_tls_g_xmm3).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_276;
                };
                {
                    (*__gamepkg_tls_g_xmm2).f[0usize] = (*__gamepkg_tls_g_xmm2).f[0usize]
                        * (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_278;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        - (*__gamepkg_tls_g_xmm2).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_280;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_282;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d68c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_284;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        - (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_286;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_292;
                };
                {
                    _fp_value_1 = ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_36 = C2Rust_Block_36::S_294;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_36 = C2Rust_Block_36::S_296;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                    c2rust_current_block_36 = C2Rust_Block_36::S_302;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_308;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_310;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_316;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_318;
                };
                return;
            }
            C2Rust_Block_36::S_324 => {
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_326;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_328;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_330;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_332;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_36 = C2Rust_Block_36::S_461;
                    } else {
                        c2rust_current_block_36 = C2Rust_Block_36::S_341;
                    }
                };
            }
            C2Rust_Block_36::S_341 => {
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_343;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + (*__gamepkg_tls_g_xmm2).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_345;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_347;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = (*__gamepkg_tls_g_xmm1);
                    c2rust_current_block_36 = C2Rust_Block_36::S_349;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_351;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_353;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_355;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d69c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_357;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_359;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_361;
                };
                {
                    XMM_STORE(
                        (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t),
                        (*__gamepkg_tls_g_xmm0),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_363;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = sqrtf(
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_365;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_367;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_MEM(
                        (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_369;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_371;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_373;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_375;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_377;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_379;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_381;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_383;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_385;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_387;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_389;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_391;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b19f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_393;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_395;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_397;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_399;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_401;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_403;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        + (*__gamepkg_tls_g_xmm2).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_405;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        / (*__gamepkg_tls_g_xmm3).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_407;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_409;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_411;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_413;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_415;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_417;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        - (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_423;
                };
            }
            C2Rust_Block_36::S_423 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_429;
                };
                {
                    _fp_value_2 = ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_36 = C2Rust_Block_36::S_431;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_36 = C2Rust_Block_36::S_433;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                    c2rust_current_block_36 = C2Rust_Block_36::S_439;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_445;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_447;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_453;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_455;
                };
                return;
            }
            C2Rust_Block_36::S_461 => {
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_463;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = (*__gamepkg_tls_g_xmm3);
                    c2rust_current_block_36 = C2Rust_Block_36::S_465;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        - (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_467;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_469;
                };
                {
                    (*__gamepkg_tls_g_xmm4) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_471;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_473;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_475;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_477;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_479;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_481;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_483;
                };
                {
                    XMM_STORE(
                        (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t),
                        (*__gamepkg_tls_g_xmm0),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_485;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = sqrtf(
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_487;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_489;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_MEM(
                        (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_491;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_493;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_495;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_497;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_499;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_501;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_503;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b19f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_505;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = (*__gamepkg_tls_g_xmm0);
                    c2rust_current_block_36 = C2Rust_Block_36::S_507;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d6a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_509;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d69c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_511;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_513;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_515;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_517;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        - ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x36d694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_519;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_521;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_523;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_525;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        * (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_527;
                };
                {
                    (*__gamepkg_tls_g_xmm1).f[0usize] = (*__gamepkg_tls_g_xmm1).f[0usize]
                        + (*__gamepkg_tls_g_xmm3).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_529;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        / (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_531;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xfffff000 as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_533;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_535;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_36 = C2Rust_Block_36::S_537;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_539;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_541;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = (*__gamepkg_tls_g_xmm1);
                    c2rust_current_block_36 = C2Rust_Block_36::S_543;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        * (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_545;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        - (*__gamepkg_tls_g_xmm3).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_547;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * (*__gamepkg_tls_g_xmm2).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_549;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = (*__gamepkg_tls_g_xmm1);
                    c2rust_current_block_36 = C2Rust_Block_36::S_551;
                };
                {
                    (*__gamepkg_tls_g_xmm3).f[0usize] = (*__gamepkg_tls_g_xmm3).f[0usize]
                        + (*__gamepkg_tls_g_xmm2).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_553;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                        / (*__gamepkg_tls_g_xmm3).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_555;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        + (*__gamepkg_tls_g_xmm0).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_557;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        + (*__gamepkg_tls_g_xmm1).f[0usize];
                    c2rust_current_block_36 = C2Rust_Block_36::S_559;
                };
                {
                    (*__gamepkg_tls_g_xmm4).f[0usize] = (*__gamepkg_tls_g_xmm4).f[0usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_36 = C2Rust_Block_36::S_561;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_567;
                };
                {
                    _fp_value_3 = ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_36 = C2Rust_Block_36::S_569;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_36 = C2Rust_Block_36::S_571;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
                    c2rust_current_block_36 = C2Rust_Block_36::S_577;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_36 = C2Rust_Block_36::S_583;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_36 = C2Rust_Block_36::S_585;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_591;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_36 = C2Rust_Block_36::S_593;
                };
                return;
            }
            C2Rust_Block_36::S_101
            | C2Rust_Block_36::S_103
            | C2Rust_Block_36::S_114
            | C2Rust_Block_36::S_120
            | C2Rust_Block_36::S_122
            | C2Rust_Block_36::S_124
            | C2Rust_Block_36::S_130
            | C2Rust_Block_36::S_136
            | C2Rust_Block_36::S_138
            | C2Rust_Block_36::S_144
            | C2Rust_Block_36::S_146
            | C2Rust_Block_36::S_154
            | C2Rust_Block_36::S_156
            | C2Rust_Block_36::S_158
            | C2Rust_Block_36::S_160
            | C2Rust_Block_36::S_171
            | C2Rust_Block_36::S_173
            | C2Rust_Block_36::S_175
            | C2Rust_Block_36::S_177
            | C2Rust_Block_36::S_188
            | C2Rust_Block_36::S_194
            | C2Rust_Block_36::S_196
            | C2Rust_Block_36::S_198
            | C2Rust_Block_36::S_2
            | C2Rust_Block_36::S_204
            | C2Rust_Block_36::S_210
            | C2Rust_Block_36::S_212
            | C2Rust_Block_36::S_218
            | C2Rust_Block_36::S_220
            | C2Rust_Block_36::S_228
            | C2Rust_Block_36::S_230
            | C2Rust_Block_36::S_232
            | C2Rust_Block_36::S_234
            | C2Rust_Block_36::S_236
            | C2Rust_Block_36::S_238
            | C2Rust_Block_36::S_240
            | C2Rust_Block_36::S_242
            | C2Rust_Block_36::S_244
            | C2Rust_Block_36::S_246
            | C2Rust_Block_36::S_248
            | C2Rust_Block_36::S_250
            | C2Rust_Block_36::S_252
            | C2Rust_Block_36::S_254
            | C2Rust_Block_36::S_256
            | C2Rust_Block_36::S_258
            | C2Rust_Block_36::S_26
            | C2Rust_Block_36::S_260
            | C2Rust_Block_36::S_262
            | C2Rust_Block_36::S_264
            | C2Rust_Block_36::S_266
            | C2Rust_Block_36::S_268
            | C2Rust_Block_36::S_270
            | C2Rust_Block_36::S_272
            | C2Rust_Block_36::S_274
            | C2Rust_Block_36::S_276
            | C2Rust_Block_36::S_278
            | C2Rust_Block_36::S_28
            | C2Rust_Block_36::S_280
            | C2Rust_Block_36::S_282
            | C2Rust_Block_36::S_284
            | C2Rust_Block_36::S_286
            | C2Rust_Block_36::S_292
            | C2Rust_Block_36::S_294
            | C2Rust_Block_36::S_296
            | C2Rust_Block_36::S_30
            | C2Rust_Block_36::S_302
            | C2Rust_Block_36::S_308
            | C2Rust_Block_36::S_310
            | C2Rust_Block_36::S_316
            | C2Rust_Block_36::S_318
            | C2Rust_Block_36::S_326
            | C2Rust_Block_36::S_328
            | C2Rust_Block_36::S_330
            | C2Rust_Block_36::S_332
            | C2Rust_Block_36::S_343
            | C2Rust_Block_36::S_345
            | C2Rust_Block_36::S_347
            | C2Rust_Block_36::S_349
            | C2Rust_Block_36::S_351
            | C2Rust_Block_36::S_353
            | C2Rust_Block_36::S_355
            | C2Rust_Block_36::S_357
            | C2Rust_Block_36::S_359
            | C2Rust_Block_36::S_36
            | C2Rust_Block_36::S_361
            | C2Rust_Block_36::S_363
            | C2Rust_Block_36::S_365
            | C2Rust_Block_36::S_367
            | C2Rust_Block_36::S_369
            | C2Rust_Block_36::S_371
            | C2Rust_Block_36::S_373
            | C2Rust_Block_36::S_375
            | C2Rust_Block_36::S_377
            | C2Rust_Block_36::S_379
            | C2Rust_Block_36::S_38
            | C2Rust_Block_36::S_381
            | C2Rust_Block_36::S_383
            | C2Rust_Block_36::S_385
            | C2Rust_Block_36::S_387
            | C2Rust_Block_36::S_389
            | C2Rust_Block_36::S_391
            | C2Rust_Block_36::S_393
            | C2Rust_Block_36::S_395
            | C2Rust_Block_36::S_397
            | C2Rust_Block_36::S_399
            | C2Rust_Block_36::S_4
            | C2Rust_Block_36::S_40
            | C2Rust_Block_36::S_401
            | C2Rust_Block_36::S_403
            | C2Rust_Block_36::S_405
            | C2Rust_Block_36::S_407
            | C2Rust_Block_36::S_409
            | C2Rust_Block_36::S_411
            | C2Rust_Block_36::S_413
            | C2Rust_Block_36::S_415
            | C2Rust_Block_36::S_417
            | C2Rust_Block_36::S_42
            | C2Rust_Block_36::S_429
            | C2Rust_Block_36::S_431
            | C2Rust_Block_36::S_433
            | C2Rust_Block_36::S_439
            | C2Rust_Block_36::S_44
            | C2Rust_Block_36::S_445
            | C2Rust_Block_36::S_447
            | C2Rust_Block_36::S_453
            | C2Rust_Block_36::S_455
            | C2Rust_Block_36::S_46
            | C2Rust_Block_36::S_463
            | C2Rust_Block_36::S_465
            | C2Rust_Block_36::S_467
            | C2Rust_Block_36::S_469
            | C2Rust_Block_36::S_471
            | C2Rust_Block_36::S_473
            | C2Rust_Block_36::S_475
            | C2Rust_Block_36::S_477
            | C2Rust_Block_36::S_479
            | C2Rust_Block_36::S_48
            | C2Rust_Block_36::S_481
            | C2Rust_Block_36::S_483
            | C2Rust_Block_36::S_485
            | C2Rust_Block_36::S_487
            | C2Rust_Block_36::S_489
            | C2Rust_Block_36::S_491
            | C2Rust_Block_36::S_493
            | C2Rust_Block_36::S_495
            | C2Rust_Block_36::S_497
            | C2Rust_Block_36::S_499
            | C2Rust_Block_36::S_50
            | C2Rust_Block_36::S_501
            | C2Rust_Block_36::S_503
            | C2Rust_Block_36::S_505
            | C2Rust_Block_36::S_507
            | C2Rust_Block_36::S_509
            | C2Rust_Block_36::S_511
            | C2Rust_Block_36::S_513
            | C2Rust_Block_36::S_515
            | C2Rust_Block_36::S_517
            | C2Rust_Block_36::S_519
            | C2Rust_Block_36::S_52
            | C2Rust_Block_36::S_521
            | C2Rust_Block_36::S_523
            | C2Rust_Block_36::S_525
            | C2Rust_Block_36::S_527
            | C2Rust_Block_36::S_529
            | C2Rust_Block_36::S_531
            | C2Rust_Block_36::S_533
            | C2Rust_Block_36::S_535
            | C2Rust_Block_36::S_537
            | C2Rust_Block_36::S_539
            | C2Rust_Block_36::S_54
            | C2Rust_Block_36::S_541
            | C2Rust_Block_36::S_543
            | C2Rust_Block_36::S_545
            | C2Rust_Block_36::S_547
            | C2Rust_Block_36::S_549
            | C2Rust_Block_36::S_551
            | C2Rust_Block_36::S_553
            | C2Rust_Block_36::S_555
            | C2Rust_Block_36::S_557
            | C2Rust_Block_36::S_559
            | C2Rust_Block_36::S_56
            | C2Rust_Block_36::S_561
            | C2Rust_Block_36::S_567
            | C2Rust_Block_36::S_569
            | C2Rust_Block_36::S_571
            | C2Rust_Block_36::S_577
            | C2Rust_Block_36::S_58
            | C2Rust_Block_36::S_583
            | C2Rust_Block_36::S_585
            | C2Rust_Block_36::S_591
            | C2Rust_Block_36::S_593
            | C2Rust_Block_36::S_6
            | C2Rust_Block_36::S_60
            | C2Rust_Block_36::S_62
            | C2Rust_Block_36::S_64
            | C2Rust_Block_36::S_66
            | C2Rust_Block_36::S_68
            | C2Rust_Block_36::S_70
            | C2Rust_Block_36::S_72
            | C2Rust_Block_36::S_74
            | C2Rust_Block_36::S_76
            | C2Rust_Block_36::S_78
            | C2Rust_Block_36::S_8
            | C2Rust_Block_36::S_80
            | C2Rust_Block_36::S_82
            | C2Rust_Block_36::S_84
            | C2Rust_Block_36::S_86
            | C2Rust_Block_36::S_97
            | C2Rust_Block_36::S_99 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0DE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3c0e5c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f0e03 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001E18F0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0E10() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3c0e5c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f0e20 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001E1B50();
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f0e26 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001E0950();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_7: uint32_t = 0x1f0e39 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_242: {
        's_193: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_193;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_242;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_201: {
            if !_fn.is_none() {
                break 's_201;
            }
            _fn = recomp_lookup(_va);
        }
        's_207: {
            if !_fn.is_none() {
                break 's_207;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_213: {
            if _fn.is_some() {
                break 's_213;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_242;
        }
        _fn.expect("non-null function pointer")();
    }
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0E50() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c0e78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c0e74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x40012 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41b32c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x10 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c0e5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f0e7e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001E0FD0();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_181: {
        if _fa == _fb {
            break 's_181;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41b328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                .wrapping_add(1 as uint32_t),
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41b328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0EA0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3c0e5c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f0eb0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001E1B50();
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f0eb6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001E0950();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_7: uint32_t = 0x1f0ec9 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_242: {
        's_193: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_193;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_242;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_201: {
            if !_fn.is_none() {
                break 's_201;
            }
            _fn = recomp_lookup(_va);
        }
        's_207: {
            if !_fn.is_none() {
                break 's_207;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_213: {
            if _fn.is_some() {
                break 's_213;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_242;
        }
        _fn.expect("non-null function pointer")();
    }
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0ED0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1f0ea0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f0ee8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001E0C80();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f0efa as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001E09E0();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0F20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b350 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0F40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_sub(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0F50() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3c0e7c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f0f73 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001E18F0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0F80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x3c0e7c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f0f9e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024D5A0();
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F0FB0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as uint16_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fb = (_fa == 0x8000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int | 0xfff as ::core::ffi::c_int) as uint16_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_105: {
        if _fa == _fb {
            break 's_105;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0x1f0fc7 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_001EDD00();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3c0e7c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f0fdc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001E1B50();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_304: {
        if _fa == _fb {
            break 's_304;
        }
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_5: uint32_t = 0x1f0fed as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_288: {
            's_227: {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    break 's_227;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_247: {
                    if !_fn.is_none() {
                        break 's_247;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_253: {
                    if !_fn.is_none() {
                        break 's_253;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_259: {
                    if _fn.is_some() {
                        break 's_259;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_288;
                }
                _fn.expect("non-null function pointer")();
                break 's_288;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        }
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t);
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0x1f1000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_001F0760();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as uint16_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fb = (_fa == 0x7fff as uint32_t) as ::core::ffi::c_int as uint32_t;
    let mut _icall_esp_0: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _icall_target_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_9: uint32_t = 0x1f100b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _va_0: uint32_t = _icall_target_0;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va_0,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_458: {
        's_409: {
            if _va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi
            {
                break 's_409;
            }
            recomp_icall_not_code_log(_va_0);
            (*__gamepkg_tls_g_esp) = _icall_esp_0;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_458;
        }
        let mut _fn_0: recomp_func_t = recomp_lookup_manual(_va_0);
        's_417: {
            if !_fn_0.is_none() {
                break 's_417;
            }
            _fn_0 = recomp_lookup(_va_0);
        }
        's_423: {
            if !_fn_0.is_none() {
                break 's_423;
            }
            _fn_0 = recomp_lookup_kernel(_va_0);
        }
        's_429: {
            if _fn_0.is_some() {
                break 's_429;
            }
            recomp_icall_fail_log(_va_0);
            (*__gamepkg_tls_g_esp) = _icall_esp_0;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_458;
        }
        _fn_0.expect("non-null function pointer")();
    }
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1020() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff0000 as uint32_t
        | ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t
        as int16_t as int32_t as uint32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    's_180: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            > if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_180;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_132: {
            if _fa == _fb {
                break 's_132;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0x1f1043 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_001E1C70();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (::core::ptr::read_volatile::<
                uint16_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as uint16_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        _fb = (_fa == 0x7fff as uint32_t) as ::core::ffi::c_int as uint32_t;
        let mut _pv_2: uint32_t = 0x1f104f as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001F0FB0();
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1060() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x41b37c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f1072 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001E1320();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_255: {
            if _fa != _fb {
                break 's_255;
            }
            let mut _pv_4: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x41b388 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 0x1f108d as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_001E1320();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_229;
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F10A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0x2c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
        .wrapping_add(0x2c as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f10b9 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001E1300();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_191: {
        if _fa != _fb {
            break 's_191;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_5: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
        .wrapping_add(0x30 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(0x30 as uint32_t);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f10d2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_001E1300();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F10E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_68: {
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_eax) = 8 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1100() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c0ebc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c0eb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x40007 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41b358 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c0e94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f112e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001E0FD0();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_171: {
        if _fa != _fb {
            break 's_171;
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1150() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_91: {
        if _fa == _fb {
            break 's_91;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0x1f1165 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_001E09E0();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41b380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_sub(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1190() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3c0e94 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f11b3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001E18F0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F11C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x3c0e94 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f11de as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024D5A0();
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F11F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
        & 0xffff as uint32_t;
    _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fbs = _fb as int16_t as int32_t;
    's_340: {
        if _fa != _fb {
            break 's_340;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3c0e94 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f120a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001E1B50();
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_178: {
            if _fa == _fb {
                break 's_178;
            }
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 0x1f1219 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_001E2D90();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41b380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x7592a0 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_7: uint32_t = 0x1f1235 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_308: {
            's_259: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_259;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_308;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_267: {
                if !_fn.is_none() {
                    break 's_267;
                }
                _fn = recomp_lookup(_va);
            }
            's_273: {
                if !_fn.is_none() {
                    break 's_273;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_279: {
                if _fn.is_some() {
                    break 's_279;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_308;
            }
            _fn.expect("non-null function pointer")();
        }
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
    );
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1250() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    enum C2Rust_Block_50 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_50,
        S_52,
        S_54,
        S_60,
        S_66,
        S_68,
        S_70,
        S_76,
        S_85,
        S_87,
        S_89,
        S_91,
        S_97,
        S_99,
        S_101,
        S_111,
        S_113,
        S_115,
        S_121,
        S_127,
        S_129,
        S_131,
        S_141,
        S_143,
        S_145,
        S_155,
        S_157,
        S_159,
        S_169,
        S_171,
        S_173,
        S_179,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_199,
        S_201,
        S_203,
        S_216,
        S_218,
        S_220,
        S_230,
        S_232,
        S_234,
        S_244,
        S_246,
        S_248,
        S_258,
        S_260,
        S_262,
        S_268,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_363,
        S_369,
        S_371,
        S_373,
        S_383,
        S_385,
        S_387,
        S_397,
        S_399,
        S_401,
        S_411,
        S_413,
        S_415,
        S_421,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_473,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_497,
        S_499,
        S_501,
        S_503,
        S_512,
        S_518,
        S_520,
        S_522,
        S_532,
        S_534,
        S_536,
        S_546,
        S_548,
        S_550,
        S_556,
        S_566,
        S_568,
        S_570,
        S_580,
        S_582,
        S_584,
        S_594,
        S_596,
        S_598,
        S_608,
        S_610,
        S_612,
        S_618,
        S_624,
        S_626,
        S_628,
        S_630,
        S_632,
        S_634,
        S_636,
        S_638,
        S_640,
        S_642,
        S_655,
        S_657,
        S_667,
        S_669,
        S_675,
        S_677,
        S_679,
        S_685,
        S_687,
        S_693,
        S_695,
        S_705,
        S_707,
        S_713,
        S_719,
        S_721,
        S_731,
        S_733,
        S_739,
        S_741,
    }
    let mut c2rust_current_block_50: C2Rust_Block_50;
    c2rust_current_block_50 = C2Rust_Block_50::S_0;
    loop {
        match c2rust_current_block_50 {
            C2Rust_Block_50::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_50 = C2Rust_Block_50::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_50 = C2Rust_Block_50::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_50 = C2Rust_Block_50::S_24;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0x1000000 as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_26;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_28;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_30;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_36;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_50 = C2Rust_Block_50::S_38;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_40;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_50;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_52;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_54;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_60;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_66;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_68;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_70;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_76;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_705;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_85;
                    }
                };
            }
            C2Rust_Block_50::S_85 => {
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_87;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ((*__gamepkg_tls_g_ebx) as int32_t
                        * ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edi).wrapping_add(0x24 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as int32_t) as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_89;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_91;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(0x18 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_97;
                };
                {
                    _pv_2 = 0xffff as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_99;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_101;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_111;
                };
                {
                    _pv_3 = 0x36003 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_113;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_115;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_121;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ebx))
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_127;
                };
                {
                    _pv_4 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_50 = C2Rust_Block_50::S_129;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_131;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_141;
                };
                {
                    _pv_5 = 1 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_143;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_145;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_155;
                };
                {
                    _pv_6 = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_157;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_159;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_169;
                };
                {
                    _pv_7 = 0x1f1286 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_171;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_173;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_179;
                };
                {
                    sub_001E11A0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_185;
                };
                {
                    _fb = 0x14 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_187;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_189;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x14 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_191;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_193;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_195;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_197;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_199;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_201;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_203;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_655;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_216;
                    }
                };
            }
            C2Rust_Block_50::S_216 => {
                {
                    _pv_8 = 4 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_218;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_220;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_230;
                };
                {
                    _pv_9 = 0x36d78c as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_232;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_234;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_244;
                };
                {
                    _pv_10 = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_246;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_248;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_258;
                };
                {
                    _pv_11 = 0x1f129a as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_260;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_262;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_268;
                };
                {
                    sub_001DEBE0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_274;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_276;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_278;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_280;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_282;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_284;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_286;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_288;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_290;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_292;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_655;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_301;
                    }
                };
            }
            C2Rust_Block_50::S_301 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_303;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_305;
                };
                {
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_307;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_309;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_311;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_363;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_324;
                    }
                };
            }
            C2Rust_Block_50::S_324 => {
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_326;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_328;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_sub((*__gamepkg_tls_g_edi)),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_330;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_332;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_334;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_336;
                };
                {
                    _fb = 0x18 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_338;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_340;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x18 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_342;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_344;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_346;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_348;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_350;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_352;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_354;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_324;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_363;
                    }
                };
            }
            C2Rust_Block_50::S_363 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_369;
                };
                {
                    _pv_12 = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_50 = C2Rust_Block_50::S_371;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_373;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_383;
                };
                {
                    _pv_13 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_385;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_387;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_397;
                };
                {
                    _pv_14 = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_399;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_401;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_14,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_411;
                };
                {
                    _pv_15 = 0x1f12c7 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_413;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_415;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_15,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_421;
                };
                {
                    sub_001DEBE0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_427;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_429;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_431;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_433;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_435;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_437;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_439;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_441;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_443;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_445;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_655;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_454;
                    }
                };
            }
            C2Rust_Block_50::S_454 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_456;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_458;
                };
                {
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_460;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_462;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_464;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_512;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_473;
                    }
                };
            }
            C2Rust_Block_50::S_473 => {
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_475;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_477;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_add((*__gamepkg_tls_g_edi)),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_479;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_481;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_483;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_485;
                };
                {
                    _fb = 0x18 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_487;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_489;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x18 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_491;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_493;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_495;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_497;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_499;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_501;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_503;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_473;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_512;
                    }
                };
            }
            C2Rust_Block_50::S_512 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_518;
                };
                {
                    _pv_16 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_520;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_522;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_16,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_532;
                };
                {
                    _pv_17 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_534;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_536;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_17,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_546;
                };
                {
                    _pv_18 = 0x1f12ee as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_548;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_550;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_18,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_556;
                };
                {
                    sub_0034FC10();
                    c2rust_current_block_50 = C2Rust_Block_50::S_566;
                };
                {
                    _pv_19 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_50 = C2Rust_Block_50::S_568;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_570;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_19,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_580;
                };
                {
                    _pv_20 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_50 = C2Rust_Block_50::S_582;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_584;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_20,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_594;
                };
                {
                    _pv_21 = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_596;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_598;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_21,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_608;
                };
                {
                    _pv_22 = 0x1f12f6 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_610;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_612;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_22,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_618;
                };
                {
                    sub_001DEBE0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_624;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_626;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_628;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_630;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_632;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_634;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_636;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_638;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_640;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_642;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_705;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_655;
                    }
                };
            }
            C2Rust_Block_50::S_655 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_657;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_667;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_669;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_675;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_677;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_679;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_685;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_687;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_693;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_695;
                };
                return;
            }
            C2Rust_Block_50::S_705 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_707;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_713;
                };
                {
                    (*__gamepkg_tls_g_eax) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_719;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_721;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_731;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_733;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_739;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_741;
                };
                return;
            }
            C2Rust_Block_50::S_101
            | C2Rust_Block_50::S_111
            | C2Rust_Block_50::S_113
            | C2Rust_Block_50::S_115
            | C2Rust_Block_50::S_121
            | C2Rust_Block_50::S_127
            | C2Rust_Block_50::S_129
            | C2Rust_Block_50::S_131
            | C2Rust_Block_50::S_141
            | C2Rust_Block_50::S_143
            | C2Rust_Block_50::S_145
            | C2Rust_Block_50::S_155
            | C2Rust_Block_50::S_157
            | C2Rust_Block_50::S_159
            | C2Rust_Block_50::S_169
            | C2Rust_Block_50::S_171
            | C2Rust_Block_50::S_173
            | C2Rust_Block_50::S_179
            | C2Rust_Block_50::S_18
            | C2Rust_Block_50::S_185
            | C2Rust_Block_50::S_187
            | C2Rust_Block_50::S_189
            | C2Rust_Block_50::S_191
            | C2Rust_Block_50::S_193
            | C2Rust_Block_50::S_195
            | C2Rust_Block_50::S_197
            | C2Rust_Block_50::S_199
            | C2Rust_Block_50::S_2
            | C2Rust_Block_50::S_201
            | C2Rust_Block_50::S_203
            | C2Rust_Block_50::S_218
            | C2Rust_Block_50::S_220
            | C2Rust_Block_50::S_230
            | C2Rust_Block_50::S_232
            | C2Rust_Block_50::S_234
            | C2Rust_Block_50::S_24
            | C2Rust_Block_50::S_244
            | C2Rust_Block_50::S_246
            | C2Rust_Block_50::S_248
            | C2Rust_Block_50::S_258
            | C2Rust_Block_50::S_26
            | C2Rust_Block_50::S_260
            | C2Rust_Block_50::S_262
            | C2Rust_Block_50::S_268
            | C2Rust_Block_50::S_274
            | C2Rust_Block_50::S_276
            | C2Rust_Block_50::S_278
            | C2Rust_Block_50::S_28
            | C2Rust_Block_50::S_280
            | C2Rust_Block_50::S_282
            | C2Rust_Block_50::S_284
            | C2Rust_Block_50::S_286
            | C2Rust_Block_50::S_288
            | C2Rust_Block_50::S_290
            | C2Rust_Block_50::S_292
            | C2Rust_Block_50::S_30
            | C2Rust_Block_50::S_303
            | C2Rust_Block_50::S_305
            | C2Rust_Block_50::S_307
            | C2Rust_Block_50::S_309
            | C2Rust_Block_50::S_311
            | C2Rust_Block_50::S_326
            | C2Rust_Block_50::S_328
            | C2Rust_Block_50::S_330
            | C2Rust_Block_50::S_332
            | C2Rust_Block_50::S_334
            | C2Rust_Block_50::S_336
            | C2Rust_Block_50::S_338
            | C2Rust_Block_50::S_340
            | C2Rust_Block_50::S_342
            | C2Rust_Block_50::S_344
            | C2Rust_Block_50::S_346
            | C2Rust_Block_50::S_348
            | C2Rust_Block_50::S_350
            | C2Rust_Block_50::S_352
            | C2Rust_Block_50::S_354
            | C2Rust_Block_50::S_36
            | C2Rust_Block_50::S_369
            | C2Rust_Block_50::S_371
            | C2Rust_Block_50::S_373
            | C2Rust_Block_50::S_38
            | C2Rust_Block_50::S_383
            | C2Rust_Block_50::S_385
            | C2Rust_Block_50::S_387
            | C2Rust_Block_50::S_397
            | C2Rust_Block_50::S_399
            | C2Rust_Block_50::S_4
            | C2Rust_Block_50::S_40
            | C2Rust_Block_50::S_401
            | C2Rust_Block_50::S_411
            | C2Rust_Block_50::S_413
            | C2Rust_Block_50::S_415
            | C2Rust_Block_50::S_421
            | C2Rust_Block_50::S_427
            | C2Rust_Block_50::S_429
            | C2Rust_Block_50::S_431
            | C2Rust_Block_50::S_433
            | C2Rust_Block_50::S_435
            | C2Rust_Block_50::S_437
            | C2Rust_Block_50::S_439
            | C2Rust_Block_50::S_441
            | C2Rust_Block_50::S_443
            | C2Rust_Block_50::S_445
            | C2Rust_Block_50::S_456
            | C2Rust_Block_50::S_458
            | C2Rust_Block_50::S_460
            | C2Rust_Block_50::S_462
            | C2Rust_Block_50::S_464
            | C2Rust_Block_50::S_475
            | C2Rust_Block_50::S_477
            | C2Rust_Block_50::S_479
            | C2Rust_Block_50::S_481
            | C2Rust_Block_50::S_483
            | C2Rust_Block_50::S_485
            | C2Rust_Block_50::S_487
            | C2Rust_Block_50::S_489
            | C2Rust_Block_50::S_491
            | C2Rust_Block_50::S_493
            | C2Rust_Block_50::S_495
            | C2Rust_Block_50::S_497
            | C2Rust_Block_50::S_499
            | C2Rust_Block_50::S_50
            | C2Rust_Block_50::S_501
            | C2Rust_Block_50::S_503
            | C2Rust_Block_50::S_518
            | C2Rust_Block_50::S_52
            | C2Rust_Block_50::S_520
            | C2Rust_Block_50::S_522
            | C2Rust_Block_50::S_532
            | C2Rust_Block_50::S_534
            | C2Rust_Block_50::S_536
            | C2Rust_Block_50::S_54
            | C2Rust_Block_50::S_546
            | C2Rust_Block_50::S_548
            | C2Rust_Block_50::S_550
            | C2Rust_Block_50::S_556
            | C2Rust_Block_50::S_566
            | C2Rust_Block_50::S_568
            | C2Rust_Block_50::S_570
            | C2Rust_Block_50::S_580
            | C2Rust_Block_50::S_582
            | C2Rust_Block_50::S_584
            | C2Rust_Block_50::S_594
            | C2Rust_Block_50::S_596
            | C2Rust_Block_50::S_598
            | C2Rust_Block_50::S_6
            | C2Rust_Block_50::S_60
            | C2Rust_Block_50::S_608
            | C2Rust_Block_50::S_610
            | C2Rust_Block_50::S_612
            | C2Rust_Block_50::S_618
            | C2Rust_Block_50::S_624
            | C2Rust_Block_50::S_626
            | C2Rust_Block_50::S_628
            | C2Rust_Block_50::S_630
            | C2Rust_Block_50::S_632
            | C2Rust_Block_50::S_634
            | C2Rust_Block_50::S_636
            | C2Rust_Block_50::S_638
            | C2Rust_Block_50::S_640
            | C2Rust_Block_50::S_642
            | C2Rust_Block_50::S_657
            | C2Rust_Block_50::S_66
            | C2Rust_Block_50::S_667
            | C2Rust_Block_50::S_669
            | C2Rust_Block_50::S_675
            | C2Rust_Block_50::S_677
            | C2Rust_Block_50::S_679
            | C2Rust_Block_50::S_68
            | C2Rust_Block_50::S_685
            | C2Rust_Block_50::S_687
            | C2Rust_Block_50::S_693
            | C2Rust_Block_50::S_695
            | C2Rust_Block_50::S_70
            | C2Rust_Block_50::S_707
            | C2Rust_Block_50::S_713
            | C2Rust_Block_50::S_719
            | C2Rust_Block_50::S_721
            | C2Rust_Block_50::S_731
            | C2Rust_Block_50::S_733
            | C2Rust_Block_50::S_739
            | C2Rust_Block_50::S_741
            | C2Rust_Block_50::S_76
            | C2Rust_Block_50::S_8
            | C2Rust_Block_50::S_87
            | C2Rust_Block_50::S_89
            | C2Rust_Block_50::S_91
            | C2Rust_Block_50::S_97
            | C2Rust_Block_50::S_99 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F1310() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    enum C2Rust_Block_51 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_20,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_42,
        S_44,
        S_46,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_98,
        S_100,
        S_102,
        S_104,
        S_110,
        S_112,
        S_114,
        S_120,
        S_126,
        S_128,
        S_130,
        S_140,
        S_142,
        S_144,
        S_150,
        S_156,
        S_158,
        S_160,
        S_166,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_247,
        S_249,
        S_251,
        S_257,
        S_263,
        S_265,
        S_267,
        S_277,
        S_279,
        S_281,
        S_291,
        S_293,
        S_295,
        S_301,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_361,
        S_363,
        S_365,
        S_371,
        S_377,
        S_379,
        S_381,
        S_391,
        S_393,
        S_395,
        S_405,
        S_407,
        S_409,
        S_415,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_467,
        S_473,
        S_475,
        S_477,
        S_487,
        S_489,
        S_491,
        S_498,
        S_504,
        S_506,
        S_508,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_529,
        S_531,
        S_533,
        S_541,
        S_543,
        S_545,
        S_549,
        S_551,
        S_555,
        S_561,
        S_568,
        S_570,
        S_572,
        S_590,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_624,
        S_626,
        S_628,
        S_630,
        S_632,
        S_634,
        S_640,
        S_642,
        S_644,
        S_650,
        S_656,
        S_658,
        S_660,
        S_670,
        S_672,
        S_674,
        S_680,
        S_686,
        S_688,
        S_690,
        S_696,
        S_702,
        S_704,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_735,
        S_737,
        S_739,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_760,
        S_762,
        S_764,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_780,
        S_782,
        S_784,
        S_794,
        S_796,
        S_798,
        S_800,
        S_802,
        S_804,
        S_806,
        S_808,
        S_810,
        S_812,
        S_814,
        S_816,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_828,
        S_830,
        S_832,
        S_834,
        S_836,
        S_838,
        S_840,
        S_842,
        S_844,
        S_857,
        S_859,
        S_869,
        S_871,
        S_873,
        S_879,
        S_881,
        S_883,
        S_889,
        S_895,
        S_897,
        S_899,
        S_905,
        S_911,
        S_913,
        S_915,
        S_917,
        S_919,
        S_921,
        S_923,
        S_925,
        S_927,
        S_929,
        S_931,
        S_933,
        S_935,
        S_948,
        S_950,
        S_952,
        S_962,
        S_964,
        S_966,
        S_976,
        S_978,
        S_980,
        S_986,
        S_992,
        S_998,
        S_1000,
        S_1002,
        S_1012,
        S_1014,
        S_1016,
        S_1026,
        S_1028,
        S_1030,
        S_1040,
        S_1042,
        S_1044,
        S_1050,
        S_1056,
        S_1058,
        S_1060,
        S_1062,
        S_1064,
        S_1066,
        S_1068,
        S_1070,
        S_1072,
        S_1074,
        S_1076,
        S_1078,
        S_1080,
        S_1082,
        S_1084,
        S_1086,
        S_1088,
        S_1090,
        S_1092,
        S_1094,
        S_1100,
        S_1102,
        S_1108,
        S_1110,
        S_1112,
        S_1114,
        S_1120,
        S_1122,
        S_1132,
        S_1134,
        S_1140,
        S_1142,
        S_1144,
        S_1146,
        S_1148,
        S_1150,
        S_1152,
        S_1154,
        S_1164,
        S_1166,
        S_1168,
        S_1174,
        S_1180,
        S_1182,
        S_1184,
        S_1190,
        S_1196,
        S_1202,
        S_1204,
        S_1206,
        S_1212,
        S_1218,
        S_1220,
        S_1222,
        S_1228,
        S_1234,
        S_1236,
        S_1238,
        S_1240,
        S_1242,
        S_1244,
        S_1254,
        S_1256,
        S_1266,
        S_1268,
        S_1274,
        S_1276,
        S_1278,
        S_1280,
        S_1286,
        S_1288,
        S_1294,
        S_1296,
        S_1298,
        S_1300,
        S_1302,
        S_1304,
        S_1306,
        S_1308,
    }
    let mut c2rust_current_block_51: C2Rust_Block_51;
    c2rust_current_block_51 = C2Rust_Block_51::S_0;
    loop {
        match c2rust_current_block_51 {
            C2Rust_Block_51::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_51 = C2Rust_Block_51::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_18;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_20;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_51 = C2Rust_Block_51::S_26;
                };
                {
                    _fb = 0x14 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_28;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_30;
                };
                {
                    _cf = ((*__gamepkg_tls_g_esp)
                        < 0x14 as ::core::ffi::c_int as uint32_t) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_32;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x14 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_34;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_36;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_42;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_44;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_46;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_56;
                };
                {
                    _pv_0 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_58;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_60;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_70;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_72;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_74;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_80;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_82;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_88;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_90;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_92;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_98;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_100;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_102;
                };
                {
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_104;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_110;
                };
                {
                    _pv_3 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_112;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_114;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_120;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_126;
                };
                {
                    _pv_4 = 1 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_128;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_130;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_140;
                };
                {
                    _pv_5 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_142;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_144;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_150;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_156;
                };
                {
                    _pv_6 = 0x1f132e as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_158;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_166;
                };
                {
                    sub_001E1200();
                    c2rust_current_block_51 = C2Rust_Block_51::S_172;
                };
                {
                    _fb = 0x10 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_174;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_176;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x10 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_178;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_180;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_182;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_184;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_186;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_188;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_190;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_192;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_194;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_203;
                    }
                };
            }
            C2Rust_Block_51::S_203 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_205;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_207;
                };
                {
                    _fb = 0x34000 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_209;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_211;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_213;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_215;
                };
                {
                    if _fa < _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1164;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_224;
                    }
                };
            }
            C2Rust_Block_51::S_224 => {
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_226;
                };
                {
                    _fb = 0x36003 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_228;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_230;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_232;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_234;
                };
                {
                    if _fa > _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1164;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_247;
                    }
                };
            }
            C2Rust_Block_51::S_247 => {
                {
                    _pv_7 = 4 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_249;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_251;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_257;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x18 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_263;
                };
                {
                    _pv_8 = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_265;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_267;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_277;
                };
                {
                    _pv_9 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_279;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_281;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_291;
                };
                {
                    _pv_10 = 0x1f1360 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_293;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_295;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_301;
                };
                {
                    sub_001DEA90();
                    c2rust_current_block_51 = C2Rust_Block_51::S_307;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_309;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_311;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_313;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_315;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_317;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_319;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_321;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_323;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_325;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_327;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_329;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_338;
                    }
                };
            }
            C2Rust_Block_51::S_338 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_340;
                };
                {
                    _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_342;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_344;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_346;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_348;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_361;
                    }
                };
            }
            C2Rust_Block_51::S_361 => {
                {
                    _pv_11 = 4 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_363;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_365;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_371;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_377;
                };
                {
                    _pv_12 = (*__gamepkg_tls_g_edx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_379;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_381;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_391;
                };
                {
                    _pv_13 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_393;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_395;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_405;
                };
                {
                    _pv_14 = 0x1f1384 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_407;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_409;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_14,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_415;
                };
                {
                    sub_001DEA90();
                    c2rust_current_block_51 = C2Rust_Block_51::S_421;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_423;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_425;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_427;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_429;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_431;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_433;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_435;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_437;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_439;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_441;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_443;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_452;
                    }
                };
            }
            C2Rust_Block_51::S_452 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_454;
                };
                {
                    _fb = 0x18 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_456;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_458;
                };
                {
                    _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                        .wrapping_add(0x18 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_460;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x18 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_462;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_464;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_467;
                };
                {
                    _icall_esp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_51 = C2Rust_Block_51::S_473;
                };
                {
                    _pv_15 = 0x3050d as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_475;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_477;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_15,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_487;
                };
                {
                    _pv_16 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_489;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_491;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_16,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_498;
                };
                {
                    _icall_target = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x7593d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_504;
                };
                {
                    _pv_17 = 0x1f13a3 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_506;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_508;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_17,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_518;
                };
                {
                    _va = _icall_target;
                    c2rust_current_block_51 = C2Rust_Block_51::S_520;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_522;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_524;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_526;
                };
                {
                    if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                    {
                        c2rust_current_block_51 = C2Rust_Block_51::S_529;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_541;
                    }
                };
            }
            C2Rust_Block_51::S_529 => {
                {
                    recomp_icall_not_code_log(_va);
                    c2rust_current_block_51 = C2Rust_Block_51::S_531;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block_51 = C2Rust_Block_51::S_533;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_590;
                };
            }
            C2Rust_Block_51::S_541 => {
                {
                    _fn = recomp_lookup_manual(_va);
                    c2rust_current_block_51 = C2Rust_Block_51::S_543;
                };
                {
                    if _fn.is_none() {
                        c2rust_current_block_51 = C2Rust_Block_51::S_545;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_549;
                    }
                };
            }
            C2Rust_Block_51::S_545 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_51 = C2Rust_Block_51::S_549;
            }
            C2Rust_Block_51::S_549 => {
                if _fn.is_none() {
                    c2rust_current_block_51 = C2Rust_Block_51::S_551;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_555;
                }
            }
            C2Rust_Block_51::S_551 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_51 = C2Rust_Block_51::S_555;
            }
            C2Rust_Block_51::S_555 => {
                if _fn.is_some() {
                    c2rust_current_block_51 = C2Rust_Block_51::S_561;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_568;
                }
            }
            C2Rust_Block_51::S_561 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_51 = C2Rust_Block_51::S_590;
            }
            C2Rust_Block_51::S_568 => {
                {
                    recomp_icall_fail_log(_va);
                    c2rust_current_block_51 = C2Rust_Block_51::S_570;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block_51 = C2Rust_Block_51::S_572;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_590;
                };
            }
            C2Rust_Block_51::S_590 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_592;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_594;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_596;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_598;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_600;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_602;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_604;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_606;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_608;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_610;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_612;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_614;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x1f4aa0 as uint32_t,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_616;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_618;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_620;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_622;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_624;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_626;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_628;
                };
                {
                    _cf = ((*__gamepkg_tls_g_eax) < 4 as ::core::ffi::c_int as uint32_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_630;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_632;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_634;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_640;
                };
                {
                    _pv_18 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_642;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_644;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_18,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_650;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(0x1c as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_656;
                };
                {
                    _pv_19 = (*__gamepkg_tls_g_edx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_658;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_660;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_19,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_670;
                };
                {
                    _pv_20 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_672;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_674;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_20,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_680;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_686;
                };
                {
                    _pv_21 = 0x1f13e7 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_688;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_690;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_21,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_696;
                };
                {
                    sub_001DEA90();
                    c2rust_current_block_51 = C2Rust_Block_51::S_702;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_704;
                };
                {
                    _fb = 0x14 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_706;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_708;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x14 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_710;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x14 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_712;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_714;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_716;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_718;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_720;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_722;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_724;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_726;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_735;
                    }
                };
            }
            C2Rust_Block_51::S_735 => {
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                        & 0xffff0000 as uint32_t
                        | ::core::ptr::read_volatile::<
                            uint16_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint16_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x1e as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_737;
                };
                {
                    _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                        as uint32_t & 0xffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_739;
                };
                {
                    _fb = ((*__gamepkg_tls_g_edi) & 0xffff as uint32_t) as uint16_t
                        as uint32_t & 0xffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_741;
                };
                {
                    _fas = _fa as int16_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_743;
                };
                {
                    _fbs = _fb as int16_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_745;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_747;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(0x3c as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_749;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_751;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_869;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_760;
                    }
                };
            }
            C2Rust_Block_51::S_760 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_762;
                };
                {
                    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_764;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_766;
                };
                {
                    _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
                        .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_768;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_770;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_772;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_774;
                };
                {
                    (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_edx)
                        & 0xffff as uint32_t) as uint16_t as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_780;
                };
                {
                    _pv_22 = ebp;
                    c2rust_current_block_51 = C2Rust_Block_51::S_782;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_784;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_22,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_794;
                };
            }
            C2Rust_Block_51::S_794 => {
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_796;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_798;
                };
                {
                    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_800;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_802;
                };
                {
                    _cf = ((::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint64_t)
                        .wrapping_add((*__gamepkg_tls_g_esi) as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_804;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_add((*__gamepkg_tls_g_esi)),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_806;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_808;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_810;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_812;
                };
                {
                    _fb = 0x18 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_814;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_816;
                };
                {
                    _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                        .wrapping_add(0x18 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_818;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x18 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_820;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_822;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_824;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_826;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_828;
                };
                {
                    _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
                        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_830;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_832;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_834;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_836;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_838;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_840;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_842;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_844;
                };
                {
                    if _fa != 0 as uint32_t {
                        c2rust_current_block_51 = C2Rust_Block_51::S_794;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_857;
                    }
                };
            }
            C2Rust_Block_51::S_857 => {
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_859;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_869;
                };
            }
            C2Rust_Block_51::S_869 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_871;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_873;
                };
                {
                    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                        * ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as int32_t) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_879;
                };
                {
                    _pv_23 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_881;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_883;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_23,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_889;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_895;
                };
                {
                    _pv_24 = 0x1f1439 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_897;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_899;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_24,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_905;
                };
                {
                    sub_001E4460();
                    c2rust_current_block_51 = C2Rust_Block_51::S_911;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_913;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_915;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(4 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_917;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_919;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_921;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_923;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_925;
                };
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_927;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_929;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_931;
                };
                {
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_933;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_935;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_948;
                    }
                };
            }
            C2Rust_Block_51::S_948 => {
                {
                    _pv_25 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_950;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_952;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_25,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_962;
                };
                {
                    _pv_26 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_964;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_966;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_26,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_976;
                };
                {
                    _pv_27 = 0x1f144a as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_978;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_980;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_27,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_986;
                };
                {
                    sub_0034FC10();
                    c2rust_current_block_51 = C2Rust_Block_51::S_992;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_998;
                };
                {
                    _pv_28 = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1000;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1002;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_28,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1012;
                };
                {
                    _pv_29 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1014;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1016;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_29,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1026;
                };
                {
                    _pv_30 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1028;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1030;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_30,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1040;
                };
                {
                    _pv_31 = 0x1f1456 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1042;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1044;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_31,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1050;
                };
                {
                    sub_001DEA90();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1056;
                };
                {
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1058;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1060;
                };
                {
                    _cf = ((*__gamepkg_tls_g_eax)
                        < ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )) as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1062;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_sub(
                            ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ),
                        );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1064;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1066;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1068;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1070;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1072;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1074;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1076;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1078;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1080;
                };
                {
                    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1082;
                };
                {
                    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1084;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1086;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1088;
                };
                {
                    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                        0xffffffff as ::core::ffi::c_uint
                    } else {
                        0 as ::core::ffi::c_uint
                    }) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1090;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1092;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1094;
                };
                {
                    (*__gamepkg_tls_g_eax) = !(*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1100;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1102;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1108;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1110;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & (*__gamepkg_tls_g_esi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1112;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1114;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1120;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1122;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1132;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1134;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1140;
                };
                {
                    _fb = 0x14 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1142;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1144;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x14 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1146;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x14 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1148;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1150;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1152;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1154;
                };
                return;
            }
            C2Rust_Block_51::S_1164 => {
                {
                    _pv_32 = 0x80000004 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1166;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1168;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_32,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1174;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        2 as uint32_t,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1180;
                };
                {
                    _pv_33 = 0x1f147e as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1182;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1184;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_33,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1190;
                };
                {
                    sub_002087B0();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1196;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x1c as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1202;
                };
                {
                    _pv_34 = (*__gamepkg_tls_g_edx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1204;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1206;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_34,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1218;
                };
                {
                    _pv_35 = 0x1f148c as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1220;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1222;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_35,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1228;
                };
                {
                    sub_001E1710();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1234;
                };
                {
                    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1236;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1238;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1240;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1242;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1244;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1254;
                };
            }
            C2Rust_Block_51::S_1254 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1256;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1266;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1268;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1274;
                };
                {
                    _cf = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1276;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1278;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1280;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1286;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1288;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1294;
                };
                {
                    _fb = 0x14 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1296;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1298;
                };
                {
                    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                        .wrapping_add(0x14 as ::core::ffi::c_int as uint64_t)
                        >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                        as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1300;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x14 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1302;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1304;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1306;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1308;
                };
                return;
            }
            C2Rust_Block_51::S_100
            | C2Rust_Block_51::S_1000
            | C2Rust_Block_51::S_1002
            | C2Rust_Block_51::S_1012
            | C2Rust_Block_51::S_1014
            | C2Rust_Block_51::S_1016
            | C2Rust_Block_51::S_102
            | C2Rust_Block_51::S_1026
            | C2Rust_Block_51::S_1028
            | C2Rust_Block_51::S_1030
            | C2Rust_Block_51::S_104
            | C2Rust_Block_51::S_1040
            | C2Rust_Block_51::S_1042
            | C2Rust_Block_51::S_1044
            | C2Rust_Block_51::S_1050
            | C2Rust_Block_51::S_1056
            | C2Rust_Block_51::S_1058
            | C2Rust_Block_51::S_1060
            | C2Rust_Block_51::S_1062
            | C2Rust_Block_51::S_1064
            | C2Rust_Block_51::S_1066
            | C2Rust_Block_51::S_1068
            | C2Rust_Block_51::S_1070
            | C2Rust_Block_51::S_1072
            | C2Rust_Block_51::S_1074
            | C2Rust_Block_51::S_1076
            | C2Rust_Block_51::S_1078
            | C2Rust_Block_51::S_1080
            | C2Rust_Block_51::S_1082
            | C2Rust_Block_51::S_1084
            | C2Rust_Block_51::S_1086
            | C2Rust_Block_51::S_1088
            | C2Rust_Block_51::S_1090
            | C2Rust_Block_51::S_1092
            | C2Rust_Block_51::S_1094
            | C2Rust_Block_51::S_110
            | C2Rust_Block_51::S_1100
            | C2Rust_Block_51::S_1102
            | C2Rust_Block_51::S_1108
            | C2Rust_Block_51::S_1110
            | C2Rust_Block_51::S_1112
            | C2Rust_Block_51::S_1114
            | C2Rust_Block_51::S_112
            | C2Rust_Block_51::S_1120
            | C2Rust_Block_51::S_1122
            | C2Rust_Block_51::S_1132
            | C2Rust_Block_51::S_1134
            | C2Rust_Block_51::S_114
            | C2Rust_Block_51::S_1140
            | C2Rust_Block_51::S_1142
            | C2Rust_Block_51::S_1144
            | C2Rust_Block_51::S_1146
            | C2Rust_Block_51::S_1148
            | C2Rust_Block_51::S_1150
            | C2Rust_Block_51::S_1152
            | C2Rust_Block_51::S_1154
            | C2Rust_Block_51::S_1166
            | C2Rust_Block_51::S_1168
            | C2Rust_Block_51::S_1174
            | C2Rust_Block_51::S_1180
            | C2Rust_Block_51::S_1182
            | C2Rust_Block_51::S_1184
            | C2Rust_Block_51::S_1190
            | C2Rust_Block_51::S_1196
            | C2Rust_Block_51::S_120
            | C2Rust_Block_51::S_1202
            | C2Rust_Block_51::S_1204
            | C2Rust_Block_51::S_1206
            | C2Rust_Block_51::S_1212
            | C2Rust_Block_51::S_1218
            | C2Rust_Block_51::S_1220
            | C2Rust_Block_51::S_1222
            | C2Rust_Block_51::S_1228
            | C2Rust_Block_51::S_1234
            | C2Rust_Block_51::S_1236
            | C2Rust_Block_51::S_1238
            | C2Rust_Block_51::S_1240
            | C2Rust_Block_51::S_1242
            | C2Rust_Block_51::S_1244
            | C2Rust_Block_51::S_1256
            | C2Rust_Block_51::S_126
            | C2Rust_Block_51::S_1266
            | C2Rust_Block_51::S_1268
            | C2Rust_Block_51::S_1274
            | C2Rust_Block_51::S_1276
            | C2Rust_Block_51::S_1278
            | C2Rust_Block_51::S_128
            | C2Rust_Block_51::S_1280
            | C2Rust_Block_51::S_1286
            | C2Rust_Block_51::S_1288
            | C2Rust_Block_51::S_1294
            | C2Rust_Block_51::S_1296
            | C2Rust_Block_51::S_1298
            | C2Rust_Block_51::S_130
            | C2Rust_Block_51::S_1300
            | C2Rust_Block_51::S_1302
            | C2Rust_Block_51::S_1304
            | C2Rust_Block_51::S_1306
            | C2Rust_Block_51::S_1308
            | C2Rust_Block_51::S_140
            | C2Rust_Block_51::S_142
            | C2Rust_Block_51::S_144
            | C2Rust_Block_51::S_150
            | C2Rust_Block_51::S_156
            | C2Rust_Block_51::S_158
            | C2Rust_Block_51::S_160
            | C2Rust_Block_51::S_166
            | C2Rust_Block_51::S_172
            | C2Rust_Block_51::S_174
            | C2Rust_Block_51::S_176
            | C2Rust_Block_51::S_178
            | C2Rust_Block_51::S_18
            | C2Rust_Block_51::S_180
            | C2Rust_Block_51::S_182
            | C2Rust_Block_51::S_184
            | C2Rust_Block_51::S_186
            | C2Rust_Block_51::S_188
            | C2Rust_Block_51::S_190
            | C2Rust_Block_51::S_192
            | C2Rust_Block_51::S_194
            | C2Rust_Block_51::S_2
            | C2Rust_Block_51::S_20
            | C2Rust_Block_51::S_205
            | C2Rust_Block_51::S_207
            | C2Rust_Block_51::S_209
            | C2Rust_Block_51::S_211
            | C2Rust_Block_51::S_213
            | C2Rust_Block_51::S_215
            | C2Rust_Block_51::S_226
            | C2Rust_Block_51::S_228
            | C2Rust_Block_51::S_230
            | C2Rust_Block_51::S_232
            | C2Rust_Block_51::S_234
            | C2Rust_Block_51::S_249
            | C2Rust_Block_51::S_251
            | C2Rust_Block_51::S_257
            | C2Rust_Block_51::S_26
            | C2Rust_Block_51::S_263
            | C2Rust_Block_51::S_265
            | C2Rust_Block_51::S_267
            | C2Rust_Block_51::S_277
            | C2Rust_Block_51::S_279
            | C2Rust_Block_51::S_28
            | C2Rust_Block_51::S_281
            | C2Rust_Block_51::S_291
            | C2Rust_Block_51::S_293
            | C2Rust_Block_51::S_295
            | C2Rust_Block_51::S_30
            | C2Rust_Block_51::S_301
            | C2Rust_Block_51::S_307
            | C2Rust_Block_51::S_309
            | C2Rust_Block_51::S_311
            | C2Rust_Block_51::S_313
            | C2Rust_Block_51::S_315
            | C2Rust_Block_51::S_317
            | C2Rust_Block_51::S_319
            | C2Rust_Block_51::S_32
            | C2Rust_Block_51::S_321
            | C2Rust_Block_51::S_323
            | C2Rust_Block_51::S_325
            | C2Rust_Block_51::S_327
            | C2Rust_Block_51::S_329
            | C2Rust_Block_51::S_34
            | C2Rust_Block_51::S_340
            | C2Rust_Block_51::S_342
            | C2Rust_Block_51::S_344
            | C2Rust_Block_51::S_346
            | C2Rust_Block_51::S_348
            | C2Rust_Block_51::S_36
            | C2Rust_Block_51::S_363
            | C2Rust_Block_51::S_365
            | C2Rust_Block_51::S_371
            | C2Rust_Block_51::S_377
            | C2Rust_Block_51::S_379
            | C2Rust_Block_51::S_381
            | C2Rust_Block_51::S_391
            | C2Rust_Block_51::S_393
            | C2Rust_Block_51::S_395
            | C2Rust_Block_51::S_4
            | C2Rust_Block_51::S_405
            | C2Rust_Block_51::S_407
            | C2Rust_Block_51::S_409
            | C2Rust_Block_51::S_415
            | C2Rust_Block_51::S_42
            | C2Rust_Block_51::S_421
            | C2Rust_Block_51::S_423
            | C2Rust_Block_51::S_425
            | C2Rust_Block_51::S_427
            | C2Rust_Block_51::S_429
            | C2Rust_Block_51::S_431
            | C2Rust_Block_51::S_433
            | C2Rust_Block_51::S_435
            | C2Rust_Block_51::S_437
            | C2Rust_Block_51::S_439
            | C2Rust_Block_51::S_44
            | C2Rust_Block_51::S_441
            | C2Rust_Block_51::S_443
            | C2Rust_Block_51::S_454
            | C2Rust_Block_51::S_456
            | C2Rust_Block_51::S_458
            | C2Rust_Block_51::S_46
            | C2Rust_Block_51::S_460
            | C2Rust_Block_51::S_462
            | C2Rust_Block_51::S_464
            | C2Rust_Block_51::S_467
            | C2Rust_Block_51::S_473
            | C2Rust_Block_51::S_475
            | C2Rust_Block_51::S_477
            | C2Rust_Block_51::S_487
            | C2Rust_Block_51::S_489
            | C2Rust_Block_51::S_491
            | C2Rust_Block_51::S_498
            | C2Rust_Block_51::S_504
            | C2Rust_Block_51::S_506
            | C2Rust_Block_51::S_508
            | C2Rust_Block_51::S_518
            | C2Rust_Block_51::S_520
            | C2Rust_Block_51::S_522
            | C2Rust_Block_51::S_524
            | C2Rust_Block_51::S_526
            | C2Rust_Block_51::S_531
            | C2Rust_Block_51::S_533
            | C2Rust_Block_51::S_543
            | C2Rust_Block_51::S_56
            | C2Rust_Block_51::S_570
            | C2Rust_Block_51::S_572
            | C2Rust_Block_51::S_58
            | C2Rust_Block_51::S_592
            | C2Rust_Block_51::S_594
            | C2Rust_Block_51::S_596
            | C2Rust_Block_51::S_598
            | C2Rust_Block_51::S_6
            | C2Rust_Block_51::S_60
            | C2Rust_Block_51::S_600
            | C2Rust_Block_51::S_602
            | C2Rust_Block_51::S_604
            | C2Rust_Block_51::S_606
            | C2Rust_Block_51::S_608
            | C2Rust_Block_51::S_610
            | C2Rust_Block_51::S_612
            | C2Rust_Block_51::S_614
            | C2Rust_Block_51::S_616
            | C2Rust_Block_51::S_618
            | C2Rust_Block_51::S_620
            | C2Rust_Block_51::S_622
            | C2Rust_Block_51::S_624
            | C2Rust_Block_51::S_626
            | C2Rust_Block_51::S_628
            | C2Rust_Block_51::S_630
            | C2Rust_Block_51::S_632
            | C2Rust_Block_51::S_634
            | C2Rust_Block_51::S_640
            | C2Rust_Block_51::S_642
            | C2Rust_Block_51::S_644
            | C2Rust_Block_51::S_650
            | C2Rust_Block_51::S_656
            | C2Rust_Block_51::S_658
            | C2Rust_Block_51::S_660
            | C2Rust_Block_51::S_670
            | C2Rust_Block_51::S_672
            | C2Rust_Block_51::S_674
            | C2Rust_Block_51::S_680
            | C2Rust_Block_51::S_686
            | C2Rust_Block_51::S_688
            | C2Rust_Block_51::S_690
            | C2Rust_Block_51::S_696
            | C2Rust_Block_51::S_70
            | C2Rust_Block_51::S_702
            | C2Rust_Block_51::S_704
            | C2Rust_Block_51::S_706
            | C2Rust_Block_51::S_708
            | C2Rust_Block_51::S_710
            | C2Rust_Block_51::S_712
            | C2Rust_Block_51::S_714
            | C2Rust_Block_51::S_716
            | C2Rust_Block_51::S_718
            | C2Rust_Block_51::S_72
            | C2Rust_Block_51::S_720
            | C2Rust_Block_51::S_722
            | C2Rust_Block_51::S_724
            | C2Rust_Block_51::S_726
            | C2Rust_Block_51::S_737
            | C2Rust_Block_51::S_739
            | C2Rust_Block_51::S_74
            | C2Rust_Block_51::S_741
            | C2Rust_Block_51::S_743
            | C2Rust_Block_51::S_745
            | C2Rust_Block_51::S_747
            | C2Rust_Block_51::S_749
            | C2Rust_Block_51::S_751
            | C2Rust_Block_51::S_762
            | C2Rust_Block_51::S_764
            | C2Rust_Block_51::S_766
            | C2Rust_Block_51::S_768
            | C2Rust_Block_51::S_770
            | C2Rust_Block_51::S_772
            | C2Rust_Block_51::S_774
            | C2Rust_Block_51::S_780
            | C2Rust_Block_51::S_782
            | C2Rust_Block_51::S_784
            | C2Rust_Block_51::S_796
            | C2Rust_Block_51::S_798
            | C2Rust_Block_51::S_8
            | C2Rust_Block_51::S_80
            | C2Rust_Block_51::S_800
            | C2Rust_Block_51::S_802
            | C2Rust_Block_51::S_804
            | C2Rust_Block_51::S_806
            | C2Rust_Block_51::S_808
            | C2Rust_Block_51::S_810
            | C2Rust_Block_51::S_812
            | C2Rust_Block_51::S_814
            | C2Rust_Block_51::S_816
            | C2Rust_Block_51::S_818
            | C2Rust_Block_51::S_82
            | C2Rust_Block_51::S_820
            | C2Rust_Block_51::S_822
            | C2Rust_Block_51::S_824
            | C2Rust_Block_51::S_826
            | C2Rust_Block_51::S_828
            | C2Rust_Block_51::S_830
            | C2Rust_Block_51::S_832
            | C2Rust_Block_51::S_834
            | C2Rust_Block_51::S_836
            | C2Rust_Block_51::S_838
            | C2Rust_Block_51::S_840
            | C2Rust_Block_51::S_842
            | C2Rust_Block_51::S_844
            | C2Rust_Block_51::S_859
            | C2Rust_Block_51::S_871
            | C2Rust_Block_51::S_873
            | C2Rust_Block_51::S_879
            | C2Rust_Block_51::S_88
            | C2Rust_Block_51::S_881
            | C2Rust_Block_51::S_883
            | C2Rust_Block_51::S_889
            | C2Rust_Block_51::S_895
            | C2Rust_Block_51::S_897
            | C2Rust_Block_51::S_899
            | C2Rust_Block_51::S_90
            | C2Rust_Block_51::S_905
            | C2Rust_Block_51::S_911
            | C2Rust_Block_51::S_913
            | C2Rust_Block_51::S_915
            | C2Rust_Block_51::S_917
            | C2Rust_Block_51::S_919
            | C2Rust_Block_51::S_92
            | C2Rust_Block_51::S_921
            | C2Rust_Block_51::S_923
            | C2Rust_Block_51::S_925
            | C2Rust_Block_51::S_927
            | C2Rust_Block_51::S_929
            | C2Rust_Block_51::S_931
            | C2Rust_Block_51::S_933
            | C2Rust_Block_51::S_935
            | C2Rust_Block_51::S_950
            | C2Rust_Block_51::S_952
            | C2Rust_Block_51::S_962
            | C2Rust_Block_51::S_964
            | C2Rust_Block_51::S_966
            | C2Rust_Block_51::S_976
            | C2Rust_Block_51::S_978
            | C2Rust_Block_51::S_98
            | C2Rust_Block_51::S_980
            | C2Rust_Block_51::S_986
            | C2Rust_Block_51::S_992
            | C2Rust_Block_51::S_998 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F14A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f14b5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001F1250();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F14C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
        .wrapping_add(0x10 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t);
    let mut _pv_1: uint32_t = 0x1f14d8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001F1310();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(4 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
