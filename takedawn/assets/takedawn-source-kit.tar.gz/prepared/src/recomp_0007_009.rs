extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __s: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_00011000();
    fn sub_001D2879();
    fn sub_001D2919();
    fn sub_002276E9();
    fn sub_00244DF0();
    fn sub_0024DAD2();
    fn sub_0024E3F1();
    fn sub_0024E472();
    fn sub_0024E4F1();
    fn sub_0024E534();
    fn sub_0024F54E();
    fn sub_0024F556();
    fn sub_0024F595();
    fn sub_0024F633();
    fn sub_0024FB36();
    fn sub_0024FB6E();
    fn sub_0024FBC9();
    fn sub_0024FC0E();
    fn sub_0025000D();
    fn sub_0025087D();
    fn sub_00250963();
    fn sub_002509AD();
    fn sub_00250A1A();
    fn sub_00250A40();
    fn sub_00250BD6();
    fn sub_00250C77();
    fn sub_00250CE1();
    fn sub_00250F5E();
    fn sub_0025104E();
    fn sub_00251095();
    fn sub_0025112E();
    fn sub_00251179();
    fn sub_002511A3();
    fn sub_002F4201();
    fn sub_002F556A();
    fn sub_002F55C8();
    fn sub_002F5756();
    fn sub_002F5760();
    fn sub_002F6110();
    fn sub_002F7432();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn sub_0024E722() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
        & 2 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    's_319: {
        's_71: {
            if _fa != _fb {
                break 's_71;
            }
            _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                & 0xff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_309: {
                if _fa == _fb {
                    break 's_309;
                }
                let mut _pv_10: uint32_t = 0x801c as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                let mut _pv_11: uint32_t = (*__gamepkg_tls_g_edi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                let mut _pv_12: uint32_t = 0x24e767 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                sub_0024EFFB();
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
            break 's_319;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x24fc8c as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi)
            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t);
        let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x60 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x24e742 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_002276E9();
        _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
            as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_224: {
            if _fa == _fb {
                break 's_224;
            }
            let mut _pv_7: uint32_t = 0x801c as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = 0x24e752 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            sub_0024EFFB();
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E76E() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    enum C2Rust_Block_3 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_84,
        S_86,
        S_88,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_118,
        S_120,
        S_122,
        S_128,
        S_134,
        S_136,
        S_138,
        S_148,
        S_150,
        S_152,
        S_158,
        S_160,
        S_162,
        S_164,
        S_170,
        S_172,
        S_174,
        S_180,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_203,
        S_211,
        S_213,
        S_215,
        S_217,
        S_219,
        S_221,
        S_229,
        S_231,
        S_233,
        S_239,
        S_245,
        S_247,
        S_249,
        S_255,
        S_257,
        S_263,
        S_265,
        S_267,
        S_273,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_320,
        S_322,
        S_324,
        S_334,
        S_336,
        S_338,
        S_348,
        S_350,
        S_352,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_372,
        S_374,
        S_376,
        S_382,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_450,
        S_452,
        S_454,
        S_456,
        S_458,
        S_467,
        S_469,
        S_475,
        S_477,
        S_479,
        S_485,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_497,
        S_503,
        S_505,
        S_507,
        S_513,
        S_519,
        S_521,
        S_523,
        S_525,
        S_527,
        S_529,
        S_531,
        S_533,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_556,
        S_566,
        S_568,
        S_578,
        S_580,
        S_590,
        S_592,
        S_598,
        S_604,
        S_606,
        S_612,
        S_614,
        S_620,
    }
    let mut c2rust_current_block_3: C2Rust_Block_3;
    c2rust_current_block_3 = C2Rust_Block_3::S_0;
    loop {
        match c2rust_current_block_3 {
            C2Rust_Block_3::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_2;
            }
            C2Rust_Block_3::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_3 = C2Rust_Block_3::S_4;
            }
            C2Rust_Block_3::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_3 = C2Rust_Block_3::S_6;
            }
            C2Rust_Block_3::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_8;
            }
            C2Rust_Block_3::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_26;
            }
            C2Rust_Block_3::S_26 => {
                _pv = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_28;
            }
            C2Rust_Block_3::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_30;
            }
            C2Rust_Block_3::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_36;
            }
            C2Rust_Block_3::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_3 = C2Rust_Block_3::S_38;
            }
            C2Rust_Block_3::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_40;
            }
            C2Rust_Block_3::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_42;
            }
            C2Rust_Block_3::S_42 => {
                _fb = 0x38 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_44;
            }
            C2Rust_Block_3::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_46;
            }
            C2Rust_Block_3::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x38 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_48;
            }
            C2Rust_Block_3::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_50;
            }
            C2Rust_Block_3::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_56;
            }
            C2Rust_Block_3::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_3 = C2Rust_Block_3::S_58;
            }
            C2Rust_Block_3::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_60;
            }
            C2Rust_Block_3::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_70;
            }
            C2Rust_Block_3::S_70 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_3 = C2Rust_Block_3::S_72;
            }
            C2Rust_Block_3::S_72 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_74;
            }
            C2Rust_Block_3::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_84;
            }
            C2Rust_Block_3::S_84 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_3 = C2Rust_Block_3::S_86;
            }
            C2Rust_Block_3::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_88;
            }
            C2Rust_Block_3::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_94;
            }
            C2Rust_Block_3::S_94 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_96;
            }
            C2Rust_Block_3::S_96 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_98;
            }
            C2Rust_Block_3::S_98 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_100;
            }
            C2Rust_Block_3::S_100 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_102;
            }
            C2Rust_Block_3::S_102 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_104;
            }
            C2Rust_Block_3::S_104 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_106;
            }
            C2Rust_Block_3::S_106 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_108;
            }
            C2Rust_Block_3::S_108 => {
                (*__gamepkg_tls_g_edi) = ebp
                    .wrapping_add(-12 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_110;
            }
            C2Rust_Block_3::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_112;
            }
            C2Rust_Block_3::S_112 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_3 = C2Rust_Block_3::S_118;
            }
            C2Rust_Block_3::S_118 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_3 = C2Rust_Block_3::S_120;
            }
            C2Rust_Block_3::S_120 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_122;
            }
            C2Rust_Block_3::S_122 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_128;
            }
            C2Rust_Block_3::S_128 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x24 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_134;
            }
            C2Rust_Block_3::S_134 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_3 = C2Rust_Block_3::S_136;
            }
            C2Rust_Block_3::S_136 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_138;
            }
            C2Rust_Block_3::S_138 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_148;
            }
            C2Rust_Block_3::S_148 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_3 = C2Rust_Block_3::S_150;
            }
            C2Rust_Block_3::S_150 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_152;
            }
            C2Rust_Block_3::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_158;
            }
            C2Rust_Block_3::S_158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_160;
            }
            C2Rust_Block_3::S_160 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_162;
            }
            C2Rust_Block_3::S_162 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_164;
            }
            C2Rust_Block_3::S_164 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_170;
            }
            C2Rust_Block_3::S_170 => {
                _pv_6 = 0x24e793 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_172;
            }
            C2Rust_Block_3::S_172 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_174;
            }
            C2Rust_Block_3::S_174 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_180;
            }
            C2Rust_Block_3::S_180 => {
                sub_002F7432();
                c2rust_current_block_3 = C2Rust_Block_3::S_186;
            }
            C2Rust_Block_3::S_186 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_188;
            }
            C2Rust_Block_3::S_188 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_190;
            }
            C2Rust_Block_3::S_190 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_192;
            }
            C2Rust_Block_3::S_192 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_194;
            }
            C2Rust_Block_3::S_194 => {
                if _fa != _fb {
                    c2rust_current_block_3 = C2Rust_Block_3::S_211;
                } else {
                    c2rust_current_block_3 = C2Rust_Block_3::S_203;
                }
            }
            C2Rust_Block_3::S_203 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x8007000e as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_556;
            }
            C2Rust_Block_3::S_211 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-56 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_213;
            }
            C2Rust_Block_3::S_213 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    5 as uint32_t,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_215;
            }
            C2Rust_Block_3::S_215 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_217;
            }
            C2Rust_Block_3::S_217 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_219;
            }
            C2Rust_Block_3::S_219 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_221;
            }
            C2Rust_Block_3::S_221 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_239;
            }
            C2Rust_Block_3::S_229 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_231;
            }
            C2Rust_Block_3::S_231 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_233;
            }
            C2Rust_Block_3::S_233 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_239;
            }
            C2Rust_Block_3::S_239 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_245;
            }
            C2Rust_Block_3::S_245 => {
                _pv_7 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_3 = C2Rust_Block_3::S_247;
            }
            C2Rust_Block_3::S_247 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_249;
            }
            C2Rust_Block_3::S_249 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_255;
            }
            C2Rust_Block_3::S_255 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_257;
            }
            C2Rust_Block_3::S_257 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_263;
            }
            C2Rust_Block_3::S_263 => {
                _pv_8 = 0x24e7c2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_265;
            }
            C2Rust_Block_3::S_265 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_267;
            }
            C2Rust_Block_3::S_267 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_273;
            }
            C2Rust_Block_3::S_273 => {
                sub_0024DAD2();
                c2rust_current_block_3 = C2Rust_Block_3::S_279;
            }
            C2Rust_Block_3::S_279 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_281;
            }
            C2Rust_Block_3::S_281 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_283;
            }
            C2Rust_Block_3::S_283 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_285;
            }
            C2Rust_Block_3::S_285 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_287;
            }
            C2Rust_Block_3::S_287 => {
                if _fa == _fb {
                    c2rust_current_block_3 = C2Rust_Block_3::S_620;
                } else {
                    c2rust_current_block_3 = C2Rust_Block_3::S_296;
                }
            }
            C2Rust_Block_3::S_296 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_298;
            }
            C2Rust_Block_3::S_298 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_300;
            }
            C2Rust_Block_3::S_300 => {
                _fb = 0x1400 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_302;
            }
            C2Rust_Block_3::S_302 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_304;
            }
            C2Rust_Block_3::S_304 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub(0x1400 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_306;
            }
            C2Rust_Block_3::S_306 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_308;
            }
            C2Rust_Block_3::S_308 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_310;
            }
            C2Rust_Block_3::S_310 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 5 as ::core::ffi::c_int;
                c2rust_current_block_3 = C2Rust_Block_3::S_312;
            }
            C2Rust_Block_3::S_312 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_314;
            }
            C2Rust_Block_3::S_314 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_320;
            }
            C2Rust_Block_3::S_320 => {
                _pv_9 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_322;
            }
            C2Rust_Block_3::S_322 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_324;
            }
            C2Rust_Block_3::S_324 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_334;
            }
            C2Rust_Block_3::S_334 => {
                _pv_10 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_3 = C2Rust_Block_3::S_336;
            }
            C2Rust_Block_3::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_338;
            }
            C2Rust_Block_3::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_348;
            }
            C2Rust_Block_3::S_348 => {
                _pv_11 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_350;
            }
            C2Rust_Block_3::S_350 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_352;
            }
            C2Rust_Block_3::S_352 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_358;
            }
            C2Rust_Block_3::S_358 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add((*__gamepkg_tls_g_ebx).wrapping_mul(8 as uint32_t))
                    .wrapping_add(-56 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_360;
            }
            C2Rust_Block_3::S_360 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_362;
            }
            C2Rust_Block_3::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp
                            .wrapping_add(
                                (*__gamepkg_tls_g_ebx).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(-52 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffd8f0 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_364;
            }
            C2Rust_Block_3::S_364 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_366;
            }
            C2Rust_Block_3::S_366 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_372;
            }
            C2Rust_Block_3::S_372 => {
                _pv_12 = 0x24e7ed as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_374;
            }
            C2Rust_Block_3::S_374 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_376;
            }
            C2Rust_Block_3::S_376 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_382;
            }
            C2Rust_Block_3::S_382 => {
                sub_002F55C8();
                c2rust_current_block_3 = C2Rust_Block_3::S_388;
            }
            C2Rust_Block_3::S_388 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                c2rust_current_block_3 = C2Rust_Block_3::S_390;
            }
            C2Rust_Block_3::S_390 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_392;
            }
            C2Rust_Block_3::S_392 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_394;
            }
            C2Rust_Block_3::S_394 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_396;
            }
            C2Rust_Block_3::S_396 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_398;
            }
            C2Rust_Block_3::S_398 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_400;
            }
            C2Rust_Block_3::S_400 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_402;
            }
            C2Rust_Block_3::S_402 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_404;
            }
            C2Rust_Block_3::S_404 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_406;
            }
            C2Rust_Block_3::S_406 => {
                if _fa < _fb {
                    c2rust_current_block_3 = C2Rust_Block_3::S_229;
                } else {
                    c2rust_current_block_3 = C2Rust_Block_3::S_415;
                }
            }
            C2Rust_Block_3::S_415 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_417;
            }
            C2Rust_Block_3::S_417 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_419;
            }
            C2Rust_Block_3::S_419 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_421;
            }
            C2Rust_Block_3::S_421 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_423;
            }
            C2Rust_Block_3::S_423 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_425;
            }
            C2Rust_Block_3::S_425 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_427;
            }
            C2Rust_Block_3::S_427 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_429;
            }
            C2Rust_Block_3::S_429 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_431;
            }
            C2Rust_Block_3::S_431 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_433;
            }
            C2Rust_Block_3::S_433 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_435;
            }
            C2Rust_Block_3::S_435 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_437;
            }
            C2Rust_Block_3::S_437 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    2 as uint32_t,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_439;
            }
            C2Rust_Block_3::S_439 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffd8f0 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_441;
            }
            C2Rust_Block_3::S_441 => {
                if _fa <= _fb {
                    c2rust_current_block_3 = C2Rust_Block_3::S_556;
                } else {
                    c2rust_current_block_3 = C2Rust_Block_3::S_450;
                }
            }
            C2Rust_Block_3::S_450 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_452;
            }
            C2Rust_Block_3::S_452 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_454;
            }
            C2Rust_Block_3::S_454 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_456;
            }
            C2Rust_Block_3::S_456 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_458;
            }
            C2Rust_Block_3::S_458 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_3 = C2Rust_Block_3::S_556;
                } else {
                    c2rust_current_block_3 = C2Rust_Block_3::S_467;
                }
            }
            C2Rust_Block_3::S_467 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_469;
            }
            C2Rust_Block_3::S_469 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-16 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_475;
            }
            C2Rust_Block_3::S_475 => {
                _pv_13 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_3 = C2Rust_Block_3::S_477;
            }
            C2Rust_Block_3::S_477 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_479;
            }
            C2Rust_Block_3::S_479 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_485;
            }
            C2Rust_Block_3::S_485 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_487;
            }
            C2Rust_Block_3::S_487 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_489;
            }
            C2Rust_Block_3::S_489 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ebx));
                c2rust_current_block_3 = C2Rust_Block_3::S_491;
            }
            C2Rust_Block_3::S_491 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_493;
            }
            C2Rust_Block_3::S_493 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_495;
            }
            C2Rust_Block_3::S_495 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_497;
            }
            C2Rust_Block_3::S_497 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_503;
            }
            C2Rust_Block_3::S_503 => {
                _pv_14 = 0x24e828 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_505;
            }
            C2Rust_Block_3::S_505 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_507;
            }
            C2Rust_Block_3::S_507 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_513;
            }
            C2Rust_Block_3::S_513 => {
                sub_00250F5E();
                c2rust_current_block_3 = C2Rust_Block_3::S_519;
            }
            C2Rust_Block_3::S_519 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_3 = C2Rust_Block_3::S_521;
            }
            C2Rust_Block_3::S_521 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_523;
            }
            C2Rust_Block_3::S_523 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_525;
            }
            C2Rust_Block_3::S_525 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_527;
            }
            C2Rust_Block_3::S_527 => {
                _fb = 0x60 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_529;
            }
            C2Rust_Block_3::S_529 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_531;
            }
            C2Rust_Block_3::S_531 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x60 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_533;
            }
            C2Rust_Block_3::S_533 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_535;
            }
            C2Rust_Block_3::S_535 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_537;
            }
            C2Rust_Block_3::S_537 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_539;
            }
            C2Rust_Block_3::S_539 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_541;
            }
            C2Rust_Block_3::S_541 => {
                _fas = _fa as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_543;
            }
            C2Rust_Block_3::S_543 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_545;
            }
            C2Rust_Block_3::S_545 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_547;
            }
            C2Rust_Block_3::S_547 => {
                if _fa < _fb {
                    c2rust_current_block_3 = C2Rust_Block_3::S_450;
                } else {
                    c2rust_current_block_3 = C2Rust_Block_3::S_556;
                }
            }
            C2Rust_Block_3::S_556 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_566;
            }
            C2Rust_Block_3::S_566 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_568;
            }
            C2Rust_Block_3::S_568 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_578;
            }
            C2Rust_Block_3::S_578 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_580;
            }
            C2Rust_Block_3::S_580 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_590;
            }
            C2Rust_Block_3::S_590 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_592;
            }
            C2Rust_Block_3::S_592 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_598;
            }
            C2Rust_Block_3::S_598 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_3 = C2Rust_Block_3::S_604;
            }
            C2Rust_Block_3::S_604 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_3 = C2Rust_Block_3::S_606;
            }
            C2Rust_Block_3::S_606 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_612;
            }
            C2Rust_Block_3::S_612 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_3 = C2Rust_Block_3::S_614;
            }
            C2Rust_Block_3::S_614 => return,
            C2Rust_Block_3::S_620 => {
                (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_3 = C2Rust_Block_3::S_566;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E843() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    enum C2Rust_Block_4 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_57,
        S_63,
        S_65,
        S_67,
        S_74,
        S_80,
        S_82,
        S_84,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_105,
        S_107,
        S_109,
        S_117,
        S_119,
        S_121,
        S_125,
        S_127,
        S_131,
        S_137,
        S_144,
        S_146,
        S_148,
        S_166,
        S_172,
        S_174,
        S_176,
        S_182,
        S_192,
        S_194,
        S_196,
        S_206,
        S_208,
        S_210,
        S_220,
        S_222,
        S_224,
        S_230,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_265,
        S_267,
        S_269,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_302,
        S_304,
        S_306,
        S_312,
        S_314,
        S_316,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_338,
        S_340,
        S_342,
        S_348,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_393,
        S_395,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_419,
        S_421,
        S_427,
        S_440,
        S_442,
        S_444,
        S_454,
        S_456,
        S_458,
        S_464,
        S_470,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_499,
        S_501,
        S_503,
        S_513,
        S_515,
        S_517,
        S_523,
        S_529,
        S_539,
        S_541,
        S_551,
        S_553,
        S_559,
        S_561,
    }
    let mut c2rust_current_block_4: C2Rust_Block_4;
    c2rust_current_block_4 = C2Rust_Block_4::S_0;
    loop {
        match c2rust_current_block_4 {
            C2Rust_Block_4::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_2;
            }
            C2Rust_Block_4::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_4 = C2Rust_Block_4::S_4;
            }
            C2Rust_Block_4::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_4 = C2Rust_Block_4::S_6;
            }
            C2Rust_Block_4::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_8;
            }
            C2Rust_Block_4::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_18;
            }
            C2Rust_Block_4::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_4 = C2Rust_Block_4::S_28;
            }
            C2Rust_Block_4::S_28 => {
                _pv = ebp;
                c2rust_current_block_4 = C2Rust_Block_4::S_30;
            }
            C2Rust_Block_4::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_32;
            }
            C2Rust_Block_4::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_42;
            }
            C2Rust_Block_4::S_42 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_4 = C2Rust_Block_4::S_44;
            }
            C2Rust_Block_4::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_46;
            }
            C2Rust_Block_4::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_52;
            }
            C2Rust_Block_4::S_52 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_4 = C2Rust_Block_4::S_54;
            }
            C2Rust_Block_4::S_54 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_57;
            }
            C2Rust_Block_4::S_57 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_4 = C2Rust_Block_4::S_63;
            }
            C2Rust_Block_4::S_63 => {
                _pv_1 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_4 = C2Rust_Block_4::S_65;
            }
            C2Rust_Block_4::S_65 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_67;
            }
            C2Rust_Block_4::S_67 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_74;
            }
            C2Rust_Block_4::S_74 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_80;
            }
            C2Rust_Block_4::S_80 => {
                _pv_2 = 0x24e851 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_82;
            }
            C2Rust_Block_4::S_82 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_84;
            }
            C2Rust_Block_4::S_84 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_94;
            }
            C2Rust_Block_4::S_94 => {
                _va = _icall_target;
                c2rust_current_block_4 = C2Rust_Block_4::S_96;
            }
            C2Rust_Block_4::S_96 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_98;
            }
            C2Rust_Block_4::S_98 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_100;
            }
            C2Rust_Block_4::S_100 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_102;
            }
            C2Rust_Block_4::S_102 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_4 = C2Rust_Block_4::S_105;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_117;
                }
            }
            C2Rust_Block_4::S_105 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_4 = C2Rust_Block_4::S_107;
            }
            C2Rust_Block_4::S_107 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_4 = C2Rust_Block_4::S_109;
            }
            C2Rust_Block_4::S_109 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_166;
            }
            C2Rust_Block_4::S_117 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_4 = C2Rust_Block_4::S_119;
            }
            C2Rust_Block_4::S_119 => {
                if _fn.is_none() {
                    c2rust_current_block_4 = C2Rust_Block_4::S_121;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_125;
                }
            }
            C2Rust_Block_4::S_121 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_4 = C2Rust_Block_4::S_125;
            }
            C2Rust_Block_4::S_125 => {
                if _fn.is_none() {
                    c2rust_current_block_4 = C2Rust_Block_4::S_127;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_131;
                }
            }
            C2Rust_Block_4::S_127 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_4 = C2Rust_Block_4::S_131;
            }
            C2Rust_Block_4::S_131 => {
                if _fn.is_some() {
                    c2rust_current_block_4 = C2Rust_Block_4::S_137;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_144;
                }
            }
            C2Rust_Block_4::S_137 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_4 = C2Rust_Block_4::S_166;
            }
            C2Rust_Block_4::S_144 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_4 = C2Rust_Block_4::S_146;
            }
            C2Rust_Block_4::S_146 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_4 = C2Rust_Block_4::S_148;
            }
            C2Rust_Block_4::S_148 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_166;
            }
            C2Rust_Block_4::S_166 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_4 = C2Rust_Block_4::S_172;
            }
            C2Rust_Block_4::S_172 => {
                _pv_3 = 0x24e858 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_174;
            }
            C2Rust_Block_4::S_174 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_176;
            }
            C2Rust_Block_4::S_176 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_182;
            }
            C2Rust_Block_4::S_182 => {
                sub_0024FC0E();
                c2rust_current_block_4 = C2Rust_Block_4::S_192;
            }
            C2Rust_Block_4::S_192 => {
                _pv_4 = 0x23 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_194;
            }
            C2Rust_Block_4::S_194 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_196;
            }
            C2Rust_Block_4::S_196 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_206;
            }
            C2Rust_Block_4::S_206 => {
                _pv_5 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_208;
            }
            C2Rust_Block_4::S_208 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_210;
            }
            C2Rust_Block_4::S_210 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_220;
            }
            C2Rust_Block_4::S_220 => {
                _pv_6 = 0x24e862 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_222;
            }
            C2Rust_Block_4::S_222 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_224;
            }
            C2Rust_Block_4::S_224 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_230;
            }
            C2Rust_Block_4::S_230 => {
                sub_0024EFFB();
                c2rust_current_block_4 = C2Rust_Block_4::S_236;
            }
            C2Rust_Block_4::S_236 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_238;
            }
            C2Rust_Block_4::S_238 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_240;
            }
            C2Rust_Block_4::S_240 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_242;
            }
            C2Rust_Block_4::S_242 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_244;
            }
            C2Rust_Block_4::S_244 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_246;
            }
            C2Rust_Block_4::S_246 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_248;
            }
            C2Rust_Block_4::S_248 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_250;
            }
            C2Rust_Block_4::S_250 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_252;
            }
            C2Rust_Block_4::S_252 => {
                if _fa == _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_476;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_265;
                }
            }
            C2Rust_Block_4::S_265 => {
                _pv_7 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_4 = C2Rust_Block_4::S_267;
            }
            C2Rust_Block_4::S_267 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_269;
            }
            C2Rust_Block_4::S_269 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_275;
            }
            C2Rust_Block_4::S_275 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_277;
            }
            C2Rust_Block_4::S_277 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_279;
            }
            C2Rust_Block_4::S_279 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_281;
            }
            C2Rust_Block_4::S_281 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_283;
            }
            C2Rust_Block_4::S_283 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_285;
            }
            C2Rust_Block_4::S_285 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_287;
            }
            C2Rust_Block_4::S_287 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_289;
            }
            C2Rust_Block_4::S_289 => {
                if _fa <= _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_405;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_302;
                }
            }
            C2Rust_Block_4::S_302 => {
                _pv_8 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_4 = C2Rust_Block_4::S_304;
            }
            C2Rust_Block_4::S_304 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_306;
            }
            C2Rust_Block_4::S_306 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_312;
            }
            C2Rust_Block_4::S_312 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_314;
            }
            C2Rust_Block_4::S_314 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_316;
            }
            C2Rust_Block_4::S_316 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_322;
            }
            C2Rust_Block_4::S_322 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_324;
            }
            C2Rust_Block_4::S_324 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_326;
            }
            C2Rust_Block_4::S_326 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_328;
            }
            C2Rust_Block_4::S_328 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ebx));
                c2rust_current_block_4 = C2Rust_Block_4::S_330;
            }
            C2Rust_Block_4::S_330 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_332;
            }
            C2Rust_Block_4::S_332 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_338;
            }
            C2Rust_Block_4::S_338 => {
                _pv_9 = 0x24e881 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_340;
            }
            C2Rust_Block_4::S_340 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_342;
            }
            C2Rust_Block_4::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_348;
            }
            C2Rust_Block_4::S_348 => {
                sub_00250963();
                c2rust_current_block_4 = C2Rust_Block_4::S_354;
            }
            C2Rust_Block_4::S_354 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_4 = C2Rust_Block_4::S_356;
            }
            C2Rust_Block_4::S_356 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_358;
            }
            C2Rust_Block_4::S_358 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_360;
            }
            C2Rust_Block_4::S_360 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_362;
            }
            C2Rust_Block_4::S_362 => {
                _fb = 0x60 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_364;
            }
            C2Rust_Block_4::S_364 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_366;
            }
            C2Rust_Block_4::S_366 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x60 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_368;
            }
            C2Rust_Block_4::S_368 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_370;
            }
            C2Rust_Block_4::S_370 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_372;
            }
            C2Rust_Block_4::S_372 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_374;
            }
            C2Rust_Block_4::S_374 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_376;
            }
            C2Rust_Block_4::S_376 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_378;
            }
            C2Rust_Block_4::S_378 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_380;
            }
            C2Rust_Block_4::S_380 => {
                if _fa < _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_322;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_393;
                }
            }
            C2Rust_Block_4::S_393 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_395;
            }
            C2Rust_Block_4::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_405;
            }
            C2Rust_Block_4::S_405 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_407;
            }
            C2Rust_Block_4::S_407 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_409;
            }
            C2Rust_Block_4::S_409 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_411;
            }
            C2Rust_Block_4::S_411 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_413;
            }
            C2Rust_Block_4::S_413 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_419;
            }
            C2Rust_Block_4::S_419 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_421;
            }
            C2Rust_Block_4::S_421 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_427;
            }
            C2Rust_Block_4::S_427 => {
                if _fa == _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_470;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_440;
                }
            }
            C2Rust_Block_4::S_440 => {
                _pv_10 = 3 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_442;
            }
            C2Rust_Block_4::S_442 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_444;
            }
            C2Rust_Block_4::S_444 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_454;
            }
            C2Rust_Block_4::S_454 => {
                _pv_11 = 0x24e89a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_456;
            }
            C2Rust_Block_4::S_456 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_458;
            }
            C2Rust_Block_4::S_458 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_464;
            }
            C2Rust_Block_4::S_464 => {
                sub_0024E722();
                c2rust_current_block_4 = C2Rust_Block_4::S_470;
            }
            C2Rust_Block_4::S_470 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_476;
            }
            C2Rust_Block_4::S_476 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_478;
            }
            C2Rust_Block_4::S_478 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_480;
            }
            C2Rust_Block_4::S_480 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_482;
            }
            C2Rust_Block_4::S_482 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_484;
            }
            C2Rust_Block_4::S_484 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_486;
            }
            C2Rust_Block_4::S_486 => {
                if _fa == _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_539;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_499;
                }
            }
            C2Rust_Block_4::S_499 => {
                _pv_12 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_4 = C2Rust_Block_4::S_501;
            }
            C2Rust_Block_4::S_501 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_503;
            }
            C2Rust_Block_4::S_503 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_513;
            }
            C2Rust_Block_4::S_513 => {
                _pv_13 = 0x24e8aa as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_515;
            }
            C2Rust_Block_4::S_515 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_517;
            }
            C2Rust_Block_4::S_517 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_523;
            }
            C2Rust_Block_4::S_523 => {
                sub_002F4201();
                c2rust_current_block_4 = C2Rust_Block_4::S_529;
            }
            C2Rust_Block_4::S_529 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_539;
            }
            C2Rust_Block_4::S_539 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_541;
            }
            C2Rust_Block_4::S_541 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_551;
            }
            C2Rust_Block_4::S_551 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_553;
            }
            C2Rust_Block_4::S_553 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_559;
            }
            C2Rust_Block_4::S_559 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_561;
            }
            C2Rust_Block_4::S_561 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E8B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_147: {
        if _fa <= _fb {
            break 's_147;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = 0x24e8c8 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_0024F556();
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                < if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_147;
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_147;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E8D5() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_223: {
        if _fa <= _fb {
            break 's_223;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x24 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = 0x50 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(0x140 as uint32_t);
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            's_176: {
                's_155: {
                    if (*__gamepkg_tls_g_df) != 0 {
                        break 's_155;
                    }
                    let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    let mut _n: uint32_t = (*__gamepkg_tls_g_ecx)
                        .wrapping_mul(4 as uint32_t);
                    's_148: {
                        's_127: {
                            if _d.offset(_n as isize) <= _s
                                || _s.offset(_n as isize) <= _d
                            {
                                break 's_127;
                            }
                            let mut _i: uint32_t = 0;
                            _i = 0 as uint32_t;
                            loop {
                                if _i >= (*__gamepkg_tls_g_ecx) {
                                    break 's_148;
                                }
                                ::core::ptr::write_volatile(
                                    ::core::ptr::with_exposed_provenance_mut::<
                                        uint32_t,
                                    >(
                                        ((*__gamepkg_tls_g_edi)
                                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                    ),
                                    ::core::ptr::read_volatile::<
                                        uint32_t,
                                    >(
                                        ::core::ptr::with_exposed_provenance_mut::<
                                            uint32_t,
                                        >(
                                            ((*__gamepkg_tls_g_esi)
                                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                        ),
                                    ),
                                );
                                _i = _i.wrapping_add(1);
                            }
                        }
                        memcpy(
                            _d as *mut ::core::ffi::c_void,
                            _s as *const ::core::ffi::c_void,
                            _n as size_t,
                        );
                    }
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    break 's_176;
                }
                let mut _i_0: uint32_t = 0;
                _i_0 = 0 as uint32_t;
                while _i_0 < (*__gamepkg_tls_g_ecx) {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    _i_0 = _i_0.wrapping_add(1);
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            }
            (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E8FD() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    's_282: {
        if _fa <= _fb {
            break 's_282;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_edi) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_266: {
            if _fa <= _fb {
                break 's_266;
            }
            loop {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_2: uint32_t = 0x24e922 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                sub_0025000D();
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_149: {
                    if _fa == _fb {
                        break 's_149;
                    }
                    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_252: {
                        if _fa <= _fb {
                            break 's_252;
                        }
                        loop {
                            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            );
                            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_eax)
                                        .wrapping_add(
                                            (*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t),
                                        ) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            );
                            let mut _pv_3: uint32_t = 0x24e940 as ::core::ffi::c_uint
                                as uint32_t;
                            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                .wrapping_sub(4 as uint32_t);
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                _pv_3,
                            );
                            sub_00250A1A();
                            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                                .wrapping_add(1);
                            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                            _fas = _fa as int32_t;
                            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                                as uint32_t;
                            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                            _fb = ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) & 0xffffffff as uint32_t;
                            _fas = _fa as int32_t;
                            _fbs = _fb as int32_t;
                            if _fa >= _fb {
                                break 's_252;
                            }
                        }
                    }
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    break 's_266;
                }
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_266;
                }
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E94E() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_ebx) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_2: uint32_t = 0x24e967 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024E4F1();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_191: {
        if _fa == _fb {
            break 's_191;
        }
        let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x24e97a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_002509AD();
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(24 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E984() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b1854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b1854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24e998 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244DF0();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ebp.wrapping_add(0xc as uint32_t);
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_5: uint32_t = 0x20 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_ecx));
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_8: uint32_t = 0x24e9bc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_002F556A();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E9C1() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_2: uint32_t = 0x24e9d7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024E4F1();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_145: {
        if _fa == _fb {
            break 's_145;
        }
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x4c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E9E6() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_ebx) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_2: uint32_t = 0x24e9ff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024E4F1();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_191: {
        if _fa == _fb {
            break 's_191;
        }
        let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x24ea12 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00250BD6();
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(24 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EA1C() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_ebx) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_2: uint32_t = 0x24ea35 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024E4F1();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_191: {
        if _fa == _fb {
            break 's_191;
        }
        let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x24ea46 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_002F5756();
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EA50() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    enum C2Rust_Block_13 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_46,
        S_48,
        S_50,
        S_60,
        S_62,
        S_64,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_93,
        S_95,
        S_97,
        S_104,
        S_107,
        S_113,
        S_115,
        S_117,
        S_127,
        S_129,
        S_131,
        S_133,
        S_135,
        S_138,
        S_140,
        S_142,
        S_150,
        S_152,
        S_154,
        S_158,
        S_160,
        S_164,
        S_170,
        S_177,
        S_179,
        S_181,
        S_199,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_217,
        S_226,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_255,
        S_257,
        S_259,
        S_265,
        S_267,
        S_269,
        S_275,
        S_277,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_390,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_417,
        S_419,
        S_421,
        S_427,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_479,
        S_481,
        S_483,
        S_489,
        S_491,
        S_493,
        S_499,
        S_511,
        S_513,
        S_515,
        S_521,
        S_523,
        S_525,
        S_531,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_563,
        S_576,
        S_578,
        S_588,
        S_590,
        S_592,
        S_594,
        S_600,
        S_602,
        S_608,
        S_617,
        S_620,
        S_626,
        S_628,
        S_630,
        S_636,
        S_638,
        S_640,
        S_646,
        S_648,
        S_650,
        S_656,
        S_662,
        S_664,
        S_666,
        S_672,
        S_674,
        S_676,
        S_678,
        S_680,
        S_686,
        S_688,
        S_690,
        S_697,
        S_703,
        S_705,
        S_707,
        S_717,
        S_719,
        S_721,
        S_723,
        S_725,
        S_728,
        S_730,
        S_732,
        S_740,
        S_742,
        S_744,
        S_748,
        S_750,
        S_754,
        S_760,
        S_767,
        S_769,
        S_771,
        S_789,
        S_792,
        S_795,
        S_801,
        S_803,
        S_805,
        S_815,
        S_817,
        S_819,
        S_821,
        S_823,
        S_826,
        S_828,
        S_830,
        S_838,
        S_840,
        S_842,
        S_846,
        S_848,
        S_852,
        S_858,
        S_865,
        S_867,
        S_869,
        S_891,
        S_893,
        S_899,
        S_905,
        S_907,
        S_913,
        S_915,
    }
    let mut c2rust_current_block_13: C2Rust_Block_13;
    c2rust_current_block_13 = C2Rust_Block_13::S_0;
    loop {
        match c2rust_current_block_13 {
            C2Rust_Block_13::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_2;
            }
            C2Rust_Block_13::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_13 = C2Rust_Block_13::S_4;
            }
            C2Rust_Block_13::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_13 = C2Rust_Block_13::S_6;
            }
            C2Rust_Block_13::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_8;
            }
            C2Rust_Block_13::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_26;
            }
            C2Rust_Block_13::S_26 => {
                _pv = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_28;
            }
            C2Rust_Block_13::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_30;
            }
            C2Rust_Block_13::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_36;
            }
            C2Rust_Block_13::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_13 = C2Rust_Block_13::S_38;
            }
            C2Rust_Block_13::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_40;
            }
            C2Rust_Block_13::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_46;
            }
            C2Rust_Block_13::S_46 => {
                _pv_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_48;
            }
            C2Rust_Block_13::S_48 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_50;
            }
            C2Rust_Block_13::S_50 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_60;
            }
            C2Rust_Block_13::S_60 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_13 = C2Rust_Block_13::S_62;
            }
            C2Rust_Block_13::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_64;
            }
            C2Rust_Block_13::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_70;
            }
            C2Rust_Block_13::S_70 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_72;
            }
            C2Rust_Block_13::S_72 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_74;
            }
            C2Rust_Block_13::S_74 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_76;
            }
            C2Rust_Block_13::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_78;
            }
            C2Rust_Block_13::S_78 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_80;
            }
            C2Rust_Block_13::S_80 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_891;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_93;
                }
            }
            C2Rust_Block_13::S_93 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_13 = C2Rust_Block_13::S_95;
            }
            C2Rust_Block_13::S_95 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_97;
            }
            C2Rust_Block_13::S_97 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_104;
            }
            C2Rust_Block_13::S_104 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_13 = C2Rust_Block_13::S_107;
            }
            C2Rust_Block_13::S_107 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_113;
            }
            C2Rust_Block_13::S_113 => {
                _pv_3 = 0x24ea6b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_115;
            }
            C2Rust_Block_13::S_115 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_117;
            }
            C2Rust_Block_13::S_117 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_127;
            }
            C2Rust_Block_13::S_127 => {
                _va = _icall_target;
                c2rust_current_block_13 = C2Rust_Block_13::S_129;
            }
            C2Rust_Block_13::S_129 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_131;
            }
            C2Rust_Block_13::S_131 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_133;
            }
            C2Rust_Block_13::S_133 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_135;
            }
            C2Rust_Block_13::S_135 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_13 = C2Rust_Block_13::S_138;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_150;
                }
            }
            C2Rust_Block_13::S_138 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_13 = C2Rust_Block_13::S_140;
            }
            C2Rust_Block_13::S_140 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_13 = C2Rust_Block_13::S_142;
            }
            C2Rust_Block_13::S_142 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_199;
            }
            C2Rust_Block_13::S_150 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_13 = C2Rust_Block_13::S_152;
            }
            C2Rust_Block_13::S_152 => {
                if _fn.is_none() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_154;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_158;
                }
            }
            C2Rust_Block_13::S_154 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_13 = C2Rust_Block_13::S_158;
            }
            C2Rust_Block_13::S_158 => {
                if _fn.is_none() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_160;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_164;
                }
            }
            C2Rust_Block_13::S_160 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_13 = C2Rust_Block_13::S_164;
            }
            C2Rust_Block_13::S_164 => {
                if _fn.is_some() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_170;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_177;
                }
            }
            C2Rust_Block_13::S_170 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_13 = C2Rust_Block_13::S_199;
            }
            C2Rust_Block_13::S_177 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_13 = C2Rust_Block_13::S_179;
            }
            C2Rust_Block_13::S_179 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_13 = C2Rust_Block_13::S_181;
            }
            C2Rust_Block_13::S_181 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_199;
            }
            C2Rust_Block_13::S_199 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_201;
            }
            C2Rust_Block_13::S_201 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_203;
            }
            C2Rust_Block_13::S_203 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_205;
            }
            C2Rust_Block_13::S_205 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_207;
            }
            C2Rust_Block_13::S_207 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_209;
            }
            C2Rust_Block_13::S_209 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_211;
            }
            C2Rust_Block_13::S_211 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_213;
            }
            C2Rust_Block_13::S_213 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        (ebp.wrapping_add(-1 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_215;
            }
            C2Rust_Block_13::S_215 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_217;
            }
            C2Rust_Block_13::S_217 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_234;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_226;
                }
            }
            C2Rust_Block_13::S_226 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_373;
            }
            C2Rust_Block_13::S_234 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_236;
            }
            C2Rust_Block_13::S_236 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_238;
            }
            C2Rust_Block_13::S_238 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_240;
            }
            C2Rust_Block_13::S_240 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_242;
            }
            C2Rust_Block_13::S_242 => {
                if _fa < _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_373;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_255;
                }
            }
            C2Rust_Block_13::S_255 => {
                _pv_4 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_257;
            }
            C2Rust_Block_13::S_257 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_259;
            }
            C2Rust_Block_13::S_259 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_265;
            }
            C2Rust_Block_13::S_265 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_267;
            }
            C2Rust_Block_13::S_267 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_269;
            }
            C2Rust_Block_13::S_269 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_275;
            }
            C2Rust_Block_13::S_275 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_277;
            }
            C2Rust_Block_13::S_277 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_283;
            }
            C2Rust_Block_13::S_283 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_285;
            }
            C2Rust_Block_13::S_285 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_287;
            }
            C2Rust_Block_13::S_287 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_289;
            }
            C2Rust_Block_13::S_289 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_291;
            }
            C2Rust_Block_13::S_291 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x64 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_297;
            }
            C2Rust_Block_13::S_297 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_299;
            }
            C2Rust_Block_13::S_299 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_301;
            }
            C2Rust_Block_13::S_301 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_303;
            }
            C2Rust_Block_13::S_303 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_305;
            }
            C2Rust_Block_13::S_305 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_355;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_314;
                }
            }
            C2Rust_Block_13::S_314 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_316;
            }
            C2Rust_Block_13::S_316 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_318;
            }
            C2Rust_Block_13::S_318 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_320;
            }
            C2Rust_Block_13::S_320 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_322;
            }
            C2Rust_Block_13::S_322 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_324;
            }
            C2Rust_Block_13::S_324 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_326;
            }
            C2Rust_Block_13::S_326 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_328;
            }
            C2Rust_Block_13::S_328 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_330;
            }
            C2Rust_Block_13::S_330 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_332;
            }
            C2Rust_Block_13::S_332 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_334;
            }
            C2Rust_Block_13::S_334 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_336;
            }
            C2Rust_Block_13::S_336 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_338;
            }
            C2Rust_Block_13::S_338 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_340;
            }
            C2Rust_Block_13::S_340 => {
                if _fa <= _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_297;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_373;
                }
            }
            C2Rust_Block_13::S_355 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_357;
            }
            C2Rust_Block_13::S_357 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_359;
            }
            C2Rust_Block_13::S_359 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_361;
            }
            C2Rust_Block_13::S_361 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_363;
            }
            C2Rust_Block_13::S_363 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_365;
            }
            C2Rust_Block_13::S_365 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_367;
            }
            C2Rust_Block_13::S_367 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_373;
            }
            C2Rust_Block_13::S_373 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_375;
            }
            C2Rust_Block_13::S_375 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_377;
            }
            C2Rust_Block_13::S_377 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_379;
            }
            C2Rust_Block_13::S_379 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_381;
            }
            C2Rust_Block_13::S_381 => {
                if _fa < _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_396;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_390;
                }
            }
            C2Rust_Block_13::S_390 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_396;
            }
            C2Rust_Block_13::S_396 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_398;
            }
            C2Rust_Block_13::S_398 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_400;
            }
            C2Rust_Block_13::S_400 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_402;
            }
            C2Rust_Block_13::S_402 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_404;
            }
            C2Rust_Block_13::S_404 => {
                if _fa <= _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_588;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_417;
                }
            }
            C2Rust_Block_13::S_417 => {
                _pv_5 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_419;
            }
            C2Rust_Block_13::S_419 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_421;
            }
            C2Rust_Block_13::S_421 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_427;
            }
            C2Rust_Block_13::S_427 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_433;
            }
            C2Rust_Block_13::S_433 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub(1 as uint32_t),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_435;
            }
            C2Rust_Block_13::S_435 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_437;
            }
            C2Rust_Block_13::S_437 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_439;
            }
            C2Rust_Block_13::S_439 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_441;
            }
            C2Rust_Block_13::S_441 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_443;
            }
            C2Rust_Block_13::S_443 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(0x6c as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_445;
            }
            C2Rust_Block_13::S_445 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_447;
            }
            C2Rust_Block_13::S_447 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_449;
            }
            C2Rust_Block_13::S_449 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_451;
            }
            C2Rust_Block_13::S_451 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_453;
            }
            C2Rust_Block_13::S_453 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_13 = C2Rust_Block_13::S_511;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_462;
                }
            }
            C2Rust_Block_13::S_462 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_464;
            }
            C2Rust_Block_13::S_464 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_466;
            }
            C2Rust_Block_13::S_466 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_468;
            }
            C2Rust_Block_13::S_468 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_470;
            }
            C2Rust_Block_13::S_470 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_13 = C2Rust_Block_13::S_537;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_479;
                }
            }
            C2Rust_Block_13::S_479 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(0x70 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_481;
            }
            C2Rust_Block_13::S_481 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_483;
            }
            C2Rust_Block_13::S_483 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_489;
            }
            C2Rust_Block_13::S_489 => {
                _pv_6 = 0x24eacd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_491;
            }
            C2Rust_Block_13::S_491 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_493;
            }
            C2Rust_Block_13::S_493 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_499;
            }
            C2Rust_Block_13::S_499 => {
                sub_00250A40();
                c2rust_current_block_13 = C2Rust_Block_13::S_537;
            }
            C2Rust_Block_13::S_511 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(0x70 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_513;
            }
            C2Rust_Block_13::S_513 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_515;
            }
            C2Rust_Block_13::S_515 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_521;
            }
            C2Rust_Block_13::S_521 => {
                _pv_7 = 0x24ead8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_523;
            }
            C2Rust_Block_13::S_523 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_525;
            }
            C2Rust_Block_13::S_525 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_531;
            }
            C2Rust_Block_13::S_531 => {
                sub_0024F595();
                c2rust_current_block_13 = C2Rust_Block_13::S_537;
            }
            C2Rust_Block_13::S_537 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_539;
            }
            C2Rust_Block_13::S_539 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_541;
            }
            C2Rust_Block_13::S_541 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_543;
            }
            C2Rust_Block_13::S_543 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_545;
            }
            C2Rust_Block_13::S_545 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_sub(1);
                c2rust_current_block_13 = C2Rust_Block_13::S_547;
            }
            C2Rust_Block_13::S_547 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_549;
            }
            C2Rust_Block_13::S_549 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_551;
            }
            C2Rust_Block_13::S_551 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_553;
            }
            C2Rust_Block_13::S_553 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x6c as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_555;
            }
            C2Rust_Block_13::S_555 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_557;
            }
            C2Rust_Block_13::S_557 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_13 = C2Rust_Block_13::S_559;
            }
            C2Rust_Block_13::S_559 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_561;
            }
            C2Rust_Block_13::S_561 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_13 = C2Rust_Block_13::S_563;
            }
            C2Rust_Block_13::S_563 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_13 = C2Rust_Block_13::S_433;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_576;
                }
            }
            C2Rust_Block_13::S_576 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_578;
            }
            C2Rust_Block_13::S_578 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_588;
            }
            C2Rust_Block_13::S_588 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_590;
            }
            C2Rust_Block_13::S_590 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_592;
            }
            C2Rust_Block_13::S_592 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_594;
            }
            C2Rust_Block_13::S_594 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_600;
            }
            C2Rust_Block_13::S_600 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_602;
            }
            C2Rust_Block_13::S_602 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_608;
            }
            C2Rust_Block_13::S_608 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_789;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_617;
                }
            }
            C2Rust_Block_13::S_617 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x50 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_620;
            }
            C2Rust_Block_13::S_620 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_13 = C2Rust_Block_13::S_626;
            }
            C2Rust_Block_13::S_626 => {
                _pv_8 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_628;
            }
            C2Rust_Block_13::S_628 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_630;
            }
            C2Rust_Block_13::S_630 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_636;
            }
            C2Rust_Block_13::S_636 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_638;
            }
            C2Rust_Block_13::S_638 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_640;
            }
            C2Rust_Block_13::S_640 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_646;
            }
            C2Rust_Block_13::S_646 => {
                _pv_9 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_648;
            }
            C2Rust_Block_13::S_648 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_650;
            }
            C2Rust_Block_13::S_650 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_656;
            }
            C2Rust_Block_13::S_656 => {
                (*__gamepkg_tls_g_eax) = 0xffffd8f0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_662;
            }
            C2Rust_Block_13::S_662 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_664;
            }
            C2Rust_Block_13::S_664 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_666;
            }
            C2Rust_Block_13::S_666 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_672;
            }
            C2Rust_Block_13::S_672 => {
                _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_674;
            }
            C2Rust_Block_13::S_674 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_676;
            }
            C2Rust_Block_13::S_676 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_678;
            }
            C2Rust_Block_13::S_678 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_680;
            }
            C2Rust_Block_13::S_680 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_686;
            }
            C2Rust_Block_13::S_686 => {
                _pv_11 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_13 = C2Rust_Block_13::S_688;
            }
            C2Rust_Block_13::S_688 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_690;
            }
            C2Rust_Block_13::S_690 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_697;
            }
            C2Rust_Block_13::S_697 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_703;
            }
            C2Rust_Block_13::S_703 => {
                _pv_12 = 0x24eb0c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_705;
            }
            C2Rust_Block_13::S_705 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_707;
            }
            C2Rust_Block_13::S_707 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_717;
            }
            C2Rust_Block_13::S_717 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_13 = C2Rust_Block_13::S_719;
            }
            C2Rust_Block_13::S_719 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_721;
            }
            C2Rust_Block_13::S_721 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_723;
            }
            C2Rust_Block_13::S_723 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_725;
            }
            C2Rust_Block_13::S_725 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_13 = C2Rust_Block_13::S_728;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_740;
                }
            }
            C2Rust_Block_13::S_728 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_13 = C2Rust_Block_13::S_730;
            }
            C2Rust_Block_13::S_730 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_13 = C2Rust_Block_13::S_732;
            }
            C2Rust_Block_13::S_732 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_789;
            }
            C2Rust_Block_13::S_740 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_13 = C2Rust_Block_13::S_742;
            }
            C2Rust_Block_13::S_742 => {
                if _fn_0.is_none() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_744;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_748;
                }
            }
            C2Rust_Block_13::S_744 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_13 = C2Rust_Block_13::S_748;
            }
            C2Rust_Block_13::S_748 => {
                if _fn_0.is_none() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_750;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_754;
                }
            }
            C2Rust_Block_13::S_750 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_13 = C2Rust_Block_13::S_754;
            }
            C2Rust_Block_13::S_754 => {
                if _fn_0.is_some() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_760;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_767;
                }
            }
            C2Rust_Block_13::S_760 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_13 = C2Rust_Block_13::S_789;
            }
            C2Rust_Block_13::S_767 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_13 = C2Rust_Block_13::S_769;
            }
            C2Rust_Block_13::S_769 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_13 = C2Rust_Block_13::S_771;
            }
            C2Rust_Block_13::S_771 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_789;
            }
            C2Rust_Block_13::S_789 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(-1 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_792;
            }
            C2Rust_Block_13::S_792 => {
                _icall_esp_1 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_13 = C2Rust_Block_13::S_795;
            }
            C2Rust_Block_13::S_795 => {
                _icall_target_1 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_801;
            }
            C2Rust_Block_13::S_801 => {
                _pv_13 = 0x24eb15 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_803;
            }
            C2Rust_Block_13::S_803 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_805;
            }
            C2Rust_Block_13::S_805 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_815;
            }
            C2Rust_Block_13::S_815 => {
                _va_1 = _icall_target_1;
                c2rust_current_block_13 = C2Rust_Block_13::S_817;
            }
            C2Rust_Block_13::S_817 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_1,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_819;
            }
            C2Rust_Block_13::S_819 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_821;
            }
            C2Rust_Block_13::S_821 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_823;
            }
            C2Rust_Block_13::S_823 => {
                if !(_va_1 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                {
                    c2rust_current_block_13 = C2Rust_Block_13::S_826;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_838;
                }
            }
            C2Rust_Block_13::S_826 => {
                recomp_icall_not_code_log(_va_1);
                c2rust_current_block_13 = C2Rust_Block_13::S_828;
            }
            C2Rust_Block_13::S_828 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_13 = C2Rust_Block_13::S_830;
            }
            C2Rust_Block_13::S_830 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_891;
            }
            C2Rust_Block_13::S_838 => {
                _fn_1 = recomp_lookup_manual(_va_1);
                c2rust_current_block_13 = C2Rust_Block_13::S_840;
            }
            C2Rust_Block_13::S_840 => {
                if _fn_1.is_none() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_842;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_846;
                }
            }
            C2Rust_Block_13::S_842 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block_13 = C2Rust_Block_13::S_846;
            }
            C2Rust_Block_13::S_846 => {
                if _fn_1.is_none() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_848;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_852;
                }
            }
            C2Rust_Block_13::S_848 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block_13 = C2Rust_Block_13::S_852;
            }
            C2Rust_Block_13::S_852 => {
                if _fn_1.is_some() {
                    c2rust_current_block_13 = C2Rust_Block_13::S_858;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_865;
                }
            }
            C2Rust_Block_13::S_858 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block_13 = C2Rust_Block_13::S_891;
            }
            C2Rust_Block_13::S_865 => {
                recomp_icall_fail_log(_va_1);
                c2rust_current_block_13 = C2Rust_Block_13::S_867;
            }
            C2Rust_Block_13::S_867 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_13 = C2Rust_Block_13::S_869;
            }
            C2Rust_Block_13::S_869 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_891;
            }
            C2Rust_Block_13::S_891 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_893;
            }
            C2Rust_Block_13::S_893 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_899;
            }
            C2Rust_Block_13::S_899 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_13 = C2Rust_Block_13::S_905;
            }
            C2Rust_Block_13::S_905 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_907;
            }
            C2Rust_Block_13::S_907 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_913;
            }
            C2Rust_Block_13::S_913 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_915;
            }
            C2Rust_Block_13::S_915 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EB1A() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_315: {
        if _fa == _fb {
            break 's_315;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        's_148: {
            if _fa <= _fb {
                break 's_148;
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx)
                .wrapping_add(0x70 as uint32_t);
            loop {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_148;
                }
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_148;
                }
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edx);
        's_234: {
            if _fa >= _fb {
                break 's_234;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x6c as uint32_t);
            loop {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_234;
                }
            }
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        if _fa >= _fb {
            break 's_315;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x6c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                        .wrapping_add(0x6c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x6c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x70 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                        .wrapping_add(0x70 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x70 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = 0xfffffffe as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                .wrapping_add(0xfffffffe as uint32_t),
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EB95() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_313: {
        if _fa == _fb {
            break 's_313;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        's_148: {
            if _fa <= _fb {
                break 's_148;
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx)
                .wrapping_add(0x70 as uint32_t);
            loop {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_148;
                }
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_148;
                }
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edx);
        's_234: {
            if _fa >= _fb {
                break 's_234;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x6c as uint32_t);
            loop {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_234;
                }
            }
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        if _fa >= _fb {
            break 's_313;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x6c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                        .wrapping_add(0x6c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x6c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x70 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                        .wrapping_add(0x70 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                    .wrapping_add(0x70 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                .wrapping_sub(1 as uint32_t),
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC0F() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_140: {
        if _fa <= _fb {
            break 's_140;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = 0x24ec2b as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            sub_00250C77();
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_140;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC36() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_140: {
        if _fa <= _fb {
            break 's_140;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = 0x24ec52 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            sub_00250CE1();
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_140;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC5D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC61() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC65() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0x24ec72 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024F54E();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC75() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_1: uint32_t = 0x24ec81 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024FB36();
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    let mut _pv_3: uint32_t = 0x24ec8c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024EC36();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EC90() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_2: uint32_t = 0x24ec9e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024EB1A();
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x24eca4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024EC0F();
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    let mut _pv_6: uint32_t = 0x24ecac as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_0024FB6E();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024ECB1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _t: uint64_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    enum C2Rust_Block_23 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_24,
        S_26,
        S_28,
        S_38,
        S_40,
        S_42,
        S_48,
        S_54,
        S_56,
        S_58,
        S_64,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_88,
        S_94,
        S_100,
        S_106,
        S_108,
        S_110,
        S_116,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_141,
        S_147,
        S_149,
        S_151,
        S_157,
        S_163,
        S_169,
        S_171,
        S_173,
        S_179,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_204,
        S_210,
        S_212,
        S_214,
        S_220,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_249,
        S_253,
        S_255,
        S_257,
        S_267,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_293,
        S_295,
        S_297,
        S_307,
        S_309,
        S_315,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_345,
        S_348,
        S_350,
        S_352,
        S_356,
        S_358,
        S_360,
        S_363,
        S_369,
        S_371,
        S_373,
        S_379,
        S_381,
        S_383,
        S_385,
        S_391,
        S_393,
        S_395,
        S_405,
        S_407,
        S_409,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_431,
        S_433,
        S_435,
        S_442,
        S_448,
        S_450,
        S_452,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_473,
        S_475,
        S_477,
        S_485,
        S_487,
        S_489,
        S_493,
        S_495,
        S_499,
        S_505,
        S_512,
        S_514,
        S_516,
        S_538,
        S_540,
        S_546,
        S_548,
    }
    let mut c2rust_current_block_23: C2Rust_Block_23;
    c2rust_current_block_23 = C2Rust_Block_23::S_0;
    loop {
        match c2rust_current_block_23 {
            C2Rust_Block_23::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_2;
            }
            C2Rust_Block_23::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_4;
            }
            C2Rust_Block_23::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_14;
            }
            C2Rust_Block_23::S_14 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_24;
            }
            C2Rust_Block_23::S_24 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_26;
            }
            C2Rust_Block_23::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_28;
            }
            C2Rust_Block_23::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_38;
            }
            C2Rust_Block_23::S_38 => {
                _pv_0 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_40;
            }
            C2Rust_Block_23::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_42;
            }
            C2Rust_Block_23::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_48;
            }
            C2Rust_Block_23::S_48 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_23 = C2Rust_Block_23::S_54;
            }
            C2Rust_Block_23::S_54 => {
                _pv_1 = 0x24ecbb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_56;
            }
            C2Rust_Block_23::S_56 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_58;
            }
            C2Rust_Block_23::S_58 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_64;
            }
            C2Rust_Block_23::S_64 => {
                sub_0024EA50();
                c2rust_current_block_23 = C2Rust_Block_23::S_70;
            }
            C2Rust_Block_23::S_70 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_72;
            }
            C2Rust_Block_23::S_72 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_74;
            }
            C2Rust_Block_23::S_74 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_76;
            }
            C2Rust_Block_23::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_78;
            }
            C2Rust_Block_23::S_78 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_84;
            }
            C2Rust_Block_23::S_84 => {
                _pv_2 = 0x24ecc9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_86;
            }
            C2Rust_Block_23::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_88;
            }
            C2Rust_Block_23::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_94;
            }
            C2Rust_Block_23::S_94 => {
                sub_0024E8D5();
                c2rust_current_block_23 = C2Rust_Block_23::S_100;
            }
            C2Rust_Block_23::S_100 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_106;
            }
            C2Rust_Block_23::S_106 => {
                _pv_3 = 0x24ecd0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_108;
            }
            C2Rust_Block_23::S_108 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_110;
            }
            C2Rust_Block_23::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_116;
            }
            C2Rust_Block_23::S_116 => {
                sub_0024E8B0();
                c2rust_current_block_23 = C2Rust_Block_23::S_122;
            }
            C2Rust_Block_23::S_122 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_124;
            }
            C2Rust_Block_23::S_124 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_126;
            }
            C2Rust_Block_23::S_126 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_128;
            }
            C2Rust_Block_23::S_128 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_130;
            }
            C2Rust_Block_23::S_130 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_132;
            }
            C2Rust_Block_23::S_132 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_23 = C2Rust_Block_23::S_163;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_141;
                }
            }
            C2Rust_Block_23::S_141 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_147;
            }
            C2Rust_Block_23::S_147 => {
                _pv_4 = 0x24ecdb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_149;
            }
            C2Rust_Block_23::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_151;
            }
            C2Rust_Block_23::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_157;
            }
            C2Rust_Block_23::S_157 => {
                sub_0024E3F1();
                c2rust_current_block_23 = C2Rust_Block_23::S_163;
            }
            C2Rust_Block_23::S_163 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_169;
            }
            C2Rust_Block_23::S_169 => {
                _pv_5 = 0x24ece2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_171;
            }
            C2Rust_Block_23::S_171 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_173;
            }
            C2Rust_Block_23::S_173 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_179;
            }
            C2Rust_Block_23::S_179 => {
                sub_0024E8FD();
                c2rust_current_block_23 = C2Rust_Block_23::S_185;
            }
            C2Rust_Block_23::S_185 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_187;
            }
            C2Rust_Block_23::S_187 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_189;
            }
            C2Rust_Block_23::S_189 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_191;
            }
            C2Rust_Block_23::S_191 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_193;
            }
            C2Rust_Block_23::S_193 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_195;
            }
            C2Rust_Block_23::S_195 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_23 = C2Rust_Block_23::S_226;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_204;
                }
            }
            C2Rust_Block_23::S_204 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_210;
            }
            C2Rust_Block_23::S_210 => {
                _pv_6 = 0x24eced as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_212;
            }
            C2Rust_Block_23::S_212 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_214;
            }
            C2Rust_Block_23::S_214 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_220;
            }
            C2Rust_Block_23::S_220 => {
                sub_0024E472();
                c2rust_current_block_23 = C2Rust_Block_23::S_226;
            }
            C2Rust_Block_23::S_226 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_228;
            }
            C2Rust_Block_23::S_228 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_230;
            }
            C2Rust_Block_23::S_230 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_232;
            }
            C2Rust_Block_23::S_232 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_234;
            }
            C2Rust_Block_23::S_234 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_236;
            }
            C2Rust_Block_23::S_236 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_238;
            }
            C2Rust_Block_23::S_238 => {
                if _fa != _fb {
                    c2rust_current_block_23 = C2Rust_Block_23::S_267;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_249;
                }
            }
            C2Rust_Block_23::S_249 => {
                _cf = ((*__gamepkg_tls_g_eax)
                    >> 1 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_253;
            }
            C2Rust_Block_23::S_253 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 1 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_255;
            }
            C2Rust_Block_23::S_255 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_257;
            }
            C2Rust_Block_23::S_257 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_293;
            }
            C2Rust_Block_23::S_267 => {
                _cf = ((*__gamepkg_tls_g_eax)
                    >> 1 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_271;
            }
            C2Rust_Block_23::S_271 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 1 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_273;
            }
            C2Rust_Block_23::S_273 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_275;
            }
            C2Rust_Block_23::S_275 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_277;
            }
            C2Rust_Block_23::S_277 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_23 = C2Rust_Block_23::S_279;
            }
            C2Rust_Block_23::S_279 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_281;
            }
            C2Rust_Block_23::S_281 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_283;
            }
            C2Rust_Block_23::S_283 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_293;
            }
            C2Rust_Block_23::S_293 => {
                _pv_7 = 0x13 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_295;
            }
            C2Rust_Block_23::S_295 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_297;
            }
            C2Rust_Block_23::S_297 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_307;
            }
            C2Rust_Block_23::S_307 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_309;
            }
            C2Rust_Block_23::S_309 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_315;
            }
            C2Rust_Block_23::S_315 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_317;
            }
            C2Rust_Block_23::S_317 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_319;
            }
            C2Rust_Block_23::S_319 => {
                _cf = ((*__gamepkg_tls_g_ecx) < (*__gamepkg_tls_g_eax))
                    as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_321;
            }
            C2Rust_Block_23::S_321 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_23 = C2Rust_Block_23::S_323;
            }
            C2Rust_Block_23::S_323 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_325;
            }
            C2Rust_Block_23::S_325 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_327;
            }
            C2Rust_Block_23::S_327 => {
                (*__gamepkg_tls_g_ecx) = ((*__gamepkg_tls_g_ecx) as int32_t
                    * 0x2710 as ::core::ffi::c_int as int32_t) as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_329;
            }
            C2Rust_Block_23::S_329 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_331;
            }
            C2Rust_Block_23::S_331 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_333;
            }
            C2Rust_Block_23::S_333 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_335;
            }
            C2Rust_Block_23::S_335 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_337;
            }
            C2Rust_Block_23::S_337 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_339;
            }
            C2Rust_Block_23::S_339 => {
                _cf = ((*__gamepkg_tls_g_ecx) != 0 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_341;
            }
            C2Rust_Block_23::S_341 => {
                (*__gamepkg_tls_g_ecx) = -((*__gamepkg_tls_g_ecx) as int32_t)
                    as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_343;
            }
            C2Rust_Block_23::S_343 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_345;
            }
            C2Rust_Block_23::S_345 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_348;
            }
            C2Rust_Block_23::S_348 => {
                _t = ((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(_cf as uint64_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_350;
            }
            C2Rust_Block_23::S_350 => {
                _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_352;
            }
            C2Rust_Block_23::S_352 => {
                (*__gamepkg_tls_g_eax) = _t as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_356;
            }
            C2Rust_Block_23::S_356 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_358;
            }
            C2Rust_Block_23::S_358 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_360;
            }
            C2Rust_Block_23::S_360 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x50 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_363;
            }
            C2Rust_Block_23::S_363 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_23 = C2Rust_Block_23::S_369;
            }
            C2Rust_Block_23::S_369 => {
                _pv_8 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_23 = C2Rust_Block_23::S_371;
            }
            C2Rust_Block_23::S_371 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_373;
            }
            C2Rust_Block_23::S_373 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_379;
            }
            C2Rust_Block_23::S_379 => {
                _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_381;
            }
            C2Rust_Block_23::S_381 => {
                (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                    as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_383;
            }
            C2Rust_Block_23::S_383 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_385;
            }
            C2Rust_Block_23::S_385 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_391;
            }
            C2Rust_Block_23::S_391 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_23 = C2Rust_Block_23::S_393;
            }
            C2Rust_Block_23::S_393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_395;
            }
            C2Rust_Block_23::S_395 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_405;
            }
            C2Rust_Block_23::S_405 => {
                _pv_10 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_23 = C2Rust_Block_23::S_407;
            }
            C2Rust_Block_23::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_409;
            }
            C2Rust_Block_23::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_415;
            }
            C2Rust_Block_23::S_415 => {
                _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_417;
            }
            C2Rust_Block_23::S_417 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_419;
            }
            C2Rust_Block_23::S_419 => {
                _cf = (((*__gamepkg_tls_g_esi) as uint64_t)
                    .wrapping_add(0x28 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_23 = C2Rust_Block_23::S_421;
            }
            C2Rust_Block_23::S_421 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_423;
            }
            C2Rust_Block_23::S_423 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_425;
            }
            C2Rust_Block_23::S_425 => {
                _fas = _fa as int32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_431;
            }
            C2Rust_Block_23::S_431 => {
                _pv_11 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_23 = C2Rust_Block_23::S_433;
            }
            C2Rust_Block_23::S_433 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_435;
            }
            C2Rust_Block_23::S_435 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_442;
            }
            C2Rust_Block_23::S_442 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_448;
            }
            C2Rust_Block_23::S_448 => {
                _pv_12 = 0x24ed27 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_450;
            }
            C2Rust_Block_23::S_450 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_452;
            }
            C2Rust_Block_23::S_452 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_462;
            }
            C2Rust_Block_23::S_462 => {
                _va = _icall_target;
                c2rust_current_block_23 = C2Rust_Block_23::S_464;
            }
            C2Rust_Block_23::S_464 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_466;
            }
            C2Rust_Block_23::S_466 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_468;
            }
            C2Rust_Block_23::S_468 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_470;
            }
            C2Rust_Block_23::S_470 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_23 = C2Rust_Block_23::S_473;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_485;
                }
            }
            C2Rust_Block_23::S_473 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_475;
            }
            C2Rust_Block_23::S_475 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_23 = C2Rust_Block_23::S_477;
            }
            C2Rust_Block_23::S_477 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_538;
            }
            C2Rust_Block_23::S_485 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_487;
            }
            C2Rust_Block_23::S_487 => {
                if _fn.is_none() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_489;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_493;
                }
            }
            C2Rust_Block_23::S_489 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_493;
            }
            C2Rust_Block_23::S_493 => {
                if _fn.is_none() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_495;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_499;
                }
            }
            C2Rust_Block_23::S_495 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_499;
            }
            C2Rust_Block_23::S_499 => {
                if _fn.is_some() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_505;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_512;
                }
            }
            C2Rust_Block_23::S_505 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_23 = C2Rust_Block_23::S_538;
            }
            C2Rust_Block_23::S_512 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_514;
            }
            C2Rust_Block_23::S_514 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_23 = C2Rust_Block_23::S_516;
            }
            C2Rust_Block_23::S_516 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_538;
            }
            C2Rust_Block_23::S_538 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_540;
            }
            C2Rust_Block_23::S_540 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_546;
            }
            C2Rust_Block_23::S_546 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_23 = C2Rust_Block_23::S_548;
            }
            C2Rust_Block_23::S_548 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024ED29() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_3: uint32_t = 0x24ed35 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024EA50();
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_184: {
        if _fa <= _fb {
            break 's_184;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_5: uint32_t = 0x24ed4e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_0024F633();
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_184;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_337: {
        if _fa <= _fb {
            break 's_337;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
                int32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    int32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_250: {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_250;
                }
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
            }
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
            {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x374e54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
            } else {
                recomp_fp_round24(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x374e54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double,
                )
            };
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
            {
                ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x374dd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double
                    - (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            } else {
                recomp_fp_round24(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x374dd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
                        - (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                )
            };
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    as ::core::ffi::c_float,
            );
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = 0x24ed8a as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            sub_0024E984();
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_337;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024ED94() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    enum C2Rust_Block_25 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_73,
        S_79,
        S_81,
        S_83,
        S_93,
        S_95,
        S_97,
        S_103,
        S_106,
        S_112,
        S_114,
        S_116,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_137,
        S_139,
        S_141,
        S_149,
        S_151,
        S_153,
        S_157,
        S_159,
        S_163,
        S_169,
        S_176,
        S_178,
        S_180,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_242,
        S_244,
        S_246,
        S_252,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_277,
        S_279,
        S_285,
        S_287,
        S_289,
        S_295,
        S_297,
        S_299,
        S_305,
        S_307,
        S_309,
        S_315,
        S_325,
        S_327,
        S_329,
        S_339,
        S_341,
        S_343,
        S_353,
        S_355,
        S_357,
        S_367,
        S_369,
        S_371,
        S_377,
        S_379,
        S_385,
        S_387,
        S_389,
        S_395,
        S_401,
        S_403,
        S_405,
        S_411,
        S_413,
        S_415,
        S_421,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_504,
        S_510,
        S_513,
        S_516,
        S_522,
        S_524,
        S_526,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_547,
        S_549,
        S_551,
        S_559,
        S_561,
        S_563,
        S_567,
        S_569,
        S_573,
        S_579,
        S_586,
        S_588,
        S_590,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_625,
        S_627,
        S_629,
        S_631,
        S_633,
        S_635,
        S_641,
        S_643,
        S_645,
        S_655,
        S_657,
        S_663,
        S_665,
        S_667,
        S_669,
        S_671,
        S_673,
        S_679,
        S_685,
        S_687,
        S_689,
        S_695,
        S_697,
        S_703,
        S_705,
        S_707,
        S_713,
        S_719,
        S_721,
        S_723,
        S_725,
        S_727,
        S_729,
        S_731,
        S_733,
        S_735,
        S_737,
        S_739,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_753,
        S_755,
        S_757,
        S_759,
        S_768,
        S_774,
        S_776,
        S_778,
        S_788,
        S_790,
        S_792,
        S_798,
        S_800,
        S_806,
        S_808,
        S_810,
        S_816,
        S_822,
        S_824,
        S_826,
        S_834,
        S_844,
        S_846,
        S_856,
        S_858,
        S_868,
        S_870,
        S_876,
        S_882,
        S_884,
        S_890,
        S_892,
    }
    let mut c2rust_current_block_25: C2Rust_Block_25;
    c2rust_current_block_25 = C2Rust_Block_25::S_0;
    loop {
        match c2rust_current_block_25 {
            C2Rust_Block_25::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_2;
            }
            C2Rust_Block_25::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_25 = C2Rust_Block_25::S_4;
            }
            C2Rust_Block_25::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_25 = C2Rust_Block_25::S_6;
            }
            C2Rust_Block_25::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_8;
            }
            C2Rust_Block_25::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_26;
            }
            C2Rust_Block_25::S_26 => {
                _pv = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_28;
            }
            C2Rust_Block_25::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_30;
            }
            C2Rust_Block_25::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_36;
            }
            C2Rust_Block_25::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_38;
            }
            C2Rust_Block_25::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_40;
            }
            C2Rust_Block_25::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_42;
            }
            C2Rust_Block_25::S_42 => {
                _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_44;
            }
            C2Rust_Block_25::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_46;
            }
            C2Rust_Block_25::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x28 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_48;
            }
            C2Rust_Block_25::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_50;
            }
            C2Rust_Block_25::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_52;
            }
            C2Rust_Block_25::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_54;
            }
            C2Rust_Block_25::S_54 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_56;
            }
            C2Rust_Block_25::S_56 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_62;
            }
            C2Rust_Block_25::S_62 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_25 = C2Rust_Block_25::S_64;
            }
            C2Rust_Block_25::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_66;
            }
            C2Rust_Block_25::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_73;
            }
            C2Rust_Block_25::S_73 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_79;
            }
            C2Rust_Block_25::S_79 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_81;
            }
            C2Rust_Block_25::S_81 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_83;
            }
            C2Rust_Block_25::S_83 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_93;
            }
            C2Rust_Block_25::S_93 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_25 = C2Rust_Block_25::S_95;
            }
            C2Rust_Block_25::S_95 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_97;
            }
            C2Rust_Block_25::S_97 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_103;
            }
            C2Rust_Block_25::S_103 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_25 = C2Rust_Block_25::S_106;
            }
            C2Rust_Block_25::S_106 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_112;
            }
            C2Rust_Block_25::S_112 => {
                _pv_3 = 0x24eda9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_114;
            }
            C2Rust_Block_25::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_116;
            }
            C2Rust_Block_25::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_126;
            }
            C2Rust_Block_25::S_126 => {
                _va = _icall_target;
                c2rust_current_block_25 = C2Rust_Block_25::S_128;
            }
            C2Rust_Block_25::S_128 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_130;
            }
            C2Rust_Block_25::S_130 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_132;
            }
            C2Rust_Block_25::S_132 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_134;
            }
            C2Rust_Block_25::S_134 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_25 = C2Rust_Block_25::S_137;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_149;
                }
            }
            C2Rust_Block_25::S_137 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_139;
            }
            C2Rust_Block_25::S_139 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_25 = C2Rust_Block_25::S_141;
            }
            C2Rust_Block_25::S_141 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_198;
            }
            C2Rust_Block_25::S_149 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_151;
            }
            C2Rust_Block_25::S_151 => {
                if _fn.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_153;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_157;
                }
            }
            C2Rust_Block_25::S_153 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_157;
            }
            C2Rust_Block_25::S_157 => {
                if _fn.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_159;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_163;
                }
            }
            C2Rust_Block_25::S_159 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_163;
            }
            C2Rust_Block_25::S_163 => {
                if _fn.is_some() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_169;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_176;
                }
            }
            C2Rust_Block_25::S_169 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_25 = C2Rust_Block_25::S_198;
            }
            C2Rust_Block_25::S_176 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_178;
            }
            C2Rust_Block_25::S_178 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_25 = C2Rust_Block_25::S_180;
            }
            C2Rust_Block_25::S_180 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_198;
            }
            C2Rust_Block_25::S_198 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_200;
            }
            C2Rust_Block_25::S_200 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_202;
            }
            C2Rust_Block_25::S_202 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_204;
            }
            C2Rust_Block_25::S_204 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_206;
            }
            C2Rust_Block_25::S_206 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_208;
            }
            C2Rust_Block_25::S_208 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_210;
            }
            C2Rust_Block_25::S_210 => {
                (*__gamepkg_tls_g_esi) = ebp.wrapping_add(8 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_212;
            }
            C2Rust_Block_25::S_212 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_214;
            }
            C2Rust_Block_25::S_214 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_216;
            }
            C2Rust_Block_25::S_216 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_218;
            }
            C2Rust_Block_25::S_218 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_220;
            }
            C2Rust_Block_25::S_220 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_222;
            }
            C2Rust_Block_25::S_222 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_224;
            }
            C2Rust_Block_25::S_224 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_25 = C2Rust_Block_25::S_226;
            }
            C2Rust_Block_25::S_226 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        (ebp.wrapping_add(-1 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_228;
            }
            C2Rust_Block_25::S_228 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_230;
            }
            C2Rust_Block_25::S_230 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_232;
            }
            C2Rust_Block_25::S_232 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_234;
            }
            C2Rust_Block_25::S_234 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_236;
            }
            C2Rust_Block_25::S_236 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_242;
            }
            C2Rust_Block_25::S_242 => {
                _pv_4 = 0x24edbe as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_244;
            }
            C2Rust_Block_25::S_244 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_246;
            }
            C2Rust_Block_25::S_246 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_252;
            }
            C2Rust_Block_25::S_252 => {
                sub_0024E534();
                c2rust_current_block_25 = C2Rust_Block_25::S_258;
            }
            C2Rust_Block_25::S_258 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_25 = C2Rust_Block_25::S_260;
            }
            C2Rust_Block_25::S_260 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_262;
            }
            C2Rust_Block_25::S_262 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_264;
            }
            C2Rust_Block_25::S_264 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_266;
            }
            C2Rust_Block_25::S_266 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_268;
            }
            C2Rust_Block_25::S_268 => {
                if _fa >= _fb {
                    c2rust_current_block_25 = C2Rust_Block_25::S_504;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_277;
                }
            }
            C2Rust_Block_25::S_277 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_279;
            }
            C2Rust_Block_25::S_279 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_285;
            }
            C2Rust_Block_25::S_285 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_287;
            }
            C2Rust_Block_25::S_287 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_289;
            }
            C2Rust_Block_25::S_289 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_295;
            }
            C2Rust_Block_25::S_295 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_25 = C2Rust_Block_25::S_297;
            }
            C2Rust_Block_25::S_297 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_299;
            }
            C2Rust_Block_25::S_299 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_305;
            }
            C2Rust_Block_25::S_305 => {
                _pv_6 = 0x24edd3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_307;
            }
            C2Rust_Block_25::S_307 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_309;
            }
            C2Rust_Block_25::S_309 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_315;
            }
            C2Rust_Block_25::S_315 => {
                sub_0024EB95();
                c2rust_current_block_25 = C2Rust_Block_25::S_325;
            }
            C2Rust_Block_25::S_325 => {
                _pv_7 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_327;
            }
            C2Rust_Block_25::S_327 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_329;
            }
            C2Rust_Block_25::S_329 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_339;
            }
            C2Rust_Block_25::S_339 => {
                _pv_8 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_341;
            }
            C2Rust_Block_25::S_341 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_343;
            }
            C2Rust_Block_25::S_343 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_353;
            }
            C2Rust_Block_25::S_353 => {
                _pv_9 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_355;
            }
            C2Rust_Block_25::S_355 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_357;
            }
            C2Rust_Block_25::S_357 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_367;
            }
            C2Rust_Block_25::S_367 => {
                _pv_10 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_369;
            }
            C2Rust_Block_25::S_369 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_371;
            }
            C2Rust_Block_25::S_371 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_377;
            }
            C2Rust_Block_25::S_377 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_379;
            }
            C2Rust_Block_25::S_379 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_385;
            }
            C2Rust_Block_25::S_385 => {
                _pv_11 = 0x24ede1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_387;
            }
            C2Rust_Block_25::S_387 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_389;
            }
            C2Rust_Block_25::S_389 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_395;
            }
            C2Rust_Block_25::S_395 => {
                sub_002F5760();
                c2rust_current_block_25 = C2Rust_Block_25::S_401;
            }
            C2Rust_Block_25::S_401 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_403;
            }
            C2Rust_Block_25::S_403 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_405;
            }
            C2Rust_Block_25::S_405 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_411;
            }
            C2Rust_Block_25::S_411 => {
                _pv_12 = 0x24ede8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_413;
            }
            C2Rust_Block_25::S_413 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_415;
            }
            C2Rust_Block_25::S_415 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_421;
            }
            C2Rust_Block_25::S_421 => {
                sub_0025087D();
                c2rust_current_block_25 = C2Rust_Block_25::S_453;
            }
            C2Rust_Block_25::S_433 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_435;
            }
            C2Rust_Block_25::S_435 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_25 = C2Rust_Block_25::S_437;
            }
            C2Rust_Block_25::S_437 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_439;
            }
            C2Rust_Block_25::S_439 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_441;
            }
            C2Rust_Block_25::S_441 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_25 = C2Rust_Block_25::S_443;
            }
            C2Rust_Block_25::S_443 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_445;
            }
            C2Rust_Block_25::S_445 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_447;
            }
            C2Rust_Block_25::S_447 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_453;
            }
            C2Rust_Block_25::S_453 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_455;
            }
            C2Rust_Block_25::S_455 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_25 = C2Rust_Block_25::S_457;
            }
            C2Rust_Block_25::S_457 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_459;
            }
            C2Rust_Block_25::S_459 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_461;
            }
            C2Rust_Block_25::S_461 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_463;
            }
            C2Rust_Block_25::S_463 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_465;
            }
            C2Rust_Block_25::S_465 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_467;
            }
            C2Rust_Block_25::S_467 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_469;
            }
            C2Rust_Block_25::S_469 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_471;
            }
            C2Rust_Block_25::S_471 => {
                if _fa < _fb {
                    c2rust_current_block_25 = C2Rust_Block_25::S_433;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_480;
                }
            }
            C2Rust_Block_25::S_480 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_482;
            }
            C2Rust_Block_25::S_482 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_484;
            }
            C2Rust_Block_25::S_484 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            )
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx)
                                .wrapping_add(
                                    (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                                )
                                .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_486;
            }
            C2Rust_Block_25::S_486 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            )
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_488;
            }
            C2Rust_Block_25::S_488 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_490;
            }
            C2Rust_Block_25::S_490 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub(1 as uint32_t),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_492;
            }
            C2Rust_Block_25::S_492 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_494;
            }
            C2Rust_Block_25::S_494 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_496;
            }
            C2Rust_Block_25::S_496 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_510;
            }
            C2Rust_Block_25::S_504 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_510;
            }
            C2Rust_Block_25::S_510 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(-1 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_513;
            }
            C2Rust_Block_25::S_513 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_516;
            }
            C2Rust_Block_25::S_516 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_522;
            }
            C2Rust_Block_25::S_522 => {
                _pv_13 = 0x24ee1a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_524;
            }
            C2Rust_Block_25::S_524 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_526;
            }
            C2Rust_Block_25::S_526 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_536;
            }
            C2Rust_Block_25::S_536 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_25 = C2Rust_Block_25::S_538;
            }
            C2Rust_Block_25::S_538 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_540;
            }
            C2Rust_Block_25::S_540 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_542;
            }
            C2Rust_Block_25::S_542 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_544;
            }
            C2Rust_Block_25::S_544 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_25 = C2Rust_Block_25::S_547;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_559;
                }
            }
            C2Rust_Block_25::S_547 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_549;
            }
            C2Rust_Block_25::S_549 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_25 = C2Rust_Block_25::S_551;
            }
            C2Rust_Block_25::S_551 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_608;
            }
            C2Rust_Block_25::S_559 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_561;
            }
            C2Rust_Block_25::S_561 => {
                if _fn_0.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_563;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_567;
                }
            }
            C2Rust_Block_25::S_563 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_567;
            }
            C2Rust_Block_25::S_567 => {
                if _fn_0.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_569;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_573;
                }
            }
            C2Rust_Block_25::S_569 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_573;
            }
            C2Rust_Block_25::S_573 => {
                if _fn_0.is_some() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_579;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_586;
                }
            }
            C2Rust_Block_25::S_579 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_25 = C2Rust_Block_25::S_608;
            }
            C2Rust_Block_25::S_586 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_588;
            }
            C2Rust_Block_25::S_588 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_25 = C2Rust_Block_25::S_590;
            }
            C2Rust_Block_25::S_590 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_608;
            }
            C2Rust_Block_25::S_608 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_610;
            }
            C2Rust_Block_25::S_610 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_612;
            }
            C2Rust_Block_25::S_612 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_614;
            }
            C2Rust_Block_25::S_614 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_616;
            }
            C2Rust_Block_25::S_616 => {
                if _fa == _fb {
                    c2rust_current_block_25 = C2Rust_Block_25::S_834;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_625;
                }
            }
            C2Rust_Block_25::S_625 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_627;
            }
            C2Rust_Block_25::S_627 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_629;
            }
            C2Rust_Block_25::S_629 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_631;
            }
            C2Rust_Block_25::S_631 => {
                (*__gamepkg_tls_g_edi) = ebp.wrapping_add(0x10 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_633;
            }
            C2Rust_Block_25::S_633 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_635;
            }
            C2Rust_Block_25::S_635 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_25 = C2Rust_Block_25::S_641;
            }
            C2Rust_Block_25::S_641 => {
                _pv_14 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_643;
            }
            C2Rust_Block_25::S_643 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_645;
            }
            C2Rust_Block_25::S_645 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_655;
            }
            C2Rust_Block_25::S_655 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_657;
            }
            C2Rust_Block_25::S_657 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_663;
            }
            C2Rust_Block_25::S_663 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-40 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_665;
            }
            C2Rust_Block_25::S_665 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_667;
            }
            C2Rust_Block_25::S_667 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_669;
            }
            C2Rust_Block_25::S_669 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_671;
            }
            C2Rust_Block_25::S_671 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_673;
            }
            C2Rust_Block_25::S_673 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_679;
            }
            C2Rust_Block_25::S_679 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_685;
            }
            C2Rust_Block_25::S_685 => {
                _pv_15 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_25 = C2Rust_Block_25::S_687;
            }
            C2Rust_Block_25::S_687 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_689;
            }
            C2Rust_Block_25::S_689 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_695;
            }
            C2Rust_Block_25::S_695 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_697;
            }
            C2Rust_Block_25::S_697 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_703;
            }
            C2Rust_Block_25::S_703 => {
                _pv_16 = 0x24ee3e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_705;
            }
            C2Rust_Block_25::S_705 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_707;
            }
            C2Rust_Block_25::S_707 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_713;
            }
            C2Rust_Block_25::S_713 => {
                sub_0024DAD2();
                c2rust_current_block_25 = C2Rust_Block_25::S_719;
            }
            C2Rust_Block_25::S_719 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_721;
            }
            C2Rust_Block_25::S_721 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_723;
            }
            C2Rust_Block_25::S_723 => {
                _fb = 0x1400 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_725;
            }
            C2Rust_Block_25::S_725 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_727;
            }
            C2Rust_Block_25::S_727 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(0x1400 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_729;
            }
            C2Rust_Block_25::S_729 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_731;
            }
            C2Rust_Block_25::S_731 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_733;
            }
            C2Rust_Block_25::S_733 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 5 as ::core::ffi::c_int;
                c2rust_current_block_25 = C2Rust_Block_25::S_735;
            }
            C2Rust_Block_25::S_735 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_737;
            }
            C2Rust_Block_25::S_737 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_739;
            }
            C2Rust_Block_25::S_739 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp
                            .wrapping_add(
                                (*__gamepkg_tls_g_edi).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(-40 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_741;
            }
            C2Rust_Block_25::S_741 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp
                            .wrapping_add(
                                (*__gamepkg_tls_g_edi).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffd8f0 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_743;
            }
            C2Rust_Block_25::S_743 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_25 = C2Rust_Block_25::S_745;
            }
            C2Rust_Block_25::S_745 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_747;
            }
            C2Rust_Block_25::S_747 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_749;
            }
            C2Rust_Block_25::S_749 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_751;
            }
            C2Rust_Block_25::S_751 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_753;
            }
            C2Rust_Block_25::S_753 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_755;
            }
            C2Rust_Block_25::S_755 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_757;
            }
            C2Rust_Block_25::S_757 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_759;
            }
            C2Rust_Block_25::S_759 => {
                if _fa < _fb {
                    c2rust_current_block_25 = C2Rust_Block_25::S_679;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_768;
                }
            }
            C2Rust_Block_25::S_768 => {
                (*__gamepkg_tls_g_eax) = ebp.wrapping_add(0xc as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_774;
            }
            C2Rust_Block_25::S_774 => {
                _pv_17 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_25 = C2Rust_Block_25::S_776;
            }
            C2Rust_Block_25::S_776 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_778;
            }
            C2Rust_Block_25::S_778 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_788;
            }
            C2Rust_Block_25::S_788 => {
                _pv_18 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_790;
            }
            C2Rust_Block_25::S_790 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_792;
            }
            C2Rust_Block_25::S_792 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_798;
            }
            C2Rust_Block_25::S_798 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_800;
            }
            C2Rust_Block_25::S_800 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_806;
            }
            C2Rust_Block_25::S_806 => {
                _pv_19 = 0x24ee69 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_808;
            }
            C2Rust_Block_25::S_808 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_810;
            }
            C2Rust_Block_25::S_810 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_816;
            }
            C2Rust_Block_25::S_816 => {
                sub_002F6110();
                c2rust_current_block_25 = C2Rust_Block_25::S_822;
            }
            C2Rust_Block_25::S_822 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_824;
            }
            C2Rust_Block_25::S_824 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_826;
            }
            C2Rust_Block_25::S_826 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_844;
            }
            C2Rust_Block_25::S_834 => {
                (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_844;
            }
            C2Rust_Block_25::S_844 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_846;
            }
            C2Rust_Block_25::S_846 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_856;
            }
            C2Rust_Block_25::S_856 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_858;
            }
            C2Rust_Block_25::S_858 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_868;
            }
            C2Rust_Block_25::S_868 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_870;
            }
            C2Rust_Block_25::S_870 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_876;
            }
            C2Rust_Block_25::S_876 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_25 = C2Rust_Block_25::S_882;
            }
            C2Rust_Block_25::S_882 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_884;
            }
            C2Rust_Block_25::S_884 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_890;
            }
            C2Rust_Block_25::S_890 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_892;
            }
            C2Rust_Block_25::S_892 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EE79() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24ee84 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024EA50();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EE87() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    enum C2Rust_Block_27 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_25,
        S_31,
        S_33,
        S_35,
        S_45,
        S_47,
        S_49,
        S_59,
        S_61,
        S_63,
        S_73,
        S_75,
        S_77,
        S_83,
        S_85,
        S_87,
        S_89,
        S_95,
        S_97,
        S_99,
        S_105,
        S_111,
        S_113,
        S_115,
        S_122,
        S_128,
        S_130,
        S_132,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_153,
        S_155,
        S_157,
        S_165,
        S_167,
        S_169,
        S_173,
        S_175,
        S_179,
        S_185,
        S_192,
        S_194,
        S_196,
        S_215,
        S_221,
        S_223,
        S_225,
        S_235,
        S_237,
        S_239,
        S_245,
        S_251,
        S_253,
        S_255,
        S_262,
        S_268,
        S_270,
        S_272,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_293,
        S_295,
        S_297,
        S_305,
        S_307,
        S_309,
        S_313,
        S_315,
        S_319,
        S_325,
        S_332,
        S_334,
        S_336,
        S_354,
        S_360,
        S_362,
        S_364,
        S_370,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_411,
        S_413,
        S_415,
        S_425,
        S_427,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_454,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_479,
        S_485,
        S_487,
        S_490,
        S_493,
        S_499,
        S_501,
        S_503,
        S_513,
        S_515,
        S_517,
        S_519,
        S_521,
        S_524,
        S_526,
        S_528,
        S_536,
        S_538,
        S_540,
        S_544,
        S_546,
        S_550,
        S_556,
        S_563,
        S_565,
        S_567,
        S_589,
        S_591,
        S_601,
        S_603,
        S_613,
        S_615,
        S_621,
        S_627,
        S_629,
        S_635,
        S_637,
        S_643,
        S_645,
        S_647,
        S_649,
        S_655,
        S_657,
        S_659,
        S_665,
        S_667,
        S_669,
        S_671,
        S_673,
        S_679,
        S_681,
        S_683,
        S_693,
        S_695,
        S_697,
        S_703,
        S_709,
        S_711,
        S_713,
        S_715,
        S_717,
        S_730,
        S_732,
        S_734,
        S_744,
        S_746,
        S_748,
        S_754,
        S_760,
        S_762,
        S_764,
        S_774,
        S_776,
        S_778,
        S_784,
        S_790,
        S_792,
        S_794,
        S_800,
        S_812,
        S_814,
        S_816,
        S_822,
        S_824,
        S_826,
        S_828,
        S_830,
        S_832,
        S_841,
        S_847,
        S_849,
        S_851,
        S_857,
        S_859,
        S_861,
        S_867,
        S_869,
        S_871,
        S_881,
        S_883,
        S_885,
        S_891,
        S_897,
        S_899,
        S_901,
        S_903,
        S_905,
        S_907,
        S_916,
        S_924,
        S_926,
        S_928,
        S_930,
        S_932,
        S_934,
        S_936,
        S_938,
        S_947,
        S_949,
        S_951,
        S_953,
        S_955,
        S_957,
        S_959,
        S_961,
        S_963,
        S_965,
        S_967,
        S_976,
        S_978,
        S_984,
        S_986,
        S_988,
        S_994,
        S_1000,
        S_1002,
        S_1004,
        S_1006,
        S_1008,
        S_1010,
        S_1023,
        S_1025,
        S_1027,
        S_1037,
        S_1039,
        S_1045,
        S_1047,
        S_1049,
        S_1051,
        S_1054,
        S_1056,
        S_1059,
        S_1060,
        S_1061,
        S_1062,
        S_1069,
        S_1073,
    }
    let mut c2rust_current_block_27: C2Rust_Block_27;
    c2rust_current_block_27 = C2Rust_Block_27::S_0;
    loop {
        match c2rust_current_block_27 {
            C2Rust_Block_27::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_2;
            }
            C2Rust_Block_27::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_27 = C2Rust_Block_27::S_4;
            }
            C2Rust_Block_27::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_27 = C2Rust_Block_27::S_6;
            }
            C2Rust_Block_27::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_8;
            }
            C2Rust_Block_27::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_18;
            }
            C2Rust_Block_27::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_27 = C2Rust_Block_27::S_25;
            }
            C2Rust_Block_27::S_25 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_27 = C2Rust_Block_27::S_31;
            }
            C2Rust_Block_27::S_31 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_27 = C2Rust_Block_27::S_33;
            }
            C2Rust_Block_27::S_33 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_35;
            }
            C2Rust_Block_27::S_35 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_45;
            }
            C2Rust_Block_27::S_45 => {
                _pv_0 = ebp;
                c2rust_current_block_27 = C2Rust_Block_27::S_47;
            }
            C2Rust_Block_27::S_47 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_49;
            }
            C2Rust_Block_27::S_49 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_59;
            }
            C2Rust_Block_27::S_59 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_27 = C2Rust_Block_27::S_61;
            }
            C2Rust_Block_27::S_61 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_63;
            }
            C2Rust_Block_27::S_63 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_73;
            }
            C2Rust_Block_27::S_73 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_27 = C2Rust_Block_27::S_75;
            }
            C2Rust_Block_27::S_75 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_77;
            }
            C2Rust_Block_27::S_77 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_83;
            }
            C2Rust_Block_27::S_83 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_27 = C2Rust_Block_27::S_85;
            }
            C2Rust_Block_27::S_85 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_87;
            }
            C2Rust_Block_27::S_87 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_89;
            }
            C2Rust_Block_27::S_89 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_95;
            }
            C2Rust_Block_27::S_95 => {
                _pv_3 = ebp;
                c2rust_current_block_27 = C2Rust_Block_27::S_97;
            }
            C2Rust_Block_27::S_97 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_99;
            }
            C2Rust_Block_27::S_99 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_105;
            }
            C2Rust_Block_27::S_105 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_111;
            }
            C2Rust_Block_27::S_111 => {
                _pv_4 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_27 = C2Rust_Block_27::S_113;
            }
            C2Rust_Block_27::S_113 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_115;
            }
            C2Rust_Block_27::S_115 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_122;
            }
            C2Rust_Block_27::S_122 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_128;
            }
            C2Rust_Block_27::S_128 => {
                _pv_5 = 0x24ee9a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_130;
            }
            C2Rust_Block_27::S_130 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_132;
            }
            C2Rust_Block_27::S_132 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_142;
            }
            C2Rust_Block_27::S_142 => {
                _va = _icall_target;
                c2rust_current_block_27 = C2Rust_Block_27::S_144;
            }
            C2Rust_Block_27::S_144 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_146;
            }
            C2Rust_Block_27::S_146 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_148;
            }
            C2Rust_Block_27::S_148 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_150;
            }
            C2Rust_Block_27::S_150 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_27 = C2Rust_Block_27::S_153;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_165;
                }
            }
            C2Rust_Block_27::S_153 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_27 = C2Rust_Block_27::S_155;
            }
            C2Rust_Block_27::S_155 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_27 = C2Rust_Block_27::S_157;
            }
            C2Rust_Block_27::S_157 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_215;
            }
            C2Rust_Block_27::S_165 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_27 = C2Rust_Block_27::S_167;
            }
            C2Rust_Block_27::S_167 => {
                if _fn.is_none() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_169;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_173;
                }
            }
            C2Rust_Block_27::S_169 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_27 = C2Rust_Block_27::S_173;
            }
            C2Rust_Block_27::S_173 => {
                if _fn.is_none() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_175;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_179;
                }
            }
            C2Rust_Block_27::S_175 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_27 = C2Rust_Block_27::S_179;
            }
            C2Rust_Block_27::S_179 => {
                if _fn.is_some() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_185;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_192;
                }
            }
            C2Rust_Block_27::S_185 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_27 = C2Rust_Block_27::S_215;
            }
            C2Rust_Block_27::S_192 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_27 = C2Rust_Block_27::S_194;
            }
            C2Rust_Block_27::S_194 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_27 = C2Rust_Block_27::S_196;
            }
            C2Rust_Block_27::S_196 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_215;
            }
            C2Rust_Block_27::S_215 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_27 = C2Rust_Block_27::S_221;
            }
            C2Rust_Block_27::S_221 => {
                _pv_6 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_27 = C2Rust_Block_27::S_223;
            }
            C2Rust_Block_27::S_223 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_225;
            }
            C2Rust_Block_27::S_225 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_235;
            }
            C2Rust_Block_27::S_235 => {
                _pv_7 = 0x24ee79 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_237;
            }
            C2Rust_Block_27::S_237 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_239;
            }
            C2Rust_Block_27::S_239 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_245;
            }
            C2Rust_Block_27::S_245 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x50 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_251;
            }
            C2Rust_Block_27::S_251 => {
                _pv_8 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_27 = C2Rust_Block_27::S_253;
            }
            C2Rust_Block_27::S_253 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_255;
            }
            C2Rust_Block_27::S_255 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_262;
            }
            C2Rust_Block_27::S_262 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_268;
            }
            C2Rust_Block_27::S_268 => {
                _pv_9 = 0x24eeaa as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_270;
            }
            C2Rust_Block_27::S_270 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_272;
            }
            C2Rust_Block_27::S_272 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_282;
            }
            C2Rust_Block_27::S_282 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_27 = C2Rust_Block_27::S_284;
            }
            C2Rust_Block_27::S_284 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_286;
            }
            C2Rust_Block_27::S_286 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_288;
            }
            C2Rust_Block_27::S_288 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_290;
            }
            C2Rust_Block_27::S_290 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_27 = C2Rust_Block_27::S_293;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_305;
                }
            }
            C2Rust_Block_27::S_293 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_27 = C2Rust_Block_27::S_295;
            }
            C2Rust_Block_27::S_295 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_27 = C2Rust_Block_27::S_297;
            }
            C2Rust_Block_27::S_297 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_354;
            }
            C2Rust_Block_27::S_305 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_27 = C2Rust_Block_27::S_307;
            }
            C2Rust_Block_27::S_307 => {
                if _fn_0.is_none() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_309;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_313;
                }
            }
            C2Rust_Block_27::S_309 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_27 = C2Rust_Block_27::S_313;
            }
            C2Rust_Block_27::S_313 => {
                if _fn_0.is_none() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_315;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_319;
                }
            }
            C2Rust_Block_27::S_315 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_27 = C2Rust_Block_27::S_319;
            }
            C2Rust_Block_27::S_319 => {
                if _fn_0.is_some() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_325;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_332;
                }
            }
            C2Rust_Block_27::S_325 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_27 = C2Rust_Block_27::S_354;
            }
            C2Rust_Block_27::S_332 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_27 = C2Rust_Block_27::S_334;
            }
            C2Rust_Block_27::S_334 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_27 = C2Rust_Block_27::S_336;
            }
            C2Rust_Block_27::S_336 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_354;
            }
            C2Rust_Block_27::S_354 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_27 = C2Rust_Block_27::S_360;
            }
            C2Rust_Block_27::S_360 => {
                _pv_10 = 0x24eeb1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_362;
            }
            C2Rust_Block_27::S_362 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_364;
            }
            C2Rust_Block_27::S_364 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_370;
            }
            C2Rust_Block_27::S_370 => {
                sub_0024FBC9();
                c2rust_current_block_27 = C2Rust_Block_27::S_376;
            }
            C2Rust_Block_27::S_376 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_27 = C2Rust_Block_27::S_378;
            }
            C2Rust_Block_27::S_378 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_380;
            }
            C2Rust_Block_27::S_380 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_382;
            }
            C2Rust_Block_27::S_382 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_384;
            }
            C2Rust_Block_27::S_384 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_386;
            }
            C2Rust_Block_27::S_386 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_27 = C2Rust_Block_27::S_485;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_395;
                }
            }
            C2Rust_Block_27::S_395 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_397;
            }
            C2Rust_Block_27::S_397 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_399;
            }
            C2Rust_Block_27::S_399 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_401;
            }
            C2Rust_Block_27::S_401 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_403;
            }
            C2Rust_Block_27::S_403 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_405;
            }
            C2Rust_Block_27::S_405 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_411;
            }
            C2Rust_Block_27::S_411 => {
                _pv_11 = 0x10 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_413;
            }
            C2Rust_Block_27::S_413 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_415;
            }
            C2Rust_Block_27::S_415 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_425;
            }
            C2Rust_Block_27::S_425 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_427;
            }
            C2Rust_Block_27::S_427 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_433;
            }
            C2Rust_Block_27::S_433 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_435;
            }
            C2Rust_Block_27::S_435 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_437;
            }
            C2Rust_Block_27::S_437 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_439;
            }
            C2Rust_Block_27::S_439 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_441;
            }
            C2Rust_Block_27::S_441 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_443;
            }
            C2Rust_Block_27::S_443 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_445;
            }
            C2Rust_Block_27::S_445 => {
                if _fa <= _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_460;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_454;
                }
            }
            C2Rust_Block_27::S_454 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_460;
            }
            C2Rust_Block_27::S_460 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_462;
            }
            C2Rust_Block_27::S_462 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_464;
            }
            C2Rust_Block_27::S_464 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_466;
            }
            C2Rust_Block_27::S_466 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_468;
            }
            C2Rust_Block_27::S_468 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_470;
            }
            C2Rust_Block_27::S_470 => {
                if _fa != _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_643;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_479;
                }
            }
            C2Rust_Block_27::S_479 => {
                (*__gamepkg_tls_g_ebx) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_485;
            }
            C2Rust_Block_27::S_485 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_487;
            }
            C2Rust_Block_27::S_487 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_27 = C2Rust_Block_27::S_490;
            }
            C2Rust_Block_27::S_490 => {
                _icall_esp_1 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_27 = C2Rust_Block_27::S_493;
            }
            C2Rust_Block_27::S_493 => {
                _icall_target_1 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_499;
            }
            C2Rust_Block_27::S_499 => {
                _pv_12 = 0x24eef4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_501;
            }
            C2Rust_Block_27::S_501 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_503;
            }
            C2Rust_Block_27::S_503 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_513;
            }
            C2Rust_Block_27::S_513 => {
                _va_1 = _icall_target_1;
                c2rust_current_block_27 = C2Rust_Block_27::S_515;
            }
            C2Rust_Block_27::S_515 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_1,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_517;
            }
            C2Rust_Block_27::S_517 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_519;
            }
            C2Rust_Block_27::S_519 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_521;
            }
            C2Rust_Block_27::S_521 => {
                if !(_va_1 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                {
                    c2rust_current_block_27 = C2Rust_Block_27::S_524;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_536;
                }
            }
            C2Rust_Block_27::S_524 => {
                recomp_icall_not_code_log(_va_1);
                c2rust_current_block_27 = C2Rust_Block_27::S_526;
            }
            C2Rust_Block_27::S_526 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_27 = C2Rust_Block_27::S_528;
            }
            C2Rust_Block_27::S_528 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_589;
            }
            C2Rust_Block_27::S_536 => {
                _fn_1 = recomp_lookup_manual(_va_1);
                c2rust_current_block_27 = C2Rust_Block_27::S_538;
            }
            C2Rust_Block_27::S_538 => {
                if _fn_1.is_none() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_540;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_544;
                }
            }
            C2Rust_Block_27::S_540 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block_27 = C2Rust_Block_27::S_544;
            }
            C2Rust_Block_27::S_544 => {
                if _fn_1.is_none() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_546;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_550;
                }
            }
            C2Rust_Block_27::S_546 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block_27 = C2Rust_Block_27::S_550;
            }
            C2Rust_Block_27::S_550 => {
                if _fn_1.is_some() {
                    c2rust_current_block_27 = C2Rust_Block_27::S_556;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_563;
                }
            }
            C2Rust_Block_27::S_556 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block_27 = C2Rust_Block_27::S_589;
            }
            C2Rust_Block_27::S_563 => {
                recomp_icall_fail_log(_va_1);
                c2rust_current_block_27 = C2Rust_Block_27::S_565;
            }
            C2Rust_Block_27::S_565 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_27 = C2Rust_Block_27::S_567;
            }
            C2Rust_Block_27::S_567 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_589;
            }
            C2Rust_Block_27::S_589 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_591;
            }
            C2Rust_Block_27::S_591 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_601;
            }
            C2Rust_Block_27::S_601 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_603;
            }
            C2Rust_Block_27::S_603 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_613;
            }
            C2Rust_Block_27::S_613 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_615;
            }
            C2Rust_Block_27::S_615 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_621;
            }
            C2Rust_Block_27::S_621 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_27 = C2Rust_Block_27::S_627;
            }
            C2Rust_Block_27::S_627 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_629;
            }
            C2Rust_Block_27::S_629 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_635;
            }
            C2Rust_Block_27::S_635 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_637;
            }
            C2Rust_Block_27::S_637 => return,
            C2Rust_Block_27::S_643 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(2 as uint32_t));
                c2rust_current_block_27 = C2Rust_Block_27::S_645;
            }
            C2Rust_Block_27::S_645 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 5 as ::core::ffi::c_int;
                c2rust_current_block_27 = C2Rust_Block_27::S_647;
            }
            C2Rust_Block_27::S_647 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_649;
            }
            C2Rust_Block_27::S_649 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_655;
            }
            C2Rust_Block_27::S_655 => {
                _pv_13 = 0x801c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_657;
            }
            C2Rust_Block_27::S_657 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_659;
            }
            C2Rust_Block_27::S_659 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_665;
            }
            C2Rust_Block_27::S_665 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_667;
            }
            C2Rust_Block_27::S_667 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_669;
            }
            C2Rust_Block_27::S_669 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_671;
            }
            C2Rust_Block_27::S_671 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_673;
            }
            C2Rust_Block_27::S_673 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_679;
            }
            C2Rust_Block_27::S_679 => {
                _pv_14 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_27 = C2Rust_Block_27::S_681;
            }
            C2Rust_Block_27::S_681 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_683;
            }
            C2Rust_Block_27::S_683 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_693;
            }
            C2Rust_Block_27::S_693 => {
                _pv_15 = 0x24ef0f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_695;
            }
            C2Rust_Block_27::S_695 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_697;
            }
            C2Rust_Block_27::S_697 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_703;
            }
            C2Rust_Block_27::S_703 => {
                sub_0024EFC3();
                c2rust_current_block_27 = C2Rust_Block_27::S_709;
            }
            C2Rust_Block_27::S_709 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_711;
            }
            C2Rust_Block_27::S_711 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_713;
            }
            C2Rust_Block_27::S_713 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_715;
            }
            C2Rust_Block_27::S_715 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_717;
            }
            C2Rust_Block_27::S_717 => {
                if _fa == _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_812;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_730;
                }
            }
            C2Rust_Block_27::S_730 => {
                _pv_16 = 0x24e30d as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_732;
            }
            C2Rust_Block_27::S_732 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_734;
            }
            C2Rust_Block_27::S_734 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_744;
            }
            C2Rust_Block_27::S_744 => {
                _pv_17 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_27 = C2Rust_Block_27::S_746;
            }
            C2Rust_Block_27::S_746 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_748;
            }
            C2Rust_Block_27::S_748 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_754;
            }
            C2Rust_Block_27::S_754 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_760;
            }
            C2Rust_Block_27::S_760 => {
                _pv_18 = 0x60 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_762;
            }
            C2Rust_Block_27::S_762 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_764;
            }
            C2Rust_Block_27::S_764 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_774;
            }
            C2Rust_Block_27::S_774 => {
                _pv_19 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_27 = C2Rust_Block_27::S_776;
            }
            C2Rust_Block_27::S_776 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_778;
            }
            C2Rust_Block_27::S_778 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_784;
            }
            C2Rust_Block_27::S_784 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_790;
            }
            C2Rust_Block_27::S_790 => {
                _pv_20 = 0x24ef26 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_792;
            }
            C2Rust_Block_27::S_792 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_794;
            }
            C2Rust_Block_27::S_794 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_800;
            }
            C2Rust_Block_27::S_800 => {
                sub_00011000();
                c2rust_current_block_27 = C2Rust_Block_27::S_822;
            }
            C2Rust_Block_27::S_812 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_814;
            }
            C2Rust_Block_27::S_814 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_816;
            }
            C2Rust_Block_27::S_816 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_822;
            }
            C2Rust_Block_27::S_822 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_824;
            }
            C2Rust_Block_27::S_824 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_826;
            }
            C2Rust_Block_27::S_826 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_828;
            }
            C2Rust_Block_27::S_828 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_830;
            }
            C2Rust_Block_27::S_830 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_832;
            }
            C2Rust_Block_27::S_832 => {
                if _fa == _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_916;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_841;
                }
            }
            C2Rust_Block_27::S_841 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_847;
            }
            C2Rust_Block_27::S_847 => {
                _pv_21 = 0x23 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_849;
            }
            C2Rust_Block_27::S_849 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_851;
            }
            C2Rust_Block_27::S_851 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_857;
            }
            C2Rust_Block_27::S_857 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 2 as ::core::ffi::c_int;
                c2rust_current_block_27 = C2Rust_Block_27::S_859;
            }
            C2Rust_Block_27::S_859 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_861;
            }
            C2Rust_Block_27::S_861 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_867;
            }
            C2Rust_Block_27::S_867 => {
                _pv_22 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_27 = C2Rust_Block_27::S_869;
            }
            C2Rust_Block_27::S_869 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_871;
            }
            C2Rust_Block_27::S_871 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_881;
            }
            C2Rust_Block_27::S_881 => {
                _pv_23 = 0x24ef3f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_883;
            }
            C2Rust_Block_27::S_883 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_885;
            }
            C2Rust_Block_27::S_885 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_891;
            }
            C2Rust_Block_27::S_891 => {
                sub_0024EFC3();
                c2rust_current_block_27 = C2Rust_Block_27::S_897;
            }
            C2Rust_Block_27::S_897 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_899;
            }
            C2Rust_Block_27::S_899 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_901;
            }
            C2Rust_Block_27::S_901 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_903;
            }
            C2Rust_Block_27::S_903 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_905;
            }
            C2Rust_Block_27::S_905 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_907;
            }
            C2Rust_Block_27::S_907 => {
                if _fa != _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_924;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_916;
                }
            }
            C2Rust_Block_27::S_916 => {
                (*__gamepkg_tls_g_ebx) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_485;
            }
            C2Rust_Block_27::S_924 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_926;
            }
            C2Rust_Block_27::S_926 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_928;
            }
            C2Rust_Block_27::S_928 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_930;
            }
            C2Rust_Block_27::S_930 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_932;
            }
            C2Rust_Block_27::S_932 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_934;
            }
            C2Rust_Block_27::S_934 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_936;
            }
            C2Rust_Block_27::S_936 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_938;
            }
            C2Rust_Block_27::S_938 => {
                if _fa <= _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_976;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_947;
                }
            }
            C2Rust_Block_27::S_947 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_949;
            }
            C2Rust_Block_27::S_949 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_951;
            }
            C2Rust_Block_27::S_951 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_27 = C2Rust_Block_27::S_953;
            }
            C2Rust_Block_27::S_953 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_955;
            }
            C2Rust_Block_27::S_955 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_957;
            }
            C2Rust_Block_27::S_957 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_959;
            }
            C2Rust_Block_27::S_959 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_961;
            }
            C2Rust_Block_27::S_961 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_963;
            }
            C2Rust_Block_27::S_963 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_965;
            }
            C2Rust_Block_27::S_965 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_967;
            }
            C2Rust_Block_27::S_967 => {
                if _fa < _fb {
                    c2rust_current_block_27 = C2Rust_Block_27::S_947;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_976;
                }
            }
            C2Rust_Block_27::S_976 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_27 = C2Rust_Block_27::S_978;
            }
            C2Rust_Block_27::S_978 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x42068c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_984;
            }
            C2Rust_Block_27::S_984 => {
                _pv_24 = 0x24ef71 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_986;
            }
            C2Rust_Block_27::S_986 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_988;
            }
            C2Rust_Block_27::S_988 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_994;
            }
            C2Rust_Block_27::S_994 => {
                sub_0024E76E();
                c2rust_current_block_27 = C2Rust_Block_27::S_1000;
            }
            C2Rust_Block_27::S_1000 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_27 = C2Rust_Block_27::S_1002;
            }
            C2Rust_Block_27::S_1002 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1004;
            }
            C2Rust_Block_27::S_1004 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1006;
            }
            C2Rust_Block_27::S_1006 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1008;
            }
            C2Rust_Block_27::S_1008 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1010;
            }
            C2Rust_Block_27::S_1010 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_27 = C2Rust_Block_27::S_485;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_1023;
                }
            }
            C2Rust_Block_27::S_1023 => {
                _pv_25 = 0x24 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1025;
            }
            C2Rust_Block_27::S_1025 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_1027;
            }
            C2Rust_Block_27::S_1027 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_1037;
            }
            C2Rust_Block_27::S_1037 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_1039;
            }
            C2Rust_Block_27::S_1039 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_1045;
            }
            C2Rust_Block_27::S_1045 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1047;
            }
            C2Rust_Block_27::S_1047 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1049;
            }
            C2Rust_Block_27::S_1049 => {
                _fas = _fa as int32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1051;
            }
            C2Rust_Block_27::S_1051 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x6c as uint32_t);
                c2rust_current_block_27 = C2Rust_Block_27::S_1054;
            }
            C2Rust_Block_27::S_1054 => {
                _i = 0;
                c2rust_current_block_27 = C2Rust_Block_27::S_1056;
            }
            C2Rust_Block_27::S_1056 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_27 = C2Rust_Block_27::S_1059;
            }
            C2Rust_Block_27::S_1059 => {
                _i = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_1060;
            }
            C2Rust_Block_27::S_1060 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_27 = C2Rust_Block_27::S_1061;
                } else {
                    c2rust_current_block_27 = C2Rust_Block_27::S_1069;
                }
            }
            C2Rust_Block_27::S_1061 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_27 = C2Rust_Block_27::S_1062;
            }
            C2Rust_Block_27::S_1062 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_27 = C2Rust_Block_27::S_1060;
            }
            C2Rust_Block_27::S_1069 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_27 = C2Rust_Block_27::S_1073;
            }
            C2Rust_Block_27::S_1073 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_27 = C2Rust_Block_27::S_589;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EF8A() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = 0x15 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(2 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx).wrapping_add(0x14 as uint32_t);
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
        -(4 as ::core::ffi::c_int as int32_t)
    } else {
        4 as ::core::ffi::c_int as int32_t
    };
    _i = 0 as uint32_t;
    while _i < (*__gamepkg_tls_g_ecx) {
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(_i.wrapping_mul(_st as uint32_t))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        _i = _i.wrapping_add(1);
    }
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EFAD() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t);
    let mut _pv_0: uint32_t = 0x24efbb as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024EF8A();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x6c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EFC3() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0x218a0000 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x24efd6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D2879();
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx);
        let mut _i: uint32_t = 0;
        let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
            -(4 as ::core::ffi::c_int as int32_t)
        } else {
            4 as ::core::ffi::c_int as int32_t
        };
        _i = 0 as uint32_t;
        while _i < (*__gamepkg_tls_g_ecx) {
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi)
                        .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            _i = _i.wrapping_add(1);
        }
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        's_199: {
            's_180: {
                if (*__gamepkg_tls_g_df) != 0 {
                    break 's_180;
                }
                memset(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_void,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax) as uint8_t as ::core::ffi::c_int,
                    (*__gamepkg_tls_g_ecx) as size_t,
                );
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                break 's_199;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_0) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024EFFB() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_120: {
        if _fa == _fb {
            break 's_120;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_76: {
            's_66: {
                if _fa == _fb {
                    break 's_66;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0x218a0000 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                break 's_76;
            }
            (*__gamepkg_tls_g_eax) = 0x218a2000 as uint32_t;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x24f020 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_001D2919();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F023() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx)
        .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(2 as uint32_t));
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t))
                as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 0xa0 as uint32_t;
    's_115: {
        's_60: {
            if (*__gamepkg_tls_g_df) == 0 {
                break 's_60;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            break 's_115;
        }
        let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _n: uint32_t = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
        's_87: {
            's_66: {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    break 's_66;
                }
                let mut _i: uint32_t = 0;
                _i = 0 as uint32_t;
                loop {
                    if _i >= (*__gamepkg_tls_g_ecx) {
                        break 's_87;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    _i = _i.wrapping_add(1);
                }
            }
            memcpy(
                _d as *mut ::core::ffi::c_void,
                _s as *const ::core::ffi::c_void,
                _n as size_t,
            );
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F053() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
        .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(2 as uint32_t));
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t))
                as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_123: {
        's_68: {
            if (*__gamepkg_tls_g_df) == 0 {
                break 's_68;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            break 's_123;
        }
        let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _n: uint32_t = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
        's_95: {
            's_74: {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    break 's_74;
                }
                let mut _i: uint32_t = 0;
                _i = 0 as uint32_t;
                loop {
                    if _i >= (*__gamepkg_tls_g_ecx) {
                        break 's_95;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    _i = _i.wrapping_add(1);
                }
            }
            memcpy(
                _d as *mut ::core::ffi::c_void,
                _s as *const ::core::ffi::c_void,
                _n as size_t,
            );
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_192: {
        's_137: {
            if (*__gamepkg_tls_g_df) == 0 {
                break 's_137;
            }
            let mut _i_2: uint32_t = 0;
            _i_2 = 0 as uint32_t;
            while _i_2 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_2 = _i_2.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
            break 's_192;
        }
        let mut _d_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _s_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _n_0: uint32_t = (*__gamepkg_tls_g_ecx);
        's_164: {
            's_143: {
                if _d_0.offset(_n_0 as isize) <= _s_0
                    || _s_0.offset(_n_0 as isize) <= _d_0
                {
                    break 's_143;
                }
                let mut _i_1: uint32_t = 0;
                _i_1 = 0 as uint32_t;
                loop {
                    if _i_1 >= _n_0 {
                        break 's_164;
                    }
                    *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                    _i_1 = _i_1.wrapping_add(1);
                }
            }
            memcpy(
                _d_0 as *mut ::core::ffi::c_void,
                _s_0 as *const ::core::ffi::c_void,
                _n_0 as size_t,
            );
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_add((*__gamepkg_tls_g_ecx));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xfff as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F094() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x24f0a8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_00251095();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F0AD() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_35: {
        if _fa != _fb {
            break 's_35;
        }
        let mut _pv: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = 0x24f0c8 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_002511A3();
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F0C9() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = 0x24f0d1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024F053();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_127: {
        if _fa == _fb {
            break 's_127;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        let mut _pv_1: uint32_t = 0x24f0dc as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_0024F0AD();
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F0E5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfff as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F0F5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_53: {
        if _fa != _fb {
            break 's_53;
        }
        (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0025112E();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F109() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_45: {
        if _fa != _fb {
            break 's_45;
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F115() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_2: uint32_t = 0x24f127 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024EFC3();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_135: {
        's_117: {
            if _fa == _fb {
                break 's_117;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_135;
        }
        (*__gamepkg_tls_g_eax) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F13A() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = 0x24f142 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0025104E();
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_119: {
        if _fa == _fb {
            break 's_119;
        }
        let mut _pv_1: uint32_t = 0x8016 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x24f154 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_0024EFFB();
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F15A() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    ebp = 0 as uint32_t;
    _fa = ebp & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esi) = 0x280 as uint32_t;
    loop {
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
        let mut _pv_4: uint32_t = 0x24f171 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_0024F115();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break;
        }
        ebp = ebp.wrapping_add(1);
        _fa = ebp & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = ebp & 0xffffffff as uint32_t;
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa < _fb {
            continue;
        }
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi).wrapping_add(0x24 as uint32_t);
        let mut _pv_6: uint32_t = 0x24f187 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_0024F115();
        break;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F18C() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_101: {
        if _fa == _fb {
            break 's_101;
        }
        let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x24f19d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_0024F13A();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F1A3() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_319: {
        if _fa != _fb {
            break 's_319;
        }
        let mut _pv_1: uint32_t = 0x8016 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x70 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x24f1ba as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_0024EFC3();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_174: {
            's_136: {
                if _fa != _fb {
                    break 's_136;
                }
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                break 's_174;
            }
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
            let mut _pv_4: uint32_t = 0x24f1c5 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_0024EFAD();
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        's_297: {
            's_193: {
                if _fa == _fb {
                    break 's_193;
                }
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                let mut _pv_5: uint32_t = 0x24f1de as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                sub_00251179();
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_297;
                }
                let mut _pv_6: uint32_t = 0xa as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x30 as uint32_t);
                let mut _pv_7: uint32_t = 0x24f1ee as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                sub_0024F115();
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_319;
                } else {
                    break 's_297;
                }
            }
            (*__gamepkg_tls_g_edi) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        let mut _pv_8: uint32_t = 0x24f1fb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_0024F18C();
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F200() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F20D() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x24f216 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024EFFB();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F217() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x48 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x5c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x64 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x70 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x74 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F271() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024F0E5();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F279() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_77: {
        if _fa == _fb {
            break 's_77;
        }
        let mut _pv_0: uint32_t = 0x24f288 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_0024F18C();
    }
    let mut _pv_1: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x24f292 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024EFFB();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F298() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    let mut _icall_esp_2: uint32_t = 0;
    let mut _icall_target_2: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _va_2: uint32_t = 0;
    let mut _fn_2: recomp_func_t = None;
    enum C2Rust_Block_49 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_36,
        S_38,
        S_40,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_71,
        S_73,
        S_75,
        S_82,
        S_85,
        S_91,
        S_93,
        S_95,
        S_105,
        S_107,
        S_109,
        S_111,
        S_113,
        S_116,
        S_118,
        S_120,
        S_128,
        S_130,
        S_132,
        S_136,
        S_138,
        S_142,
        S_148,
        S_155,
        S_157,
        S_159,
        S_177,
        S_179,
        S_181,
        S_183,
        S_186,
        S_192,
        S_194,
        S_196,
        S_203,
        S_209,
        S_211,
        S_213,
        S_223,
        S_225,
        S_227,
        S_229,
        S_231,
        S_234,
        S_236,
        S_238,
        S_246,
        S_248,
        S_250,
        S_254,
        S_256,
        S_260,
        S_266,
        S_273,
        S_275,
        S_277,
        S_295,
        S_297,
        S_300,
        S_306,
        S_308,
        S_310,
        S_316,
        S_319,
        S_325,
        S_327,
        S_329,
        S_339,
        S_341,
        S_343,
        S_345,
        S_347,
        S_350,
        S_352,
        S_354,
        S_362,
        S_364,
        S_366,
        S_370,
        S_372,
        S_376,
        S_382,
        S_389,
        S_391,
        S_393,
        S_411,
        S_414,
        S_417,
        S_423,
        S_425,
        S_427,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_448,
        S_450,
        S_452,
        S_460,
        S_462,
        S_464,
        S_468,
        S_470,
        S_474,
        S_480,
        S_487,
        S_489,
        S_491,
        S_513,
        S_515,
        S_529,
        S_531,
        S_541,
        S_543,
        S_549,
        S_551,
    }
    let mut c2rust_current_block_49: C2Rust_Block_49;
    c2rust_current_block_49 = C2Rust_Block_49::S_0;
    loop {
        match c2rust_current_block_49 {
            C2Rust_Block_49::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_2;
            }
            C2Rust_Block_49::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_4;
            }
            C2Rust_Block_49::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_22;
            }
            C2Rust_Block_49::S_22 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_24;
            }
            C2Rust_Block_49::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_26;
            }
            C2Rust_Block_49::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_36;
            }
            C2Rust_Block_49::S_36 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_38;
            }
            C2Rust_Block_49::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_40;
            }
            C2Rust_Block_49::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_46;
            }
            C2Rust_Block_49::S_46 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_48;
            }
            C2Rust_Block_49::S_48 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_50;
            }
            C2Rust_Block_49::S_50 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_52;
            }
            C2Rust_Block_49::S_52 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_54;
            }
            C2Rust_Block_49::S_54 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_56;
            }
            C2Rust_Block_49::S_56 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_58;
            }
            C2Rust_Block_49::S_58 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_529;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_71;
                }
            }
            C2Rust_Block_49::S_71 => {
                _pv_1 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_49 = C2Rust_Block_49::S_73;
            }
            C2Rust_Block_49::S_73 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_75;
            }
            C2Rust_Block_49::S_75 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_82;
            }
            C2Rust_Block_49::S_82 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_49 = C2Rust_Block_49::S_85;
            }
            C2Rust_Block_49::S_85 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_91;
            }
            C2Rust_Block_49::S_91 => {
                _pv_2 = 0x24f2ac as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_93;
            }
            C2Rust_Block_49::S_93 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_95;
            }
            C2Rust_Block_49::S_95 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_105;
            }
            C2Rust_Block_49::S_105 => {
                _va = _icall_target;
                c2rust_current_block_49 = C2Rust_Block_49::S_107;
            }
            C2Rust_Block_49::S_107 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_109;
            }
            C2Rust_Block_49::S_109 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_111;
            }
            C2Rust_Block_49::S_111 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_113;
            }
            C2Rust_Block_49::S_113 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_49 = C2Rust_Block_49::S_116;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_128;
                }
            }
            C2Rust_Block_49::S_116 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_49 = C2Rust_Block_49::S_118;
            }
            C2Rust_Block_49::S_118 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_49 = C2Rust_Block_49::S_120;
            }
            C2Rust_Block_49::S_120 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_177;
            }
            C2Rust_Block_49::S_128 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_49 = C2Rust_Block_49::S_130;
            }
            C2Rust_Block_49::S_130 => {
                if _fn.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_132;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_136;
                }
            }
            C2Rust_Block_49::S_132 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_49 = C2Rust_Block_49::S_136;
            }
            C2Rust_Block_49::S_136 => {
                if _fn.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_138;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_142;
                }
            }
            C2Rust_Block_49::S_138 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_49 = C2Rust_Block_49::S_142;
            }
            C2Rust_Block_49::S_142 => {
                if _fn.is_some() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_148;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_155;
                }
            }
            C2Rust_Block_49::S_148 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_49 = C2Rust_Block_49::S_177;
            }
            C2Rust_Block_49::S_155 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_49 = C2Rust_Block_49::S_157;
            }
            C2Rust_Block_49::S_157 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_49 = C2Rust_Block_49::S_159;
            }
            C2Rust_Block_49::S_159 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_177;
            }
            C2Rust_Block_49::S_177 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_179;
            }
            C2Rust_Block_49::S_179 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
                    | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_181;
            }
            C2Rust_Block_49::S_181 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_183;
            }
            C2Rust_Block_49::S_183 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_186;
            }
            C2Rust_Block_49::S_186 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_49 = C2Rust_Block_49::S_192;
            }
            C2Rust_Block_49::S_192 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_194;
            }
            C2Rust_Block_49::S_194 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_196;
            }
            C2Rust_Block_49::S_196 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_203;
            }
            C2Rust_Block_49::S_203 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_209;
            }
            C2Rust_Block_49::S_209 => {
                _pv_4 = 0x24f2ba as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_211;
            }
            C2Rust_Block_49::S_211 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_213;
            }
            C2Rust_Block_49::S_213 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_223;
            }
            C2Rust_Block_49::S_223 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_49 = C2Rust_Block_49::S_225;
            }
            C2Rust_Block_49::S_225 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_227;
            }
            C2Rust_Block_49::S_227 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_229;
            }
            C2Rust_Block_49::S_229 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_231;
            }
            C2Rust_Block_49::S_231 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_49 = C2Rust_Block_49::S_234;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_246;
                }
            }
            C2Rust_Block_49::S_234 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_49 = C2Rust_Block_49::S_236;
            }
            C2Rust_Block_49::S_236 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_49 = C2Rust_Block_49::S_238;
            }
            C2Rust_Block_49::S_238 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_295;
            }
            C2Rust_Block_49::S_246 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_49 = C2Rust_Block_49::S_248;
            }
            C2Rust_Block_49::S_248 => {
                if _fn_0.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_250;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_254;
                }
            }
            C2Rust_Block_49::S_250 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_49 = C2Rust_Block_49::S_254;
            }
            C2Rust_Block_49::S_254 => {
                if _fn_0.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_256;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_260;
                }
            }
            C2Rust_Block_49::S_256 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_49 = C2Rust_Block_49::S_260;
            }
            C2Rust_Block_49::S_260 => {
                if _fn_0.is_some() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_266;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_273;
                }
            }
            C2Rust_Block_49::S_266 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_49 = C2Rust_Block_49::S_295;
            }
            C2Rust_Block_49::S_273 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_49 = C2Rust_Block_49::S_275;
            }
            C2Rust_Block_49::S_275 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_49 = C2Rust_Block_49::S_277;
            }
            C2Rust_Block_49::S_277 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_295;
            }
            C2Rust_Block_49::S_295 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_297;
            }
            C2Rust_Block_49::S_297 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_300;
            }
            C2Rust_Block_49::S_300 => {
                _icall_esp_1 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_49 = C2Rust_Block_49::S_306;
            }
            C2Rust_Block_49::S_306 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_308;
            }
            C2Rust_Block_49::S_308 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_310;
            }
            C2Rust_Block_49::S_310 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_316;
            }
            C2Rust_Block_49::S_316 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_319;
            }
            C2Rust_Block_49::S_319 => {
                _icall_target_1 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_325;
            }
            C2Rust_Block_49::S_325 => {
                _pv_6 = 0x24f2c5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_327;
            }
            C2Rust_Block_49::S_327 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_329;
            }
            C2Rust_Block_49::S_329 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_339;
            }
            C2Rust_Block_49::S_339 => {
                _va_1 = _icall_target_1;
                c2rust_current_block_49 = C2Rust_Block_49::S_341;
            }
            C2Rust_Block_49::S_341 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_1,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_343;
            }
            C2Rust_Block_49::S_343 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_345;
            }
            C2Rust_Block_49::S_345 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_347;
            }
            C2Rust_Block_49::S_347 => {
                if !(_va_1 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                {
                    c2rust_current_block_49 = C2Rust_Block_49::S_350;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_362;
                }
            }
            C2Rust_Block_49::S_350 => {
                recomp_icall_not_code_log(_va_1);
                c2rust_current_block_49 = C2Rust_Block_49::S_352;
            }
            C2Rust_Block_49::S_352 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_49 = C2Rust_Block_49::S_354;
            }
            C2Rust_Block_49::S_354 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_411;
            }
            C2Rust_Block_49::S_362 => {
                _fn_1 = recomp_lookup_manual(_va_1);
                c2rust_current_block_49 = C2Rust_Block_49::S_364;
            }
            C2Rust_Block_49::S_364 => {
                if _fn_1.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_366;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_370;
                }
            }
            C2Rust_Block_49::S_366 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block_49 = C2Rust_Block_49::S_370;
            }
            C2Rust_Block_49::S_370 => {
                if _fn_1.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_372;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_376;
                }
            }
            C2Rust_Block_49::S_372 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block_49 = C2Rust_Block_49::S_376;
            }
            C2Rust_Block_49::S_376 => {
                if _fn_1.is_some() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_382;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_389;
                }
            }
            C2Rust_Block_49::S_382 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block_49 = C2Rust_Block_49::S_411;
            }
            C2Rust_Block_49::S_389 => {
                recomp_icall_fail_log(_va_1);
                c2rust_current_block_49 = C2Rust_Block_49::S_391;
            }
            C2Rust_Block_49::S_391 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_49 = C2Rust_Block_49::S_393;
            }
            C2Rust_Block_49::S_393 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_411;
            }
            C2Rust_Block_49::S_411 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_414;
            }
            C2Rust_Block_49::S_414 => {
                _icall_esp_2 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_49 = C2Rust_Block_49::S_417;
            }
            C2Rust_Block_49::S_417 => {
                _icall_target_2 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_423;
            }
            C2Rust_Block_49::S_423 => {
                _pv_7 = 0x24f2cd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_425;
            }
            C2Rust_Block_49::S_425 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_427;
            }
            C2Rust_Block_49::S_427 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_437;
            }
            C2Rust_Block_49::S_437 => {
                _va_2 = _icall_target_2;
                c2rust_current_block_49 = C2Rust_Block_49::S_439;
            }
            C2Rust_Block_49::S_439 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_2,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_441;
            }
            C2Rust_Block_49::S_441 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_443;
            }
            C2Rust_Block_49::S_443 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_445;
            }
            C2Rust_Block_49::S_445 => {
                if !(_va_2 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_2 >= g_xbox_code_lo && _va_2 < g_xbox_code_hi)
                {
                    c2rust_current_block_49 = C2Rust_Block_49::S_448;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_460;
                }
            }
            C2Rust_Block_49::S_448 => {
                recomp_icall_not_code_log(_va_2);
                c2rust_current_block_49 = C2Rust_Block_49::S_450;
            }
            C2Rust_Block_49::S_450 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_2;
                c2rust_current_block_49 = C2Rust_Block_49::S_452;
            }
            C2Rust_Block_49::S_452 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_513;
            }
            C2Rust_Block_49::S_460 => {
                _fn_2 = recomp_lookup_manual(_va_2);
                c2rust_current_block_49 = C2Rust_Block_49::S_462;
            }
            C2Rust_Block_49::S_462 => {
                if _fn_2.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_464;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_468;
                }
            }
            C2Rust_Block_49::S_464 => {
                _fn_2 = recomp_lookup(_va_2);
                c2rust_current_block_49 = C2Rust_Block_49::S_468;
            }
            C2Rust_Block_49::S_468 => {
                if _fn_2.is_none() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_470;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_474;
                }
            }
            C2Rust_Block_49::S_470 => {
                _fn_2 = recomp_lookup_kernel(_va_2);
                c2rust_current_block_49 = C2Rust_Block_49::S_474;
            }
            C2Rust_Block_49::S_474 => {
                if _fn_2.is_some() {
                    c2rust_current_block_49 = C2Rust_Block_49::S_480;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_487;
                }
            }
            C2Rust_Block_49::S_480 => {
                _fn_2.expect("non-null function pointer")();
                c2rust_current_block_49 = C2Rust_Block_49::S_513;
            }
            C2Rust_Block_49::S_487 => {
                recomp_icall_fail_log(_va_2);
                c2rust_current_block_49 = C2Rust_Block_49::S_489;
            }
            C2Rust_Block_49::S_489 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_2;
                c2rust_current_block_49 = C2Rust_Block_49::S_491;
            }
            C2Rust_Block_49::S_491 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_513;
            }
            C2Rust_Block_49::S_513 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_515;
            }
            C2Rust_Block_49::S_515 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_529;
            }
            C2Rust_Block_49::S_529 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_531;
            }
            C2Rust_Block_49::S_531 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_541;
            }
            C2Rust_Block_49::S_541 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_543;
            }
            C2Rust_Block_49::S_543 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_549;
            }
            C2Rust_Block_49::S_549 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_551;
            }
            C2Rust_Block_49::S_551 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F2D3() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_59: {
        if _fa == _fb {
            break 's_59;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x90 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_200: {
        if _fa == _fb {
            break 's_200;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = 0x24f2f4 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_190: {
            's_141: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_141;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_190;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_149: {
                if !_fn.is_none() {
                    break 's_149;
                }
                _fn = recomp_lookup(_va);
            }
            's_155: {
                if !_fn.is_none() {
                    break 's_155;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_161: {
                if _fn.is_some() {
                    break 's_161;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_190;
            }
            _fn.expect("non-null function pointer")();
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_341: {
        if _fa == _fb {
            break 's_341;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp_0: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _icall_target_0: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_3: uint32_t = 0x24f305 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _va_0: uint32_t = _icall_target_0;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va_0,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_331: {
            's_282: {
                if _va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi
                {
                    break 's_282;
                }
                recomp_icall_not_code_log(_va_0);
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_331;
            }
            let mut _fn_0: recomp_func_t = recomp_lookup_manual(_va_0);
            's_290: {
                if !_fn_0.is_none() {
                    break 's_290;
                }
                _fn_0 = recomp_lookup(_va_0);
            }
            's_296: {
                if !_fn_0.is_none() {
                    break 's_296;
                }
                _fn_0 = recomp_lookup_kernel(_va_0);
            }
            's_302: {
                if _fn_0.is_some() {
                    break 's_302;
                }
                recomp_icall_fail_log(_va_0);
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_331;
            }
            _fn_0.expect("non-null function pointer")();
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
