extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn log2(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn ceil(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn floor(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn fmod(
        __x: ::core::ffi::c_double,
        __y: ::core::ffi::c_double,
    ) -> ::core::ffi::c_double;
    fn copysign(
        __x: ::core::ffi::c_double,
        __y: ::core::ffi::c_double,
    ) -> ::core::ffi::c_double;
    fn trunc(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    fn gamepkg_tls_g_fp_cmp() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_cc() -> *mut uint16_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_002440A5();
    fn sub_002440FD();
    fn sub_00244784();
    fn sub_002447BF();
    fn sub_00245A86();
    fn sub_0024647B();
    fn sub_002475B2();
    fn sub_00248557();
    fn sub_002485FC();
    fn sub_002486AE();
    fn sub_00248F42();
    fn sub_00248F80();
    fn sub_00248FF0();
    fn sub_00249749();
    fn sub_00249B7C();
    fn sub_00249BD0();
    fn sub_00249BE5();
    fn sub_00249C15();
    fn sub_00249C6E();
    fn sub_00249CB9();
    fn sub_00249DC1();
    fn sub_00249F13();
    fn sub_00249F9B();
    fn sub_0024A02A();
    fn sub_0024A0AE();
    fn sub_0024A1A5();
    fn sub_0024A3DB();
    fn sub_0024A486();
    fn sub_0024A540();
    fn sub_0024A7F8();
    fn sub_0024A924();
    fn sub_0024A9BF();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type int64_t = i64;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const INT64_MIN: ::core::ffi::c_long = -9223372036854775807 as ::core::ffi::c_long
    - 1 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
#[inline]
unsafe extern "C" fn recomp_frndint(
    mut value: ::core::ffi::c_double,
    mut control: uint16_t,
) -> ::core::ffi::c_double {
    let mut rounded: ::core::ffi::c_double = 0.;
    's_4: {
        if value.is_finite() as i32 == 0 {
            break 's_4;
        }
        's_45: {
            'c_11463: {
                'c_11461: {
                    'c_11459: {
                        match control as ::core::ffi::c_int >> 10 as ::core::ffi::c_int
                            & 3 as ::core::ffi::c_int
                        {
                            1 => {
                                break 'c_11459;
                            }
                            2 => {
                                break 'c_11461;
                            }
                            3 => {
                                break 'c_11463;
                            }
                            _ => {}
                        }
                        let mut lo: ::core::ffi::c_double = floor(value);
                        let mut fraction: ::core::ffi::c_double = value - lo;
                        rounded = lo;
                        if !(fraction > 0.5f64
                            || fraction == 0.5f64 && fmod(lo, 2.0f64) != 0.0f64)
                        {
                            break 's_45;
                        }
                        rounded = lo + 1.0f64;
                        break 's_45;
                    }
                    rounded = floor(value);
                    break 's_45;
                }
                rounded = ceil(value);
                break 's_45;
            }
            rounded = trunc(value);
        }
        return if rounded == 0.0f64 { copysign(0.0f64, value) } else { rounded };
    }
    return value;
}
#[inline]
unsafe extern "C" fn recomp_fist(
    mut value: ::core::ffi::c_double,
    mut control: uint16_t,
    mut bits: ::core::ffi::c_uint,
) -> int64_t {
    let mut rounded: ::core::ffi::c_double = recomp_frndint(value, control);
    let mut limit: ::core::ffi::c_double = ldexp(
        1.0f64,
        bits as ::core::ffi::c_int - 1 as ::core::ffi::c_int,
    );
    's_9: {
        if !(rounded.is_finite() as i32 == 0 || rounded < -limit || rounded >= limit) {
            break 's_9;
        }
        return if bits == 64 as ::core::ffi::c_uint {
            INT64_MIN as int64_t
        } else {
            -((1 as int64_t) << bits.wrapping_sub(1 as ::core::ffi::c_uint))
        };
    }
    return rounded as int64_t;
}
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn RC_ROT(
    mut val: uint32_t,
    mut n: ::core::ffi::c_uint,
    mut cf: *mut ::core::ffi::c_int,
    mut width: ::core::ffi::c_uint,
    mut left: ::core::ffi::c_int,
) -> uint32_t {
    let mut r#mod: ::core::ffi::c_uint = width.wrapping_add(1 as ::core::ffi::c_uint);
    let mut mask: uint64_t = (if width >= 32 as ::core::ffi::c_uint {
        0xffffffff as ::core::ffi::c_ulonglong
    } else {
        ((1 as ::core::ffi::c_int as uint64_t) << width).wrapping_sub(1 as uint64_t)
            as ::core::ffi::c_ulonglong
    }) as uint64_t;
    let mut x: uint64_t = ((*cf & 1 as ::core::ffi::c_int) as uint64_t) << width
        | val as uint64_t & mask;
    n &= 31 as ::core::ffi::c_uint;
    's_14: {
        if width >= 32 as ::core::ffi::c_uint {
            break 's_14;
        }
        n = n.wrapping_rem(r#mod);
    }
    's_27: {
        if n == 0 {
            break 's_27;
        }
        let mut full: uint64_t = ((1 as ::core::ffi::c_int as uint64_t) << r#mod)
            .wrapping_sub(1 as uint64_t);
        x = if left != 0 {
            x << n | x >> r#mod.wrapping_sub(n)
        } else {
            x >> n | x << r#mod.wrapping_sub(n)
        };
        x &= full;
    }
    *cf = (x >> width & 1 as uint64_t) as ::core::ffi::c_int;
    return (x & mask) as uint32_t;
}
#[inline]
unsafe extern "C" fn recomp_parity8(mut x: uint32_t) -> ::core::ffi::c_int {
    x = (x as ::core::ffi::c_uint & 0xff as ::core::ffi::c_uint) as uint32_t;
    x ^= x >> 4 as ::core::ffi::c_int;
    x ^= x >> 2 as ::core::ffi::c_int;
    x ^= x >> 1 as ::core::ffi::c_int;
    return (!x & 1 as uint32_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244B95() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    loop {
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | ::core::ptr::read_volatile::<
                uint16_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
            & 0xffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        _fbs = _fb as int16_t as int32_t;
        if _fa == _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244BB1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_391: {
        if _fa == _fb {
            break 's_391;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41d4a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_80: {
            if _fa == _fb {
                break 's_80;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            loop {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_4: uint32_t = 0x244bdb as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                sub_00248F42();
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_6: uint32_t = 0x244be7 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                sub_00248F42();
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub(1 as uint32_t),
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                if _fa == 0 as uint32_t {
                    break;
                }
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break;
                }
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break;
                }
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_00248F80();
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244C10() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_115: {
        if _fa == _fb {
            break 's_115;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0x1000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_52: {
            if _fa < _fb {
                break 's_52;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            loop {
                _fb = 0x1000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub(0x1000 as uint32_t);
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = 0x1000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(0x1000 as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0x1000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa < _fb {
                    break;
                }
            }
            _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_sub((*__gamepkg_tls_g_eax));
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp);
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_add((*__gamepkg_tls_g_esp));
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        let mut _tmp: uint32_t = (*__gamepkg_tls_g_esp);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_eax) = _tmp;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244C51() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41d4a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_41: {
        if _fa == _fb {
            break 's_41;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x244c73 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            sub_00248F42();
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            let mut _pv_5: uint32_t = 0x244c7f as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_00248F42();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
            if _fa == _fb {
                break;
            }
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa != _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00248FF0();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244CA0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_307: {
        's_67: {
            if _fa == 0 as uint32_t {
                break 's_67;
            }
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            loop {
                _cf = ((*__gamepkg_tls_g_ecx)
                    >> 1 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 1 as ::core::ffi::c_int;
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                let mut _rcv: uint32_t = RC_ROT(
                    (*__gamepkg_tls_g_ebx),
                    1 as ::core::ffi::c_int as ::core::ffi::c_uint,
                    &raw mut _cf,
                    32 as ::core::ffi::c_uint,
                    0 as ::core::ffi::c_int,
                );
                (*__gamepkg_tls_g_ebx) = _rcv;
                _cf = ((*__gamepkg_tls_g_edx)
                    >> 1 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    >> 1 as ::core::ffi::c_int;
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                let mut _rcv_0: uint32_t = RC_ROT(
                    (*__gamepkg_tls_g_eax),
                    1 as ::core::ffi::c_int as ::core::ffi::c_uint,
                    &raw mut _cf,
                    32 as ::core::ffi::c_uint,
                    0 as ::core::ffi::c_int,
                );
                (*__gamepkg_tls_g_eax) = _rcv_0;
                _cf = 0 as ::core::ffi::c_int;
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_ecx);
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                if _fa == 0 as uint32_t {
                    break;
                }
            }
            let mut _dividend_1: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
                << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
            (*__gamepkg_tls_g_eax) = _dividend_1
                .wrapping_div((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
            (*__gamepkg_tls_g_edx) = _dividend_1
                .wrapping_rem((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
            let mut _r: uint64_t = ((*__gamepkg_tls_g_eax) as uint64_t)
                .wrapping_mul(
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint64_t,
                );
            (*__gamepkg_tls_g_eax) = _r as uint32_t;
            (*__gamepkg_tls_g_edx) = (_r >> 32 as ::core::ffi::c_int) as uint32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _r_0: uint64_t = ((*__gamepkg_tls_g_eax) as uint64_t)
                .wrapping_mul((*__gamepkg_tls_g_esi) as uint64_t);
            (*__gamepkg_tls_g_eax) = _r_0 as uint32_t;
            (*__gamepkg_tls_g_edx) = (_r_0 >> 32 as ::core::ffi::c_int) as uint32_t;
            _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            _cf = (((*__gamepkg_tls_g_edx) as uint64_t)
                .wrapping_add((*__gamepkg_tls_g_ecx) as uint64_t)
                >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                .wrapping_add((*__gamepkg_tls_g_ecx));
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            's_289: {
                's_277: {
                    if _cf != 0 {
                        break 's_277;
                    }
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    if _fa > _fb {
                        break 's_277;
                    }
                    if _fa < _fb {
                        break 's_289;
                    }
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    _cf = (_fa < _fb) as ::core::ffi::c_int;
                    if _fa <= _fb {
                        break 's_289;
                    }
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_sub(1);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
            }
            _cf = 0 as ::core::ffi::c_int;
            (*__gamepkg_tls_g_edx) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
            break 's_307;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _cf = 0 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _dividend: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
            << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
        (*__gamepkg_tls_g_eax) = _dividend
            .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
        (*__gamepkg_tls_g_edx) = _dividend
            .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _dividend_0: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
            << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
        (*__gamepkg_tls_g_eax) = _dividend_0
            .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
        (*__gamepkg_tls_g_edx) = _dividend_0
            .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ebx);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244D08() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_10 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_81,
        S_83,
        S_85,
        S_95,
        S_97,
        S_99,
        S_109,
        S_111,
        S_113,
        S_119,
        S_121,
        S_123,
        S_125,
        S_131,
        S_133,
        S_135,
        S_141,
        S_147,
        S_149,
        S_151,
        S_153,
        S_159,
        S_161,
        S_171,
        S_173,
        S_179,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_242,
        S_244,
        S_250,
        S_252,
        S_262,
        S_264,
        S_266,
        S_280,
        S_282,
        S_292,
        S_294,
        S_300,
        S_302,
        S_312,
        S_314,
        S_316,
        S_328,
        S_334,
        S_336,
        S_342,
        S_344,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_457,
        S_459,
        S_465,
        S_467,
        S_477,
        S_479,
        S_481,
        S_491,
        S_493,
        S_495,
        S_501,
        S_503,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_517,
        S_519,
        S_521,
        S_523,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_550,
        S_552,
        S_554,
        S_556,
        S_558,
        S_560,
        S_562,
        S_564,
        S_570,
        S_572,
        S_578,
        S_580,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_624,
        S_626,
        S_632,
        S_634,
    }
    let mut c2rust_current_block_10: C2Rust_Block_10;
    c2rust_current_block_10 = C2Rust_Block_10::S_0;
    loop {
        match c2rust_current_block_10 {
            C2Rust_Block_10::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_2;
            }
            C2Rust_Block_10::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_10 = C2Rust_Block_10::S_4;
            }
            C2Rust_Block_10::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_6;
            }
            C2Rust_Block_10::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_8;
            }
            C2Rust_Block_10::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_18;
            }
            C2Rust_Block_10::S_18 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_28;
            }
            C2Rust_Block_10::S_28 => {
                _pv = ebp;
                c2rust_current_block_10 = C2Rust_Block_10::S_30;
            }
            C2Rust_Block_10::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_32;
            }
            C2Rust_Block_10::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_38;
            }
            C2Rust_Block_10::S_38 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_10 = C2Rust_Block_10::S_40;
            }
            C2Rust_Block_10::S_40 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_10 = C2Rust_Block_10::S_42;
            }
            C2Rust_Block_10::S_42 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_10 = C2Rust_Block_10::S_44;
            }
            C2Rust_Block_10::S_44 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xe as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_46;
            }
            C2Rust_Block_10::S_46 => {
                (*__gamepkg_tls_g_ecx) = 0x7ff0 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_48;
            }
            C2Rust_Block_10::S_48 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_10 = C2Rust_Block_10::S_50;
            }
            C2Rust_Block_10::S_50 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_52;
            }
            C2Rust_Block_10::S_52 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & (*__gamepkg_tls_g_ecx);
                c2rust_current_block_10 = C2Rust_Block_10::S_54;
            }
            C2Rust_Block_10::S_54 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_56;
            }
            C2Rust_Block_10::S_56 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_58;
            }
            C2Rust_Block_10::S_58 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_60;
            }
            C2Rust_Block_10::S_60 => {
                _fb = ((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_62;
            }
            C2Rust_Block_10::S_62 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_64;
            }
            C2Rust_Block_10::S_64 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_66;
            }
            C2Rust_Block_10::S_66 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_68;
            }
            C2Rust_Block_10::S_68 => {
                if _fa != _fb {
                    c2rust_current_block_10 = C2Rust_Block_10::S_350;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_81;
                }
            }
            C2Rust_Block_10::S_81 => {
                _fp_value = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_83;
            }
            C2Rust_Block_10::S_83 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_85;
            }
            C2Rust_Block_10::S_85 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_10 = C2Rust_Block_10::S_95;
            }
            C2Rust_Block_10::S_95 => {
                _pv_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_10 = C2Rust_Block_10::S_97;
            }
            C2Rust_Block_10::S_97 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_99;
            }
            C2Rust_Block_10::S_99 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_109;
            }
            C2Rust_Block_10::S_109 => {
                _pv_1 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_10 = C2Rust_Block_10::S_111;
            }
            C2Rust_Block_10::S_111 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_113;
            }
            C2Rust_Block_10::S_113 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_119;
            }
            C2Rust_Block_10::S_119 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_121;
            }
            C2Rust_Block_10::S_121 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_123;
            }
            C2Rust_Block_10::S_123 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_10 = C2Rust_Block_10::S_125;
            }
            C2Rust_Block_10::S_125 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_10 = C2Rust_Block_10::S_131;
            }
            C2Rust_Block_10::S_131 => {
                _pv_2 = 0x244d29 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_133;
            }
            C2Rust_Block_10::S_133 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_135;
            }
            C2Rust_Block_10::S_135 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_141;
            }
            C2Rust_Block_10::S_141 => {
                sub_002475B2();
                c2rust_current_block_10 = C2Rust_Block_10::S_147;
            }
            C2Rust_Block_10::S_147 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_10 = C2Rust_Block_10::S_149;
            }
            C2Rust_Block_10::S_149 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_151;
            }
            C2Rust_Block_10::S_151 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_153;
            }
            C2Rust_Block_10::S_153 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_159;
            }
            C2Rust_Block_10::S_159 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_161;
            }
            C2Rust_Block_10::S_161 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_171;
            }
            C2Rust_Block_10::S_171 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_173;
            }
            C2Rust_Block_10::S_173 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_179;
            }
            C2Rust_Block_10::S_179 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_10 = C2Rust_Block_10::S_328;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_188;
                }
            }
            C2Rust_Block_10::S_188 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_10 = C2Rust_Block_10::S_190;
            }
            C2Rust_Block_10::S_190 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_192;
            }
            C2Rust_Block_10::S_192 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_194;
            }
            C2Rust_Block_10::S_194 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_196;
            }
            C2Rust_Block_10::S_196 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_10 = C2Rust_Block_10::S_312;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_205;
                }
            }
            C2Rust_Block_10::S_205 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_10 = C2Rust_Block_10::S_207;
            }
            C2Rust_Block_10::S_207 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_209;
            }
            C2Rust_Block_10::S_209 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_211;
            }
            C2Rust_Block_10::S_211 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_213;
            }
            C2Rust_Block_10::S_213 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_10 = C2Rust_Block_10::S_262;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_222;
                }
            }
            C2Rust_Block_10::S_222 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_224;
            }
            C2Rust_Block_10::S_224 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_226;
            }
            C2Rust_Block_10::S_226 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_228;
            }
            C2Rust_Block_10::S_228 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_230;
            }
            C2Rust_Block_10::S_230 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_10 = C2Rust_Block_10::S_232;
            }
            C2Rust_Block_10::S_232 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_234;
            }
            C2Rust_Block_10::S_234 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_236;
            }
            C2Rust_Block_10::S_236 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_242;
            }
            C2Rust_Block_10::S_242 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_244;
            }
            C2Rust_Block_10::S_244 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_250;
            }
            C2Rust_Block_10::S_250 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_252;
            }
            C2Rust_Block_10::S_252 => return,
            C2Rust_Block_10::S_262 => {
                _pv_3 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_264;
            }
            C2Rust_Block_10::S_264 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_266;
            }
            C2Rust_Block_10::S_266 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_280;
            }
            C2Rust_Block_10::S_280 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_282;
            }
            C2Rust_Block_10::S_282 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_292;
            }
            C2Rust_Block_10::S_292 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_294;
            }
            C2Rust_Block_10::S_294 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_300;
            }
            C2Rust_Block_10::S_300 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_302;
            }
            C2Rust_Block_10::S_302 => return,
            C2Rust_Block_10::S_312 => {
                _pv_4 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_314;
            }
            C2Rust_Block_10::S_314 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_316;
            }
            C2Rust_Block_10::S_316 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_280;
            }
            C2Rust_Block_10::S_328 => {
                (*__gamepkg_tls_g_eax) = 0x200 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_334;
            }
            C2Rust_Block_10::S_334 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_336;
            }
            C2Rust_Block_10::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_342;
            }
            C2Rust_Block_10::S_342 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_344;
            }
            C2Rust_Block_10::S_344 => return,
            C2Rust_Block_10::S_350 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_352;
            }
            C2Rust_Block_10::S_352 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x8000 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_354;
            }
            C2Rust_Block_10::S_354 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_356;
            }
            C2Rust_Block_10::S_356 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_358;
            }
            C2Rust_Block_10::S_358 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_360;
            }
            C2Rust_Block_10::S_360 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_362;
            }
            C2Rust_Block_10::S_362 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_364;
            }
            C2Rust_Block_10::S_364 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_366;
            }
            C2Rust_Block_10::S_366 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_368;
            }
            C2Rust_Block_10::S_368 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_10 = C2Rust_Block_10::S_370;
            }
            C2Rust_Block_10::S_370 => {
                if _fa != _fb {
                    c2rust_current_block_10 = C2Rust_Block_10::S_477;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_379;
                }
            }
            C2Rust_Block_10::S_379 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xfffff as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_381;
            }
            C2Rust_Block_10::S_381 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_383;
            }
            C2Rust_Block_10::S_383 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_385;
            }
            C2Rust_Block_10::S_385 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_387;
            }
            C2Rust_Block_10::S_387 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_389;
            }
            C2Rust_Block_10::S_389 => {
                if _fa != _fb {
                    c2rust_current_block_10 = C2Rust_Block_10::S_417;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_398;
                }
            }
            C2Rust_Block_10::S_398 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_400;
            }
            C2Rust_Block_10::S_400 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_402;
            }
            C2Rust_Block_10::S_402 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_404;
            }
            C2Rust_Block_10::S_404 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_406;
            }
            C2Rust_Block_10::S_406 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_408;
            }
            C2Rust_Block_10::S_408 => {
                if _fa == _fb {
                    c2rust_current_block_10 = C2Rust_Block_10::S_477;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_417;
                }
            }
            C2Rust_Block_10::S_417 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_10 = C2Rust_Block_10::S_419;
            }
            C2Rust_Block_10::S_419 => {
                _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_421;
            }
            C2Rust_Block_10::S_421 => {
                (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                    as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_423;
            }
            C2Rust_Block_10::S_423 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_425;
            }
            C2Rust_Block_10::S_425 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_427;
            }
            C2Rust_Block_10::S_427 => {
                (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                    0xffffffff as ::core::ffi::c_uint
                } else {
                    0 as ::core::ffi::c_uint
                }) as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_429;
            }
            C2Rust_Block_10::S_429 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_431;
            }
            C2Rust_Block_10::S_431 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_433;
            }
            C2Rust_Block_10::S_433 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_435;
            }
            C2Rust_Block_10::S_435 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff90 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_437;
            }
            C2Rust_Block_10::S_437 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_439;
            }
            C2Rust_Block_10::S_439 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_441;
            }
            C2Rust_Block_10::S_441 => {
                _fb = 0x80 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_443;
            }
            C2Rust_Block_10::S_443 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_445;
            }
            C2Rust_Block_10::S_445 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(0x80 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_447;
            }
            C2Rust_Block_10::S_447 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x80 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_449;
            }
            C2Rust_Block_10::S_449 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_451;
            }
            C2Rust_Block_10::S_451 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_457;
            }
            C2Rust_Block_10::S_457 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_459;
            }
            C2Rust_Block_10::S_459 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_465;
            }
            C2Rust_Block_10::S_465 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_467;
            }
            C2Rust_Block_10::S_467 => return,
            C2Rust_Block_10::S_477 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_479;
            }
            C2Rust_Block_10::S_479 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_481;
            }
            C2Rust_Block_10::S_481 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_10 = C2Rust_Block_10::S_491;
            }
            C2Rust_Block_10::S_491 => {
                _fp_value_1 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_493;
            }
            C2Rust_Block_10::S_493 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_495;
            }
            C2Rust_Block_10::S_495 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_10 = C2Rust_Block_10::S_501;
            }
            C2Rust_Block_10::S_501 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_10 = C2Rust_Block_10::S_503;
            }
            C2Rust_Block_10::S_503 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_505;
            }
            C2Rust_Block_10::S_505 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_507;
            }
            C2Rust_Block_10::S_507 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_509;
            }
            C2Rust_Block_10::S_509 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_511;
            }
            C2Rust_Block_10::S_511 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x44 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_513;
            }
            C2Rust_Block_10::S_513 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_515;
            }
            C2Rust_Block_10::S_515 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_517;
            }
            C2Rust_Block_10::S_517 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_519;
            }
            C2Rust_Block_10::S_519 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_521;
            }
            C2Rust_Block_10::S_521 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_10 = C2Rust_Block_10::S_523;
            }
            C2Rust_Block_10::S_523 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_10 = C2Rust_Block_10::S_586;
                } else {
                    c2rust_current_block_10 = C2Rust_Block_10::S_532;
                }
            }
            C2Rust_Block_10::S_532 => {
                _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_534;
            }
            C2Rust_Block_10::S_534 => {
                (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                    as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_536;
            }
            C2Rust_Block_10::S_536 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_538;
            }
            C2Rust_Block_10::S_538 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_540;
            }
            C2Rust_Block_10::S_540 => {
                (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                    0xffffffff as ::core::ffi::c_uint
                } else {
                    0 as ::core::ffi::c_uint
                }) as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_542;
            }
            C2Rust_Block_10::S_542 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_544;
            }
            C2Rust_Block_10::S_544 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_546;
            }
            C2Rust_Block_10::S_546 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_548;
            }
            C2Rust_Block_10::S_548 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffffe0 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_550;
            }
            C2Rust_Block_10::S_550 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_552;
            }
            C2Rust_Block_10::S_552 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_554;
            }
            C2Rust_Block_10::S_554 => {
                _fb = 0x40 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_556;
            }
            C2Rust_Block_10::S_556 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_558;
            }
            C2Rust_Block_10::S_558 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(0x40 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_560;
            }
            C2Rust_Block_10::S_560 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x40 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_562;
            }
            C2Rust_Block_10::S_562 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_564;
            }
            C2Rust_Block_10::S_564 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_570;
            }
            C2Rust_Block_10::S_570 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_572;
            }
            C2Rust_Block_10::S_572 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_578;
            }
            C2Rust_Block_10::S_578 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_580;
            }
            C2Rust_Block_10::S_580 => return,
            C2Rust_Block_10::S_586 => {
                _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_588;
            }
            C2Rust_Block_10::S_588 => {
                (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                    as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_590;
            }
            C2Rust_Block_10::S_590 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_592;
            }
            C2Rust_Block_10::S_592 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_594;
            }
            C2Rust_Block_10::S_594 => {
                (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                    0xffffffff as ::core::ffi::c_uint
                } else {
                    0 as ::core::ffi::c_uint
                }) as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_596;
            }
            C2Rust_Block_10::S_596 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_598;
            }
            C2Rust_Block_10::S_598 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_600;
            }
            C2Rust_Block_10::S_600 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_602;
            }
            C2Rust_Block_10::S_602 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff08 as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_604;
            }
            C2Rust_Block_10::S_604 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_606;
            }
            C2Rust_Block_10::S_606 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_608;
            }
            C2Rust_Block_10::S_608 => {
                _fb = 0x100 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_610;
            }
            C2Rust_Block_10::S_610 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_612;
            }
            C2Rust_Block_10::S_612 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(0x100 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_10 = C2Rust_Block_10::S_614;
            }
            C2Rust_Block_10::S_614 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x100 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_616;
            }
            C2Rust_Block_10::S_616 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_618;
            }
            C2Rust_Block_10::S_618 => {
                _fas = _fa as int32_t;
                c2rust_current_block_10 = C2Rust_Block_10::S_624;
            }
            C2Rust_Block_10::S_624 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_10 = C2Rust_Block_10::S_626;
            }
            C2Rust_Block_10::S_626 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_632;
            }
            C2Rust_Block_10::S_632 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_10 = C2Rust_Block_10::S_634;
            }
            C2Rust_Block_10::S_634 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244DA4() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x2493e9 as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6630 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6634 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x249096 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6638 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x2490fb as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c663c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x24903e as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6640 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x2490e1 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6644 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244DDC() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x244de1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00244DA4();
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_75: {
        if _fa == _fb {
            break 's_75;
        }
        let mut _pv_0: uint32_t = 0x244ded as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_00248557();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244DF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = ((*__gamepkg_tls_g_esp) < 0x20 as ::core::ffi::c_int as uint32_t)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x20 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp) & 0xfffffff0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value: ::core::ffi::c_double = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            as ::core::ffi::c_float,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            int64_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        recomp_fist(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
            (*__gamepkg_tls_g_fp_control_word),
            64 as ::core::ffi::c_uint,
        ),
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        int64_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            int64_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_294: {
        's_126: {
            if _fa != _fb {
                break 's_126;
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_edx) & 0x7fffffff as uint32_t
                & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            _cf = 0 as ::core::ffi::c_int;
            if _fa != _fb {
                break 's_126;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    as ::core::ffi::c_float,
            );
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    as ::core::ffi::c_float,
            );
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            break 's_294;
        }
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = if (*__gamepkg_tls_g_fp_control_word) as ::core::ffi::c_uint
            & 0x300 as ::core::ffi::c_uint != 0
        {
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
                - (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        } else {
            recomp_fp_round24(
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize]
                    - (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
            )
        };
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        _cf = 0 as ::core::ffi::c_int;
        's_209: {
            if _fa.wrapping_sub(_fb) >> 31 as ::core::ffi::c_int == 0 as uint32_t {
                break 's_209;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    as ::core::ffi::c_float,
            );
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _cf = 0 as ::core::ffi::c_int;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) ^ 0x80000000 as uint32_t;
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = 0x7fffffff as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
                .wrapping_add(0x7fffffff as ::core::ffi::c_int as uint64_t)
                >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add(0x7fffffff as uint32_t);
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _t_0: uint64_t = ((*__gamepkg_tls_g_eax) as uint64_t)
                .wrapping_add(0 as ::core::ffi::c_int as uint64_t)
                .wrapping_add(_cf as uint64_t);
            _cf = (_t_0 >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_eax) = _t_0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _t_1: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
                .wrapping_add(0 as ::core::ffi::c_int as uint64_t)
                .wrapping_add(_cf as uint64_t);
            _cf = (_t_1 >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_edx) = _t_1 as uint32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_294;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                as ::core::ffi::c_float,
        );
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0x7fffffff as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
            .wrapping_add(0x7fffffff as ::core::ffi::c_int as uint64_t)
            >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
            .wrapping_add(0x7fffffff as uint32_t);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _t_2: uint64_t = ((*__gamepkg_tls_g_eax) as uint64_t)
            .wrapping_sub(0 as ::core::ffi::c_int as uint64_t)
            .wrapping_sub(_cf as uint64_t);
        _cf = (_t_2 >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = _t_2 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _t_3: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
            .wrapping_sub(0 as ::core::ffi::c_int as uint64_t)
            .wrapping_sub(_cf as uint64_t);
        _cf = (_t_3 >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_edx) = _t_3 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244E68() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_edx) = 0x3c6652 as uint32_t;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00249749();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244E9C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x14 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x244eb3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00244EC0();
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00244EC0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_8: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _t: ::core::ffi::c_double = 0.;
    let mut _fp_value_3: ::core::ffi::c_double = 0.;
    let mut _pv_9: uint32_t = 0;
    let mut _fp_value_4: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_16 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_30,
        S_32,
        S_34,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_63,
        S_65,
        S_67,
        S_73,
        S_79,
        S_81,
        S_83,
        S_85,
        S_87,
        S_89,
        S_91,
        S_93,
        S_95,
        S_108,
        S_110,
        S_112,
        S_118,
        S_124,
        S_133,
        S_135,
        S_137,
        S_139,
        S_141,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_168,
        S_170,
        S_178,
        S_180,
        S_182,
        S_188,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_211,
        S_217,
        S_219,
        S_221,
        S_223,
        S_225,
        S_228,
        S_230,
        S_232,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_265,
        S_267,
        S_269,
        S_277,
        S_279,
        S_285,
        S_287,
        S_289,
        S_295,
        S_305,
        S_307,
        S_313,
        S_315,
        S_321,
        S_327,
        S_329,
        S_331,
        S_337,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_360,
        S_362,
        S_364,
        S_366,
        S_374,
        S_376,
        S_378,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_403,
        S_405,
        S_407,
        S_415,
        S_417,
        S_419,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_454,
        S_460,
        S_462,
        S_464,
        S_470,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_509,
        S_511,
        S_513,
        S_515,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_557,
        S_559,
        S_561,
        S_567,
        S_569,
        S_571,
        S_573,
        S_575,
        S_577,
        S_579,
        S_581,
        S_583,
        S_589,
        S_591,
        S_593,
        S_599,
        S_605,
        S_607,
        S_609,
        S_611,
        S_613,
        S_619,
        S_621,
        S_631,
        S_633,
        S_635,
        S_641,
        S_643,
        S_645,
        S_647,
        S_649,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_662,
        S_664,
        S_666,
        S_674,
        S_682,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
        S_696,
        S_705,
        S_707,
        S_709,
        S_711,
        S_713,
        S_715,
        S_717,
        S_719,
        S_721,
        S_734,
        S_736,
        S_738,
        S_744,
        S_750,
        S_752,
        S_754,
        S_756,
        S_758,
        S_760,
        S_762,
        S_764,
        S_766,
        S_779,
        S_781,
        S_783,
        S_789,
        S_791,
        S_793,
        S_795,
        S_797,
        S_806,
        S_812,
        S_824,
        S_826,
        S_828,
        S_834,
        S_836,
        S_838,
        S_840,
        S_842,
        S_845,
        S_847,
        S_849,
        S_857,
        S_859,
        S_861,
        S_863,
        S_869,
        S_875,
        S_877,
        S_879,
        S_885,
        S_887,
        S_889,
        S_896,
        S_902,
        S_904,
        S_906,
        S_918,
        S_920,
        S_922,
        S_928,
        S_934,
        S_936,
        S_938,
        S_940,
        S_942,
        S_944,
        S_953,
        S_955,
        S_961,
        S_963,
        S_965,
        S_971,
    }
    let mut c2rust_current_block_16: C2Rust_Block_16;
    c2rust_current_block_16 = C2Rust_Block_16::S_0;
    loop {
        match c2rust_current_block_16 {
            C2Rust_Block_16::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_2;
            }
            C2Rust_Block_16::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_16 = C2Rust_Block_16::S_4;
            }
            C2Rust_Block_16::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_6;
            }
            C2Rust_Block_16::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_8;
            }
            C2Rust_Block_16::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_18;
            }
            C2Rust_Block_16::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_16 = C2Rust_Block_16::S_24;
            }
            C2Rust_Block_16::S_24 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_16 = C2Rust_Block_16::S_30;
            }
            C2Rust_Block_16::S_30 => {
                _pv = (*__gamepkg_tls_g_eax);
                c2rust_current_block_16 = C2Rust_Block_16::S_32;
            }
            C2Rust_Block_16::S_32 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_34;
            }
            C2Rust_Block_16::S_34 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_40;
            }
            C2Rust_Block_16::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_control_word),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_42;
            }
            C2Rust_Block_16::S_42 => {
                _fa = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_44;
            }
            C2Rust_Block_16::S_44 => {
                _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_46;
            }
            C2Rust_Block_16::S_46 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_48;
            }
            C2Rust_Block_16::S_48 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_50;
            }
            C2Rust_Block_16::S_50 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_79;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_63;
                }
            }
            C2Rust_Block_16::S_63 => {
                _pv_0 = 0x244ed4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_65;
            }
            C2Rust_Block_16::S_65 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_67;
            }
            C2Rust_Block_16::S_67 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_73;
            }
            C2Rust_Block_16::S_73 => {
                sub_00249BE5();
                c2rust_current_block_16 = C2Rust_Block_16::S_79;
            }
            C2Rust_Block_16::S_79 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0x7ff00000 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_81;
            }
            C2Rust_Block_16::S_81 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_83;
            }
            C2Rust_Block_16::S_83 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_85;
            }
            C2Rust_Block_16::S_85 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_87;
            }
            C2Rust_Block_16::S_87 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_89;
            }
            C2Rust_Block_16::S_89 => {
                _fb = 0x7ff00000 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_91;
            }
            C2Rust_Block_16::S_91 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_93;
            }
            C2Rust_Block_16::S_93 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_95;
            }
            C2Rust_Block_16::S_95 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_427;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_108;
                }
            }
            C2Rust_Block_16::S_108 => {
                _pv_1 = 0x244eef as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_110;
            }
            C2Rust_Block_16::S_110 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_112;
            }
            C2Rust_Block_16::S_112 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_118;
            }
            C2Rust_Block_16::S_118 => {
                sub_00249C15();
                c2rust_current_block_16 = C2Rust_Block_16::S_124;
            }
            C2Rust_Block_16::S_124 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_415;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_133;
                }
            }
            C2Rust_Block_16::S_133 => {
                _fa = (*__gamepkg_tls_g_eax) & 0x7ff00000 as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_135;
            }
            C2Rust_Block_16::S_135 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_137;
            }
            C2Rust_Block_16::S_137 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_139;
            }
            C2Rust_Block_16::S_139 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_141;
            }
            C2Rust_Block_16::S_141 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_682;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_150;
                }
            }
            C2Rust_Block_16::S_150 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xf as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_152;
            }
            C2Rust_Block_16::S_152 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int & 0x80 as ::core::ffi::c_int) as uint8_t
                        as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_154;
            }
            C2Rust_Block_16::S_154 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_156;
            }
            C2Rust_Block_16::S_156 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_158;
            }
            C2Rust_Block_16::S_158 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_16 = C2Rust_Block_16::S_896;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_168;
                }
            }
            C2Rust_Block_16::S_168 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize]
                    * log2(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                    );
                c2rust_current_block_16 = C2Rust_Block_16::S_170;
            }
            C2Rust_Block_16::S_170 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_178;
            }
            C2Rust_Block_16::S_178 => {
                _pv_2 = 0x244f14 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_180;
            }
            C2Rust_Block_16::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_182;
            }
            C2Rust_Block_16::S_182 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_188;
            }
            C2Rust_Block_16::S_188 => {
                sub_00249BD0();
                c2rust_current_block_16 = C2Rust_Block_16::S_194;
            }
            C2Rust_Block_16::S_194 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_196;
            }
            C2Rust_Block_16::S_196 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_198;
            }
            C2Rust_Block_16::S_198 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_200;
            }
            C2Rust_Block_16::S_200 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_202;
            }
            C2Rust_Block_16::S_202 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_217;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_211;
                }
            }
            C2Rust_Block_16::S_211 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_16 = C2Rust_Block_16::S_217;
            }
            C2Rust_Block_16::S_217 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41d2a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_219;
            }
            C2Rust_Block_16::S_219 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_221;
            }
            C2Rust_Block_16::S_221 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_223;
            }
            C2Rust_Block_16::S_223 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_225;
            }
            C2Rust_Block_16::S_225 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_228;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_240;
                }
            }
            C2Rust_Block_16::S_228 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_230;
            }
            C2Rust_Block_16::S_230 => {
                sub_00249C6E();
                c2rust_current_block_16 = C2Rust_Block_16::S_232;
            }
            C2Rust_Block_16::S_232 => return,
            C2Rust_Block_16::S_240 => {
                (*__gamepkg_tls_g_ecx) = 0x3c612c as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_242;
            }
            C2Rust_Block_16::S_242 => {
                (*__gamepkg_tls_g_edx) = 0x1d as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_244;
            }
            C2Rust_Block_16::S_244 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_246;
            }
            C2Rust_Block_16::S_246 => {
                sub_00249CB9();
                c2rust_current_block_16 = C2Rust_Block_16::S_248;
            }
            C2Rust_Block_16::S_248 => return,
            C2Rust_Block_16::S_254 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41d2a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_256;
            }
            C2Rust_Block_16::S_256 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_258;
            }
            C2Rust_Block_16::S_258 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_260;
            }
            C2Rust_Block_16::S_260 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_262;
            }
            C2Rust_Block_16::S_262 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_265;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_277;
                }
            }
            C2Rust_Block_16::S_265 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_267;
            }
            C2Rust_Block_16::S_267 => {
                sub_00249C6E();
                c2rust_current_block_16 = C2Rust_Block_16::S_269;
            }
            C2Rust_Block_16::S_269 => return,
            C2Rust_Block_16::S_277 => {
                (*__gamepkg_tls_g_ecx) = 0x3c612c as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_279;
            }
            C2Rust_Block_16::S_279 => {
                (*__gamepkg_tls_g_edx) = 0x1d as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_285;
            }
            C2Rust_Block_16::S_285 => {
                _pv_3 = 0x244f55 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_287;
            }
            C2Rust_Block_16::S_287 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_289;
            }
            C2Rust_Block_16::S_289 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_295;
            }
            C2Rust_Block_16::S_295 => {
                sub_00249B7C();
                c2rust_current_block_16 = C2Rust_Block_16::S_305;
            }
            C2Rust_Block_16::S_305 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_307;
            }
            C2Rust_Block_16::S_307 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_313;
            }
            C2Rust_Block_16::S_313 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_315;
            }
            C2Rust_Block_16::S_315 => return,
            C2Rust_Block_16::S_321 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_327;
            }
            C2Rust_Block_16::S_327 => {
                _pv_4 = 0x244f60 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_329;
            }
            C2Rust_Block_16::S_329 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_331;
            }
            C2Rust_Block_16::S_331 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_337;
            }
            C2Rust_Block_16::S_337 => {
                sub_00249C15();
                c2rust_current_block_16 = C2Rust_Block_16::S_343;
            }
            C2Rust_Block_16::S_343 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x16 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_345;
            }
            C2Rust_Block_16::S_345 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_347;
            }
            C2Rust_Block_16::S_347 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_349;
            }
            C2Rust_Block_16::S_349 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_351;
            }
            C2Rust_Block_16::S_351 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_374;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_360;
                }
            }
            C2Rust_Block_16::S_360 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_16 = C2Rust_Block_16::S_362;
            }
            C2Rust_Block_16::S_362 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_364;
            }
            C2Rust_Block_16::S_364 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_366;
            }
            C2Rust_Block_16::S_366 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_476;
            }
            C2Rust_Block_16::S_374 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                            + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                                as usize],
                    )
                };
                c2rust_current_block_16 = C2Rust_Block_16::S_376;
            }
            C2Rust_Block_16::S_376 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_378;
            }
            C2Rust_Block_16::S_378 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_254;
            }
            C2Rust_Block_16::S_386 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xe as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_388;
            }
            C2Rust_Block_16::S_388 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_390;
            }
            C2Rust_Block_16::S_390 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_392;
            }
            C2Rust_Block_16::S_392 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_394;
            }
            C2Rust_Block_16::S_394 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_374;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_403;
                }
            }
            C2Rust_Block_16::S_403 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                            + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                                as usize],
                    )
                };
                c2rust_current_block_16 = C2Rust_Block_16::S_405;
            }
            C2Rust_Block_16::S_405 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_407;
            }
            C2Rust_Block_16::S_407 => {
                (*__gamepkg_tls_g_eax) = 7 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_254;
            }
            C2Rust_Block_16::S_415 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_417;
            }
            C2Rust_Block_16::S_417 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_419;
            }
            C2Rust_Block_16::S_419 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_476;
            }
            C2Rust_Block_16::S_427 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_429;
            }
            C2Rust_Block_16::S_429 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_431;
            }
            C2Rust_Block_16::S_431 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_433;
            }
            C2Rust_Block_16::S_433 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_435;
            }
            C2Rust_Block_16::S_435 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_437;
            }
            C2Rust_Block_16::S_437 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_439;
            }
            C2Rust_Block_16::S_439 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    | ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                c2rust_current_block_16 = C2Rust_Block_16::S_441;
            }
            C2Rust_Block_16::S_441 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_443;
            }
            C2Rust_Block_16::S_443 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_445;
            }
            C2Rust_Block_16::S_445 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_16 = C2Rust_Block_16::S_321;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_454;
                }
            }
            C2Rust_Block_16::S_454 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_460;
            }
            C2Rust_Block_16::S_460 => {
                _pv_5 = 0x244f9d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_462;
            }
            C2Rust_Block_16::S_462 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_464;
            }
            C2Rust_Block_16::S_464 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_470;
            }
            C2Rust_Block_16::S_470 => {
                sub_00249C15();
                c2rust_current_block_16 = C2Rust_Block_16::S_476;
            }
            C2Rust_Block_16::S_476 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_478;
            }
            C2Rust_Block_16::S_478 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_16 = C2Rust_Block_16::S_480;
            }
            C2Rust_Block_16::S_480 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7ff00000 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_482;
            }
            C2Rust_Block_16::S_482 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_484;
            }
            C2Rust_Block_16::S_484 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_486;
            }
            C2Rust_Block_16::S_486 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xfffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_488;
            }
            C2Rust_Block_16::S_488 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_490;
            }
            C2Rust_Block_16::S_490 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_492;
            }
            C2Rust_Block_16::S_492 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_494;
            }
            C2Rust_Block_16::S_494 => {
                _fb = 0x7ff00000 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_496;
            }
            C2Rust_Block_16::S_496 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_498;
            }
            C2Rust_Block_16::S_498 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_500;
            }
            C2Rust_Block_16::S_500 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_524;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_509;
                }
            }
            C2Rust_Block_16::S_509 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    | ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                c2rust_current_block_16 = C2Rust_Block_16::S_511;
            }
            C2Rust_Block_16::S_511 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_513;
            }
            C2Rust_Block_16::S_513 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_515;
            }
            C2Rust_Block_16::S_515 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_16 = C2Rust_Block_16::S_386;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_524;
                }
            }
            C2Rust_Block_16::S_524 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_526;
            }
            C2Rust_Block_16::S_526 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_528;
            }
            C2Rust_Block_16::S_528 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_530;
            }
            C2Rust_Block_16::S_530 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_532;
            }
            C2Rust_Block_16::S_532 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_403;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_541;
                }
            }
            C2Rust_Block_16::S_541 => {
                _fb = 0x74 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_543;
            }
            C2Rust_Block_16::S_543 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_545;
            }
            C2Rust_Block_16::S_545 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x74 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_547;
            }
            C2Rust_Block_16::S_547 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_549;
            }
            C2Rust_Block_16::S_549 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_551;
            }
            C2Rust_Block_16::S_551 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp);
                c2rust_current_block_16 = C2Rust_Block_16::S_557;
            }
            C2Rust_Block_16::S_557 => {
                _pv_6 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_16 = C2Rust_Block_16::S_559;
            }
            C2Rust_Block_16::S_559 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_561;
            }
            C2Rust_Block_16::S_561 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_567;
            }
            C2Rust_Block_16::S_567 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_569;
            }
            C2Rust_Block_16::S_569 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_571;
            }
            C2Rust_Block_16::S_571 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x10 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_573;
            }
            C2Rust_Block_16::S_573 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_575;
            }
            C2Rust_Block_16::S_575 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_577;
            }
            C2Rust_Block_16::S_577 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_579;
            }
            C2Rust_Block_16::S_579 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_581;
            }
            C2Rust_Block_16::S_581 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_583;
            }
            C2Rust_Block_16::S_583 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_589;
            }
            C2Rust_Block_16::S_589 => {
                _pv_7 = 0x244fd8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_591;
            }
            C2Rust_Block_16::S_591 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_593;
            }
            C2Rust_Block_16::S_593 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_599;
            }
            C2Rust_Block_16::S_599 => {
                sub_00249DC1();
                c2rust_current_block_16 = C2Rust_Block_16::S_605;
            }
            C2Rust_Block_16::S_605 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_607;
            }
            C2Rust_Block_16::S_607 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_609;
            }
            C2Rust_Block_16::S_609 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_611;
            }
            C2Rust_Block_16::S_611 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_613;
            }
            C2Rust_Block_16::S_613 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_619;
            }
            C2Rust_Block_16::S_619 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_621;
            }
            C2Rust_Block_16::S_621 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_631;
            }
            C2Rust_Block_16::S_631 => {
                _fp_value = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_633;
            }
            C2Rust_Block_16::S_633 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_635;
            }
            C2Rust_Block_16::S_635 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_16 = C2Rust_Block_16::S_641;
            }
            C2Rust_Block_16::S_641 => {
                _fb = 0x74 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_643;
            }
            C2Rust_Block_16::S_643 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_645;
            }
            C2Rust_Block_16::S_645 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x74 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_647;
            }
            C2Rust_Block_16::S_647 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_649;
            }
            C2Rust_Block_16::S_649 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_651;
            }
            C2Rust_Block_16::S_651 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_653;
            }
            C2Rust_Block_16::S_653 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_655;
            }
            C2Rust_Block_16::S_655 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_657;
            }
            C2Rust_Block_16::S_657 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_659;
            }
            C2Rust_Block_16::S_659 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_662;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_674;
                }
            }
            C2Rust_Block_16::S_662 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_664;
            }
            C2Rust_Block_16::S_664 => {
                sub_00249C6E();
                c2rust_current_block_16 = C2Rust_Block_16::S_666;
            }
            C2Rust_Block_16::S_666 => return,
            C2Rust_Block_16::S_674 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_254;
            }
            C2Rust_Block_16::S_682 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_684;
            }
            C2Rust_Block_16::S_684 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_686;
            }
            C2Rust_Block_16::S_686 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_688;
            }
            C2Rust_Block_16::S_688 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_690;
            }
            C2Rust_Block_16::S_690 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    | ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                c2rust_current_block_16 = C2Rust_Block_16::S_692;
            }
            C2Rust_Block_16::S_692 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_694;
            }
            C2Rust_Block_16::S_694 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_696;
            }
            C2Rust_Block_16::S_696 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_16 = C2Rust_Block_16::S_150;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_705;
                }
            }
            C2Rust_Block_16::S_705 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_707;
            }
            C2Rust_Block_16::S_707 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_709;
            }
            C2Rust_Block_16::S_709 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7fffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_711;
            }
            C2Rust_Block_16::S_711 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_713;
            }
            C2Rust_Block_16::S_713 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_715;
            }
            C2Rust_Block_16::S_715 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    | ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                c2rust_current_block_16 = C2Rust_Block_16::S_717;
            }
            C2Rust_Block_16::S_717 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_719;
            }
            C2Rust_Block_16::S_719 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_721;
            }
            C2Rust_Block_16::S_721 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_16 = C2Rust_Block_16::S_869;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_734;
                }
            }
            C2Rust_Block_16::S_734 => {
                _pv_8 = 0x24501f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_736;
            }
            C2Rust_Block_16::S_736 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_738;
            }
            C2Rust_Block_16::S_738 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_744;
            }
            C2Rust_Block_16::S_744 => {
                sub_00245085();
                c2rust_current_block_16 = C2Rust_Block_16::S_750;
            }
            C2Rust_Block_16::S_750 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
                    | (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xf as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t) << 8 as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_752;
            }
            C2Rust_Block_16::S_752 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
                    | ((((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int
                        & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                        >> 7 as ::core::ffi::c_int) as uint8_t as uint32_t)
                        << 8 as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_754;
            }
            C2Rust_Block_16::S_754 => {
                _fa = ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_756;
            }
            C2Rust_Block_16::S_756 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_758;
            }
            C2Rust_Block_16::S_758 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x17 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0x80 as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_760;
            }
            C2Rust_Block_16::S_760 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_762;
            }
            C2Rust_Block_16::S_762 => {
                _fas = _fa as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_764;
            }
            C2Rust_Block_16::S_764 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_766;
            }
            C2Rust_Block_16::S_766 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_824;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_779;
                }
            }
            C2Rust_Block_16::S_779 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3c66b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_16 = C2Rust_Block_16::S_781;
            }
            C2Rust_Block_16::S_781 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_783;
            }
            C2Rust_Block_16::S_783 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_16 = C2Rust_Block_16::S_789;
            }
            C2Rust_Block_16::S_789 => {
                _fa = (((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_791;
            }
            C2Rust_Block_16::S_791 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_793;
            }
            C2Rust_Block_16::S_793 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_795;
            }
            C2Rust_Block_16::S_795 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_797;
            }
            C2Rust_Block_16::S_797 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_812;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_806;
                }
            }
            C2Rust_Block_16::S_806 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_16 = C2Rust_Block_16::S_812;
            }
            C2Rust_Block_16::S_812 => {
                (*__gamepkg_tls_g_eax) = 2 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_254;
            }
            C2Rust_Block_16::S_824 => {
                _fp_value_1 = 0.0f64;
                c2rust_current_block_16 = C2Rust_Block_16::S_826;
            }
            C2Rust_Block_16::S_826 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_828;
            }
            C2Rust_Block_16::S_828 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_16 = C2Rust_Block_16::S_834;
            }
            C2Rust_Block_16::S_834 => {
                _fa = (((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_836;
            }
            C2Rust_Block_16::S_836 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_838;
            }
            C2Rust_Block_16::S_838 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_840;
            }
            C2Rust_Block_16::S_840 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_842;
            }
            C2Rust_Block_16::S_842 => {
                if _fa == _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_845;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_857;
                }
            }
            C2Rust_Block_16::S_845 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_847;
            }
            C2Rust_Block_16::S_847 => {
                sub_00249C6E();
                c2rust_current_block_16 = C2Rust_Block_16::S_849;
            }
            C2Rust_Block_16::S_849 => return,
            C2Rust_Block_16::S_857 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_16 = C2Rust_Block_16::S_859;
            }
            C2Rust_Block_16::S_859 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_861;
            }
            C2Rust_Block_16::S_861 => {
                sub_00249C6E();
                c2rust_current_block_16 = C2Rust_Block_16::S_863;
            }
            C2Rust_Block_16::S_863 => return,
            C2Rust_Block_16::S_869 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_875;
            }
            C2Rust_Block_16::S_875 => {
                _fp_value_2 = 1.0f64;
                c2rust_current_block_16 = C2Rust_Block_16::S_877;
            }
            C2Rust_Block_16::S_877 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_879;
            }
            C2Rust_Block_16::S_879 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                c2rust_current_block_16 = C2Rust_Block_16::S_885;
            }
            C2Rust_Block_16::S_885 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_16 = C2Rust_Block_16::S_887;
            }
            C2Rust_Block_16::S_887 => {
                sub_00249C6E();
                c2rust_current_block_16 = C2Rust_Block_16::S_889;
            }
            C2Rust_Block_16::S_889 => return,
            C2Rust_Block_16::S_896 => {
                _t = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize];
                c2rust_current_block_16 = C2Rust_Block_16::S_902;
            }
            C2Rust_Block_16::S_902 => {
                _fp_value_3 = _t;
                c2rust_current_block_16 = C2Rust_Block_16::S_904;
            }
            C2Rust_Block_16::S_904 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_906;
            }
            C2Rust_Block_16::S_906 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
                c2rust_current_block_16 = C2Rust_Block_16::S_918;
            }
            C2Rust_Block_16::S_918 => {
                _pv_9 = 0x245067 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_920;
            }
            C2Rust_Block_16::S_920 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_16 = C2Rust_Block_16::S_922;
            }
            C2Rust_Block_16::S_922 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_16 = C2Rust_Block_16::S_928;
            }
            C2Rust_Block_16::S_928 => {
                sub_00245085();
                c2rust_current_block_16 = C2Rust_Block_16::S_934;
            }
            C2Rust_Block_16::S_934 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_16 = C2Rust_Block_16::S_936;
            }
            C2Rust_Block_16::S_936 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_938;
            }
            C2Rust_Block_16::S_938 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_940;
            }
            C2Rust_Block_16::S_940 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_942;
            }
            C2Rust_Block_16::S_942 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_944;
            }
            C2Rust_Block_16::S_944 => {
                if _fa != _fb {
                    c2rust_current_block_16 = C2Rust_Block_16::S_168;
                } else {
                    c2rust_current_block_16 = C2Rust_Block_16::S_953;
                }
            }
            C2Rust_Block_16::S_953 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_955;
            }
            C2Rust_Block_16::S_955 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_961;
            }
            C2Rust_Block_16::S_961 => {
                _fp_value_4 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3c6710 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_16 = C2Rust_Block_16::S_963;
            }
            C2Rust_Block_16::S_963 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_16 = C2Rust_Block_16::S_965;
            }
            C2Rust_Block_16::S_965 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_4;
                c2rust_current_block_16 = C2Rust_Block_16::S_971;
            }
            C2Rust_Block_16::S_971 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_16 = C2Rust_Block_16::S_254;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245085() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value: ::core::ffi::c_double = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = recomp_frndint(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        (*__gamepkg_tls_g_fp_control_word),
    );
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
            != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | 0 as ::core::ffi::c_int as uint8_t as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
    's_53: {
        if _fa & 0x40 as uint32_t == 0 {
            break 's_53;
        }
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
            as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
        {
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3c6124 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
        } else {
            recomp_fp_round24(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3c6124 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
            )
        };
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fb = (_fa == 0x80 as uint32_t) as ::core::ffi::c_int as uint32_t;
        let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
        let mut _fp_value_0: ::core::ffi::c_double = _t_0;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = recomp_frndint(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
            (*__gamepkg_tls_g_fp_control_word),
        );
        (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
                != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize]
        {
            2 as ::core::ffi::c_int
        } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
        {
            -1 as ::core::ffi::c_int
        } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
        {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
        (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
            == 2 as ::core::ffi::c_int
        {
            0x4500 as ::core::ffi::c_uint
        } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
            0x100 as ::core::ffi::c_uint
        } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
            0 as ::core::ffi::c_uint
        } else {
            0x4000 as ::core::ffi::c_uint
        }) as uint16_t;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
        's_124: {
            if _fa & 0x40 as uint32_t == 0 {
                break 's_124;
            }
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as uint8_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fb = (_fa == 0x80 as uint32_t) as ::core::ffi::c_int as uint32_t;
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002450AD() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    enum C2Rust_Block_18 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_74,
        S_83,
        S_91,
        S_93,
        S_95,
        S_97,
        S_99,
        S_108,
        S_114,
        S_124,
        S_126,
        S_128,
        S_138,
        S_140,
        S_142,
        S_152,
        S_154,
        S_156,
        S_162,
        S_168,
        S_170,
        S_172,
        S_174,
        S_180,
        S_182,
        S_192,
        S_194,
        S_200,
        S_202,
        S_215,
        S_217,
        S_219,
        S_229,
        S_231,
        S_233,
        S_239,
        S_245,
        S_247,
        S_249,
        S_255,
        S_261,
        S_263,
        S_265,
        S_267,
        S_273,
        S_275,
        S_285,
        S_287,
        S_293,
        S_295,
        S_308,
        S_310,
        S_312,
        S_322,
        S_324,
        S_334,
        S_336,
        S_342,
        S_344,
        S_350,
        S_352,
        S_354,
        S_356,
        S_364,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_409,
        S_411,
        S_413,
        S_415,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_477,
        S_479,
        S_481,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_497,
        S_499,
        S_501,
        S_503,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_522,
        S_524,
        S_526,
        S_532,
        S_534,
        S_540,
        S_542,
    }
    let mut c2rust_current_block_18: C2Rust_Block_18;
    c2rust_current_block_18 = C2Rust_Block_18::S_0;
    loop {
        match c2rust_current_block_18 {
            C2Rust_Block_18::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_2;
            }
            C2Rust_Block_18::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_18 = C2Rust_Block_18::S_4;
            }
            C2Rust_Block_18::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_18 = C2Rust_Block_18::S_6;
            }
            C2Rust_Block_18::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_8;
            }
            C2Rust_Block_18::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_18;
            }
            C2Rust_Block_18::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_18 = C2Rust_Block_18::S_24;
            }
            C2Rust_Block_18::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b938 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_26;
            }
            C2Rust_Block_18::S_26 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_28;
            }
            C2Rust_Block_18::S_28 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_30;
            }
            C2Rust_Block_18::S_30 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_32;
            }
            C2Rust_Block_18::S_32 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_38;
            }
            C2Rust_Block_18::S_38 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_18 = C2Rust_Block_18::S_40;
            }
            C2Rust_Block_18::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_42;
            }
            C2Rust_Block_18::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_52;
            }
            C2Rust_Block_18::S_52 => {
                _pv_0 = 0x14 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_54;
            }
            C2Rust_Block_18::S_54 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_56;
            }
            C2Rust_Block_18::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_66;
            }
            C2Rust_Block_18::S_66 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_68;
            }
            C2Rust_Block_18::S_68 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_74;
            }
            C2Rust_Block_18::S_74 => {
                if _fa != _fb {
                    c2rust_current_block_18 = C2Rust_Block_18::S_91;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_83;
                }
            }
            C2Rust_Block_18::S_83 => {
                (*__gamepkg_tls_g_eax) = 0x200 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_114;
            }
            C2Rust_Block_18::S_91 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_93;
            }
            C2Rust_Block_18::S_93 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_95;
            }
            C2Rust_Block_18::S_95 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_97;
            }
            C2Rust_Block_18::S_97 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_99;
            }
            C2Rust_Block_18::S_99 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_18 = C2Rust_Block_18::S_124;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_108;
                }
            }
            C2Rust_Block_18::S_108 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_18 = C2Rust_Block_18::S_114;
            }
            C2Rust_Block_18::S_114 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b938 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_124;
            }
            C2Rust_Block_18::S_124 => {
                _pv_1 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_126;
            }
            C2Rust_Block_18::S_126 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_128;
            }
            C2Rust_Block_18::S_128 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_138;
            }
            C2Rust_Block_18::S_138 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_18 = C2Rust_Block_18::S_140;
            }
            C2Rust_Block_18::S_140 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_142;
            }
            C2Rust_Block_18::S_142 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_152;
            }
            C2Rust_Block_18::S_152 => {
                _pv_3 = 0x2450d4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_154;
            }
            C2Rust_Block_18::S_154 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_156;
            }
            C2Rust_Block_18::S_156 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_162;
            }
            C2Rust_Block_18::S_162 => {
                sub_002440FD();
                c2rust_current_block_18 = C2Rust_Block_18::S_168;
            }
            C2Rust_Block_18::S_168 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_170;
            }
            C2Rust_Block_18::S_170 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_172;
            }
            C2Rust_Block_18::S_172 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_174;
            }
            C2Rust_Block_18::S_174 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_180;
            }
            C2Rust_Block_18::S_180 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_182;
            }
            C2Rust_Block_18::S_182 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_192;
            }
            C2Rust_Block_18::S_192 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_194;
            }
            C2Rust_Block_18::S_194 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_200;
            }
            C2Rust_Block_18::S_200 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_202;
            }
            C2Rust_Block_18::S_202 => {
                if _fa != _fb {
                    c2rust_current_block_18 = C2Rust_Block_18::S_350;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_215;
                }
            }
            C2Rust_Block_18::S_215 => {
                _pv_4 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_217;
            }
            C2Rust_Block_18::S_217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_219;
            }
            C2Rust_Block_18::S_219 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_229;
            }
            C2Rust_Block_18::S_229 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_18 = C2Rust_Block_18::S_231;
            }
            C2Rust_Block_18::S_231 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_233;
            }
            C2Rust_Block_18::S_233 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_239;
            }
            C2Rust_Block_18::S_239 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b938 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_245;
            }
            C2Rust_Block_18::S_245 => {
                _pv_6 = 0x2450ed as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_247;
            }
            C2Rust_Block_18::S_247 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_249;
            }
            C2Rust_Block_18::S_249 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_255;
            }
            C2Rust_Block_18::S_255 => {
                sub_002440FD();
                c2rust_current_block_18 = C2Rust_Block_18::S_261;
            }
            C2Rust_Block_18::S_261 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_263;
            }
            C2Rust_Block_18::S_263 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_265;
            }
            C2Rust_Block_18::S_265 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_267;
            }
            C2Rust_Block_18::S_267 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_273;
            }
            C2Rust_Block_18::S_273 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_275;
            }
            C2Rust_Block_18::S_275 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_285;
            }
            C2Rust_Block_18::S_285 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_287;
            }
            C2Rust_Block_18::S_287 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_293;
            }
            C2Rust_Block_18::S_293 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_295;
            }
            C2Rust_Block_18::S_295 => {
                if _fa != _fb {
                    c2rust_current_block_18 = C2Rust_Block_18::S_350;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_308;
                }
            }
            C2Rust_Block_18::S_308 => {
                _pv_7 = 0x1a as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_310;
            }
            C2Rust_Block_18::S_310 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_312;
            }
            C2Rust_Block_18::S_312 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_322;
            }
            C2Rust_Block_18::S_322 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_324;
            }
            C2Rust_Block_18::S_324 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_334;
            }
            C2Rust_Block_18::S_334 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_336;
            }
            C2Rust_Block_18::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_342;
            }
            C2Rust_Block_18::S_342 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_344;
            }
            C2Rust_Block_18::S_344 => return,
            C2Rust_Block_18::S_350 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_352;
            }
            C2Rust_Block_18::S_352 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_354;
            }
            C2Rust_Block_18::S_354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_356;
            }
            C2Rust_Block_18::S_356 => {
                (*__gamepkg_tls_g_ecx) = 0x3c6130 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_370;
            }
            C2Rust_Block_18::S_364 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_370;
            }
            C2Rust_Block_18::S_370 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_eax))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_372;
            }
            C2Rust_Block_18::S_372 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_374;
            }
            C2Rust_Block_18::S_374 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_376;
            }
            C2Rust_Block_18::S_376 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_378;
            }
            C2Rust_Block_18::S_378 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_380;
            }
            C2Rust_Block_18::S_380 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_382;
            }
            C2Rust_Block_18::S_382 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_384;
            }
            C2Rust_Block_18::S_384 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_386;
            }
            C2Rust_Block_18::S_386 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_388;
            }
            C2Rust_Block_18::S_388 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_390;
            }
            C2Rust_Block_18::S_390 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_392;
            }
            C2Rust_Block_18::S_392 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_394;
            }
            C2Rust_Block_18::S_394 => {
                _fb = 0x3c63b0 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_396;
            }
            C2Rust_Block_18::S_396 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_398;
            }
            C2Rust_Block_18::S_398 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_400;
            }
            C2Rust_Block_18::S_400 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_18 = C2Rust_Block_18::S_364;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_409;
                }
            }
            C2Rust_Block_18::S_409 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_411;
            }
            C2Rust_Block_18::S_411 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_413;
            }
            C2Rust_Block_18::S_413 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_415;
            }
            C2Rust_Block_18::S_415 => {
                (*__gamepkg_tls_g_edx) = 0x3c6140 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_421;
            }
            C2Rust_Block_18::S_421 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_18 = C2Rust_Block_18::S_423;
            }
            C2Rust_Block_18::S_423 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_18 = C2Rust_Block_18::S_425;
            }
            C2Rust_Block_18::S_425 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x1f as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_427;
            }
            C2Rust_Block_18::S_427 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_429;
            }
            C2Rust_Block_18::S_429 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_431;
            }
            C2Rust_Block_18::S_431 => {
                (*__gamepkg_tls_g_esi) = ((*__gamepkg_tls_g_esi) as int32_t
                    >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_433;
            }
            C2Rust_Block_18::S_433 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_435;
            }
            C2Rust_Block_18::S_435 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_437;
            }
            C2Rust_Block_18::S_437 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_mul(4 as uint32_t)
                            .wrapping_add(0x76b820 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_439;
            }
            C2Rust_Block_18::S_439 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
                c2rust_current_block_18 = C2Rust_Block_18::S_441;
            }
            C2Rust_Block_18::S_441 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_443;
            }
            C2Rust_Block_18::S_443 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_445;
            }
            C2Rust_Block_18::S_445 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_447;
            }
            C2Rust_Block_18::S_447 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_449;
            }
            C2Rust_Block_18::S_449 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_451;
            }
            C2Rust_Block_18::S_451 => {
                if _fa == _fb {
                    c2rust_current_block_18 = C2Rust_Block_18::S_477;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_460;
                }
            }
            C2Rust_Block_18::S_460 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_462;
            }
            C2Rust_Block_18::S_462 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_464;
            }
            C2Rust_Block_18::S_464 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_466;
            }
            C2Rust_Block_18::S_466 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_468;
            }
            C2Rust_Block_18::S_468 => {
                if _fa != _fb {
                    c2rust_current_block_18 = C2Rust_Block_18::S_487;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_477;
                }
            }
            C2Rust_Block_18::S_477 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0xffffffff as uint32_t,
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_479;
            }
            C2Rust_Block_18::S_479 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_481;
            }
            C2Rust_Block_18::S_481 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_487;
            }
            C2Rust_Block_18::S_487 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_489;
            }
            C2Rust_Block_18::S_489 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_491;
            }
            C2Rust_Block_18::S_491 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_493;
            }
            C2Rust_Block_18::S_493 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_495;
            }
            C2Rust_Block_18::S_495 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_497;
            }
            C2Rust_Block_18::S_497 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_18 = C2Rust_Block_18::S_499;
            }
            C2Rust_Block_18::S_499 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_501;
            }
            C2Rust_Block_18::S_501 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_503;
            }
            C2Rust_Block_18::S_503 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_505;
            }
            C2Rust_Block_18::S_505 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_507;
            }
            C2Rust_Block_18::S_507 => {
                _fb = 0x3c61a0 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_509;
            }
            C2Rust_Block_18::S_509 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_511;
            }
            C2Rust_Block_18::S_511 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_513;
            }
            C2Rust_Block_18::S_513 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_18 = C2Rust_Block_18::S_421;
                } else {
                    c2rust_current_block_18 = C2Rust_Block_18::S_522;
                }
            }
            C2Rust_Block_18::S_522 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_524;
            }
            C2Rust_Block_18::S_524 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_526;
            }
            C2Rust_Block_18::S_526 => {
                _fas = _fa as int32_t;
                c2rust_current_block_18 = C2Rust_Block_18::S_532;
            }
            C2Rust_Block_18::S_532 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_18 = C2Rust_Block_18::S_534;
            }
            C2Rust_Block_18::S_534 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_540;
            }
            C2Rust_Block_18::S_540 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_18 = C2Rust_Block_18::S_542;
            }
            C2Rust_Block_18::S_542 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245156() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0x24515b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00245561();
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (0x41d2d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_71: {
        if _fa == _fb {
            break 's_71;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_0024A02A();
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024516A() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 0x3c6130 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_136: {
        if _fa < _fb {
            break 's_136;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0x3c6390 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa > _fb {
            break 's_136;
        }
        _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
            >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0x24518c as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_002486AE();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = 0x245198 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_256: {
        's_207: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_207;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_256;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_215: {
            if !_fn.is_none() {
                break 's_215;
            }
            _fn = recomp_lookup(_va);
        }
        's_221: {
            if !_fn.is_none() {
                break 's_221;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_227: {
            if _fn.is_some() {
                break 's_227;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_256;
        }
        _fn.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245199() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_37: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_37;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x36b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = 0x2451bb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_223: {
            's_174: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_174;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_223;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_182: {
                if !_fn.is_none() {
                    break 's_182;
                }
                _fn = recomp_lookup(_va);
            }
            's_188: {
                if !_fn.is_none() {
                    break 's_188;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_194: {
                if _fn.is_some() {
                    break 's_194;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_223;
            }
            _fn.expect("non-null function pointer")();
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2451ab as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002486AE();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002451BC() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 0x3c6130 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_136: {
        if _fa < _fb {
            break 's_136;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0x3c6390 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa > _fb {
            break 's_136;
        }
        _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
            >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0x2451de as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_002485FC();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = 0x2451ea as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_256: {
        's_207: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_207;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_256;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_215: {
            if !_fn.is_none() {
                break 's_215;
            }
            _fn = recomp_lookup(_va);
        }
        's_221: {
            if !_fn.is_none() {
                break 's_221;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_227: {
            if _fn.is_some() {
                break 's_227;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_256;
        }
        _fn.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002451EB() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_37: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_37;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x36b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = 0x24520d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_223: {
            's_174: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_174;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_223;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_182: {
                if !_fn.is_none() {
                    break 's_182;
                }
                _fn = recomp_lookup(_va);
            }
            's_188: {
                if !_fn.is_none() {
                    break 's_188;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_194: {
                if _fn.is_some() {
                    break 's_194;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_223;
            }
            _fn.expect("non-null function pointer")();
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2451fd as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002485FC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024520E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    enum C2Rust_Block_31 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_84,
        S_86,
        S_88,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_123,
        S_133,
        S_135,
        S_137,
        S_147,
        S_149,
        S_151,
        S_161,
        S_163,
        S_165,
        S_171,
        S_173,
        S_179,
        S_181,
        S_183,
        S_189,
        S_195,
        S_197,
        S_199,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_243,
        S_245,
        S_247,
        S_249,
        S_251,
        S_259,
        S_261,
        S_263,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_285,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_341,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_367,
        S_369,
        S_371,
        S_373,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_395,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_421,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_446,
        S_448,
        S_454,
        S_456,
        S_458,
        S_464,
        S_470,
        S_476,
        S_478,
        S_480,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_524,
        S_526,
        S_528,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_550,
        S_552,
        S_554,
        S_556,
        S_558,
        S_560,
        S_562,
        S_564,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_607,
        S_609,
        S_611,
        S_621,
        S_623,
        S_625,
        S_635,
        S_637,
        S_639,
        S_645,
        S_647,
        S_653,
        S_655,
        S_657,
        S_663,
        S_669,
        S_671,
        S_673,
        S_675,
        S_677,
        S_679,
        S_681,
        S_683,
        S_685,
        S_687,
        S_696,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_733,
        S_735,
        S_737,
        S_739,
        S_745,
        S_747,
        S_749,
        S_751,
        S_757,
        S_759,
        S_761,
        S_763,
        S_765,
        S_774,
        S_776,
        S_778,
        S_780,
        S_792,
        S_794,
        S_796,
        S_806,
        S_808,
        S_810,
        S_820,
        S_822,
        S_824,
        S_830,
        S_832,
        S_838,
        S_840,
        S_842,
        S_848,
        S_854,
        S_856,
        S_858,
        S_860,
        S_862,
        S_864,
        S_866,
        S_868,
        S_870,
        S_872,
        S_874,
        S_883,
        S_885,
        S_887,
        S_889,
        S_891,
        S_893,
        S_902,
        S_904,
        S_906,
        S_908,
        S_910,
        S_919,
        S_925,
        S_927,
        S_929,
        S_931,
        S_933,
        S_935,
        S_941,
        S_950,
        S_952,
        S_954,
        S_956,
        S_962,
        S_964,
        S_966,
        S_968,
        S_970,
        S_972,
        S_978,
        S_980,
        S_982,
        S_984,
        S_986,
        S_988,
        S_990,
        S_1000,
        S_1002,
        S_1012,
        S_1014,
        S_1024,
        S_1026,
        S_1032,
        S_1038,
        S_1040,
        S_1046,
        S_1048,
    }
    let mut c2rust_current_block_31: C2Rust_Block_31;
    c2rust_current_block_31 = C2Rust_Block_31::S_0;
    loop {
        match c2rust_current_block_31 {
            C2Rust_Block_31::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_2;
            }
            C2Rust_Block_31::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_31 = C2Rust_Block_31::S_4;
            }
            C2Rust_Block_31::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_6;
            }
            C2Rust_Block_31::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_8;
            }
            C2Rust_Block_31::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_26;
            }
            C2Rust_Block_31::S_26 => {
                _pv = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_28;
            }
            C2Rust_Block_31::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_30;
            }
            C2Rust_Block_31::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_36;
            }
            C2Rust_Block_31::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_31 = C2Rust_Block_31::S_38;
            }
            C2Rust_Block_31::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_40;
            }
            C2Rust_Block_31::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_42;
            }
            C2Rust_Block_31::S_42 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_44;
            }
            C2Rust_Block_31::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_46;
            }
            C2Rust_Block_31::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_48;
            }
            C2Rust_Block_31::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_50;
            }
            C2Rust_Block_31::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_56;
            }
            C2Rust_Block_31::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_31 = C2Rust_Block_31::S_58;
            }
            C2Rust_Block_31::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_60;
            }
            C2Rust_Block_31::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_70;
            }
            C2Rust_Block_31::S_70 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_72;
            }
            C2Rust_Block_31::S_72 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_74;
            }
            C2Rust_Block_31::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_84;
            }
            C2Rust_Block_31::S_84 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_31 = C2Rust_Block_31::S_86;
            }
            C2Rust_Block_31::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_88;
            }
            C2Rust_Block_31::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_94;
            }
            C2Rust_Block_31::S_94 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_96;
            }
            C2Rust_Block_31::S_96 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_98;
            }
            C2Rust_Block_31::S_98 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_100;
            }
            C2Rust_Block_31::S_100 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_102;
            }
            C2Rust_Block_31::S_102 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_104;
            }
            C2Rust_Block_31::S_104 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_106;
            }
            C2Rust_Block_31::S_106 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_108;
            }
            C2Rust_Block_31::S_108 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_110;
            }
            C2Rust_Block_31::S_110 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_112;
            }
            C2Rust_Block_31::S_112 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_114;
            }
            C2Rust_Block_31::S_114 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_31 = C2Rust_Block_31::S_133;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_123;
                }
            }
            C2Rust_Block_31::S_123 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_133;
            }
            C2Rust_Block_31::S_133 => {
                _pv_3 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_135;
            }
            C2Rust_Block_31::S_135 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_137;
            }
            C2Rust_Block_31::S_137 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_147;
            }
            C2Rust_Block_31::S_147 => {
                _pv_4 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_31 = C2Rust_Block_31::S_149;
            }
            C2Rust_Block_31::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_151;
            }
            C2Rust_Block_31::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_161;
            }
            C2Rust_Block_31::S_161 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_163;
            }
            C2Rust_Block_31::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_165;
            }
            C2Rust_Block_31::S_165 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_171;
            }
            C2Rust_Block_31::S_171 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_173;
            }
            C2Rust_Block_31::S_173 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_179;
            }
            C2Rust_Block_31::S_179 => {
                _pv_6 = 0x245233 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_181;
            }
            C2Rust_Block_31::S_181 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_183;
            }
            C2Rust_Block_31::S_183 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_189;
            }
            C2Rust_Block_31::S_189 => {
                sub_0024A1A5();
                c2rust_current_block_31 = C2Rust_Block_31::S_195;
            }
            C2Rust_Block_31::S_195 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_197;
            }
            C2Rust_Block_31::S_197 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_199;
            }
            C2Rust_Block_31::S_199 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_201;
            }
            C2Rust_Block_31::S_201 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_203;
            }
            C2Rust_Block_31::S_203 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_205;
            }
            C2Rust_Block_31::S_205 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_207;
            }
            C2Rust_Block_31::S_207 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_209;
            }
            C2Rust_Block_31::S_209 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_211;
            }
            C2Rust_Block_31::S_211 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_213;
            }
            C2Rust_Block_31::S_213 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_215;
            }
            C2Rust_Block_31::S_215 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_31 = C2Rust_Block_31::S_476;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_224;
                }
            }
            C2Rust_Block_31::S_224 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_226;
            }
            C2Rust_Block_31::S_226 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t
                    as ::core::ffi::c_int & 0x108 as ::core::ffi::c_int) as uint32_t
                    & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_228;
            }
            C2Rust_Block_31::S_228 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_230;
            }
            C2Rust_Block_31::S_230 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_232;
            }
            C2Rust_Block_31::S_232 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_234;
            }
            C2Rust_Block_31::S_234 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_259;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_243;
                }
            }
            C2Rust_Block_31::S_243 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_245;
            }
            C2Rust_Block_31::S_245 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_247;
            }
            C2Rust_Block_31::S_247 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_31 = C2Rust_Block_31::S_249;
            }
            C2Rust_Block_31::S_249 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_251;
            }
            C2Rust_Block_31::S_251 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1000;
            }
            C2Rust_Block_31::S_259 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_261;
            }
            C2Rust_Block_31::S_261 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_263;
            }
            C2Rust_Block_31::S_263 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_265;
            }
            C2Rust_Block_31::S_265 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_267;
            }
            C2Rust_Block_31::S_267 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_269;
            }
            C2Rust_Block_31::S_269 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_31 = C2Rust_Block_31::S_271;
            }
            C2Rust_Block_31::S_271 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_273;
            }
            C2Rust_Block_31::S_273 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_275;
            }
            C2Rust_Block_31::S_275 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 3 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_277;
            }
            C2Rust_Block_31::S_277 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_279;
            }
            C2Rust_Block_31::S_279 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_281;
            }
            C2Rust_Block_31::S_281 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_283;
            }
            C2Rust_Block_31::S_283 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_285;
            }
            C2Rust_Block_31::S_285 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_429;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_294;
                }
            }
            C2Rust_Block_31::S_294 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_296;
            }
            C2Rust_Block_31::S_296 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_298;
            }
            C2Rust_Block_31::S_298 => {
                (*__gamepkg_tls_g_ebx) = ((*__gamepkg_tls_g_ebx) as int32_t
                    >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_300;
            }
            C2Rust_Block_31::S_300 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_302;
            }
            C2Rust_Block_31::S_302 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_304;
            }
            C2Rust_Block_31::S_304 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx)
                            .wrapping_mul(4 as uint32_t)
                            .wrapping_add(0x76b820 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_306;
            }
            C2Rust_Block_31::S_306 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0x1f as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_308;
            }
            C2Rust_Block_31::S_308 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_310;
            }
            C2Rust_Block_31::S_310 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_312;
            }
            C2Rust_Block_31::S_312 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_31 = C2Rust_Block_31::S_314;
            }
            C2Rust_Block_31::S_314 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ebx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_ecx).wrapping_mul(8 as uint32_t),
                            )
                            .wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x80 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_316;
            }
            C2Rust_Block_31::S_316 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_318;
            }
            C2Rust_Block_31::S_318 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_320;
            }
            C2Rust_Block_31::S_320 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_322;
            }
            C2Rust_Block_31::S_322 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_404;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_331;
                }
            }
            C2Rust_Block_31::S_331 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_31 = C2Rust_Block_31::S_333;
            }
            C2Rust_Block_31::S_333 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_335;
            }
            C2Rust_Block_31::S_335 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_337;
            }
            C2Rust_Block_31::S_337 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_339;
            }
            C2Rust_Block_31::S_339 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_341;
            }
            C2Rust_Block_31::S_341 => {
                if _fa >= _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_404;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_350;
                }
            }
            C2Rust_Block_31::S_350 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_352;
            }
            C2Rust_Block_31::S_352 => {
                _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_354;
            }
            C2Rust_Block_31::S_354 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_356;
            }
            C2Rust_Block_31::S_356 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_358;
            }
            C2Rust_Block_31::S_358 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_379;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_367;
                }
            }
            C2Rust_Block_31::S_367 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_369;
            }
            C2Rust_Block_31::S_369 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_371;
            }
            C2Rust_Block_31::S_371 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_373;
            }
            C2Rust_Block_31::S_373 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_379;
            }
            C2Rust_Block_31::S_379 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_381;
            }
            C2Rust_Block_31::S_381 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_383;
            }
            C2Rust_Block_31::S_383 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_385;
            }
            C2Rust_Block_31::S_385 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_387;
            }
            C2Rust_Block_31::S_387 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_389;
            }
            C2Rust_Block_31::S_389 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_391;
            }
            C2Rust_Block_31::S_391 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_393;
            }
            C2Rust_Block_31::S_393 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_395;
            }
            C2Rust_Block_31::S_395 => {
                if _fa < _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_350;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_404;
                }
            }
            C2Rust_Block_31::S_404 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_406;
            }
            C2Rust_Block_31::S_406 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_408;
            }
            C2Rust_Block_31::S_408 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_410;
            }
            C2Rust_Block_31::S_410 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_412;
            }
            C2Rust_Block_31::S_412 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_488;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_421;
                }
            }
            C2Rust_Block_31::S_421 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1000;
            }
            C2Rust_Block_31::S_429 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_431;
            }
            C2Rust_Block_31::S_431 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_433;
            }
            C2Rust_Block_31::S_433 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_435;
            }
            C2Rust_Block_31::S_435 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_437;
            }
            C2Rust_Block_31::S_437 => {
                if (_fas as uint8_t as ::core::ffi::c_int
                    - _fbs as uint8_t as ::core::ffi::c_int) as uint8_t
                    as ::core::ffi::c_int >> 7 as ::core::ffi::c_int
                    != 0 as ::core::ffi::c_int
                {
                    c2rust_current_block_31 = C2Rust_Block_31::S_404;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_446;
                }
            }
            C2Rust_Block_31::S_446 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_448;
            }
            C2Rust_Block_31::S_448 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_454;
            }
            C2Rust_Block_31::S_454 => {
                _pv_7 = 0x2452a5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_456;
            }
            C2Rust_Block_31::S_456 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_458;
            }
            C2Rust_Block_31::S_458 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_464;
            }
            C2Rust_Block_31::S_464 => {
                sub_0024A0AE();
                c2rust_current_block_31 = C2Rust_Block_31::S_470;
            }
            C2Rust_Block_31::S_470 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x16 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_476;
            }
            C2Rust_Block_31::S_476 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_478;
            }
            C2Rust_Block_31::S_478 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_480;
            }
            C2Rust_Block_31::S_480 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1000;
            }
            C2Rust_Block_31::S_488 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_490;
            }
            C2Rust_Block_31::S_490 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_492;
            }
            C2Rust_Block_31::S_492 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_494;
            }
            C2Rust_Block_31::S_494 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_496;
            }
            C2Rust_Block_31::S_496 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_978;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_505;
                }
            }
            C2Rust_Block_31::S_505 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_507;
            }
            C2Rust_Block_31::S_507 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_509;
            }
            C2Rust_Block_31::S_509 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_511;
            }
            C2Rust_Block_31::S_511 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_513;
            }
            C2Rust_Block_31::S_513 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_515;
            }
            C2Rust_Block_31::S_515 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_536;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_524;
                }
            }
            C2Rust_Block_31::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_526;
            }
            C2Rust_Block_31::S_526 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_528;
            }
            C2Rust_Block_31::S_528 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_978;
            }
            C2Rust_Block_31::S_536 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_538;
            }
            C2Rust_Block_31::S_538 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_540;
            }
            C2Rust_Block_31::S_540 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_31 = C2Rust_Block_31::S_542;
            }
            C2Rust_Block_31::S_542 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_544;
            }
            C2Rust_Block_31::S_544 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_546;
            }
            C2Rust_Block_31::S_546 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_548;
            }
            C2Rust_Block_31::S_548 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_550;
            }
            C2Rust_Block_31::S_550 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_31 = C2Rust_Block_31::S_552;
            }
            C2Rust_Block_31::S_552 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_554;
            }
            C2Rust_Block_31::S_554 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_556;
            }
            C2Rust_Block_31::S_556 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_558;
            }
            C2Rust_Block_31::S_558 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_560;
            }
            C2Rust_Block_31::S_560 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_562;
            }
            C2Rust_Block_31::S_562 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_564;
            }
            C2Rust_Block_31::S_564 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_566;
            }
            C2Rust_Block_31::S_566 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x76b820 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_568;
            }
            C2Rust_Block_31::S_568 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_570;
            }
            C2Rust_Block_31::S_570 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x1f as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_572;
            }
            C2Rust_Block_31::S_572 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_574;
            }
            C2Rust_Block_31::S_574 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_576;
            }
            C2Rust_Block_31::S_576 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
                c2rust_current_block_31 = C2Rust_Block_31::S_578;
            }
            C2Rust_Block_31::S_578 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_580;
            }
            C2Rust_Block_31::S_580 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_582;
            }
            C2Rust_Block_31::S_582 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_584;
            }
            C2Rust_Block_31::S_584 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_586;
            }
            C2Rust_Block_31::S_586 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add((*__gamepkg_tls_g_eax))
                            .wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x80 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_588;
            }
            C2Rust_Block_31::S_588 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_590;
            }
            C2Rust_Block_31::S_590 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_592;
            }
            C2Rust_Block_31::S_592 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_594;
            }
            C2Rust_Block_31::S_594 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_962;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_607;
                }
            }
            C2Rust_Block_31::S_607 => {
                _pv_8 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_609;
            }
            C2Rust_Block_31::S_609 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_611;
            }
            C2Rust_Block_31::S_611 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_621;
            }
            C2Rust_Block_31::S_621 => {
                _pv_9 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_623;
            }
            C2Rust_Block_31::S_623 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_625;
            }
            C2Rust_Block_31::S_625 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_635;
            }
            C2Rust_Block_31::S_635 => {
                _pv_10 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_637;
            }
            C2Rust_Block_31::S_637 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_639;
            }
            C2Rust_Block_31::S_639 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_645;
            }
            C2Rust_Block_31::S_645 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_647;
            }
            C2Rust_Block_31::S_647 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_653;
            }
            C2Rust_Block_31::S_653 => {
                _pv_11 = 0x2452ff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_655;
            }
            C2Rust_Block_31::S_655 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_657;
            }
            C2Rust_Block_31::S_657 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_663;
            }
            C2Rust_Block_31::S_663 => {
                sub_0024A1A5();
                c2rust_current_block_31 = C2Rust_Block_31::S_669;
            }
            C2Rust_Block_31::S_669 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_671;
            }
            C2Rust_Block_31::S_671 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_673;
            }
            C2Rust_Block_31::S_673 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_675;
            }
            C2Rust_Block_31::S_675 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_677;
            }
            C2Rust_Block_31::S_677 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_679;
            }
            C2Rust_Block_31::S_679 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_681;
            }
            C2Rust_Block_31::S_681 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_683;
            }
            C2Rust_Block_31::S_683 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_685;
            }
            C2Rust_Block_31::S_685 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_687;
            }
            C2Rust_Block_31::S_687 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_792;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_696;
                }
            }
            C2Rust_Block_31::S_696 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_698;
            }
            C2Rust_Block_31::S_698 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_700;
            }
            C2Rust_Block_31::S_700 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_702;
            }
            C2Rust_Block_31::S_702 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_704;
            }
            C2Rust_Block_31::S_704 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_31 = C2Rust_Block_31::S_706;
            }
            C2Rust_Block_31::S_706 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_708;
            }
            C2Rust_Block_31::S_708 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_757;
            }
            C2Rust_Block_31::S_716 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_718;
            }
            C2Rust_Block_31::S_718 => {
                _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_720;
            }
            C2Rust_Block_31::S_720 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_722;
            }
            C2Rust_Block_31::S_722 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_724;
            }
            C2Rust_Block_31::S_724 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_745;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_733;
                }
            }
            C2Rust_Block_31::S_733 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_735;
            }
            C2Rust_Block_31::S_735 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_737;
            }
            C2Rust_Block_31::S_737 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_739;
            }
            C2Rust_Block_31::S_739 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_745;
            }
            C2Rust_Block_31::S_745 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_747;
            }
            C2Rust_Block_31::S_747 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_749;
            }
            C2Rust_Block_31::S_749 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_751;
            }
            C2Rust_Block_31::S_751 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_757;
            }
            C2Rust_Block_31::S_757 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_759;
            }
            C2Rust_Block_31::S_759 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_761;
            }
            C2Rust_Block_31::S_761 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_763;
            }
            C2Rust_Block_31::S_763 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_765;
            }
            C2Rust_Block_31::S_765 => {
                if _fa < _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_716;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_774;
                }
            }
            C2Rust_Block_31::S_774 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xd as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_776;
            }
            C2Rust_Block_31::S_776 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_778;
            }
            C2Rust_Block_31::S_778 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_780;
            }
            C2Rust_Block_31::S_780 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_941;
            }
            C2Rust_Block_31::S_792 => {
                _pv_12 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_794;
            }
            C2Rust_Block_31::S_794 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_796;
            }
            C2Rust_Block_31::S_796 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_806;
            }
            C2Rust_Block_31::S_806 => {
                _pv_13 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_808;
            }
            C2Rust_Block_31::S_808 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_810;
            }
            C2Rust_Block_31::S_810 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_820;
            }
            C2Rust_Block_31::S_820 => {
                _pv_14 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_822;
            }
            C2Rust_Block_31::S_822 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_824;
            }
            C2Rust_Block_31::S_824 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_830;
            }
            C2Rust_Block_31::S_830 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_832;
            }
            C2Rust_Block_31::S_832 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_838;
            }
            C2Rust_Block_31::S_838 => {
                _pv_15 = 0x245331 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_840;
            }
            C2Rust_Block_31::S_840 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_842;
            }
            C2Rust_Block_31::S_842 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_848;
            }
            C2Rust_Block_31::S_848 => {
                sub_0024A1A5();
                c2rust_current_block_31 = C2Rust_Block_31::S_854;
            }
            C2Rust_Block_31::S_854 => {
                (*__gamepkg_tls_g_eax) = 0x200 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_856;
            }
            C2Rust_Block_31::S_856 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_858;
            }
            C2Rust_Block_31::S_858 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_860;
            }
            C2Rust_Block_31::S_860 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_862;
            }
            C2Rust_Block_31::S_862 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_864;
            }
            C2Rust_Block_31::S_864 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_866;
            }
            C2Rust_Block_31::S_866 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_868;
            }
            C2Rust_Block_31::S_868 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_870;
            }
            C2Rust_Block_31::S_870 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_872;
            }
            C2Rust_Block_31::S_872 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_874;
            }
            C2Rust_Block_31::S_874 => {
                if _fa > _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_919;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_883;
                }
            }
            C2Rust_Block_31::S_883 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_885;
            }
            C2Rust_Block_31::S_885 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_887;
            }
            C2Rust_Block_31::S_887 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_889;
            }
            C2Rust_Block_31::S_889 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_891;
            }
            C2Rust_Block_31::S_891 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_893;
            }
            C2Rust_Block_31::S_893 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_919;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_902;
                }
            }
            C2Rust_Block_31::S_902 => {
                _fa = (((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 4 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_904;
            }
            C2Rust_Block_31::S_904 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_906;
            }
            C2Rust_Block_31::S_906 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_908;
            }
            C2Rust_Block_31::S_908 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_910;
            }
            C2Rust_Block_31::S_910 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_925;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_919;
                }
            }
            C2Rust_Block_31::S_919 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_925;
            }
            C2Rust_Block_31::S_925 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_927;
            }
            C2Rust_Block_31::S_927 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_929;
            }
            C2Rust_Block_31::S_929 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add((*__gamepkg_tls_g_eax))
                            .wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_931;
            }
            C2Rust_Block_31::S_931 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_933;
            }
            C2Rust_Block_31::S_933 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_935;
            }
            C2Rust_Block_31::S_935 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_941;
            }
            C2Rust_Block_31::S_941 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_962;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_950;
                }
            }
            C2Rust_Block_31::S_950 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_952;
            }
            C2Rust_Block_31::S_952 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_954;
            }
            C2Rust_Block_31::S_954 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_956;
            }
            C2Rust_Block_31::S_956 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_962;
            }
            C2Rust_Block_31::S_962 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_964;
            }
            C2Rust_Block_31::S_964 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_966;
            }
            C2Rust_Block_31::S_966 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_968;
            }
            C2Rust_Block_31::S_968 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_970;
            }
            C2Rust_Block_31::S_970 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_972;
            }
            C2Rust_Block_31::S_972 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_978;
            }
            C2Rust_Block_31::S_978 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_980;
            }
            C2Rust_Block_31::S_980 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_982;
            }
            C2Rust_Block_31::S_982 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_984;
            }
            C2Rust_Block_31::S_984 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_986;
            }
            C2Rust_Block_31::S_986 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_31 = C2Rust_Block_31::S_988;
            }
            C2Rust_Block_31::S_988 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_990;
            }
            C2Rust_Block_31::S_990 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1000;
            }
            C2Rust_Block_31::S_1000 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1002;
            }
            C2Rust_Block_31::S_1002 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1012;
            }
            C2Rust_Block_31::S_1012 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1014;
            }
            C2Rust_Block_31::S_1014 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1024;
            }
            C2Rust_Block_31::S_1024 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1026;
            }
            C2Rust_Block_31::S_1026 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1032;
            }
            C2Rust_Block_31::S_1032 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_31 = C2Rust_Block_31::S_1038;
            }
            C2Rust_Block_31::S_1038 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1040;
            }
            C2Rust_Block_31::S_1040 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1046;
            }
            C2Rust_Block_31::S_1046 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1048;
            }
            C2Rust_Block_31::S_1048 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245370() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x374040 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24537c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x245384 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024516A();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_5: uint32_t = 0x245391 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_0024520E();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_6: uint32_t = 0x24539e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_002453A7();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_7: uint32_t = 0x2453a6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002453A7() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2453af as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002453B1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            & 3 as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_297: {
        if _fa != _fb {
            break 's_297;
        }
        _fa = (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
            as ::core::ffi::c_int & 0x108 as ::core::ffi::c_int) as uint32_t
            & 0xffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        _fbs = _fb as int16_t as int32_t;
        if _fa == _fb {
            break 's_297;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_sub((*__gamepkg_tls_g_eax));
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_285: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                <= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_285;
            }
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x2453e2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_0024A3DB();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_265: {
                if _fa != _fb {
                    break 's_265;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if (_fa as uint8_t as ::core::ffi::c_int
                    - _fb as uint8_t as ::core::ffi::c_int) as uint8_t
                    as ::core::ffi::c_int >> 7 as ::core::ffi::c_int
                    == 0 as ::core::ffi::c_int
                {
                    break 's_285;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffd as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                break 's_285;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0x20 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) | 0xffffffff as uint32_t;
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024540E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x245419 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_002453B1();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_101: {
        if _fa != _fb {
            break 's_101;
        }
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0x40 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        _cf = 0 as ::core::ffi::c_int;
        's_228: {
            if _fa == _fb {
                break 's_228;
            }
            let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x245431 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            sub_0024A486();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
            (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                0xffffffff as ::core::ffi::c_uint
            } else {
                0 as ::core::ffi::c_uint
            }) as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        _cf = 0 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024543C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    enum C2Rust_Block_21 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_72,
        S_74,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_94,
        S_96,
        S_98,
        S_104,
        S_106,
        S_112,
        S_114,
        S_116,
        S_122,
        S_132,
        S_134,
        S_140,
        S_142,
        S_144,
        S_146,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_165,
        S_167,
        S_169,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_219,
        S_221,
        S_223,
        S_233,
        S_235,
        S_237,
        S_243,
        S_245,
        S_251,
        S_253,
        S_255,
        S_261,
        S_271,
        S_273,
        S_283,
        S_285,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_351,
        S_353,
        S_355,
        S_361,
        S_363,
        S_369,
        S_371,
        S_373,
        S_379,
        S_389,
        S_391,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_414,
        S_416,
        S_418,
        S_420,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_466,
        S_468,
        S_470,
        S_476,
        S_478,
        S_484,
        S_486,
        S_488,
        S_494,
        S_504,
        S_506,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_529,
        S_531,
        S_533,
        S_539,
        S_541,
        S_543,
        S_549,
        S_551,
        S_553,
        S_559,
        S_565,
        S_567,
        S_569,
        S_571,
    }
    let mut c2rust_current_block_21: C2Rust_Block_21;
    c2rust_current_block_21 = C2Rust_Block_21::S_0;
    loop {
        match c2rust_current_block_21 {
            C2Rust_Block_21::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_2;
            }
            C2Rust_Block_21::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_21 = C2Rust_Block_21::S_4;
            }
            C2Rust_Block_21::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_21 = C2Rust_Block_21::S_6;
            }
            C2Rust_Block_21::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_8;
            }
            C2Rust_Block_21::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_18;
            }
            C2Rust_Block_21::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_21 = C2Rust_Block_21::S_28;
            }
            C2Rust_Block_21::S_28 => {
                _pv = 0x14 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_30;
            }
            C2Rust_Block_21::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_32;
            }
            C2Rust_Block_21::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_42;
            }
            C2Rust_Block_21::S_42 => {
                _pv_0 = 0x374050 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_44;
            }
            C2Rust_Block_21::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_46;
            }
            C2Rust_Block_21::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_52;
            }
            C2Rust_Block_21::S_52 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_54;
            }
            C2Rust_Block_21::S_54 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_56;
            }
            C2Rust_Block_21::S_56 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_62;
            }
            C2Rust_Block_21::S_62 => {
                _pv_1 = 0x245448 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_64;
            }
            C2Rust_Block_21::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_66;
            }
            C2Rust_Block_21::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_72;
            }
            C2Rust_Block_21::S_72 => {
                sub_00244784();
                c2rust_current_block_21 = C2Rust_Block_21::S_74;
            }
            C2Rust_Block_21::S_74 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_21 = C2Rust_Block_21::S_80;
            }
            C2Rust_Block_21::S_80 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_82;
            }
            C2Rust_Block_21::S_82 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_84;
            }
            C2Rust_Block_21::S_84 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_86;
            }
            C2Rust_Block_21::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_88;
            }
            C2Rust_Block_21::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_94;
            }
            C2Rust_Block_21::S_94 => {
                _pv_2 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_96;
            }
            C2Rust_Block_21::S_96 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_98;
            }
            C2Rust_Block_21::S_98 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_104;
            }
            C2Rust_Block_21::S_104 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_106;
            }
            C2Rust_Block_21::S_106 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_112;
            }
            C2Rust_Block_21::S_112 => {
                _pv_3 = 0x245457 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_114;
            }
            C2Rust_Block_21::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_116;
            }
            C2Rust_Block_21::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_122;
            }
            C2Rust_Block_21::S_122 => {
                sub_002486AE();
                c2rust_current_block_21 = C2Rust_Block_21::S_132;
            }
            C2Rust_Block_21::S_132 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_134;
            }
            C2Rust_Block_21::S_134 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_140;
            }
            C2Rust_Block_21::S_140 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_142;
            }
            C2Rust_Block_21::S_142 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_144;
            }
            C2Rust_Block_21::S_144 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_146;
            }
            C2Rust_Block_21::S_146 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_152;
            }
            C2Rust_Block_21::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_154;
            }
            C2Rust_Block_21::S_154 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_156;
            }
            C2Rust_Block_21::S_156 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b938 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_158;
            }
            C2Rust_Block_21::S_158 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_160;
            }
            C2Rust_Block_21::S_160 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_162;
            }
            C2Rust_Block_21::S_162 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_21 = C2Rust_Block_21::S_165;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_177;
                }
            }
            C2Rust_Block_21::S_165 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_167;
            }
            C2Rust_Block_21::S_167 => {
                sub_002454ED();
                c2rust_current_block_21 = C2Rust_Block_21::S_169;
            }
            C2Rust_Block_21::S_169 => return,
            C2Rust_Block_21::S_177 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_179;
            }
            C2Rust_Block_21::S_179 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_181;
            }
            C2Rust_Block_21::S_181 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_183;
            }
            C2Rust_Block_21::S_183 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_185;
            }
            C2Rust_Block_21::S_185 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_187;
            }
            C2Rust_Block_21::S_187 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_189;
            }
            C2Rust_Block_21::S_189 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_565;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_198;
                }
            }
            C2Rust_Block_21::S_198 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x83 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_200;
            }
            C2Rust_Block_21::S_200 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_202;
            }
            C2Rust_Block_21::S_202 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_204;
            }
            C2Rust_Block_21::S_204 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_206;
            }
            C2Rust_Block_21::S_206 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_565;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_219;
                }
            }
            C2Rust_Block_21::S_219 => {
                _pv_4 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_221;
            }
            C2Rust_Block_21::S_221 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_223;
            }
            C2Rust_Block_21::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_233;
            }
            C2Rust_Block_21::S_233 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_21 = C2Rust_Block_21::S_235;
            }
            C2Rust_Block_21::S_235 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_237;
            }
            C2Rust_Block_21::S_237 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_243;
            }
            C2Rust_Block_21::S_243 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_245;
            }
            C2Rust_Block_21::S_245 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_251;
            }
            C2Rust_Block_21::S_251 => {
                _pv_6 = 0x245485 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_253;
            }
            C2Rust_Block_21::S_253 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_255;
            }
            C2Rust_Block_21::S_255 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_261;
            }
            C2Rust_Block_21::S_261 => {
                sub_00245199();
                c2rust_current_block_21 = C2Rust_Block_21::S_271;
            }
            C2Rust_Block_21::S_271 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_273;
            }
            C2Rust_Block_21::S_273 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_283;
            }
            C2Rust_Block_21::S_283 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_285;
            }
            C2Rust_Block_21::S_285 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_291;
            }
            C2Rust_Block_21::S_291 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_293;
            }
            C2Rust_Block_21::S_293 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_295;
            }
            C2Rust_Block_21::S_295 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_297;
            }
            C2Rust_Block_21::S_297 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                c2rust_current_block_21 = C2Rust_Block_21::S_299;
            }
            C2Rust_Block_21::S_299 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_301;
            }
            C2Rust_Block_21::S_301 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_303;
            }
            C2Rust_Block_21::S_303 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_305;
            }
            C2Rust_Block_21::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_307;
            }
            C2Rust_Block_21::S_307 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_309;
            }
            C2Rust_Block_21::S_309 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_311;
            }
            C2Rust_Block_21::S_311 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_313;
            }
            C2Rust_Block_21::S_313 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x83 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_315;
            }
            C2Rust_Block_21::S_315 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_317;
            }
            C2Rust_Block_21::S_317 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_319;
            }
            C2Rust_Block_21::S_319 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_321;
            }
            C2Rust_Block_21::S_321 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_539;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_330;
                }
            }
            C2Rust_Block_21::S_330 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_332;
            }
            C2Rust_Block_21::S_332 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_334;
            }
            C2Rust_Block_21::S_334 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_336;
            }
            C2Rust_Block_21::S_336 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_338;
            }
            C2Rust_Block_21::S_338 => {
                if _fa != _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_428;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_351;
                }
            }
            C2Rust_Block_21::S_351 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_353;
            }
            C2Rust_Block_21::S_353 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_355;
            }
            C2Rust_Block_21::S_355 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_361;
            }
            C2Rust_Block_21::S_361 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_363;
            }
            C2Rust_Block_21::S_363 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_369;
            }
            C2Rust_Block_21::S_369 => {
                _pv_8 = 0x2454a8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_371;
            }
            C2Rust_Block_21::S_371 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_373;
            }
            C2Rust_Block_21::S_373 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_379;
            }
            C2Rust_Block_21::S_379 => {
                sub_0024540E();
                c2rust_current_block_21 = C2Rust_Block_21::S_389;
            }
            C2Rust_Block_21::S_389 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_391;
            }
            C2Rust_Block_21::S_391 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_397;
            }
            C2Rust_Block_21::S_397 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_399;
            }
            C2Rust_Block_21::S_399 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_401;
            }
            C2Rust_Block_21::S_401 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_403;
            }
            C2Rust_Block_21::S_403 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_405;
            }
            C2Rust_Block_21::S_405 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_539;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_414;
                }
            }
            C2Rust_Block_21::S_414 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_416;
            }
            C2Rust_Block_21::S_416 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_418;
            }
            C2Rust_Block_21::S_418 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_420;
            }
            C2Rust_Block_21::S_420 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_539;
            }
            C2Rust_Block_21::S_428 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_430;
            }
            C2Rust_Block_21::S_430 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_432;
            }
            C2Rust_Block_21::S_432 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_434;
            }
            C2Rust_Block_21::S_434 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_436;
            }
            C2Rust_Block_21::S_436 => {
                if _fa != _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_539;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_445;
                }
            }
            C2Rust_Block_21::S_445 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_447;
            }
            C2Rust_Block_21::S_447 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_449;
            }
            C2Rust_Block_21::S_449 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_451;
            }
            C2Rust_Block_21::S_451 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_453;
            }
            C2Rust_Block_21::S_453 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_539;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_466;
                }
            }
            C2Rust_Block_21::S_466 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_468;
            }
            C2Rust_Block_21::S_468 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_470;
            }
            C2Rust_Block_21::S_470 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_476;
            }
            C2Rust_Block_21::S_476 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_478;
            }
            C2Rust_Block_21::S_478 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_484;
            }
            C2Rust_Block_21::S_484 => {
                _pv_10 = 0x2454c3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_486;
            }
            C2Rust_Block_21::S_486 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_488;
            }
            C2Rust_Block_21::S_488 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_494;
            }
            C2Rust_Block_21::S_494 => {
                sub_0024540E();
                c2rust_current_block_21 = C2Rust_Block_21::S_504;
            }
            C2Rust_Block_21::S_504 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_506;
            }
            C2Rust_Block_21::S_506 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_512;
            }
            C2Rust_Block_21::S_512 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_514;
            }
            C2Rust_Block_21::S_514 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_516;
            }
            C2Rust_Block_21::S_516 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_518;
            }
            C2Rust_Block_21::S_518 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_520;
            }
            C2Rust_Block_21::S_520 => {
                if _fa != _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_539;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_529;
                }
            }
            C2Rust_Block_21::S_529 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_531;
            }
            C2Rust_Block_21::S_531 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_533;
            }
            C2Rust_Block_21::S_533 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_539;
            }
            C2Rust_Block_21::S_539 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_541;
            }
            C2Rust_Block_21::S_541 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_543;
            }
            C2Rust_Block_21::S_543 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_549;
            }
            C2Rust_Block_21::S_549 => {
                _pv_11 = 0x2454d4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_551;
            }
            C2Rust_Block_21::S_551 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_553;
            }
            C2Rust_Block_21::S_553 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_559;
            }
            C2Rust_Block_21::S_559 => {
                sub_002454DC();
                c2rust_current_block_21 = C2Rust_Block_21::S_565;
            }
            C2Rust_Block_21::S_565 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_21 = C2Rust_Block_21::S_567;
            }
            C2Rust_Block_21::S_567 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_569;
            }
            C2Rust_Block_21::S_569 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_571;
            }
            C2Rust_Block_21::S_571 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_152;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002454D7() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_002454DC();
}
#[no_mangle]
pub unsafe extern "C" fn sub_002454DC() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t))
                as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x2454ea as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_002451EB();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002454ED() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = 0x2454f6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00245508();
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_75: {
        if _fa == _fb {
            break 's_75;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = 0x245507 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245508() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24550f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002485FC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245511() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x374068 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24551d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_299: {
        's_107: {
            if _fa == _fb {
                break 's_107;
            }
            let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_5: uint32_t = 0x245535 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_0024516A();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
            let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_7: uint32_t = 0x245541 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_0024540E();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0xffffffff as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_8: uint32_t = 0x24554e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            sub_00245557();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            break 's_299;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_ebp) = ebp;
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _pv_3: uint32_t = 0x24552a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_0024543C();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x245556 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245557() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24555f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245561() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x245568 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024543C();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024556A() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    enum C2Rust_Block_37 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_38,
        S_40,
        S_42,
        S_48,
        S_50,
        S_52,
        S_58,
        S_67,
        S_69,
        S_71,
        S_73,
        S_75,
        S_77,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_103,
        S_105,
        S_107,
        S_109,
        S_111,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_136,
        S_149,
        S_151,
        S_153,
        S_163,
        S_165,
        S_167,
        S_173,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_193,
        S_195,
        S_201,
        S_203,
        S_205,
        S_215,
        S_217,
        S_219,
        S_229,
        S_231,
        S_233,
        S_239,
        S_245,
        S_247,
        S_249,
        S_251,
        S_253,
        S_259,
        S_261,
        S_267,
        S_276,
        S_278,
        S_280,
        S_282,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_341,
        S_351,
        S_353,
        S_355,
        S_365,
        S_367,
        S_369,
        S_379,
        S_381,
        S_383,
        S_393,
        S_395,
        S_397,
        S_403,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_455,
        S_457,
        S_459,
        S_465,
        S_471,
        S_473,
        S_475,
        S_477,
        S_487,
        S_489,
        S_499,
        S_501,
        S_507,
        S_509,
    }
    let mut c2rust_current_block_37: C2Rust_Block_37;
    c2rust_current_block_37 = C2Rust_Block_37::S_0;
    loop {
        match c2rust_current_block_37 {
            C2Rust_Block_37::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_2;
            }
            C2Rust_Block_37::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_4;
            }
            C2Rust_Block_37::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_22;
            }
            C2Rust_Block_37::S_22 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_37 = C2Rust_Block_37::S_24;
            }
            C2Rust_Block_37::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_26;
            }
            C2Rust_Block_37::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_32;
            }
            C2Rust_Block_37::S_32 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_34;
            }
            C2Rust_Block_37::S_34 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_36;
            }
            C2Rust_Block_37::S_36 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x83 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_38;
            }
            C2Rust_Block_37::S_38 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_40;
            }
            C2Rust_Block_37::S_40 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_42;
            }
            C2Rust_Block_37::S_42 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_48;
            }
            C2Rust_Block_37::S_48 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_37 = C2Rust_Block_37::S_50;
            }
            C2Rust_Block_37::S_50 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_52;
            }
            C2Rust_Block_37::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_58;
            }
            C2Rust_Block_37::S_58 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_455;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_67;
                }
            }
            C2Rust_Block_37::S_67 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_69;
            }
            C2Rust_Block_37::S_69 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_71;
            }
            C2Rust_Block_37::S_71 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_73;
            }
            C2Rust_Block_37::S_73 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_75;
            }
            C2Rust_Block_37::S_75 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_77;
            }
            C2Rust_Block_37::S_77 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_120;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_86;
                }
            }
            C2Rust_Block_37::S_86 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_88;
            }
            C2Rust_Block_37::S_88 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_90;
            }
            C2Rust_Block_37::S_90 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_92;
            }
            C2Rust_Block_37::S_92 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_94;
            }
            C2Rust_Block_37::S_94 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_120;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_103;
                }
            }
            C2Rust_Block_37::S_103 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_105;
            }
            C2Rust_Block_37::S_105 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_107;
            }
            C2Rust_Block_37::S_107 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_109;
            }
            C2Rust_Block_37::S_109 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_111;
            }
            C2Rust_Block_37::S_111 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_455;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_120;
                }
            }
            C2Rust_Block_37::S_120 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffffef as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_122;
            }
            C2Rust_Block_37::S_122 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_124;
            }
            C2Rust_Block_37::S_124 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_126;
            }
            C2Rust_Block_37::S_126 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_128;
            }
            C2Rust_Block_37::S_128 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_130;
            }
            C2Rust_Block_37::S_130 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_132;
            }
            C2Rust_Block_37::S_132 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_134;
            }
            C2Rust_Block_37::S_134 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_136;
            }
            C2Rust_Block_37::S_136 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_215;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_149;
                }
            }
            C2Rust_Block_37::S_149 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_37 = C2Rust_Block_37::S_151;
            }
            C2Rust_Block_37::S_151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_153;
            }
            C2Rust_Block_37::S_153 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_163;
            }
            C2Rust_Block_37::S_163 => {
                _pv_2 = 0x24559a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_165;
            }
            C2Rust_Block_37::S_165 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_167;
            }
            C2Rust_Block_37::S_167 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_173;
            }
            C2Rust_Block_37::S_173 => {
                sub_0024520E();
                c2rust_current_block_37 = C2Rust_Block_37::S_179;
            }
            C2Rust_Block_37::S_179 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_181;
            }
            C2Rust_Block_37::S_181 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_183;
            }
            C2Rust_Block_37::S_183 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_185;
            }
            C2Rust_Block_37::S_185 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_187;
            }
            C2Rust_Block_37::S_187 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_193;
            }
            C2Rust_Block_37::S_193 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_195;
            }
            C2Rust_Block_37::S_195 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_201;
            }
            C2Rust_Block_37::S_201 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_203;
            }
            C2Rust_Block_37::S_203 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_205;
            }
            C2Rust_Block_37::S_205 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_215;
            }
            C2Rust_Block_37::S_215 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_37 = C2Rust_Block_37::S_217;
            }
            C2Rust_Block_37::S_217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_219;
            }
            C2Rust_Block_37::S_219 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_229;
            }
            C2Rust_Block_37::S_229 => {
                _pv_4 = 0x2455a7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_231;
            }
            C2Rust_Block_37::S_231 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_233;
            }
            C2Rust_Block_37::S_233 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_239;
            }
            C2Rust_Block_37::S_239 => {
                sub_002453B1();
                c2rust_current_block_37 = C2Rust_Block_37::S_245;
            }
            C2Rust_Block_37::S_245 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_247;
            }
            C2Rust_Block_37::S_247 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_249;
            }
            C2Rust_Block_37::S_249 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_251;
            }
            C2Rust_Block_37::S_251 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_253;
            }
            C2Rust_Block_37::S_253 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_259;
            }
            C2Rust_Block_37::S_259 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_261;
            }
            C2Rust_Block_37::S_261 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_267;
            }
            C2Rust_Block_37::S_267 => {
                if (_fa as uint8_t as ::core::ffi::c_int
                    - _fb as uint8_t as ::core::ffi::c_int) as uint8_t
                    as ::core::ffi::c_int >> 7 as ::core::ffi::c_int
                    == 0 as ::core::ffi::c_int
                {
                    c2rust_current_block_37 = C2Rust_Block_37::S_290;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_276;
                }
            }
            C2Rust_Block_37::S_276 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffc as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_278;
            }
            C2Rust_Block_37::S_278 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_280;
            }
            C2Rust_Block_37::S_280 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_282;
            }
            C2Rust_Block_37::S_282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_351;
            }
            C2Rust_Block_37::S_290 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_292;
            }
            C2Rust_Block_37::S_292 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_294;
            }
            C2Rust_Block_37::S_294 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_296;
            }
            C2Rust_Block_37::S_296 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_298;
            }
            C2Rust_Block_37::S_298 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_351;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_307;
                }
            }
            C2Rust_Block_37::S_307 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_309;
            }
            C2Rust_Block_37::S_309 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_311;
            }
            C2Rust_Block_37::S_311 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_313;
            }
            C2Rust_Block_37::S_313 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_315;
            }
            C2Rust_Block_37::S_315 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_351;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_324;
                }
            }
            C2Rust_Block_37::S_324 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 4 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_326;
            }
            C2Rust_Block_37::S_326 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_328;
            }
            C2Rust_Block_37::S_328 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_330;
            }
            C2Rust_Block_37::S_330 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_332;
            }
            C2Rust_Block_37::S_332 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_351;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_341;
                }
            }
            C2Rust_Block_37::S_341 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x200 as uint32_t,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_351;
            }
            C2Rust_Block_37::S_351 => {
                _pv_5 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_37 = C2Rust_Block_37::S_353;
            }
            C2Rust_Block_37::S_353 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_355;
            }
            C2Rust_Block_37::S_355 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_365;
            }
            C2Rust_Block_37::S_365 => {
                _pv_6 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_367;
            }
            C2Rust_Block_37::S_367 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_369;
            }
            C2Rust_Block_37::S_369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_379;
            }
            C2Rust_Block_37::S_379 => {
                _pv_7 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_381;
            }
            C2Rust_Block_37::S_381 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_383;
            }
            C2Rust_Block_37::S_383 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_393;
            }
            C2Rust_Block_37::S_393 => {
                _pv_8 = 0x2455d8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_395;
            }
            C2Rust_Block_37::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_397;
            }
            C2Rust_Block_37::S_397 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_403;
            }
            C2Rust_Block_37::S_403 => {
                sub_0024A1A5();
                c2rust_current_block_37 = C2Rust_Block_37::S_409;
            }
            C2Rust_Block_37::S_409 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_411;
            }
            C2Rust_Block_37::S_411 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_413;
            }
            C2Rust_Block_37::S_413 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_415;
            }
            C2Rust_Block_37::S_415 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_417;
            }
            C2Rust_Block_37::S_417 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_419;
            }
            C2Rust_Block_37::S_419 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_421;
            }
            C2Rust_Block_37::S_421 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_423;
            }
            C2Rust_Block_37::S_423 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_425;
            }
            C2Rust_Block_37::S_425 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_427;
            }
            C2Rust_Block_37::S_427 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_429;
            }
            C2Rust_Block_37::S_429 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_431;
            }
            C2Rust_Block_37::S_431 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_433;
            }
            C2Rust_Block_37::S_433 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | (if _fa != _fb {
                        1 as ::core::ffi::c_int
                    } else {
                        0 as ::core::ffi::c_int
                    }) as uint8_t as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_435;
            }
            C2Rust_Block_37::S_435 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
                c2rust_current_block_37 = C2Rust_Block_37::S_437;
            }
            C2Rust_Block_37::S_437 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_439;
            }
            C2Rust_Block_37::S_439 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_441;
            }
            C2Rust_Block_37::S_441 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_443;
            }
            C2Rust_Block_37::S_443 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_37 = C2Rust_Block_37::S_487;
            }
            C2Rust_Block_37::S_455 => {
                _pv_9 = 0x2455ed as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_457;
            }
            C2Rust_Block_37::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_459;
            }
            C2Rust_Block_37::S_459 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_465;
            }
            C2Rust_Block_37::S_465 => {
                sub_0024A0AE();
                c2rust_current_block_37 = C2Rust_Block_37::S_471;
            }
            C2Rust_Block_37::S_471 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x16 as uint32_t,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_473;
            }
            C2Rust_Block_37::S_473 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_475;
            }
            C2Rust_Block_37::S_475 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_477;
            }
            C2Rust_Block_37::S_477 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_487;
            }
            C2Rust_Block_37::S_487 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_489;
            }
            C2Rust_Block_37::S_489 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_499;
            }
            C2Rust_Block_37::S_499 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_501;
            }
            C2Rust_Block_37::S_501 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_507;
            }
            C2Rust_Block_37::S_507 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_509;
            }
            C2Rust_Block_37::S_509 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002455F9() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x374078 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x245605 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x24560d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024516A();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_7: uint32_t = 0x245620 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_0024556A();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_8: uint32_t = 0x24562f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_00245638();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x245637 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245638() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x245640 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245642() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x10 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024564D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    enum C2Rust_Block_41 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_72,
        S_74,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_115,
        S_117,
        S_119,
        S_121,
        S_123,
        S_125,
        S_127,
        S_133,
        S_135,
        S_137,
        S_143,
        S_145,
        S_151,
        S_153,
        S_155,
        S_161,
        S_171,
        S_173,
        S_179,
        S_181,
        S_183,
        S_189,
        S_191,
        S_193,
        S_199,
        S_201,
        S_207,
        S_209,
        S_211,
        S_217,
        S_223,
        S_229,
        S_231,
        S_233,
        S_243,
        S_245,
        S_247,
        S_257,
        S_259,
        S_261,
        S_271,
        S_273,
        S_275,
        S_281,
        S_283,
        S_289,
        S_291,
        S_293,
        S_299,
        S_305,
        S_311,
        S_313,
        S_315,
        S_325,
        S_327,
        S_329,
        S_335,
        S_337,
        S_343,
        S_345,
        S_347,
        S_353,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_383,
        S_385,
        S_387,
        S_393,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_435,
        S_437,
        S_439,
        S_445,
        S_447,
        S_453,
        S_455,
    }
    let mut c2rust_current_block_41: C2Rust_Block_41;
    c2rust_current_block_41 = C2Rust_Block_41::S_0;
    loop {
        match c2rust_current_block_41 {
            C2Rust_Block_41::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_2;
            }
            C2Rust_Block_41::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_41 = C2Rust_Block_41::S_4;
            }
            C2Rust_Block_41::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_41 = C2Rust_Block_41::S_6;
            }
            C2Rust_Block_41::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_8;
            }
            C2Rust_Block_41::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_18;
            }
            C2Rust_Block_41::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_41 = C2Rust_Block_41::S_28;
            }
            C2Rust_Block_41::S_28 => {
                _pv = 0x14 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_30;
            }
            C2Rust_Block_41::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_32;
            }
            C2Rust_Block_41::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_42;
            }
            C2Rust_Block_41::S_42 => {
                _pv_0 = 0x374088 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_44;
            }
            C2Rust_Block_41::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_46;
            }
            C2Rust_Block_41::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_52;
            }
            C2Rust_Block_41::S_52 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_54;
            }
            C2Rust_Block_41::S_54 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_56;
            }
            C2Rust_Block_41::S_56 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_62;
            }
            C2Rust_Block_41::S_62 => {
                _pv_1 = 0x245659 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_64;
            }
            C2Rust_Block_41::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_66;
            }
            C2Rust_Block_41::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_72;
            }
            C2Rust_Block_41::S_72 => {
                sub_00244784();
                c2rust_current_block_41 = C2Rust_Block_41::S_74;
            }
            C2Rust_Block_41::S_74 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_41 = C2Rust_Block_41::S_80;
            }
            C2Rust_Block_41::S_80 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_82;
            }
            C2Rust_Block_41::S_82 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(1 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_88;
            }
            C2Rust_Block_41::S_88 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_90;
            }
            C2Rust_Block_41::S_90 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_41 = C2Rust_Block_41::S_92;
            }
            C2Rust_Block_41::S_92 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_94;
            }
            C2Rust_Block_41::S_94 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_96;
            }
            C2Rust_Block_41::S_96 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_98;
            }
            C2Rust_Block_41::S_98 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_100;
            }
            C2Rust_Block_41::S_100 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_102;
            }
            C2Rust_Block_41::S_102 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_104;
            }
            C2Rust_Block_41::S_104 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_106;
            }
            C2Rust_Block_41::S_106 => {
                if _fa != _fb {
                    c2rust_current_block_41 = C2Rust_Block_41::S_88;
                } else {
                    c2rust_current_block_41 = C2Rust_Block_41::S_115;
                }
            }
            C2Rust_Block_41::S_115 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_117;
            }
            C2Rust_Block_41::S_117 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_119;
            }
            C2Rust_Block_41::S_119 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_41 = C2Rust_Block_41::S_121;
            }
            C2Rust_Block_41::S_121 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_123;
            }
            C2Rust_Block_41::S_123 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_125;
            }
            C2Rust_Block_41::S_125 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_127;
            }
            C2Rust_Block_41::S_127 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_133;
            }
            C2Rust_Block_41::S_133 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_41 = C2Rust_Block_41::S_135;
            }
            C2Rust_Block_41::S_135 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_137;
            }
            C2Rust_Block_41::S_137 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_143;
            }
            C2Rust_Block_41::S_143 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_145;
            }
            C2Rust_Block_41::S_145 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_151;
            }
            C2Rust_Block_41::S_151 => {
                _pv_3 = 0x245674 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_153;
            }
            C2Rust_Block_41::S_153 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_155;
            }
            C2Rust_Block_41::S_155 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_161;
            }
            C2Rust_Block_41::S_161 => {
                sub_0024516A();
                c2rust_current_block_41 = C2Rust_Block_41::S_171;
            }
            C2Rust_Block_41::S_171 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_173;
            }
            C2Rust_Block_41::S_173 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_179;
            }
            C2Rust_Block_41::S_179 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_181;
            }
            C2Rust_Block_41::S_181 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_183;
            }
            C2Rust_Block_41::S_183 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_189;
            }
            C2Rust_Block_41::S_189 => {
                _pv_4 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_41 = C2Rust_Block_41::S_191;
            }
            C2Rust_Block_41::S_191 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_193;
            }
            C2Rust_Block_41::S_193 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_199;
            }
            C2Rust_Block_41::S_199 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_201;
            }
            C2Rust_Block_41::S_201 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_207;
            }
            C2Rust_Block_41::S_207 => {
                _pv_5 = 0x24567f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_209;
            }
            C2Rust_Block_41::S_209 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_211;
            }
            C2Rust_Block_41::S_211 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_217;
            }
            C2Rust_Block_41::S_217 => {
                sub_00249F13();
                c2rust_current_block_41 = C2Rust_Block_41::S_223;
            }
            C2Rust_Block_41::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_229;
            }
            C2Rust_Block_41::S_229 => {
                _pv_6 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_41 = C2Rust_Block_41::S_231;
            }
            C2Rust_Block_41::S_231 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_233;
            }
            C2Rust_Block_41::S_233 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_243;
            }
            C2Rust_Block_41::S_243 => {
                _pv_7 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_245;
            }
            C2Rust_Block_41::S_245 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_247;
            }
            C2Rust_Block_41::S_247 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_257;
            }
            C2Rust_Block_41::S_257 => {
                _pv_8 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_259;
            }
            C2Rust_Block_41::S_259 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_261;
            }
            C2Rust_Block_41::S_261 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_271;
            }
            C2Rust_Block_41::S_271 => {
                _pv_9 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_273;
            }
            C2Rust_Block_41::S_273 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_275;
            }
            C2Rust_Block_41::S_275 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_281;
            }
            C2Rust_Block_41::S_281 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_283;
            }
            C2Rust_Block_41::S_283 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_289;
            }
            C2Rust_Block_41::S_289 => {
                _pv_10 = 0x245690 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_291;
            }
            C2Rust_Block_41::S_291 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_293;
            }
            C2Rust_Block_41::S_293 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_299;
            }
            C2Rust_Block_41::S_299 => {
                sub_0024574A();
                c2rust_current_block_41 = C2Rust_Block_41::S_305;
            }
            C2Rust_Block_41::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_311;
            }
            C2Rust_Block_41::S_311 => {
                _pv_11 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_41 = C2Rust_Block_41::S_313;
            }
            C2Rust_Block_41::S_313 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_315;
            }
            C2Rust_Block_41::S_315 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_325;
            }
            C2Rust_Block_41::S_325 => {
                _pv_12 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_327;
            }
            C2Rust_Block_41::S_327 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_329;
            }
            C2Rust_Block_41::S_329 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_335;
            }
            C2Rust_Block_41::S_335 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_337;
            }
            C2Rust_Block_41::S_337 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_343;
            }
            C2Rust_Block_41::S_343 => {
                _pv_13 = 0x24569c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_345;
            }
            C2Rust_Block_41::S_345 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_347;
            }
            C2Rust_Block_41::S_347 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_353;
            }
            C2Rust_Block_41::S_353 => {
                sub_00249F9B();
                c2rust_current_block_41 = C2Rust_Block_41::S_359;
            }
            C2Rust_Block_41::S_359 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_361;
            }
            C2Rust_Block_41::S_361 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_363;
            }
            C2Rust_Block_41::S_363 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_365;
            }
            C2Rust_Block_41::S_365 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_367;
            }
            C2Rust_Block_41::S_367 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_369;
            }
            C2Rust_Block_41::S_369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0xffffffff as uint32_t,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_371;
            }
            C2Rust_Block_41::S_371 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_373;
            }
            C2Rust_Block_41::S_373 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_375;
            }
            C2Rust_Block_41::S_375 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_377;
            }
            C2Rust_Block_41::S_377 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_383;
            }
            C2Rust_Block_41::S_383 => {
                _pv_14 = 0x2456a8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_385;
            }
            C2Rust_Block_41::S_385 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_387;
            }
            C2Rust_Block_41::S_387 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_393;
            }
            C2Rust_Block_41::S_393 => {
                sub_002456BA();
                c2rust_current_block_41 = C2Rust_Block_41::S_399;
            }
            C2Rust_Block_41::S_399 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_401;
            }
            C2Rust_Block_41::S_401 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_403;
            }
            C2Rust_Block_41::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_405;
            }
            C2Rust_Block_41::S_405 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_407;
            }
            C2Rust_Block_41::S_407 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_409;
            }
            C2Rust_Block_41::S_409 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_411;
            }
            C2Rust_Block_41::S_411 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_413;
            }
            C2Rust_Block_41::S_413 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_415;
            }
            C2Rust_Block_41::S_415 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (if _fa == _fb {
                        1 as ::core::ffi::c_int
                    } else {
                        0 as ::core::ffi::c_int
                    }) as uint8_t as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_417;
            }
            C2Rust_Block_41::S_417 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_41 = C2Rust_Block_41::S_419;
            }
            C2Rust_Block_41::S_419 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_421;
            }
            C2Rust_Block_41::S_421 => {
                _fas = _fa as int32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_423;
            }
            C2Rust_Block_41::S_423 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_425;
            }
            C2Rust_Block_41::S_425 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_427;
            }
            C2Rust_Block_41::S_427 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_429;
            }
            C2Rust_Block_41::S_429 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_41 = C2Rust_Block_41::S_435;
            }
            C2Rust_Block_41::S_435 => {
                _pv_15 = 0x2456b9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_41 = C2Rust_Block_41::S_437;
            }
            C2Rust_Block_41::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_439;
            }
            C2Rust_Block_41::S_439 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_41 = C2Rust_Block_41::S_445;
            }
            C2Rust_Block_41::S_445 => {
                sub_002447BF();
                c2rust_current_block_41 = C2Rust_Block_41::S_447;
            }
            C2Rust_Block_41::S_447 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_41 = C2Rust_Block_41::S_453;
            }
            C2Rust_Block_41::S_453 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_41 = C2Rust_Block_41::S_455;
            }
            C2Rust_Block_41::S_455 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002456BA() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2456c2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002456C4() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0x18 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x374098 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x2456d0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_406: {
        's_103: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                <= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_103;
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_3: uint32_t = 0x2456ee as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            sub_0024516A();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            's_370: {
                's_364: loop {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_sub(1 as uint32_t),
                    );
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    if _fa == 0 as uint32_t {
                        break;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_sub(1 as uint32_t),
                    );
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    's_287: {
                        's_213: {
                            if _fas >= 0 as int32_t {
                                break 's_213;
                            }
                            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
                            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                .wrapping_sub(4 as uint32_t);
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                _pv_4,
                            );
                            (*__gamepkg_tls_g_ebp) = ebp;
                            (*__gamepkg_tls_g_seh_ebp) = ebp;
                            let mut _pv_5: uint32_t = 0x24570d as ::core::ffi::c_uint
                                as uint32_t;
                            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                .wrapping_sub(4 as uint32_t);
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                _pv_5,
                            );
                            sub_0024A540();
                            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            );
                            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                .wrapping_add(4 as uint32_t);
                            break 's_287;
                        }
                        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint32_t;
                        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                            as uint32_t;
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            (*__gamepkg_tls_g_ecx),
                        );
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-36 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                        & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_335: {
                        if _fa != _fb {
                            break 's_335;
                        }
                        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                        _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        _fbs = _fb as int32_t;
                        if _fa != _fb {
                            break 's_364;
                        }
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) & 0 as uint32_t,
                        );
                        _fa = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        break 's_370;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-40 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                    _fas = _fa as int8_t as int32_t;
                    _fbs = _fb as int8_t as int32_t;
                    if _fa == _fb {
                        break;
                    }
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0xffffffff as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_6: uint32_t = 0x245736 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_00245742();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            break 's_406;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_7: uint32_t = 0x24573e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024573F() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00245742();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245742() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x245748 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024574A() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _d_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_0: uint32_t = 0;
    let mut _i_1: uint32_t = 0;
    let mut _i_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _dividend_0: uint64_t = 0;
    enum C2Rust_Block_43 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_58,
        S_60,
        S_62,
        S_72,
        S_74,
        S_76,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_111,
        S_113,
        S_115,
        S_127,
        S_129,
        S_131,
        S_137,
        S_139,
        S_141,
        S_143,
        S_145,
        S_147,
        S_156,
        S_158,
        S_166,
        S_174,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_197,
        S_199,
        S_201,
        S_203,
        S_205,
        S_207,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_233,
        S_239,
        S_241,
        S_243,
        S_245,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_259,
        S_261,
        S_263,
        S_267,
        S_269,
        S_271,
        S_273,
        S_277,
        S_280,
        S_281,
        S_282,
        S_283,
        S_294,
        S_296,
        S_301,
        S_304,
        S_305,
        S_306,
        S_307,
        S_314,
        S_316,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_336,
        S_338,
        S_340,
        S_342,
        S_346,
        S_349,
        S_350,
        S_351,
        S_352,
        S_363,
        S_365,
        S_370,
        S_373,
        S_374,
        S_375,
        S_376,
        S_383,
        S_385,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_448,
        S_450,
        S_452,
        S_454,
        S_456,
        S_469,
        S_471,
        S_473,
        S_479,
        S_481,
        S_487,
        S_489,
        S_491,
        S_497,
        S_503,
        S_505,
        S_507,
        S_509,
        S_515,
        S_517,
        S_523,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_549,
        S_551,
        S_553,
        S_555,
        S_558,
        S_560,
        S_562,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_584,
        S_586,
        S_588,
        S_598,
        S_600,
        S_602,
        S_612,
        S_614,
        S_616,
        S_622,
        S_624,
        S_630,
        S_632,
        S_634,
        S_640,
        S_646,
        S_648,
        S_650,
        S_652,
        S_654,
        S_656,
        S_658,
        S_660,
        S_662,
        S_664,
        S_673,
        S_675,
        S_677,
        S_679,
        S_681,
        S_683,
        S_685,
        S_687,
        S_689,
        S_691,
        S_693,
        S_695,
        S_697,
        S_699,
        S_701,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_734,
        S_740,
        S_742,
        S_744,
        S_754,
        S_756,
        S_758,
        S_764,
        S_766,
        S_772,
        S_774,
        S_776,
        S_782,
        S_788,
        S_790,
        S_792,
        S_794,
        S_800,
        S_802,
        S_812,
        S_814,
        S_820,
        S_829,
        S_831,
        S_833,
        S_835,
        S_837,
        S_839,
        S_841,
        S_843,
        S_845,
        S_847,
        S_849,
        S_851,
        S_853,
        S_855,
        S_857,
        S_859,
        S_868,
        S_874,
        S_876,
        S_878,
        S_880,
        S_882,
        S_884,
        S_893,
        S_903,
        S_905,
        S_919,
        S_921,
        S_931,
        S_933,
        S_939,
        S_945,
        S_947,
        S_953,
        S_955,
        S_961,
        S_963,
        S_965,
        S_967,
        S_969,
        S_971,
        S_977,
        S_979,
        S_981,
        S_984,
        S_986,
        S_988,
    }
    let mut c2rust_current_block_43: C2Rust_Block_43;
    c2rust_current_block_43 = C2Rust_Block_43::S_0;
    loop {
        match c2rust_current_block_43 {
            C2Rust_Block_43::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_2;
            }
            C2Rust_Block_43::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_43 = C2Rust_Block_43::S_4;
            }
            C2Rust_Block_43::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_43 = C2Rust_Block_43::S_6;
            }
            C2Rust_Block_43::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_8;
            }
            C2Rust_Block_43::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_26;
            }
            C2Rust_Block_43::S_26 => {
                _pv = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_28;
            }
            C2Rust_Block_43::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_30;
            }
            C2Rust_Block_43::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_36;
            }
            C2Rust_Block_43::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_43 = C2Rust_Block_43::S_38;
            }
            C2Rust_Block_43::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_40;
            }
            C2Rust_Block_43::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_42;
            }
            C2Rust_Block_43::S_42 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_44;
            }
            C2Rust_Block_43::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_46;
            }
            C2Rust_Block_43::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_48;
            }
            C2Rust_Block_43::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_50;
            }
            C2Rust_Block_43::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_52;
            }
            C2Rust_Block_43::S_52 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_58;
            }
            C2Rust_Block_43::S_58 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_43 = C2Rust_Block_43::S_60;
            }
            C2Rust_Block_43::S_60 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_62;
            }
            C2Rust_Block_43::S_62 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_72;
            }
            C2Rust_Block_43::S_72 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_43 = C2Rust_Block_43::S_74;
            }
            C2Rust_Block_43::S_74 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_76;
            }
            C2Rust_Block_43::S_76 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_82;
            }
            C2Rust_Block_43::S_82 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_84;
            }
            C2Rust_Block_43::S_84 => {
                (*__gamepkg_tls_g_edi) = ((*__gamepkg_tls_g_edi) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_86;
            }
            C2Rust_Block_43::S_86 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_88;
            }
            C2Rust_Block_43::S_88 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_90;
            }
            C2Rust_Block_43::S_90 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_92;
            }
            C2Rust_Block_43::S_92 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_94;
            }
            C2Rust_Block_43::S_94 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_43 = C2Rust_Block_43::S_96;
            }
            C2Rust_Block_43::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_98;
            }
            C2Rust_Block_43::S_98 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_100;
            }
            C2Rust_Block_43::S_100 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_102;
            }
            C2Rust_Block_43::S_102 => {
                if _fa != _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_127;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_111;
                }
            }
            C2Rust_Block_43::S_111 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_113;
            }
            C2Rust_Block_43::S_113 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_115;
            }
            C2Rust_Block_43::S_115 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_919;
            }
            C2Rust_Block_43::S_127 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_43 = C2Rust_Block_43::S_129;
            }
            C2Rust_Block_43::S_129 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_131;
            }
            C2Rust_Block_43::S_131 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_137;
            }
            C2Rust_Block_43::S_137 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_139;
            }
            C2Rust_Block_43::S_139 => {
                _fa = (::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x10c as ::core::ffi::c_int) as uint32_t
                    & 0xffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_141;
            }
            C2Rust_Block_43::S_141 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_143;
            }
            C2Rust_Block_43::S_143 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_145;
            }
            C2Rust_Block_43::S_145 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_147;
            }
            C2Rust_Block_43::S_147 => {
                if _fa == _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_166;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_156;
                }
            }
            C2Rust_Block_43::S_156 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_158;
            }
            C2Rust_Block_43::S_158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_180;
            }
            C2Rust_Block_43::S_166 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1000 as uint32_t,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_180;
            }
            C2Rust_Block_43::S_174 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_180;
            }
            C2Rust_Block_43::S_180 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_182;
            }
            C2Rust_Block_43::S_182 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0x108 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_184;
            }
            C2Rust_Block_43::S_184 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_186;
            }
            C2Rust_Block_43::S_186 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_188;
            }
            C2Rust_Block_43::S_188 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_43 = C2Rust_Block_43::S_431;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_197;
                }
            }
            C2Rust_Block_43::S_197 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_199;
            }
            C2Rust_Block_43::S_199 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_201;
            }
            C2Rust_Block_43::S_201 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_203;
            }
            C2Rust_Block_43::S_203 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_205;
            }
            C2Rust_Block_43::S_205 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_207;
            }
            C2Rust_Block_43::S_207 => {
                if _fa == _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_431;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_216;
                }
            }
            C2Rust_Block_43::S_216 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_218;
            }
            C2Rust_Block_43::S_218 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_220;
            }
            C2Rust_Block_43::S_220 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_222;
            }
            C2Rust_Block_43::S_222 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_224;
            }
            C2Rust_Block_43::S_224 => {
                if _fa >= _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_239;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_233;
                }
            }
            C2Rust_Block_43::S_233 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_43 = C2Rust_Block_43::S_239;
            }
            C2Rust_Block_43::S_239 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_241;
            }
            C2Rust_Block_43::S_241 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_243;
            }
            C2Rust_Block_43::S_243 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_245;
            }
            C2Rust_Block_43::S_245 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_247;
            }
            C2Rust_Block_43::S_247 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_249;
            }
            C2Rust_Block_43::S_249 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_251;
            }
            C2Rust_Block_43::S_251 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_43 = C2Rust_Block_43::S_253;
            }
            C2Rust_Block_43::S_253 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_43 = C2Rust_Block_43::S_255;
            }
            C2Rust_Block_43::S_255 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_43 = C2Rust_Block_43::S_257;
            }
            C2Rust_Block_43::S_257 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_43 = C2Rust_Block_43::S_259;
            }
            C2Rust_Block_43::S_259 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_261;
            }
            C2Rust_Block_43::S_261 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_263;
            }
            C2Rust_Block_43::S_263 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_43 = C2Rust_Block_43::S_267;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_301;
                }
            }
            C2Rust_Block_43::S_267 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_269;
            }
            C2Rust_Block_43::S_269 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_271;
            }
            C2Rust_Block_43::S_271 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_43 = C2Rust_Block_43::S_273;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_277;
                }
            }
            C2Rust_Block_43::S_273 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_294;
            }
            C2Rust_Block_43::S_277 => {
                _i = 0;
                c2rust_current_block_43 = C2Rust_Block_43::S_280;
            }
            C2Rust_Block_43::S_280 => {
                _i = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_281;
            }
            C2Rust_Block_43::S_281 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_43 = C2Rust_Block_43::S_282;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_294;
                }
            }
            C2Rust_Block_43::S_282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_283;
            }
            C2Rust_Block_43::S_283 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_43 = C2Rust_Block_43::S_281;
            }
            C2Rust_Block_43::S_294 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_43 = C2Rust_Block_43::S_296;
            }
            C2Rust_Block_43::S_296 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_43 = C2Rust_Block_43::S_322;
            }
            C2Rust_Block_43::S_301 => {
                _i_0 = 0;
                c2rust_current_block_43 = C2Rust_Block_43::S_304;
            }
            C2Rust_Block_43::S_304 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_305;
            }
            C2Rust_Block_43::S_305 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_43 = C2Rust_Block_43::S_306;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_314;
                }
            }
            C2Rust_Block_43::S_306 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_307;
            }
            C2Rust_Block_43::S_307 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_43 = C2Rust_Block_43::S_305;
            }
            C2Rust_Block_43::S_314 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_43 = C2Rust_Block_43::S_316;
            }
            C2Rust_Block_43::S_316 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_43 = C2Rust_Block_43::S_322;
            }
            C2Rust_Block_43::S_322 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_324;
            }
            C2Rust_Block_43::S_324 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_43 = C2Rust_Block_43::S_326;
            }
            C2Rust_Block_43::S_326 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_328;
            }
            C2Rust_Block_43::S_328 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_330;
            }
            C2Rust_Block_43::S_330 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_332;
            }
            C2Rust_Block_43::S_332 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_43 = C2Rust_Block_43::S_336;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_370;
                }
            }
            C2Rust_Block_43::S_336 => {
                _d_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_338;
            }
            C2Rust_Block_43::S_338 => {
                _n_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_43 = C2Rust_Block_43::S_340;
            }
            C2Rust_Block_43::S_340 => {
                if _d_0.offset(_n_0 as isize) <= _s_0
                    || _s_0.offset(_n_0 as isize) <= _d_0
                {
                    c2rust_current_block_43 = C2Rust_Block_43::S_342;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_346;
                }
            }
            C2Rust_Block_43::S_342 => {
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_363;
            }
            C2Rust_Block_43::S_346 => {
                _i_1 = 0;
                c2rust_current_block_43 = C2Rust_Block_43::S_349;
            }
            C2Rust_Block_43::S_349 => {
                _i_1 = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_350;
            }
            C2Rust_Block_43::S_350 => {
                if _i_1 < _n_0 {
                    c2rust_current_block_43 = C2Rust_Block_43::S_351;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_363;
                }
            }
            C2Rust_Block_43::S_351 => {
                *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                c2rust_current_block_43 = C2Rust_Block_43::S_352;
            }
            C2Rust_Block_43::S_352 => {
                _i_1 = _i_1.wrapping_add(1);
                c2rust_current_block_43 = C2Rust_Block_43::S_350;
            }
            C2Rust_Block_43::S_363 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_43 = C2Rust_Block_43::S_365;
            }
            C2Rust_Block_43::S_365 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_43 = C2Rust_Block_43::S_391;
            }
            C2Rust_Block_43::S_370 => {
                _i_2 = 0;
                c2rust_current_block_43 = C2Rust_Block_43::S_373;
            }
            C2Rust_Block_43::S_373 => {
                _i_2 = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_374;
            }
            C2Rust_Block_43::S_374 => {
                if _i_2 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_43 = C2Rust_Block_43::S_375;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_383;
                }
            }
            C2Rust_Block_43::S_375 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_376;
            }
            C2Rust_Block_43::S_376 => {
                _i_2 = _i_2.wrapping_add(1);
                c2rust_current_block_43 = C2Rust_Block_43::S_374;
            }
            C2Rust_Block_43::S_383 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_43 = C2Rust_Block_43::S_385;
            }
            C2Rust_Block_43::S_385 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_43 = C2Rust_Block_43::S_391;
            }
            C2Rust_Block_43::S_391 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_393;
            }
            C2Rust_Block_43::S_393 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_395;
            }
            C2Rust_Block_43::S_395 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_397;
            }
            C2Rust_Block_43::S_397 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_399;
            }
            C2Rust_Block_43::S_399 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_401;
            }
            C2Rust_Block_43::S_401 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_403;
            }
            C2Rust_Block_43::S_403 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_405;
            }
            C2Rust_Block_43::S_405 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_407;
            }
            C2Rust_Block_43::S_407 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ebx) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_409;
            }
            C2Rust_Block_43::S_409 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_411;
            }
            C2Rust_Block_43::S_411 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_413;
            }
            C2Rust_Block_43::S_413 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_415;
            }
            C2Rust_Block_43::S_415 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_417;
            }
            C2Rust_Block_43::S_417 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_419;
            }
            C2Rust_Block_43::S_419 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_421;
            }
            C2Rust_Block_43::S_421 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_423;
            }
            C2Rust_Block_43::S_423 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_874;
            }
            C2Rust_Block_43::S_431 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_433;
            }
            C2Rust_Block_43::S_433 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_435;
            }
            C2Rust_Block_43::S_435 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_437;
            }
            C2Rust_Block_43::S_437 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_439;
            }
            C2Rust_Block_43::S_439 => {
                if _fa < _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_734;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_448;
                }
            }
            C2Rust_Block_43::S_448 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_450;
            }
            C2Rust_Block_43::S_450 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_452;
            }
            C2Rust_Block_43::S_452 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_454;
            }
            C2Rust_Block_43::S_454 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_456;
            }
            C2Rust_Block_43::S_456 => {
                if _fa == _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_532;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_469;
                }
            }
            C2Rust_Block_43::S_469 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_43 = C2Rust_Block_43::S_471;
            }
            C2Rust_Block_43::S_471 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_473;
            }
            C2Rust_Block_43::S_473 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_479;
            }
            C2Rust_Block_43::S_479 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_481;
            }
            C2Rust_Block_43::S_481 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_487;
            }
            C2Rust_Block_43::S_487 => {
                _pv_4 = 0x2457dd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_489;
            }
            C2Rust_Block_43::S_489 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_491;
            }
            C2Rust_Block_43::S_491 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_497;
            }
            C2Rust_Block_43::S_497 => {
                sub_002453B1();
                c2rust_current_block_43 = C2Rust_Block_43::S_503;
            }
            C2Rust_Block_43::S_503 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_505;
            }
            C2Rust_Block_43::S_505 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_507;
            }
            C2Rust_Block_43::S_507 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_509;
            }
            C2Rust_Block_43::S_509 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_515;
            }
            C2Rust_Block_43::S_515 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_517;
            }
            C2Rust_Block_43::S_517 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_523;
            }
            C2Rust_Block_43::S_523 => {
                if _fa != _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_961;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_532;
                }
            }
            C2Rust_Block_43::S_532 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_534;
            }
            C2Rust_Block_43::S_534 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_536;
            }
            C2Rust_Block_43::S_536 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_538;
            }
            C2Rust_Block_43::S_538 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_540;
            }
            C2Rust_Block_43::S_540 => {
                if _fa == _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_584;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_549;
                }
            }
            C2Rust_Block_43::S_549 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_43 = C2Rust_Block_43::S_551;
            }
            C2Rust_Block_43::S_551 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_553;
            }
            C2Rust_Block_43::S_553 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_555;
            }
            C2Rust_Block_43::S_555 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_558;
            }
            C2Rust_Block_43::S_558 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_560;
            }
            C2Rust_Block_43::S_560 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_562;
            }
            C2Rust_Block_43::S_562 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_566;
            }
            C2Rust_Block_43::S_566 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_568;
            }
            C2Rust_Block_43::S_568 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_570;
            }
            C2Rust_Block_43::S_570 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_43 = C2Rust_Block_43::S_572;
            }
            C2Rust_Block_43::S_572 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_574;
            }
            C2Rust_Block_43::S_574 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_584;
            }
            C2Rust_Block_43::S_584 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_43 = C2Rust_Block_43::S_586;
            }
            C2Rust_Block_43::S_586 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_588;
            }
            C2Rust_Block_43::S_588 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_598;
            }
            C2Rust_Block_43::S_598 => {
                _pv_6 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_600;
            }
            C2Rust_Block_43::S_600 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_602;
            }
            C2Rust_Block_43::S_602 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_612;
            }
            C2Rust_Block_43::S_612 => {
                _pv_7 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_614;
            }
            C2Rust_Block_43::S_614 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_616;
            }
            C2Rust_Block_43::S_616 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_622;
            }
            C2Rust_Block_43::S_622 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_624;
            }
            C2Rust_Block_43::S_624 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_630;
            }
            C2Rust_Block_43::S_630 => {
                _pv_8 = 0x2457fd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_632;
            }
            C2Rust_Block_43::S_632 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_634;
            }
            C2Rust_Block_43::S_634 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_640;
            }
            C2Rust_Block_43::S_640 => {
                sub_0024A3DB();
                c2rust_current_block_43 = C2Rust_Block_43::S_646;
            }
            C2Rust_Block_43::S_646 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_648;
            }
            C2Rust_Block_43::S_648 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_650;
            }
            C2Rust_Block_43::S_650 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_652;
            }
            C2Rust_Block_43::S_652 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_654;
            }
            C2Rust_Block_43::S_654 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_656;
            }
            C2Rust_Block_43::S_656 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_658;
            }
            C2Rust_Block_43::S_658 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_660;
            }
            C2Rust_Block_43::S_660 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_662;
            }
            C2Rust_Block_43::S_662 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_664;
            }
            C2Rust_Block_43::S_664 => {
                if _fa == _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_710;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_673;
                }
            }
            C2Rust_Block_43::S_673 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_675;
            }
            C2Rust_Block_43::S_675 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_677;
            }
            C2Rust_Block_43::S_677 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_679;
            }
            C2Rust_Block_43::S_679 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_681;
            }
            C2Rust_Block_43::S_681 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_683;
            }
            C2Rust_Block_43::S_683 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_685;
            }
            C2Rust_Block_43::S_685 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_687;
            }
            C2Rust_Block_43::S_687 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_689;
            }
            C2Rust_Block_43::S_689 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_691;
            }
            C2Rust_Block_43::S_691 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_693;
            }
            C2Rust_Block_43::S_693 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_695;
            }
            C2Rust_Block_43::S_695 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_697;
            }
            C2Rust_Block_43::S_697 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_699;
            }
            C2Rust_Block_43::S_699 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_701;
            }
            C2Rust_Block_43::S_701 => {
                if _fa >= _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_874;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_710;
                }
            }
            C2Rust_Block_43::S_710 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0x20 as uint32_t,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_712;
            }
            C2Rust_Block_43::S_712 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_714;
            }
            C2Rust_Block_43::S_714 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_716;
            }
            C2Rust_Block_43::S_716 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_43 = C2Rust_Block_43::S_718;
            }
            C2Rust_Block_43::S_718 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_720;
            }
            C2Rust_Block_43::S_720 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_722;
            }
            C2Rust_Block_43::S_722 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_43 = C2Rust_Block_43::S_724;
            }
            C2Rust_Block_43::S_724 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_726;
            }
            C2Rust_Block_43::S_726 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_977;
            }
            C2Rust_Block_43::S_734 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_740;
            }
            C2Rust_Block_43::S_740 => {
                _pv_9 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_43 = C2Rust_Block_43::S_742;
            }
            C2Rust_Block_43::S_742 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_744;
            }
            C2Rust_Block_43::S_744 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_754;
            }
            C2Rust_Block_43::S_754 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_43 = C2Rust_Block_43::S_756;
            }
            C2Rust_Block_43::S_756 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_758;
            }
            C2Rust_Block_43::S_758 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_764;
            }
            C2Rust_Block_43::S_764 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_766;
            }
            C2Rust_Block_43::S_766 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_772;
            }
            C2Rust_Block_43::S_772 => {
                _pv_11 = 0x245824 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_774;
            }
            C2Rust_Block_43::S_774 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_776;
            }
            C2Rust_Block_43::S_776 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_782;
            }
            C2Rust_Block_43::S_782 => {
                sub_0024647B();
                c2rust_current_block_43 = C2Rust_Block_43::S_788;
            }
            C2Rust_Block_43::S_788 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_790;
            }
            C2Rust_Block_43::S_790 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_792;
            }
            C2Rust_Block_43::S_792 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_794;
            }
            C2Rust_Block_43::S_794 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_800;
            }
            C2Rust_Block_43::S_800 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_802;
            }
            C2Rust_Block_43::S_802 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_812;
            }
            C2Rust_Block_43::S_812 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_814;
            }
            C2Rust_Block_43::S_814 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_820;
            }
            C2Rust_Block_43::S_820 => {
                if _fa == _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_961;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_829;
                }
            }
            C2Rust_Block_43::S_829 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_831;
            }
            C2Rust_Block_43::S_831 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_833;
            }
            C2Rust_Block_43::S_833 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_835;
            }
            C2Rust_Block_43::S_835 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_837;
            }
            C2Rust_Block_43::S_837 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_839;
            }
            C2Rust_Block_43::S_839 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_sub(1);
                c2rust_current_block_43 = C2Rust_Block_43::S_841;
            }
            C2Rust_Block_43::S_841 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_843;
            }
            C2Rust_Block_43::S_843 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_845;
            }
            C2Rust_Block_43::S_845 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_847;
            }
            C2Rust_Block_43::S_847 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_849;
            }
            C2Rust_Block_43::S_849 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_851;
            }
            C2Rust_Block_43::S_851 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_853;
            }
            C2Rust_Block_43::S_853 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_855;
            }
            C2Rust_Block_43::S_855 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_857;
            }
            C2Rust_Block_43::S_857 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_859;
            }
            C2Rust_Block_43::S_859 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    > if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_43 = C2Rust_Block_43::S_874;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_868;
                }
            }
            C2Rust_Block_43::S_868 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_874;
            }
            C2Rust_Block_43::S_874 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_876;
            }
            C2Rust_Block_43::S_876 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_878;
            }
            C2Rust_Block_43::S_878 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_880;
            }
            C2Rust_Block_43::S_880 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_882;
            }
            C2Rust_Block_43::S_882 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_884;
            }
            C2Rust_Block_43::S_884 => {
                if _fa != _fb {
                    c2rust_current_block_43 = C2Rust_Block_43::S_174;
                } else {
                    c2rust_current_block_43 = C2Rust_Block_43::S_893;
                }
            }
            C2Rust_Block_43::S_893 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_903;
            }
            C2Rust_Block_43::S_903 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_905;
            }
            C2Rust_Block_43::S_905 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_919;
            }
            C2Rust_Block_43::S_919 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_921;
            }
            C2Rust_Block_43::S_921 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_931;
            }
            C2Rust_Block_43::S_931 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_933;
            }
            C2Rust_Block_43::S_933 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_939;
            }
            C2Rust_Block_43::S_939 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_43 = C2Rust_Block_43::S_945;
            }
            C2Rust_Block_43::S_945 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_43 = C2Rust_Block_43::S_947;
            }
            C2Rust_Block_43::S_947 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_953;
            }
            C2Rust_Block_43::S_953 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_43 = C2Rust_Block_43::S_955;
            }
            C2Rust_Block_43::S_955 => return,
            C2Rust_Block_43::S_961 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_43 = C2Rust_Block_43::S_963;
            }
            C2Rust_Block_43::S_963 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_965;
            }
            C2Rust_Block_43::S_965 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_967;
            }
            C2Rust_Block_43::S_967 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_esi));
                c2rust_current_block_43 = C2Rust_Block_43::S_969;
            }
            C2Rust_Block_43::S_969 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_971;
            }
            C2Rust_Block_43::S_971 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_977;
            }
            C2Rust_Block_43::S_977 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_979;
            }
            C2Rust_Block_43::S_979 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_981;
            }
            C2Rust_Block_43::S_981 => {
                _fas = _fa as int32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_984;
            }
            C2Rust_Block_43::S_984 => {
                _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_986;
            }
            C2Rust_Block_43::S_986 => {
                (*__gamepkg_tls_g_eax) = _dividend_0
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_988;
            }
            C2Rust_Block_43::S_988 => {
                (*__gamepkg_tls_g_edx) = _dividend_0
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_43 = C2Rust_Block_43::S_903;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245861() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x3740a8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24586d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x245875 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024516A();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_8: uint32_t = 0x24588b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_0024574A();
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x24589a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_002458A3();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_10: uint32_t = 0x2458a2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002458A3() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2458ab as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002458AD() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _d_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_0: uint32_t = 0;
    let mut _i_1: uint32_t = 0;
    let mut _i_2: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _dividend_0: uint64_t = 0;
    enum C2Rust_Block_49 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_58,
        S_60,
        S_62,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_88,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_111,
        S_113,
        S_115,
        S_127,
        S_129,
        S_131,
        S_137,
        S_139,
        S_141,
        S_143,
        S_145,
        S_147,
        S_156,
        S_158,
        S_166,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_199,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_225,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_241,
        S_243,
        S_245,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_259,
        S_261,
        S_263,
        S_265,
        S_269,
        S_272,
        S_273,
        S_274,
        S_275,
        S_286,
        S_288,
        S_293,
        S_296,
        S_297,
        S_298,
        S_299,
        S_306,
        S_308,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_328,
        S_330,
        S_332,
        S_334,
        S_338,
        S_341,
        S_342,
        S_343,
        S_344,
        S_355,
        S_357,
        S_362,
        S_365,
        S_366,
        S_367,
        S_368,
        S_375,
        S_377,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_461,
        S_463,
        S_465,
        S_468,
        S_470,
        S_472,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_496,
        S_498,
        S_500,
        S_510,
        S_512,
        S_514,
        S_524,
        S_526,
        S_528,
        S_534,
        S_536,
        S_542,
        S_544,
        S_546,
        S_552,
        S_558,
        S_560,
        S_562,
        S_564,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_632,
        S_634,
        S_636,
        S_642,
        S_644,
        S_650,
        S_652,
        S_654,
        S_660,
        S_666,
        S_668,
        S_670,
        S_672,
        S_678,
        S_680,
        S_686,
        S_695,
        S_697,
        S_699,
        S_701,
        S_703,
        S_705,
        S_707,
        S_709,
        S_711,
        S_713,
        S_715,
        S_717,
        S_723,
        S_729,
        S_731,
        S_733,
        S_735,
        S_737,
        S_746,
        S_756,
        S_758,
        S_772,
        S_774,
        S_784,
        S_786,
        S_792,
        S_798,
        S_800,
        S_806,
        S_808,
        S_814,
        S_816,
        S_818,
        S_824,
        S_826,
        S_828,
        S_830,
        S_832,
        S_834,
        S_836,
        S_838,
        S_840,
        S_843,
        S_845,
        S_847,
        S_857,
        S_859,
        S_861,
    }
    let mut c2rust_current_block_49: C2Rust_Block_49;
    c2rust_current_block_49 = C2Rust_Block_49::S_0;
    loop {
        match c2rust_current_block_49 {
            C2Rust_Block_49::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_2;
            }
            C2Rust_Block_49::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_49 = C2Rust_Block_49::S_4;
            }
            C2Rust_Block_49::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_6;
            }
            C2Rust_Block_49::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_8;
            }
            C2Rust_Block_49::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_26;
            }
            C2Rust_Block_49::S_26 => {
                _pv = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_28;
            }
            C2Rust_Block_49::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_30;
            }
            C2Rust_Block_49::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_36;
            }
            C2Rust_Block_49::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_49 = C2Rust_Block_49::S_38;
            }
            C2Rust_Block_49::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_40;
            }
            C2Rust_Block_49::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_42;
            }
            C2Rust_Block_49::S_42 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_44;
            }
            C2Rust_Block_49::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_46;
            }
            C2Rust_Block_49::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_48;
            }
            C2Rust_Block_49::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_50;
            }
            C2Rust_Block_49::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_52;
            }
            C2Rust_Block_49::S_52 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_58;
            }
            C2Rust_Block_49::S_58 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_60;
            }
            C2Rust_Block_49::S_60 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_62;
            }
            C2Rust_Block_49::S_62 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_68;
            }
            C2Rust_Block_49::S_68 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_70;
            }
            C2Rust_Block_49::S_70 => {
                (*__gamepkg_tls_g_esi) = ((*__gamepkg_tls_g_esi) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_72;
            }
            C2Rust_Block_49::S_72 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_74;
            }
            C2Rust_Block_49::S_74 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_76;
            }
            C2Rust_Block_49::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_78;
            }
            C2Rust_Block_49::S_78 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_84;
            }
            C2Rust_Block_49::S_84 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_86;
            }
            C2Rust_Block_49::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_88;
            }
            C2Rust_Block_49::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_94;
            }
            C2Rust_Block_49::S_94 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_96;
            }
            C2Rust_Block_49::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_98;
            }
            C2Rust_Block_49::S_98 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_100;
            }
            C2Rust_Block_49::S_100 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_102;
            }
            C2Rust_Block_49::S_102 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_127;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_111;
                }
            }
            C2Rust_Block_49::S_111 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_113;
            }
            C2Rust_Block_49::S_113 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_115;
            }
            C2Rust_Block_49::S_115 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_772;
            }
            C2Rust_Block_49::S_127 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_49 = C2Rust_Block_49::S_129;
            }
            C2Rust_Block_49::S_129 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_131;
            }
            C2Rust_Block_49::S_131 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_137;
            }
            C2Rust_Block_49::S_137 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_139;
            }
            C2Rust_Block_49::S_139 => {
                _fa = (::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x10c as ::core::ffi::c_int) as uint32_t
                    & 0xffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_141;
            }
            C2Rust_Block_49::S_141 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_143;
            }
            C2Rust_Block_49::S_143 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_145;
            }
            C2Rust_Block_49::S_145 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_147;
            }
            C2Rust_Block_49::S_147 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_166;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_156;
                }
            }
            C2Rust_Block_49::S_156 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_158;
            }
            C2Rust_Block_49::S_158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_172;
            }
            C2Rust_Block_49::S_166 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1000 as uint32_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_172;
            }
            C2Rust_Block_49::S_172 => {
                _fa = (::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x10c as ::core::ffi::c_int) as uint32_t
                    & 0xffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_174;
            }
            C2Rust_Block_49::S_174 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_176;
            }
            C2Rust_Block_49::S_176 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_178;
            }
            C2Rust_Block_49::S_178 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_180;
            }
            C2Rust_Block_49::S_180 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_425;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_189;
                }
            }
            C2Rust_Block_49::S_189 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_191;
            }
            C2Rust_Block_49::S_191 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_193;
            }
            C2Rust_Block_49::S_193 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_195;
            }
            C2Rust_Block_49::S_195 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_197;
            }
            C2Rust_Block_49::S_197 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_199;
            }
            C2Rust_Block_49::S_199 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_425;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_208;
                }
            }
            C2Rust_Block_49::S_208 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_210;
            }
            C2Rust_Block_49::S_210 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_212;
            }
            C2Rust_Block_49::S_212 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_214;
            }
            C2Rust_Block_49::S_214 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_216;
            }
            C2Rust_Block_49::S_216 => {
                if _fa >= _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_231;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_225;
                }
            }
            C2Rust_Block_49::S_225 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_231;
            }
            C2Rust_Block_49::S_231 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_233;
            }
            C2Rust_Block_49::S_233 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_235;
            }
            C2Rust_Block_49::S_235 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_237;
            }
            C2Rust_Block_49::S_237 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_239;
            }
            C2Rust_Block_49::S_239 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_241;
            }
            C2Rust_Block_49::S_241 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_243;
            }
            C2Rust_Block_49::S_243 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_245;
            }
            C2Rust_Block_49::S_245 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_247;
            }
            C2Rust_Block_49::S_247 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_249;
            }
            C2Rust_Block_49::S_249 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_251;
            }
            C2Rust_Block_49::S_251 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_253;
            }
            C2Rust_Block_49::S_253 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_255;
            }
            C2Rust_Block_49::S_255 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_49 = C2Rust_Block_49::S_259;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_293;
                }
            }
            C2Rust_Block_49::S_259 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_261;
            }
            C2Rust_Block_49::S_261 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_263;
            }
            C2Rust_Block_49::S_263 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_49 = C2Rust_Block_49::S_265;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_269;
                }
            }
            C2Rust_Block_49::S_265 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_286;
            }
            C2Rust_Block_49::S_269 => {
                _i = 0;
                c2rust_current_block_49 = C2Rust_Block_49::S_272;
            }
            C2Rust_Block_49::S_272 => {
                _i = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_273;
            }
            C2Rust_Block_49::S_273 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_49 = C2Rust_Block_49::S_274;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_286;
                }
            }
            C2Rust_Block_49::S_274 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_275;
            }
            C2Rust_Block_49::S_275 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_273;
            }
            C2Rust_Block_49::S_286 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_288;
            }
            C2Rust_Block_49::S_288 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_314;
            }
            C2Rust_Block_49::S_293 => {
                _i_0 = 0;
                c2rust_current_block_49 = C2Rust_Block_49::S_296;
            }
            C2Rust_Block_49::S_296 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_297;
            }
            C2Rust_Block_49::S_297 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_49 = C2Rust_Block_49::S_298;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_306;
                }
            }
            C2Rust_Block_49::S_298 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_299;
            }
            C2Rust_Block_49::S_299 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_297;
            }
            C2Rust_Block_49::S_306 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_308;
            }
            C2Rust_Block_49::S_308 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_314;
            }
            C2Rust_Block_49::S_314 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_316;
            }
            C2Rust_Block_49::S_316 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_49 = C2Rust_Block_49::S_318;
            }
            C2Rust_Block_49::S_318 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_320;
            }
            C2Rust_Block_49::S_320 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_322;
            }
            C2Rust_Block_49::S_322 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_324;
            }
            C2Rust_Block_49::S_324 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_49 = C2Rust_Block_49::S_328;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_362;
                }
            }
            C2Rust_Block_49::S_328 => {
                _d_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_330;
            }
            C2Rust_Block_49::S_330 => {
                _n_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_332;
            }
            C2Rust_Block_49::S_332 => {
                if _d_0.offset(_n_0 as isize) <= _s_0
                    || _s_0.offset(_n_0 as isize) <= _d_0
                {
                    c2rust_current_block_49 = C2Rust_Block_49::S_334;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_338;
                }
            }
            C2Rust_Block_49::S_334 => {
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_355;
            }
            C2Rust_Block_49::S_338 => {
                _i_1 = 0;
                c2rust_current_block_49 = C2Rust_Block_49::S_341;
            }
            C2Rust_Block_49::S_341 => {
                _i_1 = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_342;
            }
            C2Rust_Block_49::S_342 => {
                if _i_1 < _n_0 {
                    c2rust_current_block_49 = C2Rust_Block_49::S_343;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_355;
                }
            }
            C2Rust_Block_49::S_343 => {
                *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                c2rust_current_block_49 = C2Rust_Block_49::S_344;
            }
            C2Rust_Block_49::S_344 => {
                _i_1 = _i_1.wrapping_add(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_342;
            }
            C2Rust_Block_49::S_355 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_49 = C2Rust_Block_49::S_357;
            }
            C2Rust_Block_49::S_357 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_49 = C2Rust_Block_49::S_383;
            }
            C2Rust_Block_49::S_362 => {
                _i_2 = 0;
                c2rust_current_block_49 = C2Rust_Block_49::S_365;
            }
            C2Rust_Block_49::S_365 => {
                _i_2 = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_366;
            }
            C2Rust_Block_49::S_366 => {
                if _i_2 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_49 = C2Rust_Block_49::S_367;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_375;
                }
            }
            C2Rust_Block_49::S_367 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_368;
            }
            C2Rust_Block_49::S_368 => {
                _i_2 = _i_2.wrapping_add(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_366;
            }
            C2Rust_Block_49::S_375 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_49 = C2Rust_Block_49::S_377;
            }
            C2Rust_Block_49::S_377 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_49 = C2Rust_Block_49::S_383;
            }
            C2Rust_Block_49::S_383 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_385;
            }
            C2Rust_Block_49::S_385 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_387;
            }
            C2Rust_Block_49::S_387 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_389;
            }
            C2Rust_Block_49::S_389 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_391;
            }
            C2Rust_Block_49::S_391 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_393;
            }
            C2Rust_Block_49::S_393 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_395;
            }
            C2Rust_Block_49::S_395 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_397;
            }
            C2Rust_Block_49::S_397 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_399;
            }
            C2Rust_Block_49::S_399 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ebx) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_401;
            }
            C2Rust_Block_49::S_401 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_403;
            }
            C2Rust_Block_49::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_405;
            }
            C2Rust_Block_49::S_405 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_407;
            }
            C2Rust_Block_49::S_407 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_409;
            }
            C2Rust_Block_49::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_411;
            }
            C2Rust_Block_49::S_411 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_413;
            }
            C2Rust_Block_49::S_413 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_415;
            }
            C2Rust_Block_49::S_415 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_417;
            }
            C2Rust_Block_49::S_417 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_729;
            }
            C2Rust_Block_49::S_425 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_427;
            }
            C2Rust_Block_49::S_427 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_429;
            }
            C2Rust_Block_49::S_429 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_431;
            }
            C2Rust_Block_49::S_431 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_433;
            }
            C2Rust_Block_49::S_433 => {
                if _fa < _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_632;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_442;
                }
            }
            C2Rust_Block_49::S_442 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_444;
            }
            C2Rust_Block_49::S_444 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_446;
            }
            C2Rust_Block_49::S_446 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_448;
            }
            C2Rust_Block_49::S_448 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_450;
            }
            C2Rust_Block_49::S_450 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_452;
            }
            C2Rust_Block_49::S_452 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_496;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_461;
                }
            }
            C2Rust_Block_49::S_461 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_463;
            }
            C2Rust_Block_49::S_463 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_465;
            }
            C2Rust_Block_49::S_465 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_468;
            }
            C2Rust_Block_49::S_468 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_470;
            }
            C2Rust_Block_49::S_470 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_472;
            }
            C2Rust_Block_49::S_472 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_476;
            }
            C2Rust_Block_49::S_476 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_478;
            }
            C2Rust_Block_49::S_478 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_480;
            }
            C2Rust_Block_49::S_480 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_482;
            }
            C2Rust_Block_49::S_482 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_49 = C2Rust_Block_49::S_484;
            }
            C2Rust_Block_49::S_484 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_486;
            }
            C2Rust_Block_49::S_486 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_496;
            }
            C2Rust_Block_49::S_496 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_498;
            }
            C2Rust_Block_49::S_498 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_500;
            }
            C2Rust_Block_49::S_500 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_510;
            }
            C2Rust_Block_49::S_510 => {
                _pv_4 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_512;
            }
            C2Rust_Block_49::S_512 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_514;
            }
            C2Rust_Block_49::S_514 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_524;
            }
            C2Rust_Block_49::S_524 => {
                _pv_5 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_526;
            }
            C2Rust_Block_49::S_526 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_528;
            }
            C2Rust_Block_49::S_528 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_534;
            }
            C2Rust_Block_49::S_534 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_536;
            }
            C2Rust_Block_49::S_536 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_542;
            }
            C2Rust_Block_49::S_542 => {
                _pv_6 = 0x24594f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_544;
            }
            C2Rust_Block_49::S_544 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_546;
            }
            C2Rust_Block_49::S_546 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_552;
            }
            C2Rust_Block_49::S_552 => {
                sub_0024A7F8();
                c2rust_current_block_49 = C2Rust_Block_49::S_558;
            }
            C2Rust_Block_49::S_558 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_560;
            }
            C2Rust_Block_49::S_560 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_562;
            }
            C2Rust_Block_49::S_562 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_564;
            }
            C2Rust_Block_49::S_564 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_566;
            }
            C2Rust_Block_49::S_566 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_568;
            }
            C2Rust_Block_49::S_568 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_570;
            }
            C2Rust_Block_49::S_570 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_572;
            }
            C2Rust_Block_49::S_572 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_574;
            }
            C2Rust_Block_49::S_574 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_576;
            }
            C2Rust_Block_49::S_576 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_814;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_585;
                }
            }
            C2Rust_Block_49::S_585 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_587;
            }
            C2Rust_Block_49::S_587 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_589;
            }
            C2Rust_Block_49::S_589 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_591;
            }
            C2Rust_Block_49::S_591 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_593;
            }
            C2Rust_Block_49::S_593 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_857;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_602;
                }
            }
            C2Rust_Block_49::S_602 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_604;
            }
            C2Rust_Block_49::S_604 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_606;
            }
            C2Rust_Block_49::S_606 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_49 = C2Rust_Block_49::S_608;
            }
            C2Rust_Block_49::S_608 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_610;
            }
            C2Rust_Block_49::S_610 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_612;
            }
            C2Rust_Block_49::S_612 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_614;
            }
            C2Rust_Block_49::S_614 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_616;
            }
            C2Rust_Block_49::S_616 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_618;
            }
            C2Rust_Block_49::S_618 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_620;
            }
            C2Rust_Block_49::S_620 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_723;
            }
            C2Rust_Block_49::S_632 => {
                _pv_7 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_49 = C2Rust_Block_49::S_634;
            }
            C2Rust_Block_49::S_634 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_636;
            }
            C2Rust_Block_49::S_636 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_642;
            }
            C2Rust_Block_49::S_642 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_644;
            }
            C2Rust_Block_49::S_644 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_650;
            }
            C2Rust_Block_49::S_650 => {
                _pv_8 = 0x245968 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_652;
            }
            C2Rust_Block_49::S_652 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_654;
            }
            C2Rust_Block_49::S_654 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_660;
            }
            C2Rust_Block_49::S_660 => {
                sub_0024A540();
                c2rust_current_block_49 = C2Rust_Block_49::S_666;
            }
            C2Rust_Block_49::S_666 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_668;
            }
            C2Rust_Block_49::S_668 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_670;
            }
            C2Rust_Block_49::S_670 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_672;
            }
            C2Rust_Block_49::S_672 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_678;
            }
            C2Rust_Block_49::S_678 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_680;
            }
            C2Rust_Block_49::S_680 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_686;
            }
            C2Rust_Block_49::S_686 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_824;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_695;
                }
            }
            C2Rust_Block_49::S_695 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_697;
            }
            C2Rust_Block_49::S_697 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_699;
            }
            C2Rust_Block_49::S_699 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_701;
            }
            C2Rust_Block_49::S_701 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_703;
            }
            C2Rust_Block_49::S_703 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_705;
            }
            C2Rust_Block_49::S_705 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_707;
            }
            C2Rust_Block_49::S_707 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_709;
            }
            C2Rust_Block_49::S_709 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_711;
            }
            C2Rust_Block_49::S_711 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_713;
            }
            C2Rust_Block_49::S_713 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_715;
            }
            C2Rust_Block_49::S_715 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_717;
            }
            C2Rust_Block_49::S_717 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_723;
            }
            C2Rust_Block_49::S_723 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_729;
            }
            C2Rust_Block_49::S_729 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_731;
            }
            C2Rust_Block_49::S_731 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_733;
            }
            C2Rust_Block_49::S_733 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_735;
            }
            C2Rust_Block_49::S_735 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_737;
            }
            C2Rust_Block_49::S_737 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_172;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_746;
                }
            }
            C2Rust_Block_49::S_746 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_756;
            }
            C2Rust_Block_49::S_756 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_758;
            }
            C2Rust_Block_49::S_758 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_772;
            }
            C2Rust_Block_49::S_772 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_774;
            }
            C2Rust_Block_49::S_774 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_784;
            }
            C2Rust_Block_49::S_784 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_786;
            }
            C2Rust_Block_49::S_786 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_792;
            }
            C2Rust_Block_49::S_792 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_49 = C2Rust_Block_49::S_798;
            }
            C2Rust_Block_49::S_798 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_800;
            }
            C2Rust_Block_49::S_800 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_806;
            }
            C2Rust_Block_49::S_806 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_808;
            }
            C2Rust_Block_49::S_808 => return,
            C2Rust_Block_49::S_814 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0x10 as uint32_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_816;
            }
            C2Rust_Block_49::S_816 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_818;
            }
            C2Rust_Block_49::S_818 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_824;
            }
            C2Rust_Block_49::S_824 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_826;
            }
            C2Rust_Block_49::S_826 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_828;
            }
            C2Rust_Block_49::S_828 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_830;
            }
            C2Rust_Block_49::S_830 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edi));
                c2rust_current_block_49 = C2Rust_Block_49::S_832;
            }
            C2Rust_Block_49::S_832 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_834;
            }
            C2Rust_Block_49::S_834 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_836;
            }
            C2Rust_Block_49::S_836 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_838;
            }
            C2Rust_Block_49::S_838 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_840;
            }
            C2Rust_Block_49::S_840 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_843;
            }
            C2Rust_Block_49::S_843 => {
                _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_845;
            }
            C2Rust_Block_49::S_845 => {
                (*__gamepkg_tls_g_eax) = _dividend_0
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_847;
            }
            C2Rust_Block_49::S_847 => {
                (*__gamepkg_tls_g_edx) = _dividend_0
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_756;
            }
            C2Rust_Block_49::S_857 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0x20 as uint32_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_859;
            }
            C2Rust_Block_49::S_859 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_861;
            }
            C2Rust_Block_49::S_861 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_824;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002459A5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x3740b8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x2459b1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x2459b9 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024516A();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_8: uint32_t = 0x2459cf as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_002458AD();
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x2459de as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_002459E7();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_10: uint32_t = 0x2459e6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002459E7() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x2459ef as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002451BC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002459F1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 0x83 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_289: {
        if _fa == _fb {
            break 's_289;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x245a06 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_002453B1();
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        let mut _pv_4: uint32_t = 0x245a0e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_0024A9BF();
        let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x245a16 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_0024A924();
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_214: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                >= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_214;
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | 0xffffffff as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_289;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_289;
        }
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x245a2f as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_002440A5();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245A3D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x3740c8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x245a49 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 0x40 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_115: {
        's_105: {
            if _fa != _fb {
                break 's_105;
            }
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_4: uint32_t = 0x245a69 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_0024516A();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_6: uint32_t = 0x245a74 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_002459F1();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0xffffffff as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_7: uint32_t = 0x245a81 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            sub_00245A86();
            break 's_115;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_2: uint32_t = 0x245a62 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00245A83() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00245A86();
}
