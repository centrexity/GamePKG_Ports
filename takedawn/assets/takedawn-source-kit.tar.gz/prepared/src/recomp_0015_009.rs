extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298220() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298240() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298260() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298280() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002982A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002982C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002982E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298300() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298320() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298340() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298360() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298380() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002983A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x396eb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002983C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x398cc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002983E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298400() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298420() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298440() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298460() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298480() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002984A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002984C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002984E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298500() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298520() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298550() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298580() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002985A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002985C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x35bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002985E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298600() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298620() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298640() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298660() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298680() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e9d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002986A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e9ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002986C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eabc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002986E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eadc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298700() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eaac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298720() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298740() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eac0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298760() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298780() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56eac0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eafc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002987A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eae4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002987C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eb18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002987E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eb00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298800() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56eb00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eb14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298820() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56ea58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298840() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eb08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00298860() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56ea6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56eaa8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
