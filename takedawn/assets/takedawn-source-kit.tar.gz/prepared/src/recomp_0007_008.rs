extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_00011000();
    fn sub_0024DAD2();
    fn sub_0024DAEA();
    fn sub_0024DB2A();
    fn sub_0024DBCD();
    fn sub_0024DC3A();
    fn sub_0024DC5D();
    fn sub_0024DC89();
    fn sub_0024DCB5();
    fn sub_0024DCE9();
    fn sub_0024DD1D();
    fn sub_0024DD51();
    fn sub_0024DDA4();
    fn sub_0024EFC3();
    fn sub_0024EFFB();
    fn sub_0024F109();
    fn sub_0024F279();
    fn sub_0024F298();
    fn sub_0024F30D();
    fn sub_0024F332();
    fn sub_0024F767();
    fn sub_0024F7F6();
    fn sub_0024F99F();
    fn sub_0024FAAF();
    fn sub_0024FADC();
    fn sub_00250B13();
    fn sub_00250B2D();
    fn sub_00250D19();
    fn sub_00363D4E();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn sub_0024DDF7() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    enum C2Rust_Block {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_80,
        S_83,
        S_86,
        S_92,
        S_94,
        S_96,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_117,
        S_119,
        S_121,
        S_129,
        S_131,
        S_133,
        S_137,
        S_139,
        S_143,
        S_149,
        S_156,
        S_158,
        S_160,
        S_179,
        S_185,
        S_187,
        S_189,
        S_195,
        S_198,
        S_204,
        S_206,
        S_208,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_229,
        S_231,
        S_233,
        S_241,
        S_243,
        S_245,
        S_249,
        S_251,
        S_255,
        S_261,
        S_268,
        S_270,
        S_272,
        S_294,
        S_296,
        S_298,
        S_304,
        S_310,
        S_312,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_345,
        S_347,
        S_349,
        S_359,
        S_361,
        S_363,
        S_369,
        S_375,
        S_377,
        S_379,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_412,
        S_415,
        S_418,
        S_424,
        S_426,
        S_428,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_449,
        S_451,
        S_453,
        S_461,
        S_463,
        S_465,
        S_469,
        S_471,
        S_475,
        S_481,
        S_488,
        S_490,
        S_492,
        S_510,
        S_516,
        S_518,
        S_520,
        S_526,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_561,
        S_563,
        S_565,
        S_575,
        S_577,
        S_579,
        S_585,
        S_591,
        S_597,
        S_599,
        S_605,
        S_607,
        S_617,
        S_619,
        S_629,
        S_631,
        S_641,
        S_643,
        S_649,
        S_651,
        S_653,
    }
    let mut c2rust_current_block: C2Rust_Block;
    c2rust_current_block = C2Rust_Block::S_0;
    loop {
        match c2rust_current_block {
            C2Rust_Block::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block = C2Rust_Block::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block = C2Rust_Block::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block = C2Rust_Block::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block = C2Rust_Block::S_28;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block = C2Rust_Block::S_30;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_32;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block = C2Rust_Block::S_42;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block = C2Rust_Block::S_44;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_46;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block = C2Rust_Block::S_56;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block = C2Rust_Block::S_58;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_60;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block = C2Rust_Block::S_70;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block = C2Rust_Block::S_72;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_74;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block = C2Rust_Block::S_80;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block = C2Rust_Block::S_83;
                };
                {
                    _icall_esp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block = C2Rust_Block::S_86;
                };
                {
                    _icall_target = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_92;
                };
                {
                    _pv_3 = 0x24de03 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_94;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_96;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block = C2Rust_Block::S_106;
                };
                {
                    _va = _icall_target;
                    c2rust_current_block = C2Rust_Block::S_108;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va,
                    );
                    c2rust_current_block = C2Rust_Block::S_110;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block = C2Rust_Block::S_112;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block = C2Rust_Block::S_114;
                };
                {
                    if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                    {
                        c2rust_current_block = C2Rust_Block::S_117;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_129;
                    }
                };
            }
            C2Rust_Block::S_117 => {
                {
                    recomp_icall_not_code_log(_va);
                    c2rust_current_block = C2Rust_Block::S_119;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block = C2Rust_Block::S_121;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_179;
                };
            }
            C2Rust_Block::S_129 => {
                {
                    _fn = recomp_lookup_manual(_va);
                    c2rust_current_block = C2Rust_Block::S_131;
                };
                {
                    if _fn.is_none() {
                        c2rust_current_block = C2Rust_Block::S_133;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_137;
                    }
                };
            }
            C2Rust_Block::S_133 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block = C2Rust_Block::S_137;
            }
            C2Rust_Block::S_137 => {
                if _fn.is_none() {
                    c2rust_current_block = C2Rust_Block::S_139;
                } else {
                    c2rust_current_block = C2Rust_Block::S_143;
                }
            }
            C2Rust_Block::S_139 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block = C2Rust_Block::S_143;
            }
            C2Rust_Block::S_143 => {
                if _fn.is_some() {
                    c2rust_current_block = C2Rust_Block::S_149;
                } else {
                    c2rust_current_block = C2Rust_Block::S_156;
                }
            }
            C2Rust_Block::S_149 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block = C2Rust_Block::S_179;
            }
            C2Rust_Block::S_156 => {
                {
                    recomp_icall_fail_log(_va);
                    c2rust_current_block = C2Rust_Block::S_158;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block = C2Rust_Block::S_160;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_179;
                };
            }
            C2Rust_Block::S_179 => {
                {
                    _icall_esp_0 = (*__gamepkg_tls_g_esp);
                    c2rust_current_block = C2Rust_Block::S_185;
                };
                {
                    _pv_4 = 0x420630 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_187;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_189;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block = C2Rust_Block::S_195;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                        & 0xffffff00 as uint32_t
                        | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_198;
                };
                {
                    _icall_target_0 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_204;
                };
                {
                    _pv_5 = 0x24de10 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_206;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_208;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block = C2Rust_Block::S_218;
                };
                {
                    _va_0 = _icall_target_0;
                    c2rust_current_block = C2Rust_Block::S_220;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va_0,
                    );
                    c2rust_current_block = C2Rust_Block::S_222;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block = C2Rust_Block::S_224;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block = C2Rust_Block::S_226;
                };
                {
                    if !(_va_0 >= 0xfe000000 as uint32_t
                        || g_xbox_code_hi == 0 as uint32_t
                        || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                    {
                        c2rust_current_block = C2Rust_Block::S_229;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_241;
                    }
                };
            }
            C2Rust_Block::S_229 => {
                {
                    recomp_icall_not_code_log(_va_0);
                    c2rust_current_block = C2Rust_Block::S_231;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    c2rust_current_block = C2Rust_Block::S_233;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_294;
                };
            }
            C2Rust_Block::S_241 => {
                {
                    _fn_0 = recomp_lookup_manual(_va_0);
                    c2rust_current_block = C2Rust_Block::S_243;
                };
                {
                    if _fn_0.is_none() {
                        c2rust_current_block = C2Rust_Block::S_245;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_249;
                    }
                };
            }
            C2Rust_Block::S_245 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block = C2Rust_Block::S_249;
            }
            C2Rust_Block::S_249 => {
                if _fn_0.is_none() {
                    c2rust_current_block = C2Rust_Block::S_251;
                } else {
                    c2rust_current_block = C2Rust_Block::S_255;
                }
            }
            C2Rust_Block::S_251 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block = C2Rust_Block::S_255;
            }
            C2Rust_Block::S_255 => {
                if _fn_0.is_some() {
                    c2rust_current_block = C2Rust_Block::S_261;
                } else {
                    c2rust_current_block = C2Rust_Block::S_268;
                }
            }
            C2Rust_Block::S_261 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block = C2Rust_Block::S_294;
            }
            C2Rust_Block::S_268 => {
                {
                    recomp_icall_fail_log(_va_0);
                    c2rust_current_block = C2Rust_Block::S_270;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    c2rust_current_block = C2Rust_Block::S_272;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_294;
                };
            }
            C2Rust_Block::S_294 => {
                {
                    _pv_6 = 4 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_296;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_298;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block = C2Rust_Block::S_304;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(0x28 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_310;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_312;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_322;
                };
            }
            C2Rust_Block::S_322 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_324;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_326;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_328;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block = C2Rust_Block::S_330;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block = C2Rust_Block::S_332;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block = C2Rust_Block::S_385;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_345;
                    }
                };
            }
            C2Rust_Block::S_345 => {
                {
                    _pv_7 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x374e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_347;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_349;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block = C2Rust_Block::S_359;
                };
                {
                    _pv_8 = 0x24de27 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_361;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_363;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block = C2Rust_Block::S_369;
                };
                {
                    sub_0024F298();
                    c2rust_current_block = C2Rust_Block::S_375;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) & 0 as uint32_t,
                    );
                    c2rust_current_block = C2Rust_Block::S_377;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_379;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block = C2Rust_Block::S_385;
                };
            }
            C2Rust_Block::S_385 => {
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_387;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block = C2Rust_Block::S_389;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_391;
                };
                {
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_393;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block = C2Rust_Block::S_395;
                };
                {
                    ebp = ebp.wrapping_sub(1);
                    c2rust_current_block = C2Rust_Block::S_397;
                };
                {
                    _fa = ebp & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_399;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block = C2Rust_Block::S_401;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_403;
                };
                {
                    if _fa != 0 as uint32_t {
                        c2rust_current_block = C2Rust_Block::S_322;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_412;
                    }
                };
            }
            C2Rust_Block::S_412 => {
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        & 0xffffff00 as uint32_t
                        | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                            as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_415;
                };
                {
                    _icall_esp_1 = (*__gamepkg_tls_g_esp);
                    c2rust_current_block = C2Rust_Block::S_418;
                };
                {
                    _icall_target_1 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_424;
                };
                {
                    _pv_9 = 0x24de38 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_426;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_428;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block = C2Rust_Block::S_438;
                };
                {
                    _va_1 = _icall_target_1;
                    c2rust_current_block = C2Rust_Block::S_440;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va_1,
                    );
                    c2rust_current_block = C2Rust_Block::S_442;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block = C2Rust_Block::S_444;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block = C2Rust_Block::S_446;
                };
                {
                    if !(_va_1 >= 0xfe000000 as uint32_t
                        || g_xbox_code_hi == 0 as uint32_t
                        || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                    {
                        c2rust_current_block = C2Rust_Block::S_449;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_461;
                    }
                };
            }
            C2Rust_Block::S_449 => {
                {
                    recomp_icall_not_code_log(_va_1);
                    c2rust_current_block = C2Rust_Block::S_451;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_1;
                    c2rust_current_block = C2Rust_Block::S_453;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_510;
                };
            }
            C2Rust_Block::S_461 => {
                {
                    _fn_1 = recomp_lookup_manual(_va_1);
                    c2rust_current_block = C2Rust_Block::S_463;
                };
                {
                    if _fn_1.is_none() {
                        c2rust_current_block = C2Rust_Block::S_465;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_469;
                    }
                };
            }
            C2Rust_Block::S_465 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block = C2Rust_Block::S_469;
            }
            C2Rust_Block::S_469 => {
                if _fn_1.is_none() {
                    c2rust_current_block = C2Rust_Block::S_471;
                } else {
                    c2rust_current_block = C2Rust_Block::S_475;
                }
            }
            C2Rust_Block::S_471 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block = C2Rust_Block::S_475;
            }
            C2Rust_Block::S_475 => {
                if _fn_1.is_some() {
                    c2rust_current_block = C2Rust_Block::S_481;
                } else {
                    c2rust_current_block = C2Rust_Block::S_488;
                }
            }
            C2Rust_Block::S_481 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block = C2Rust_Block::S_510;
            }
            C2Rust_Block::S_488 => {
                {
                    recomp_icall_fail_log(_va_1);
                    c2rust_current_block = C2Rust_Block::S_490;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_1;
                    c2rust_current_block = C2Rust_Block::S_492;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_510;
                };
            }
            C2Rust_Block::S_510 => {
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                    c2rust_current_block = C2Rust_Block::S_516;
                };
                {
                    _pv_10 = 0x24de3f as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_518;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_520;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block = C2Rust_Block::S_526;
                };
                {
                    sub_0024DD51();
                    c2rust_current_block = C2Rust_Block::S_532;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_534;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_536;
                };
                {
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_538;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block = C2Rust_Block::S_540;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_542;
                };
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_544;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block = C2Rust_Block::S_546;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block = C2Rust_Block::S_548;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block = C2Rust_Block::S_597;
                    } else {
                        c2rust_current_block = C2Rust_Block::S_561;
                    }
                };
            }
            C2Rust_Block::S_561 => {
                {
                    _pv_11 = 3 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_563;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_565;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block = C2Rust_Block::S_575;
                };
                {
                    _pv_12 = 0x24de4f as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block = C2Rust_Block::S_577;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_579;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block = C2Rust_Block::S_585;
                };
                {
                    sub_0024DDA4();
                    c2rust_current_block = C2Rust_Block::S_591;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block = C2Rust_Block::S_597;
                };
            }
            C2Rust_Block::S_597 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x42068c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block = C2Rust_Block::S_599;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block = C2Rust_Block::S_605;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_607;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_617;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_619;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_629;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_631;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_641;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block = C2Rust_Block::S_643;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block = C2Rust_Block::S_649;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block = C2Rust_Block::S_651;
                };
                {
                    sub_0024FAAF();
                    c2rust_current_block = C2Rust_Block::S_653;
                };
                return;
            }
            C2Rust_Block::S_106
            | C2Rust_Block::S_108
            | C2Rust_Block::S_110
            | C2Rust_Block::S_112
            | C2Rust_Block::S_114
            | C2Rust_Block::S_119
            | C2Rust_Block::S_121
            | C2Rust_Block::S_131
            | C2Rust_Block::S_158
            | C2Rust_Block::S_160
            | C2Rust_Block::S_18
            | C2Rust_Block::S_185
            | C2Rust_Block::S_187
            | C2Rust_Block::S_189
            | C2Rust_Block::S_195
            | C2Rust_Block::S_198
            | C2Rust_Block::S_2
            | C2Rust_Block::S_204
            | C2Rust_Block::S_206
            | C2Rust_Block::S_208
            | C2Rust_Block::S_218
            | C2Rust_Block::S_220
            | C2Rust_Block::S_222
            | C2Rust_Block::S_224
            | C2Rust_Block::S_226
            | C2Rust_Block::S_231
            | C2Rust_Block::S_233
            | C2Rust_Block::S_243
            | C2Rust_Block::S_270
            | C2Rust_Block::S_272
            | C2Rust_Block::S_28
            | C2Rust_Block::S_296
            | C2Rust_Block::S_298
            | C2Rust_Block::S_30
            | C2Rust_Block::S_304
            | C2Rust_Block::S_310
            | C2Rust_Block::S_312
            | C2Rust_Block::S_32
            | C2Rust_Block::S_324
            | C2Rust_Block::S_326
            | C2Rust_Block::S_328
            | C2Rust_Block::S_330
            | C2Rust_Block::S_332
            | C2Rust_Block::S_347
            | C2Rust_Block::S_349
            | C2Rust_Block::S_359
            | C2Rust_Block::S_361
            | C2Rust_Block::S_363
            | C2Rust_Block::S_369
            | C2Rust_Block::S_375
            | C2Rust_Block::S_377
            | C2Rust_Block::S_379
            | C2Rust_Block::S_387
            | C2Rust_Block::S_389
            | C2Rust_Block::S_391
            | C2Rust_Block::S_393
            | C2Rust_Block::S_395
            | C2Rust_Block::S_397
            | C2Rust_Block::S_399
            | C2Rust_Block::S_4
            | C2Rust_Block::S_401
            | C2Rust_Block::S_403
            | C2Rust_Block::S_415
            | C2Rust_Block::S_418
            | C2Rust_Block::S_42
            | C2Rust_Block::S_424
            | C2Rust_Block::S_426
            | C2Rust_Block::S_428
            | C2Rust_Block::S_438
            | C2Rust_Block::S_44
            | C2Rust_Block::S_440
            | C2Rust_Block::S_442
            | C2Rust_Block::S_444
            | C2Rust_Block::S_446
            | C2Rust_Block::S_451
            | C2Rust_Block::S_453
            | C2Rust_Block::S_46
            | C2Rust_Block::S_463
            | C2Rust_Block::S_490
            | C2Rust_Block::S_492
            | C2Rust_Block::S_516
            | C2Rust_Block::S_518
            | C2Rust_Block::S_520
            | C2Rust_Block::S_526
            | C2Rust_Block::S_532
            | C2Rust_Block::S_534
            | C2Rust_Block::S_536
            | C2Rust_Block::S_538
            | C2Rust_Block::S_540
            | C2Rust_Block::S_542
            | C2Rust_Block::S_544
            | C2Rust_Block::S_546
            | C2Rust_Block::S_548
            | C2Rust_Block::S_56
            | C2Rust_Block::S_563
            | C2Rust_Block::S_565
            | C2Rust_Block::S_575
            | C2Rust_Block::S_577
            | C2Rust_Block::S_579
            | C2Rust_Block::S_58
            | C2Rust_Block::S_585
            | C2Rust_Block::S_591
            | C2Rust_Block::S_599
            | C2Rust_Block::S_6
            | C2Rust_Block::S_60
            | C2Rust_Block::S_605
            | C2Rust_Block::S_607
            | C2Rust_Block::S_617
            | C2Rust_Block::S_619
            | C2Rust_Block::S_629
            | C2Rust_Block::S_631
            | C2Rust_Block::S_641
            | C2Rust_Block::S_643
            | C2Rust_Block::S_649
            | C2Rust_Block::S_651
            | C2Rust_Block::S_653
            | C2Rust_Block::S_70
            | C2Rust_Block::S_72
            | C2Rust_Block::S_74
            | C2Rust_Block::S_8
            | C2Rust_Block::S_80
            | C2Rust_Block::S_83
            | C2Rust_Block::S_86
            | C2Rust_Block::S_92
            | C2Rust_Block::S_94
            | C2Rust_Block::S_96 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DE67() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                .wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DE72() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
        * 0x2710 as ::core::ffi::c_int as int32_t) as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = ((::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint64_t)
        .wrapping_add((*__gamepkg_tls_g_eax) as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x68 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add((*__gamepkg_tls_g_eax)),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv: uint32_t = 0x420658 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _t: uint64_t = (::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint64_t)
        .wrapping_add(0 as ::core::ffi::c_int as uint64_t)
        .wrapping_add(_cf as uint64_t);
    _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _t as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x420630 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b8e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0x24de99 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_199: {
        's_150: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_150;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_199;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_158: {
            if !_fn.is_none() {
                break 's_158;
            }
            _fn = recomp_lookup(_va);
        }
        's_164: {
            if !_fn.is_none() {
                break 's_164;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_170: {
            if _fn.is_some() {
                break 's_170;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_199;
        }
        _fn.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DE9C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    enum C2Rust_Block_3 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_98,
        S_100,
        S_102,
        S_108,
        S_110,
        S_112,
        S_118,
        S_120,
        S_126,
        S_128,
        S_130,
        S_140,
        S_142,
        S_144,
        S_150,
        S_152,
        S_154,
        S_160,
        S_162,
        S_164,
        S_170,
        S_180,
        S_182,
        S_184,
        S_194,
        S_196,
        S_198,
        S_208,
        S_210,
        S_212,
        S_218,
        S_220,
        S_222,
        S_228,
        S_230,
        S_232,
        S_238,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_315,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_370,
        S_372,
        S_378,
        S_380,
        S_382,
        S_388,
        S_394,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_470,
        S_472,
        S_478,
        S_480,
        S_482,
        S_488,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_533,
        S_535,
        S_545,
        S_547,
        S_553,
        S_555,
        S_557,
        S_563,
        S_565,
        S_571,
        S_577,
        S_579,
        S_585,
        S_587,
    }
    let mut c2rust_current_block_3: C2Rust_Block_3;
    c2rust_current_block_3 = C2Rust_Block_3::S_0;
    loop {
        match c2rust_current_block_3 {
            C2Rust_Block_3::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_3 = C2Rust_Block_3::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_3 = C2Rust_Block_3::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_26;
                };
                {
                    _pv = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_30;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_36;
                };
                {
                    ebp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_3 = C2Rust_Block_3::S_38;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_40;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_42;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_44;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_46;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0xc as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_48;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_50;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_56;
                };
                {
                    _pv_0 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_3 = C2Rust_Block_3::S_58;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_60;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_70;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_3 = C2Rust_Block_3::S_72;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_74;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_80;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_3 = C2Rust_Block_3::S_82;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_88;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_3 = C2Rust_Block_3::S_90;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_92;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_98;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_100;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_102;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_108;
                };
                {
                    _pv_3 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_3 = C2Rust_Block_3::S_110;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_112;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_118;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_120;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_126;
                };
                {
                    _pv_4 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_3 = C2Rust_Block_3::S_128;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_130;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_140;
                };
                {
                    _pv_5 = 0x362c54 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_142;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_144;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_150;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_152;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_154;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_160;
                };
                {
                    _pv_6 = 0x24dec1 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_162;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_164;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_170;
                };
                {
                    sub_00363D4E();
                    c2rust_current_block_3 = C2Rust_Block_3::S_180;
                };
                {
                    _pv_7 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_3 = C2Rust_Block_3::S_182;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_184;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_194;
                };
                {
                    _pv_8 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_3 = C2Rust_Block_3::S_196;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_198;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_208;
                };
                {
                    _pv_9 = 0x362c60 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_210;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_218;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_220;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_222;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_228;
                };
                {
                    _pv_10 = 0x24ded0 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_230;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_232;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_238;
                };
                {
                    sub_00363D4E();
                    c2rust_current_block_3 = C2Rust_Block_3::S_244;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_246;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_248;
                };
                {
                    (*__gamepkg_tls_g_edi) = !(*__gamepkg_tls_g_edi);
                    c2rust_current_block_3 = C2Rust_Block_3::S_250;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        & ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_3 = C2Rust_Block_3::S_252;
                };
                {
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_254;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_256;
                };
                {
                    (*__gamepkg_tls_g_eax) = !(*__gamepkg_tls_g_eax);
                    c2rust_current_block_3 = C2Rust_Block_3::S_258;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                    c2rust_current_block_3 = C2Rust_Block_3::S_260;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_262;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_264;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_266;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_268;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(0x28 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_274;
                };
            }
            C2Rust_Block_3::S_274 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_276;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_278;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_280;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_282;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                    c2rust_current_block_3 = C2Rust_Block_3::S_284;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_286;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_288;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_290;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int;
                    c2rust_current_block_3 = C2Rust_Block_3::S_292;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_294;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_296;
                };
                {
                    _fa = (*__gamepkg_tls_g_edi) & (*__gamepkg_tls_g_eax)
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_298;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_300;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_302;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_304;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_306;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_334;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_315;
                    }
                };
            }
            C2Rust_Block_3::S_315 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_317;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & (*__gamepkg_tls_g_eax)
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_319;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_321;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_323;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_325;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_400;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_334;
                    }
                };
            }
            C2Rust_Block_3::S_334 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_336;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_338;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_340;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_342;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_344;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_400;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_353;
                    }
                };
            }
            C2Rust_Block_3::S_353 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_355;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_357;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_359;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_361;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_400;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_370;
                    }
                };
            }
            C2Rust_Block_3::S_370 => {
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_372;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_378;
                };
                {
                    _pv_11 = 0x24df10 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_380;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_382;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_388;
                };
                {
                    sub_0024F30D();
                    c2rust_current_block_3 = C2Rust_Block_3::S_394;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_400;
                };
            }
            C2Rust_Block_3::S_400 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_402;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_404;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_406;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_408;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_494;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_417;
                    }
                };
            }
            C2Rust_Block_3::S_417 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_419;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_421;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_423;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_425;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_494;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_434;
                    }
                };
            }
            C2Rust_Block_3::S_434 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_436;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_438;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_440;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_442;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_444;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_494;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_453;
                    }
                };
            }
            C2Rust_Block_3::S_453 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_455;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_457;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_459;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_461;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_494;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_470;
                    }
                };
            }
            C2Rust_Block_3::S_470 => {
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_472;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_478;
                };
                {
                    _pv_12 = 0x24df2e as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_480;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_482;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_488;
                };
                {
                    sub_0024F332();
                    c2rust_current_block_3 = C2Rust_Block_3::S_494;
                };
            }
            C2Rust_Block_3::S_494 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_add(1 as uint32_t),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_496;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_498;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_500;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_502;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_504;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_506;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_508;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_510;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_512;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_514;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_516;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_518;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_520;
                };
                {
                    if _fa < _fb {
                        c2rust_current_block_3 = C2Rust_Block_3::S_274;
                    } else {
                        c2rust_current_block_3 = C2Rust_Block_3::S_533;
                    }
                };
            }
            C2Rust_Block_3::S_533 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_535;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_545;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_547;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_553;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_555;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_557;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_3 = C2Rust_Block_3::S_563;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_565;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_571;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_3 = C2Rust_Block_3::S_577;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_3 = C2Rust_Block_3::S_579;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_585;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_3 = C2Rust_Block_3::S_587;
                };
                return;
            }
            C2Rust_Block_3::S_100
            | C2Rust_Block_3::S_102
            | C2Rust_Block_3::S_108
            | C2Rust_Block_3::S_110
            | C2Rust_Block_3::S_112
            | C2Rust_Block_3::S_118
            | C2Rust_Block_3::S_120
            | C2Rust_Block_3::S_126
            | C2Rust_Block_3::S_128
            | C2Rust_Block_3::S_130
            | C2Rust_Block_3::S_140
            | C2Rust_Block_3::S_142
            | C2Rust_Block_3::S_144
            | C2Rust_Block_3::S_150
            | C2Rust_Block_3::S_152
            | C2Rust_Block_3::S_154
            | C2Rust_Block_3::S_160
            | C2Rust_Block_3::S_162
            | C2Rust_Block_3::S_164
            | C2Rust_Block_3::S_170
            | C2Rust_Block_3::S_180
            | C2Rust_Block_3::S_182
            | C2Rust_Block_3::S_184
            | C2Rust_Block_3::S_194
            | C2Rust_Block_3::S_196
            | C2Rust_Block_3::S_198
            | C2Rust_Block_3::S_2
            | C2Rust_Block_3::S_208
            | C2Rust_Block_3::S_210
            | C2Rust_Block_3::S_212
            | C2Rust_Block_3::S_218
            | C2Rust_Block_3::S_220
            | C2Rust_Block_3::S_222
            | C2Rust_Block_3::S_228
            | C2Rust_Block_3::S_230
            | C2Rust_Block_3::S_232
            | C2Rust_Block_3::S_238
            | C2Rust_Block_3::S_244
            | C2Rust_Block_3::S_246
            | C2Rust_Block_3::S_248
            | C2Rust_Block_3::S_250
            | C2Rust_Block_3::S_252
            | C2Rust_Block_3::S_254
            | C2Rust_Block_3::S_256
            | C2Rust_Block_3::S_258
            | C2Rust_Block_3::S_26
            | C2Rust_Block_3::S_260
            | C2Rust_Block_3::S_262
            | C2Rust_Block_3::S_264
            | C2Rust_Block_3::S_266
            | C2Rust_Block_3::S_268
            | C2Rust_Block_3::S_276
            | C2Rust_Block_3::S_278
            | C2Rust_Block_3::S_28
            | C2Rust_Block_3::S_280
            | C2Rust_Block_3::S_282
            | C2Rust_Block_3::S_284
            | C2Rust_Block_3::S_286
            | C2Rust_Block_3::S_288
            | C2Rust_Block_3::S_290
            | C2Rust_Block_3::S_292
            | C2Rust_Block_3::S_294
            | C2Rust_Block_3::S_296
            | C2Rust_Block_3::S_298
            | C2Rust_Block_3::S_30
            | C2Rust_Block_3::S_300
            | C2Rust_Block_3::S_302
            | C2Rust_Block_3::S_304
            | C2Rust_Block_3::S_306
            | C2Rust_Block_3::S_317
            | C2Rust_Block_3::S_319
            | C2Rust_Block_3::S_321
            | C2Rust_Block_3::S_323
            | C2Rust_Block_3::S_325
            | C2Rust_Block_3::S_336
            | C2Rust_Block_3::S_338
            | C2Rust_Block_3::S_340
            | C2Rust_Block_3::S_342
            | C2Rust_Block_3::S_344
            | C2Rust_Block_3::S_355
            | C2Rust_Block_3::S_357
            | C2Rust_Block_3::S_359
            | C2Rust_Block_3::S_36
            | C2Rust_Block_3::S_361
            | C2Rust_Block_3::S_372
            | C2Rust_Block_3::S_378
            | C2Rust_Block_3::S_38
            | C2Rust_Block_3::S_380
            | C2Rust_Block_3::S_382
            | C2Rust_Block_3::S_388
            | C2Rust_Block_3::S_394
            | C2Rust_Block_3::S_4
            | C2Rust_Block_3::S_40
            | C2Rust_Block_3::S_402
            | C2Rust_Block_3::S_404
            | C2Rust_Block_3::S_406
            | C2Rust_Block_3::S_408
            | C2Rust_Block_3::S_419
            | C2Rust_Block_3::S_42
            | C2Rust_Block_3::S_421
            | C2Rust_Block_3::S_423
            | C2Rust_Block_3::S_425
            | C2Rust_Block_3::S_436
            | C2Rust_Block_3::S_438
            | C2Rust_Block_3::S_44
            | C2Rust_Block_3::S_440
            | C2Rust_Block_3::S_442
            | C2Rust_Block_3::S_444
            | C2Rust_Block_3::S_455
            | C2Rust_Block_3::S_457
            | C2Rust_Block_3::S_459
            | C2Rust_Block_3::S_46
            | C2Rust_Block_3::S_461
            | C2Rust_Block_3::S_472
            | C2Rust_Block_3::S_478
            | C2Rust_Block_3::S_48
            | C2Rust_Block_3::S_480
            | C2Rust_Block_3::S_482
            | C2Rust_Block_3::S_488
            | C2Rust_Block_3::S_496
            | C2Rust_Block_3::S_498
            | C2Rust_Block_3::S_50
            | C2Rust_Block_3::S_500
            | C2Rust_Block_3::S_502
            | C2Rust_Block_3::S_504
            | C2Rust_Block_3::S_506
            | C2Rust_Block_3::S_508
            | C2Rust_Block_3::S_510
            | C2Rust_Block_3::S_512
            | C2Rust_Block_3::S_514
            | C2Rust_Block_3::S_516
            | C2Rust_Block_3::S_518
            | C2Rust_Block_3::S_520
            | C2Rust_Block_3::S_535
            | C2Rust_Block_3::S_545
            | C2Rust_Block_3::S_547
            | C2Rust_Block_3::S_553
            | C2Rust_Block_3::S_555
            | C2Rust_Block_3::S_557
            | C2Rust_Block_3::S_56
            | C2Rust_Block_3::S_563
            | C2Rust_Block_3::S_565
            | C2Rust_Block_3::S_571
            | C2Rust_Block_3::S_577
            | C2Rust_Block_3::S_579
            | C2Rust_Block_3::S_58
            | C2Rust_Block_3::S_585
            | C2Rust_Block_3::S_587
            | C2Rust_Block_3::S_6
            | C2Rust_Block_3::S_60
            | C2Rust_Block_3::S_70
            | C2Rust_Block_3::S_72
            | C2Rust_Block_3::S_74
            | C2Rust_Block_3::S_8
            | C2Rust_Block_3::S_80
            | C2Rust_Block_3::S_82
            | C2Rust_Block_3::S_88
            | C2Rust_Block_3::S_90
            | C2Rust_Block_3::S_92
            | C2Rust_Block_3::S_98 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DF41() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_51: {
        if _fa == _fb {
            break 's_51;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi).wrapping_add(0x28 as uint32_t);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_186: {
                if _fa == _fb {
                    break 's_186;
                }
                let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                let mut _pv_4: uint32_t = 0x24df65 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                sub_0024F99F();
            }
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_sub(1);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
            if _fa == 0 as uint32_t {
                break;
            }
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DF71() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x374e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi)
        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
        .wrapping_add(0x28 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = 0x24df8a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024F298();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0x24df91 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024F7F6();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_sub(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DFA1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24dfaa as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024DAD2();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_196: {
        's_69: {
            if _fa == _fb {
                break 's_69;
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            's_132: {
                if _fa == _fb {
                    break 's_132;
                }
                let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_159: {
                if _fa == _fb {
                    break 's_159;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_186: {
                if _fa == _fb {
                    break 's_186;
                }
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_196;
        }
        (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DFE6() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024DB2A();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DFEB() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DFFA() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024DBCD();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024DFFF() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024DC3A();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E004() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_2: uint32_t = 0x24e01b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024DC5D();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E020() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_2: uint32_t = 0x24e037 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024DC89();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E03C() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_4: uint32_t = 0x24e05b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024DCB5();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(28 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E060() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_4: uint32_t = 0x24e07f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024DCE9();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(28 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E084() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    let mut _pv_4: uint32_t = 0x24e0a3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024DD1D();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(28 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E0A8() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    let mut _pv_1: uint32_t = 0x24e0b5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024DF41();
    let mut _pv_2: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fb = 0x40 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    loop {
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_227: {
            if _fa == _fb {
                break 's_227;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_3: uint32_t = 0x24e0c7 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_178: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_178;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_227;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_186: {
                if !_fn.is_none() {
                    break 's_186;
                }
                _fn = recomp_lookup(_va);
            }
            's_192: {
                if !_fn.is_none() {
                    break 's_192;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_198: {
                if _fn.is_some() {
                    break 's_198;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_227;
            }
            _fn.expect("non-null function pointer")();
        }
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        if _fa == 0 as uint32_t {
            break;
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E0D4() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                .wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_105: {
        's_99: {
            if _fa == _fb {
                break 's_99;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0x24e0eb as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_0024DF71();
            break 's_105;
        }
        (*__gamepkg_tls_g_esi) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E0F8() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = 0x24e103 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_158: {
        's_97: {
            if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
            {
                break 's_97;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_117: {
                if !_fn.is_none() {
                    break 's_117;
                }
                _fn = recomp_lookup(_va);
            }
            's_123: {
                if !_fn.is_none() {
                    break 's_123;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_129: {
                if _fn.is_some() {
                    break 's_129;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_158;
            }
            _fn.expect("non-null function pointer")();
            break 's_158;
        }
        recomp_icall_not_code_log(_va);
        (*__gamepkg_tls_g_esp) = _icall_esp;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    }
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t;
    let mut _pv_3: uint32_t = 0x24e10c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024DE9C();
    let mut _pv_4: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    _fb = 0x40 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    loop {
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_339: {
            if _fa == _fb {
                break 's_339;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _icall_esp_0: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _icall_target_0: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_5: uint32_t = 0x24e11e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _va_0: uint32_t = _icall_target_0;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va_0,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_290: {
                if _va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi
                {
                    break 's_290;
                }
                recomp_icall_not_code_log(_va_0);
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_339;
            }
            let mut _fn_0: recomp_func_t = recomp_lookup_manual(_va_0);
            's_298: {
                if !_fn_0.is_none() {
                    break 's_298;
                }
                _fn_0 = recomp_lookup(_va_0);
            }
            's_304: {
                if !_fn_0.is_none() {
                    break 's_304;
                }
                _fn_0 = recomp_lookup_kernel(_va_0);
            }
            's_310: {
                if _fn_0.is_some() {
                    break 's_310;
                }
                recomp_icall_fail_log(_va_0);
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_339;
            }
            _fn_0.expect("non-null function pointer")();
        }
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        if _fa == 0 as uint32_t {
            break;
        }
    }
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t;
    let mut _icall_esp_1: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _icall_target_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_6: uint32_t = 0x24e12c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _va_1: uint32_t = _icall_target_1;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va_1,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_468: {
        's_415: {
            if _va_1 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi
            {
                break 's_415;
            }
            recomp_icall_not_code_log(_va_1);
            (*__gamepkg_tls_g_esp) = _icall_esp_1;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_468;
        }
        let mut _fn_1: recomp_func_t = recomp_lookup_manual(_va_1);
        's_423: {
            if !_fn_1.is_none() {
                break 's_423;
            }
            _fn_1 = recomp_lookup(_va_1);
        }
        's_429: {
            if !_fn_1.is_none() {
                break 's_429;
            }
            _fn_1 = recomp_lookup_kernel(_va_1);
        }
        's_435: {
            if _fn_1.is_some() {
                break 's_435;
            }
            recomp_icall_fail_log(_va_1);
            (*__gamepkg_tls_g_esp) = _icall_esp_1;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_468;
        }
        _fn_1.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E132() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024E0A8();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E137() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024E0D4();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E13C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = 0x24e144 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024DDF7();
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_119: {
        if _fa == _fb {
            break 's_119;
        }
        let mut _pv_1: uint32_t = 0x801a as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x24e156 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_0024EFFB();
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E15C() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x14 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24e169 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024DE72();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = 0x24e174 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024E0F8();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E177() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    enum C2Rust_Block_23 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_58,
        S_60,
        S_62,
        S_72,
        S_74,
        S_76,
        S_82,
        S_88,
        S_90,
        S_92,
        S_98,
        S_104,
        S_106,
        S_112,
        S_114,
        S_118,
        S_120,
        S_122,
        S_124,
        S_128,
        S_131,
        S_132,
        S_133,
        S_134,
        S_145,
        S_147,
        S_152,
        S_155,
        S_156,
        S_157,
        S_158,
        S_165,
        S_167,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_199,
        S_201,
        S_203,
        S_212,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_236,
        S_238,
        S_240,
        S_246,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_271,
        S_273,
        S_275,
        S_281,
        S_283,
        S_285,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_305,
        S_307,
        S_309,
        S_319,
        S_321,
        S_323,
        S_329,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_356,
        S_358,
        S_360,
        S_370,
        S_372,
        S_374,
        S_380,
        S_386,
        S_388,
        S_390,
        S_400,
        S_402,
        S_404,
        S_410,
        S_416,
        S_418,
        S_420,
        S_426,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_451,
        S_463,
        S_465,
        S_467,
        S_477,
        S_479,
        S_481,
        S_491,
        S_493,
        S_495,
        S_501,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_517,
        S_527,
        S_533,
        S_535,
        S_537,
        S_547,
        S_549,
        S_551,
        S_558,
        S_564,
        S_566,
        S_568,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_589,
        S_591,
        S_593,
        S_601,
        S_603,
        S_605,
        S_609,
        S_611,
        S_615,
        S_621,
        S_628,
        S_630,
        S_632,
        S_651,
        S_657,
        S_659,
        S_661,
        S_671,
        S_673,
        S_675,
        S_685,
        S_687,
        S_689,
        S_696,
        S_702,
        S_704,
        S_706,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_727,
        S_729,
        S_731,
        S_739,
        S_741,
        S_743,
        S_747,
        S_749,
        S_753,
        S_759,
        S_766,
        S_768,
        S_770,
        S_788,
        S_791,
        S_797,
        S_799,
        S_801,
        S_808,
        S_814,
        S_816,
        S_818,
        S_828,
        S_830,
        S_832,
        S_834,
        S_836,
        S_839,
        S_841,
        S_843,
        S_851,
        S_853,
        S_855,
        S_859,
        S_861,
        S_865,
        S_871,
        S_878,
        S_880,
        S_882,
        S_904,
        S_906,
        S_908,
        S_914,
        S_920,
        S_922,
        S_924,
        S_930,
        S_940,
        S_942,
        S_948,
        S_954,
        S_956,
        S_966,
        S_968,
        S_978,
        S_980,
        S_986,
        S_988,
    }
    let mut c2rust_current_block_23: C2Rust_Block_23;
    c2rust_current_block_23 = C2Rust_Block_23::S_0;
    loop {
        match c2rust_current_block_23 {
            C2Rust_Block_23::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_23 = C2Rust_Block_23::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_23 = C2Rust_Block_23::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_23 = C2Rust_Block_23::S_28;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_23 = C2Rust_Block_23::S_30;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_32;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_42;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_23 = C2Rust_Block_23::S_44;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_46;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_52;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_58;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_23 = C2Rust_Block_23::S_60;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_62;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_72;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_23 = C2Rust_Block_23::S_74;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_76;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_82;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_23 = C2Rust_Block_23::S_88;
                };
                {
                    _pv_3 = 9 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_90;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_92;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_98;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_104;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_106;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_112;
                };
                {
                    (*__gamepkg_tls_g_esi) = ebp;
                    c2rust_current_block_23 = C2Rust_Block_23::S_114;
                };
                {
                    if (*__gamepkg_tls_g_df) == 0 {
                        c2rust_current_block_23 = C2Rust_Block_23::S_118;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_152;
                    }
                };
            }
            C2Rust_Block_23::S_118 => {
                {
                    _d = ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    _s = ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_120;
                };
                {
                    _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_122;
                };
                {
                    if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                        c2rust_current_block_23 = C2Rust_Block_23::S_124;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_128;
                    }
                };
            }
            C2Rust_Block_23::S_124 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_145;
            }
            C2Rust_Block_23::S_128 => {
                {
                    _i = 0;
                    c2rust_current_block_23 = C2Rust_Block_23::S_131;
                };
                {
                    _i = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_132;
                };
            }
            C2Rust_Block_23::S_132 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_23 = C2Rust_Block_23::S_133;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_145;
                }
            }
            C2Rust_Block_23::S_133 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_134;
                };
                {
                    _i = _i.wrapping_add(1);
                    c2rust_current_block_23 = C2Rust_Block_23::S_132;
                };
            }
            C2Rust_Block_23::S_145 => {
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    c2rust_current_block_23 = C2Rust_Block_23::S_147;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    c2rust_current_block_23 = C2Rust_Block_23::S_173;
                };
            }
            C2Rust_Block_23::S_152 => {
                {
                    _i_0 = 0;
                    c2rust_current_block_23 = C2Rust_Block_23::S_155;
                };
                {
                    _i_0 = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_156;
                };
            }
            C2Rust_Block_23::S_156 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_23 = C2Rust_Block_23::S_157;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_165;
                }
            }
            C2Rust_Block_23::S_157 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_158;
                };
                {
                    _i_0 = _i_0.wrapping_add(1);
                    c2rust_current_block_23 = C2Rust_Block_23::S_156;
                };
            }
            C2Rust_Block_23::S_165 => {
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_sub(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    c2rust_current_block_23 = C2Rust_Block_23::S_167;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_sub(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    c2rust_current_block_23 = C2Rust_Block_23::S_173;
                };
            }
            C2Rust_Block_23::S_173 => {
                {
                    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_175;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_177;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_179;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_181;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_183;
                };
                {
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_185;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_187;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                    c2rust_current_block_23 = C2Rust_Block_23::S_189;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_191;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_193;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_195;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_197;
                };
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_199;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_201;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_203;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_23 = C2Rust_Block_23::S_218;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_212;
                    }
                };
            }
            C2Rust_Block_23::S_212 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x42068c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_23 = C2Rust_Block_23::S_218;
            }
            C2Rust_Block_23::S_218 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (0x420688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edi) & 0xffff as uint32_t) as uint16_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_220;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (0x42067a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_222;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x42067c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3e80 as uint32_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_224;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (0x420686 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x10 as uint16_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_226;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (0x420684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        2 as uint16_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_228;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x420680 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x7d00 as uint32_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_230;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (0x420678 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_236;
                };
                {
                    _pv_4 = 0x24e1d8 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_238;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_240;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_246;
                };
                {
                    sub_0024FADC();
                    c2rust_current_block_23 = C2Rust_Block_23::S_252;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_23 = C2Rust_Block_23::S_254;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_256;
                };
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_258;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_260;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_262;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        < if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_23 = C2Rust_Block_23::S_940;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_271;
                    }
                };
            }
            C2Rust_Block_23::S_271 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_273;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_23 = C2Rust_Block_23::S_275;
                };
                {
                    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                        * 0x7c as ::core::ffi::c_int as int32_t) as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_281;
                };
                {
                    _pv_5 = 0x8019 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_283;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_285;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_291;
                };
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_293;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_295;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_297;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_299;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_305;
                };
                {
                    _pv_6 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_23 = C2Rust_Block_23::S_307;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_309;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_319;
                };
                {
                    _pv_7 = 0x24e1f4 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_321;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_323;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_329;
                };
                {
                    sub_0024EFC3();
                    c2rust_current_block_23 = C2Rust_Block_23::S_335;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_337;
                };
                {
                    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_339;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_341;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_343;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_23 = C2Rust_Block_23::S_432;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_356;
                    }
                };
            }
            C2Rust_Block_23::S_356 => {
                {
                    _pv_8 = 0x24f217 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_358;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_360;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_370;
                };
                {
                    _pv_9 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_23 = C2Rust_Block_23::S_372;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_374;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_380;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_386;
                };
                {
                    _pv_10 = 0x7c as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_388;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_390;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_400;
                };
                {
                    _pv_11 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_23 = C2Rust_Block_23::S_402;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_404;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_410;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_416;
                };
                {
                    _pv_12 = 0x24e20b as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_418;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_420;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_426;
                };
                {
                    sub_00011000();
                    c2rust_current_block_23 = C2Rust_Block_23::S_432;
                };
            }
            C2Rust_Block_23::S_432 => {
                {
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_434;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_436;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_438;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_440;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_442;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_23 = C2Rust_Block_23::S_463;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_451;
                    }
                };
            }
            C2Rust_Block_23::S_451 => {
                (*__gamepkg_tls_g_esi) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_23 = C2Rust_Block_23::S_940;
            }
            C2Rust_Block_23::S_463 => {
                {
                    _pv_13 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x374e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_465;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_467;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_477;
                };
                {
                    _pv_14 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_23 = C2Rust_Block_23::S_479;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_481;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_14,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_491;
                };
                {
                    _pv_15 = 0x24e225 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_493;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_495;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_15,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_501;
                };
                {
                    sub_0024DB2A();
                    c2rust_current_block_23 = C2Rust_Block_23::S_507;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_23 = C2Rust_Block_23::S_509;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_511;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_513;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_515;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_517;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        < if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_23 = C2Rust_Block_23::S_940;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_527;
                    }
                };
            }
            C2Rust_Block_23::S_527 => {
                {
                    _icall_esp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_23 = C2Rust_Block_23::S_533;
                };
                {
                    _pv_16 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_535;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_537;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_16,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_547;
                };
                {
                    _pv_17 = 0x420630 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_549;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_551;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_17,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_558;
                };
                {
                    _icall_target = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_564;
                };
                {
                    _pv_18 = 0x24e238 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_566;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_568;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_18,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_578;
                };
                {
                    _va = _icall_target;
                    c2rust_current_block_23 = C2Rust_Block_23::S_580;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_582;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_584;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_586;
                };
                {
                    if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                    {
                        c2rust_current_block_23 = C2Rust_Block_23::S_589;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_601;
                    }
                };
            }
            C2Rust_Block_23::S_589 => {
                {
                    recomp_icall_not_code_log(_va);
                    c2rust_current_block_23 = C2Rust_Block_23::S_591;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block_23 = C2Rust_Block_23::S_593;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_651;
                };
            }
            C2Rust_Block_23::S_601 => {
                {
                    _fn = recomp_lookup_manual(_va);
                    c2rust_current_block_23 = C2Rust_Block_23::S_603;
                };
                {
                    if _fn.is_none() {
                        c2rust_current_block_23 = C2Rust_Block_23::S_605;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_609;
                    }
                };
            }
            C2Rust_Block_23::S_605 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_609;
            }
            C2Rust_Block_23::S_609 => {
                if _fn.is_none() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_611;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_615;
                }
            }
            C2Rust_Block_23::S_611 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_23 = C2Rust_Block_23::S_615;
            }
            C2Rust_Block_23::S_615 => {
                if _fn.is_some() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_621;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_628;
                }
            }
            C2Rust_Block_23::S_621 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_23 = C2Rust_Block_23::S_651;
            }
            C2Rust_Block_23::S_628 => {
                {
                    recomp_icall_fail_log(_va);
                    c2rust_current_block_23 = C2Rust_Block_23::S_630;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block_23 = C2Rust_Block_23::S_632;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_651;
                };
            }
            C2Rust_Block_23::S_651 => {
                {
                    _icall_esp_0 = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_23 = C2Rust_Block_23::S_657;
                };
                {
                    _pv_19 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_23 = C2Rust_Block_23::S_659;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_661;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_19,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_671;
                };
                {
                    _pv_20 = 0x24e15c as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_673;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_675;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_20,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_685;
                };
                {
                    _pv_21 = 0x420658 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_687;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_689;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_21,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_696;
                };
                {
                    _icall_target_0 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_702;
                };
                {
                    _pv_22 = 0x24e249 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_704;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_706;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_22,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_716;
                };
                {
                    _va_0 = _icall_target_0;
                    c2rust_current_block_23 = C2Rust_Block_23::S_718;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va_0,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_720;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_722;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_724;
                };
                {
                    if !(_va_0 >= 0xfe000000 as uint32_t
                        || g_xbox_code_hi == 0 as uint32_t
                        || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                    {
                        c2rust_current_block_23 = C2Rust_Block_23::S_727;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_739;
                    }
                };
            }
            C2Rust_Block_23::S_727 => {
                {
                    recomp_icall_not_code_log(_va_0);
                    c2rust_current_block_23 = C2Rust_Block_23::S_729;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    c2rust_current_block_23 = C2Rust_Block_23::S_731;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_788;
                };
            }
            C2Rust_Block_23::S_739 => {
                {
                    _fn_0 = recomp_lookup_manual(_va_0);
                    c2rust_current_block_23 = C2Rust_Block_23::S_741;
                };
                {
                    if _fn_0.is_none() {
                        c2rust_current_block_23 = C2Rust_Block_23::S_743;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_747;
                    }
                };
            }
            C2Rust_Block_23::S_743 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_23 = C2Rust_Block_23::S_747;
            }
            C2Rust_Block_23::S_747 => {
                if _fn_0.is_none() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_749;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_753;
                }
            }
            C2Rust_Block_23::S_749 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_23 = C2Rust_Block_23::S_753;
            }
            C2Rust_Block_23::S_753 => {
                if _fn_0.is_some() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_759;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_766;
                }
            }
            C2Rust_Block_23::S_759 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_23 = C2Rust_Block_23::S_788;
            }
            C2Rust_Block_23::S_766 => {
                {
                    recomp_icall_fail_log(_va_0);
                    c2rust_current_block_23 = C2Rust_Block_23::S_768;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    c2rust_current_block_23 = C2Rust_Block_23::S_770;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_788;
                };
            }
            C2Rust_Block_23::S_788 => {
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                        .wrapping_add(0x68 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_791;
                };
                {
                    _icall_esp_1 = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_23 = C2Rust_Block_23::S_797;
                };
                {
                    _pv_23 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_23 = C2Rust_Block_23::S_799;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_801;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_23,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_808;
                };
                {
                    _icall_target_1 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b7dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_814;
                };
                {
                    _pv_24 = 0x24e253 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_816;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_818;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_24,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_828;
                };
                {
                    _va_1 = _icall_target_1;
                    c2rust_current_block_23 = C2Rust_Block_23::S_830;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va_1,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_832;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_834;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_836;
                };
                {
                    if !(_va_1 >= 0xfe000000 as uint32_t
                        || g_xbox_code_hi == 0 as uint32_t
                        || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                    {
                        c2rust_current_block_23 = C2Rust_Block_23::S_839;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_851;
                    }
                };
            }
            C2Rust_Block_23::S_839 => {
                {
                    recomp_icall_not_code_log(_va_1);
                    c2rust_current_block_23 = C2Rust_Block_23::S_841;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_1;
                    c2rust_current_block_23 = C2Rust_Block_23::S_843;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_904;
                };
            }
            C2Rust_Block_23::S_851 => {
                {
                    _fn_1 = recomp_lookup_manual(_va_1);
                    c2rust_current_block_23 = C2Rust_Block_23::S_853;
                };
                {
                    if _fn_1.is_none() {
                        c2rust_current_block_23 = C2Rust_Block_23::S_855;
                    } else {
                        c2rust_current_block_23 = C2Rust_Block_23::S_859;
                    }
                };
            }
            C2Rust_Block_23::S_855 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block_23 = C2Rust_Block_23::S_859;
            }
            C2Rust_Block_23::S_859 => {
                if _fn_1.is_none() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_861;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_865;
                }
            }
            C2Rust_Block_23::S_861 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block_23 = C2Rust_Block_23::S_865;
            }
            C2Rust_Block_23::S_865 => {
                if _fn_1.is_some() {
                    c2rust_current_block_23 = C2Rust_Block_23::S_871;
                } else {
                    c2rust_current_block_23 = C2Rust_Block_23::S_878;
                }
            }
            C2Rust_Block_23::S_871 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block_23 = C2Rust_Block_23::S_904;
            }
            C2Rust_Block_23::S_878 => {
                {
                    recomp_icall_fail_log(_va_1);
                    c2rust_current_block_23 = C2Rust_Block_23::S_880;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_1;
                    c2rust_current_block_23 = C2Rust_Block_23::S_882;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_904;
                };
            }
            C2Rust_Block_23::S_904 => {
                {
                    _pv_25 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_906;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_908;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_25,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_914;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_23 = C2Rust_Block_23::S_920;
                };
                {
                    _pv_26 = 0x24e25c as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_23 = C2Rust_Block_23::S_922;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_924;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_26,
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_930;
                };
                {
                    sub_0024DE72();
                    c2rust_current_block_23 = C2Rust_Block_23::S_940;
                };
            }
            C2Rust_Block_23::S_940 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_942;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_948;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_23 = C2Rust_Block_23::S_954;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_956;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_966;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_968;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_978;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_23 = C2Rust_Block_23::S_980;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_986;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_23 = C2Rust_Block_23::S_988;
                };
                return;
            }
            C2Rust_Block_23::S_104
            | C2Rust_Block_23::S_106
            | C2Rust_Block_23::S_112
            | C2Rust_Block_23::S_114
            | C2Rust_Block_23::S_120
            | C2Rust_Block_23::S_122
            | C2Rust_Block_23::S_131
            | C2Rust_Block_23::S_134
            | C2Rust_Block_23::S_147
            | C2Rust_Block_23::S_155
            | C2Rust_Block_23::S_158
            | C2Rust_Block_23::S_167
            | C2Rust_Block_23::S_175
            | C2Rust_Block_23::S_177
            | C2Rust_Block_23::S_179
            | C2Rust_Block_23::S_18
            | C2Rust_Block_23::S_181
            | C2Rust_Block_23::S_183
            | C2Rust_Block_23::S_185
            | C2Rust_Block_23::S_187
            | C2Rust_Block_23::S_189
            | C2Rust_Block_23::S_191
            | C2Rust_Block_23::S_193
            | C2Rust_Block_23::S_195
            | C2Rust_Block_23::S_197
            | C2Rust_Block_23::S_199
            | C2Rust_Block_23::S_2
            | C2Rust_Block_23::S_201
            | C2Rust_Block_23::S_203
            | C2Rust_Block_23::S_220
            | C2Rust_Block_23::S_222
            | C2Rust_Block_23::S_224
            | C2Rust_Block_23::S_226
            | C2Rust_Block_23::S_228
            | C2Rust_Block_23::S_230
            | C2Rust_Block_23::S_236
            | C2Rust_Block_23::S_238
            | C2Rust_Block_23::S_240
            | C2Rust_Block_23::S_246
            | C2Rust_Block_23::S_252
            | C2Rust_Block_23::S_254
            | C2Rust_Block_23::S_256
            | C2Rust_Block_23::S_258
            | C2Rust_Block_23::S_260
            | C2Rust_Block_23::S_262
            | C2Rust_Block_23::S_273
            | C2Rust_Block_23::S_275
            | C2Rust_Block_23::S_28
            | C2Rust_Block_23::S_281
            | C2Rust_Block_23::S_283
            | C2Rust_Block_23::S_285
            | C2Rust_Block_23::S_291
            | C2Rust_Block_23::S_293
            | C2Rust_Block_23::S_295
            | C2Rust_Block_23::S_297
            | C2Rust_Block_23::S_299
            | C2Rust_Block_23::S_30
            | C2Rust_Block_23::S_305
            | C2Rust_Block_23::S_307
            | C2Rust_Block_23::S_309
            | C2Rust_Block_23::S_319
            | C2Rust_Block_23::S_32
            | C2Rust_Block_23::S_321
            | C2Rust_Block_23::S_323
            | C2Rust_Block_23::S_329
            | C2Rust_Block_23::S_335
            | C2Rust_Block_23::S_337
            | C2Rust_Block_23::S_339
            | C2Rust_Block_23::S_341
            | C2Rust_Block_23::S_343
            | C2Rust_Block_23::S_358
            | C2Rust_Block_23::S_360
            | C2Rust_Block_23::S_370
            | C2Rust_Block_23::S_372
            | C2Rust_Block_23::S_374
            | C2Rust_Block_23::S_380
            | C2Rust_Block_23::S_386
            | C2Rust_Block_23::S_388
            | C2Rust_Block_23::S_390
            | C2Rust_Block_23::S_4
            | C2Rust_Block_23::S_400
            | C2Rust_Block_23::S_402
            | C2Rust_Block_23::S_404
            | C2Rust_Block_23::S_410
            | C2Rust_Block_23::S_416
            | C2Rust_Block_23::S_418
            | C2Rust_Block_23::S_42
            | C2Rust_Block_23::S_420
            | C2Rust_Block_23::S_426
            | C2Rust_Block_23::S_434
            | C2Rust_Block_23::S_436
            | C2Rust_Block_23::S_438
            | C2Rust_Block_23::S_44
            | C2Rust_Block_23::S_440
            | C2Rust_Block_23::S_442
            | C2Rust_Block_23::S_46
            | C2Rust_Block_23::S_465
            | C2Rust_Block_23::S_467
            | C2Rust_Block_23::S_477
            | C2Rust_Block_23::S_479
            | C2Rust_Block_23::S_481
            | C2Rust_Block_23::S_491
            | C2Rust_Block_23::S_493
            | C2Rust_Block_23::S_495
            | C2Rust_Block_23::S_501
            | C2Rust_Block_23::S_507
            | C2Rust_Block_23::S_509
            | C2Rust_Block_23::S_511
            | C2Rust_Block_23::S_513
            | C2Rust_Block_23::S_515
            | C2Rust_Block_23::S_517
            | C2Rust_Block_23::S_52
            | C2Rust_Block_23::S_533
            | C2Rust_Block_23::S_535
            | C2Rust_Block_23::S_537
            | C2Rust_Block_23::S_547
            | C2Rust_Block_23::S_549
            | C2Rust_Block_23::S_551
            | C2Rust_Block_23::S_558
            | C2Rust_Block_23::S_564
            | C2Rust_Block_23::S_566
            | C2Rust_Block_23::S_568
            | C2Rust_Block_23::S_578
            | C2Rust_Block_23::S_58
            | C2Rust_Block_23::S_580
            | C2Rust_Block_23::S_582
            | C2Rust_Block_23::S_584
            | C2Rust_Block_23::S_586
            | C2Rust_Block_23::S_591
            | C2Rust_Block_23::S_593
            | C2Rust_Block_23::S_6
            | C2Rust_Block_23::S_60
            | C2Rust_Block_23::S_603
            | C2Rust_Block_23::S_62
            | C2Rust_Block_23::S_630
            | C2Rust_Block_23::S_632
            | C2Rust_Block_23::S_657
            | C2Rust_Block_23::S_659
            | C2Rust_Block_23::S_661
            | C2Rust_Block_23::S_671
            | C2Rust_Block_23::S_673
            | C2Rust_Block_23::S_675
            | C2Rust_Block_23::S_685
            | C2Rust_Block_23::S_687
            | C2Rust_Block_23::S_689
            | C2Rust_Block_23::S_696
            | C2Rust_Block_23::S_702
            | C2Rust_Block_23::S_704
            | C2Rust_Block_23::S_706
            | C2Rust_Block_23::S_716
            | C2Rust_Block_23::S_718
            | C2Rust_Block_23::S_72
            | C2Rust_Block_23::S_720
            | C2Rust_Block_23::S_722
            | C2Rust_Block_23::S_724
            | C2Rust_Block_23::S_729
            | C2Rust_Block_23::S_731
            | C2Rust_Block_23::S_74
            | C2Rust_Block_23::S_741
            | C2Rust_Block_23::S_76
            | C2Rust_Block_23::S_768
            | C2Rust_Block_23::S_770
            | C2Rust_Block_23::S_791
            | C2Rust_Block_23::S_797
            | C2Rust_Block_23::S_799
            | C2Rust_Block_23::S_8
            | C2Rust_Block_23::S_801
            | C2Rust_Block_23::S_808
            | C2Rust_Block_23::S_814
            | C2Rust_Block_23::S_816
            | C2Rust_Block_23::S_818
            | C2Rust_Block_23::S_82
            | C2Rust_Block_23::S_828
            | C2Rust_Block_23::S_830
            | C2Rust_Block_23::S_832
            | C2Rust_Block_23::S_834
            | C2Rust_Block_23::S_836
            | C2Rust_Block_23::S_841
            | C2Rust_Block_23::S_843
            | C2Rust_Block_23::S_853
            | C2Rust_Block_23::S_88
            | C2Rust_Block_23::S_880
            | C2Rust_Block_23::S_882
            | C2Rust_Block_23::S_90
            | C2Rust_Block_23::S_906
            | C2Rust_Block_23::S_908
            | C2Rust_Block_23::S_914
            | C2Rust_Block_23::S_92
            | C2Rust_Block_23::S_920
            | C2Rust_Block_23::S_922
            | C2Rust_Block_23::S_924
            | C2Rust_Block_23::S_930
            | C2Rust_Block_23::S_942
            | C2Rust_Block_23::S_948
            | C2Rust_Block_23::S_954
            | C2Rust_Block_23::S_956
            | C2Rust_Block_23::S_966
            | C2Rust_Block_23::S_968
            | C2Rust_Block_23::S_978
            | C2Rust_Block_23::S_98
            | C2Rust_Block_23::S_980
            | C2Rust_Block_23::S_986
            | C2Rust_Block_23::S_988 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E265() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = 0x801a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x80 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x24e27d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024EFC3();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_157: {
        's_119: {
            if _fa != _fb {
                break 's_119;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_157;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _pv_4: uint32_t = 0x24e288 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_0024DAEA();
    }
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_316: {
        's_176: {
            if _fa == _fb {
                break 's_176;
            }
            let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
            let mut _pv_6: uint32_t = 0x24e2a7 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_0024E177();
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_249: {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_249;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                break 's_316;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_302: {
                if _fa == _fb {
                    break 's_302;
                }
                let mut _pv_7: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                let mut _pv_8: uint32_t = 0x24e2c7 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                sub_0024E13C();
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_316;
        }
        (*__gamepkg_tls_g_esi) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E2D5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx).wrapping_add(0x78 as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _old: uint32_t = {
        let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let __gamepkg_atomic_value = (*__gamepkg_tls_g_eax);
        ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
            .fetch_add(__gamepkg_atomic_value, ::core::sync::atomic::Ordering::SeqCst)
    };
    (*__gamepkg_tls_g_eax) = _old;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_157: {
        if _fa != _fb {
            break 's_157;
        }
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_157;
        }
        let mut _pv_1: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_ebp) = ebp;
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _pv_2: uint32_t = 0x24e301 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_0024E13C();
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E308() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024E2D5();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E30D() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x50 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x48 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x5c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        4 as uint32_t,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx).wrapping_add(0x40 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E34F() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t);
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x70 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_esi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(2 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E377() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx).wrapping_add(0xfc as uint32_t);
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x6c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        2 as uint32_t,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t))
                .wrapping_add(0x70 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_esi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E39E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3A6() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3A9() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3AE() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(24 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3B6() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3BE() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(20 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3C6() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3CE() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv: uint32_t = 0x24e3e2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_0024F767();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3E5() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x24e3ee as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_0024F279();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E3F1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    enum C2Rust_Block_39 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_99,
        S_101,
        S_103,
        S_109,
        S_111,
        S_113,
        S_115,
        S_117,
        S_119,
        S_121,
        S_123,
        S_129,
        S_131,
        S_133,
        S_143,
        S_145,
        S_147,
        S_149,
        S_151,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_176,
        S_178,
        S_180,
        S_186,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_213,
        S_215,
        S_217,
        S_223,
        S_225,
        S_227,
        S_233,
        S_235,
        S_237,
        S_243,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_259,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_337,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_374,
        S_376,
        S_386,
        S_388,
        S_402,
        S_404,
        S_410,
        S_416,
        S_418,
        S_424,
        S_426,
    }
    let mut c2rust_current_block_39: C2Rust_Block_39;
    c2rust_current_block_39 = C2Rust_Block_39::S_0;
    loop {
        match c2rust_current_block_39 {
            C2Rust_Block_39::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_39 = C2Rust_Block_39::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_39 = C2Rust_Block_39::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_26;
                };
                {
                    _pv = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_30;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_36;
                };
                {
                    ebp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_39 = C2Rust_Block_39::S_38;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_40;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_42;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_44;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_46;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0xc as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_48;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_50;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_56;
                };
                {
                    _pv_0 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_39 = C2Rust_Block_39::S_58;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_60;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_66;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_68;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_70;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_72;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_39 = C2Rust_Block_39::S_74;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_76;
                };
                {
                    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_78;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_80;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_82;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        2 as uint32_t,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_84;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_86;
                };
                {
                    if _fa <= _fb {
                        c2rust_current_block_39 = C2Rust_Block_39::S_402;
                    } else {
                        c2rust_current_block_39 = C2Rust_Block_39::S_99;
                    }
                };
            }
            C2Rust_Block_39::S_99 => {
                {
                    _pv_1 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_39 = C2Rust_Block_39::S_101;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_103;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_109;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_111;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_113;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_115;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                    c2rust_current_block_39 = C2Rust_Block_39::S_117;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_119;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_121;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_123;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_129;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_39 = C2Rust_Block_39::S_131;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_133;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_143;
                };
            }
            C2Rust_Block_39::S_143 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_145;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_147;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_149;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_151;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_39 = C2Rust_Block_39::S_374;
                    } else {
                        c2rust_current_block_39 = C2Rust_Block_39::S_160;
                    }
                };
            }
            C2Rust_Block_39::S_160 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_162;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_164;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_eax))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_166;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_168;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_170;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_176;
                };
                {
                    _pv_3 = 0x24e42a as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_178;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_180;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_186;
                };
                {
                    sub_0024F109();
                    c2rust_current_block_39 = C2Rust_Block_39::S_192;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_194;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_196;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_198;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_200;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_39 = C2Rust_Block_39::S_321;
                    } else {
                        c2rust_current_block_39 = C2Rust_Block_39::S_213;
                    }
                };
            }
            C2Rust_Block_39::S_213 => {
                {
                    _pv_4 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_39 = C2Rust_Block_39::S_215;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_217;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_223;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_39 = C2Rust_Block_39::S_225;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_227;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_233;
                };
                {
                    _pv_5 = 0x24e436 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_235;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_237;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_243;
                };
                {
                    sub_0024E34F();
                    c2rust_current_block_39 = C2Rust_Block_39::S_249;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_251;
                };
                {
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_253;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_255;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_257;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_39 = C2Rust_Block_39::S_259;
                };
                {
                    if _fa >= _fb {
                        c2rust_current_block_39 = C2Rust_Block_39::S_301;
                    } else {
                        c2rust_current_block_39 = C2Rust_Block_39::S_268;
                    }
                };
            }
            C2Rust_Block_39::S_268 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_270;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    c2rust_current_block_39 = C2Rust_Block_39::S_272;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_274;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                    c2rust_current_block_39 = C2Rust_Block_39::S_276;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_278;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_280;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_282;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax)
                                .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_284;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_286;
                };
                {
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_288;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_290;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_292;
                };
                {
                    if _fa < _fb {
                        c2rust_current_block_39 = C2Rust_Block_39::S_268;
                    } else {
                        c2rust_current_block_39 = C2Rust_Block_39::S_301;
                    }
                };
            }
            C2Rust_Block_39::S_301 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_303;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_305;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_sub(1 as uint32_t),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_307;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_309;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_311;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_313;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx)
                                .wrapping_add(
                                    (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                                )
                                .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_343;
                };
            }
            C2Rust_Block_39::S_321 => {
                {
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_323;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_325;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_add(4 as uint32_t),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_327;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_329;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_331;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                    c2rust_current_block_39 = C2Rust_Block_39::S_333;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_335;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_337;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_343;
                };
            }
            C2Rust_Block_39::S_343 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_add(1 as uint32_t),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_345;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_347;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_349;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_351;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_353;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_355;
                };
                {
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_357;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_359;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_39 = C2Rust_Block_39::S_361;
                };
                {
                    if _fa < _fb {
                        c2rust_current_block_39 = C2Rust_Block_39::S_143;
                    } else {
                        c2rust_current_block_39 = C2Rust_Block_39::S_374;
                    }
                };
            }
            C2Rust_Block_39::S_374 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_376;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_386;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_388;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_402;
                };
            }
            C2Rust_Block_39::S_402 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_404;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_410;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_39 = C2Rust_Block_39::S_416;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_39 = C2Rust_Block_39::S_418;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_424;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_39 = C2Rust_Block_39::S_426;
                };
                return;
            }
            C2Rust_Block_39::S_101
            | C2Rust_Block_39::S_103
            | C2Rust_Block_39::S_109
            | C2Rust_Block_39::S_111
            | C2Rust_Block_39::S_113
            | C2Rust_Block_39::S_115
            | C2Rust_Block_39::S_117
            | C2Rust_Block_39::S_119
            | C2Rust_Block_39::S_121
            | C2Rust_Block_39::S_123
            | C2Rust_Block_39::S_129
            | C2Rust_Block_39::S_131
            | C2Rust_Block_39::S_133
            | C2Rust_Block_39::S_145
            | C2Rust_Block_39::S_147
            | C2Rust_Block_39::S_149
            | C2Rust_Block_39::S_151
            | C2Rust_Block_39::S_162
            | C2Rust_Block_39::S_164
            | C2Rust_Block_39::S_166
            | C2Rust_Block_39::S_168
            | C2Rust_Block_39::S_170
            | C2Rust_Block_39::S_176
            | C2Rust_Block_39::S_178
            | C2Rust_Block_39::S_180
            | C2Rust_Block_39::S_186
            | C2Rust_Block_39::S_192
            | C2Rust_Block_39::S_194
            | C2Rust_Block_39::S_196
            | C2Rust_Block_39::S_198
            | C2Rust_Block_39::S_2
            | C2Rust_Block_39::S_200
            | C2Rust_Block_39::S_215
            | C2Rust_Block_39::S_217
            | C2Rust_Block_39::S_223
            | C2Rust_Block_39::S_225
            | C2Rust_Block_39::S_227
            | C2Rust_Block_39::S_233
            | C2Rust_Block_39::S_235
            | C2Rust_Block_39::S_237
            | C2Rust_Block_39::S_243
            | C2Rust_Block_39::S_249
            | C2Rust_Block_39::S_251
            | C2Rust_Block_39::S_253
            | C2Rust_Block_39::S_255
            | C2Rust_Block_39::S_257
            | C2Rust_Block_39::S_259
            | C2Rust_Block_39::S_26
            | C2Rust_Block_39::S_270
            | C2Rust_Block_39::S_272
            | C2Rust_Block_39::S_274
            | C2Rust_Block_39::S_276
            | C2Rust_Block_39::S_278
            | C2Rust_Block_39::S_28
            | C2Rust_Block_39::S_280
            | C2Rust_Block_39::S_282
            | C2Rust_Block_39::S_284
            | C2Rust_Block_39::S_286
            | C2Rust_Block_39::S_288
            | C2Rust_Block_39::S_290
            | C2Rust_Block_39::S_292
            | C2Rust_Block_39::S_30
            | C2Rust_Block_39::S_303
            | C2Rust_Block_39::S_305
            | C2Rust_Block_39::S_307
            | C2Rust_Block_39::S_309
            | C2Rust_Block_39::S_311
            | C2Rust_Block_39::S_313
            | C2Rust_Block_39::S_323
            | C2Rust_Block_39::S_325
            | C2Rust_Block_39::S_327
            | C2Rust_Block_39::S_329
            | C2Rust_Block_39::S_331
            | C2Rust_Block_39::S_333
            | C2Rust_Block_39::S_335
            | C2Rust_Block_39::S_337
            | C2Rust_Block_39::S_345
            | C2Rust_Block_39::S_347
            | C2Rust_Block_39::S_349
            | C2Rust_Block_39::S_351
            | C2Rust_Block_39::S_353
            | C2Rust_Block_39::S_355
            | C2Rust_Block_39::S_357
            | C2Rust_Block_39::S_359
            | C2Rust_Block_39::S_36
            | C2Rust_Block_39::S_361
            | C2Rust_Block_39::S_376
            | C2Rust_Block_39::S_38
            | C2Rust_Block_39::S_386
            | C2Rust_Block_39::S_388
            | C2Rust_Block_39::S_4
            | C2Rust_Block_39::S_40
            | C2Rust_Block_39::S_404
            | C2Rust_Block_39::S_410
            | C2Rust_Block_39::S_416
            | C2Rust_Block_39::S_418
            | C2Rust_Block_39::S_42
            | C2Rust_Block_39::S_424
            | C2Rust_Block_39::S_426
            | C2Rust_Block_39::S_44
            | C2Rust_Block_39::S_46
            | C2Rust_Block_39::S_48
            | C2Rust_Block_39::S_50
            | C2Rust_Block_39::S_56
            | C2Rust_Block_39::S_58
            | C2Rust_Block_39::S_6
            | C2Rust_Block_39::S_60
            | C2Rust_Block_39::S_66
            | C2Rust_Block_39::S_68
            | C2Rust_Block_39::S_70
            | C2Rust_Block_39::S_72
            | C2Rust_Block_39::S_74
            | C2Rust_Block_39::S_76
            | C2Rust_Block_39::S_78
            | C2Rust_Block_39::S_8
            | C2Rust_Block_39::S_80
            | C2Rust_Block_39::S_82
            | C2Rust_Block_39::S_84
            | C2Rust_Block_39::S_86 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E472() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    's_383: {
        if _fa >= _fb {
            break 's_383;
        }
        loop {
            _fa = ebp & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ebx).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_257: {
                's_149: {
                    if _fa > _fb {
                        break 's_149;
                    }
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    let mut _pv_5: uint32_t = 0x50 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    let mut _i: uint32_t = 0;
                    let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    };
                    _i = 0 as uint32_t;
                    while _i < (*__gamepkg_tls_g_ecx) {
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edi)
                                    .wrapping_add(_i.wrapping_mul(_st as uint32_t))
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            (*__gamepkg_tls_g_eax),
                        );
                        _i = _i.wrapping_add(1);
                    }
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t),
                        );
                    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    break 's_257;
                }
                let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                let mut _pv_4: uint32_t = 0x24e49a as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                sub_0024E377();
                ebp = ebp.wrapping_sub(1);
                _fa = ebp & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
            }
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        loop {
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_383;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ebx).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx).wrapping_add(0x24 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_6: uint32_t = 0x50 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            let mut _i_0: uint32_t = 0;
            let mut _st_0: int32_t = if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            };
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i_0.wrapping_mul(_st_0 as uint32_t))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st_0 as uint32_t));
            (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx).wrapping_add(0x4c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E4D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x24e4e0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024DE67();
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) < (*__gamepkg_tls_g_ecx)) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub((*__gamepkg_tls_g_ecx));
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x80004005 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E4F1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    's_238: {
        if _fa <= _fb {
            break 's_238;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
        's_226: loop {
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_173: {
                if _fa != _fb {
                    break 's_173;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_173;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_ebx).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                break 's_226;
            }
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E534() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_200: {
        if _fa <= _fb {
            break 's_200;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        's_184: loop {
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_133: {
                if _fa != _fb {
                    break 's_133;
                }
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_133;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                break 's_184;
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E56B() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_204: {
        if _fa == _fb {
            break 's_204;
        }
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa <= _fb {
            break 's_204;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx).wrapping_add(0x50 as uint32_t);
        's_188: loop {
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_119: {
                if _fa != _fb {
                    break 's_119;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(2 as uint32_t));
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 5 as ::core::ffi::c_int;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                break 's_188;
            }
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 0x60 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add(0x60 as uint32_t);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E5A0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_7: uint32_t = 0;
    enum C2Rust_Block_45 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_76,
        S_78,
        S_80,
        S_90,
        S_92,
        S_94,
        S_100,
        S_103,
        S_106,
        S_112,
        S_114,
        S_116,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_137,
        S_139,
        S_141,
        S_149,
        S_151,
        S_153,
        S_157,
        S_159,
        S_163,
        S_169,
        S_176,
        S_178,
        S_180,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_242,
        S_244,
        S_246,
        S_252,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_277,
        S_285,
        S_287,
        S_289,
        S_295,
        S_297,
        S_299,
        S_305,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_370,
        S_373,
        S_376,
        S_382,
        S_384,
        S_386,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_407,
        S_409,
        S_411,
        S_419,
        S_421,
        S_423,
        S_427,
        S_429,
        S_433,
        S_439,
        S_446,
        S_448,
        S_450,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_485,
        S_487,
        S_489,
        S_495,
        S_497,
        S_499,
        S_505,
        S_511,
        S_517,
        S_519,
        S_529,
        S_531,
        S_541,
        S_543,
        S_549,
        S_555,
        S_557,
        S_563,
        S_565,
    }
    let mut c2rust_current_block_45: C2Rust_Block_45;
    c2rust_current_block_45 = C2Rust_Block_45::S_0;
    loop {
        match c2rust_current_block_45 {
            C2Rust_Block_45::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_45 = C2Rust_Block_45::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_45 = C2Rust_Block_45::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_26;
                };
                {
                    _pv = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_30;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_36;
                };
                {
                    ebp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_45 = C2Rust_Block_45::S_38;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_40;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_42;
                };
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_44;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_46;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0xc as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_48;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_50;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_52;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) & 0 as uint32_t,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_54;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_56;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_62;
                };
                {
                    _pv_0 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_45 = C2Rust_Block_45::S_64;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_66;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_76;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_45 = C2Rust_Block_45::S_78;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_80;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_90;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_45 = C2Rust_Block_45::S_92;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_94;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_100;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_45 = C2Rust_Block_45::S_103;
                };
                {
                    _icall_esp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_45 = C2Rust_Block_45::S_106;
                };
                {
                    _icall_target = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_112;
                };
                {
                    _pv_3 = 0x24e5b5 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_114;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_116;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_126;
                };
                {
                    _va = _icall_target;
                    c2rust_current_block_45 = C2Rust_Block_45::S_128;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_130;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_132;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_134;
                };
                {
                    if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                    {
                        c2rust_current_block_45 = C2Rust_Block_45::S_137;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_149;
                    }
                };
            }
            C2Rust_Block_45::S_137 => {
                {
                    recomp_icall_not_code_log(_va);
                    c2rust_current_block_45 = C2Rust_Block_45::S_139;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_141;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_198;
                };
            }
            C2Rust_Block_45::S_149 => {
                {
                    _fn = recomp_lookup_manual(_va);
                    c2rust_current_block_45 = C2Rust_Block_45::S_151;
                };
                {
                    if _fn.is_none() {
                        c2rust_current_block_45 = C2Rust_Block_45::S_153;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_157;
                    }
                };
            }
            C2Rust_Block_45::S_153 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_45 = C2Rust_Block_45::S_157;
            }
            C2Rust_Block_45::S_157 => {
                if _fn.is_none() {
                    c2rust_current_block_45 = C2Rust_Block_45::S_159;
                } else {
                    c2rust_current_block_45 = C2Rust_Block_45::S_163;
                }
            }
            C2Rust_Block_45::S_159 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_45 = C2Rust_Block_45::S_163;
            }
            C2Rust_Block_45::S_163 => {
                if _fn.is_some() {
                    c2rust_current_block_45 = C2Rust_Block_45::S_169;
                } else {
                    c2rust_current_block_45 = C2Rust_Block_45::S_176;
                }
            }
            C2Rust_Block_45::S_169 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_45 = C2Rust_Block_45::S_198;
            }
            C2Rust_Block_45::S_176 => {
                {
                    recomp_icall_fail_log(_va);
                    c2rust_current_block_45 = C2Rust_Block_45::S_178;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_180;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_198;
                };
            }
            C2Rust_Block_45::S_198 => {
                {
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_200;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_202;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0xc as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_204;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_206;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_208;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_45 = C2Rust_Block_45::S_210;
                };
                {
                    (*__gamepkg_tls_g_esi) = ebp.wrapping_add(8 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_214;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_216;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_218;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_220;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_222;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_224;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_45 = C2Rust_Block_45::S_226;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(-1 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_228;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_230;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_232;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_234;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_236;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_242;
                };
                {
                    _pv_4 = 0x24e5ca as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_244;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_246;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_252;
                };
                {
                    sub_0024E4F1();
                    c2rust_current_block_45 = C2Rust_Block_45::S_258;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_260;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_262;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_264;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_266;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_268;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_45 = C2Rust_Block_45::S_285;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_277;
                    }
                };
            }
            C2Rust_Block_45::S_277 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x80004005 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_45 = C2Rust_Block_45::S_370;
            }
            C2Rust_Block_45::S_285 => {
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_45 = C2Rust_Block_45::S_287;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_289;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_295;
                };
                {
                    _pv_5 = 0x24e5e1 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_297;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_299;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_305;
                };
                {
                    sub_0024E56B();
                    c2rust_current_block_45 = C2Rust_Block_45::S_311;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_313;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_315;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_317;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_319;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_321;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_45 = C2Rust_Block_45::S_277;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_330;
                    }
                };
            }
            C2Rust_Block_45::S_330 => {
                {
                    (*__gamepkg_tls_g_esi) = ebp.wrapping_add(8 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_332;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_45 = C2Rust_Block_45::S_334;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_336;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_338;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_340;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_342;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_344;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_346;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_348;
                };
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_350;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (if (*__gamepkg_tls_g_df) != 0 {
                                -(4 as ::core::ffi::c_int as int32_t)
                            } else {
                                4 as ::core::ffi::c_int as int32_t
                            }) as uint32_t,
                        );
                    c2rust_current_block_45 = C2Rust_Block_45::S_352;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_354;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_356;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx)
                                .wrapping_add(
                                    (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                                ) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_358;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            )
                            .wrapping_add(1 as uint32_t),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_360;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_362;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_364;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_370;
                };
            }
            C2Rust_Block_45::S_370 => {
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        & 0xffffff00 as uint32_t
                        | ::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                (ebp.wrapping_add(-1 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_373;
                };
                {
                    _icall_esp_0 = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_45 = C2Rust_Block_45::S_376;
                };
                {
                    _icall_target_0 = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_382;
                };
                {
                    _pv_6 = 0x24e605 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_384;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_386;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_396;
                };
                {
                    _va_0 = _icall_target_0;
                    c2rust_current_block_45 = C2Rust_Block_45::S_398;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va_0,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_400;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_402;
                };
                {
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_404;
                };
                {
                    if !(_va_0 >= 0xfe000000 as uint32_t
                        || g_xbox_code_hi == 0 as uint32_t
                        || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                    {
                        c2rust_current_block_45 = C2Rust_Block_45::S_407;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_419;
                    }
                };
            }
            C2Rust_Block_45::S_407 => {
                {
                    recomp_icall_not_code_log(_va_0);
                    c2rust_current_block_45 = C2Rust_Block_45::S_409;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    c2rust_current_block_45 = C2Rust_Block_45::S_411;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_468;
                };
            }
            C2Rust_Block_45::S_419 => {
                {
                    _fn_0 = recomp_lookup_manual(_va_0);
                    c2rust_current_block_45 = C2Rust_Block_45::S_421;
                };
                {
                    if _fn_0.is_none() {
                        c2rust_current_block_45 = C2Rust_Block_45::S_423;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_427;
                    }
                };
            }
            C2Rust_Block_45::S_423 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_45 = C2Rust_Block_45::S_427;
            }
            C2Rust_Block_45::S_427 => {
                if _fn_0.is_none() {
                    c2rust_current_block_45 = C2Rust_Block_45::S_429;
                } else {
                    c2rust_current_block_45 = C2Rust_Block_45::S_433;
                }
            }
            C2Rust_Block_45::S_429 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_45 = C2Rust_Block_45::S_433;
            }
            C2Rust_Block_45::S_433 => {
                if _fn_0.is_some() {
                    c2rust_current_block_45 = C2Rust_Block_45::S_439;
                } else {
                    c2rust_current_block_45 = C2Rust_Block_45::S_446;
                }
            }
            C2Rust_Block_45::S_439 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_45 = C2Rust_Block_45::S_468;
            }
            C2Rust_Block_45::S_446 => {
                {
                    recomp_icall_fail_log(_va_0);
                    c2rust_current_block_45 = C2Rust_Block_45::S_448;
                };
                {
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    c2rust_current_block_45 = C2Rust_Block_45::S_450;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_468;
                };
            }
            C2Rust_Block_45::S_468 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_470;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_472;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_474;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_476;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        < if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_45 = C2Rust_Block_45::S_511;
                    } else {
                        c2rust_current_block_45 = C2Rust_Block_45::S_485;
                    }
                };
            }
            C2Rust_Block_45::S_485 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_487;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_489;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_495;
                };
                {
                    _pv_7 = 0x24e613 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_45 = C2Rust_Block_45::S_497;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_499;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_505;
                };
                {
                    sub_00250D19();
                    c2rust_current_block_45 = C2Rust_Block_45::S_511;
                };
            }
            C2Rust_Block_45::S_511 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_517;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_519;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_529;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_531;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_541;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_543;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_549;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_45 = C2Rust_Block_45::S_555;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_45 = C2Rust_Block_45::S_557;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_563;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(16 as uint32_t);
                    c2rust_current_block_45 = C2Rust_Block_45::S_565;
                };
                return;
            }
            C2Rust_Block_45::S_100
            | C2Rust_Block_45::S_103
            | C2Rust_Block_45::S_106
            | C2Rust_Block_45::S_112
            | C2Rust_Block_45::S_114
            | C2Rust_Block_45::S_116
            | C2Rust_Block_45::S_126
            | C2Rust_Block_45::S_128
            | C2Rust_Block_45::S_130
            | C2Rust_Block_45::S_132
            | C2Rust_Block_45::S_134
            | C2Rust_Block_45::S_139
            | C2Rust_Block_45::S_141
            | C2Rust_Block_45::S_151
            | C2Rust_Block_45::S_178
            | C2Rust_Block_45::S_180
            | C2Rust_Block_45::S_2
            | C2Rust_Block_45::S_200
            | C2Rust_Block_45::S_202
            | C2Rust_Block_45::S_204
            | C2Rust_Block_45::S_206
            | C2Rust_Block_45::S_208
            | C2Rust_Block_45::S_210
            | C2Rust_Block_45::S_212
            | C2Rust_Block_45::S_214
            | C2Rust_Block_45::S_216
            | C2Rust_Block_45::S_218
            | C2Rust_Block_45::S_220
            | C2Rust_Block_45::S_222
            | C2Rust_Block_45::S_224
            | C2Rust_Block_45::S_226
            | C2Rust_Block_45::S_228
            | C2Rust_Block_45::S_230
            | C2Rust_Block_45::S_232
            | C2Rust_Block_45::S_234
            | C2Rust_Block_45::S_236
            | C2Rust_Block_45::S_242
            | C2Rust_Block_45::S_244
            | C2Rust_Block_45::S_246
            | C2Rust_Block_45::S_252
            | C2Rust_Block_45::S_258
            | C2Rust_Block_45::S_26
            | C2Rust_Block_45::S_260
            | C2Rust_Block_45::S_262
            | C2Rust_Block_45::S_264
            | C2Rust_Block_45::S_266
            | C2Rust_Block_45::S_268
            | C2Rust_Block_45::S_28
            | C2Rust_Block_45::S_287
            | C2Rust_Block_45::S_289
            | C2Rust_Block_45::S_295
            | C2Rust_Block_45::S_297
            | C2Rust_Block_45::S_299
            | C2Rust_Block_45::S_30
            | C2Rust_Block_45::S_305
            | C2Rust_Block_45::S_311
            | C2Rust_Block_45::S_313
            | C2Rust_Block_45::S_315
            | C2Rust_Block_45::S_317
            | C2Rust_Block_45::S_319
            | C2Rust_Block_45::S_321
            | C2Rust_Block_45::S_332
            | C2Rust_Block_45::S_334
            | C2Rust_Block_45::S_336
            | C2Rust_Block_45::S_338
            | C2Rust_Block_45::S_340
            | C2Rust_Block_45::S_342
            | C2Rust_Block_45::S_344
            | C2Rust_Block_45::S_346
            | C2Rust_Block_45::S_348
            | C2Rust_Block_45::S_350
            | C2Rust_Block_45::S_352
            | C2Rust_Block_45::S_354
            | C2Rust_Block_45::S_356
            | C2Rust_Block_45::S_358
            | C2Rust_Block_45::S_36
            | C2Rust_Block_45::S_360
            | C2Rust_Block_45::S_362
            | C2Rust_Block_45::S_364
            | C2Rust_Block_45::S_373
            | C2Rust_Block_45::S_376
            | C2Rust_Block_45::S_38
            | C2Rust_Block_45::S_382
            | C2Rust_Block_45::S_384
            | C2Rust_Block_45::S_386
            | C2Rust_Block_45::S_396
            | C2Rust_Block_45::S_398
            | C2Rust_Block_45::S_4
            | C2Rust_Block_45::S_40
            | C2Rust_Block_45::S_400
            | C2Rust_Block_45::S_402
            | C2Rust_Block_45::S_404
            | C2Rust_Block_45::S_409
            | C2Rust_Block_45::S_411
            | C2Rust_Block_45::S_42
            | C2Rust_Block_45::S_421
            | C2Rust_Block_45::S_44
            | C2Rust_Block_45::S_448
            | C2Rust_Block_45::S_450
            | C2Rust_Block_45::S_46
            | C2Rust_Block_45::S_470
            | C2Rust_Block_45::S_472
            | C2Rust_Block_45::S_474
            | C2Rust_Block_45::S_476
            | C2Rust_Block_45::S_48
            | C2Rust_Block_45::S_487
            | C2Rust_Block_45::S_489
            | C2Rust_Block_45::S_495
            | C2Rust_Block_45::S_497
            | C2Rust_Block_45::S_499
            | C2Rust_Block_45::S_50
            | C2Rust_Block_45::S_505
            | C2Rust_Block_45::S_517
            | C2Rust_Block_45::S_519
            | C2Rust_Block_45::S_52
            | C2Rust_Block_45::S_529
            | C2Rust_Block_45::S_531
            | C2Rust_Block_45::S_54
            | C2Rust_Block_45::S_541
            | C2Rust_Block_45::S_543
            | C2Rust_Block_45::S_549
            | C2Rust_Block_45::S_555
            | C2Rust_Block_45::S_557
            | C2Rust_Block_45::S_56
            | C2Rust_Block_45::S_563
            | C2Rust_Block_45::S_565
            | C2Rust_Block_45::S_6
            | C2Rust_Block_45::S_62
            | C2Rust_Block_45::S_64
            | C2Rust_Block_45::S_66
            | C2Rust_Block_45::S_76
            | C2Rust_Block_45::S_78
            | C2Rust_Block_45::S_8
            | C2Rust_Block_45::S_80
            | C2Rust_Block_45::S_90
            | C2Rust_Block_45::S_92
            | C2Rust_Block_45::S_94 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E61D() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_168: {
        if _fa <= _fb {
            break 's_168;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        loop {
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(
                    (if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    }) as uint32_t,
                );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add(
                    (if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    }) as uint32_t,
                );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(
                    (if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    }) as uint32_t,
                );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add(
                    (if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    }) as uint32_t,
                );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(
                    (if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    }) as uint32_t,
                );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add(
                    (if (*__gamepkg_tls_g_df) != 0 {
                        -(4 as ::core::ffi::c_int as int32_t)
                    } else {
                        4 as ::core::ffi::c_int as int32_t
                    }) as uint32_t,
                );
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E64E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) << 2 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add((*__gamepkg_tls_g_eax)) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0x24e668 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_00250B13();
    ebp = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_272: {
        if _fa <= _fb {
            break 's_272;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_184: {
            if _fa == _fb {
                break 's_184;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edi));
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
            if _fa == 0 as uint32_t {
                break 's_272;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_4: uint32_t = 0x24e6a3 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_00250B13();
            _fa = ebp & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_272;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E6C5() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_esi) = ebp.wrapping_add(8 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x80004005 as ::core::ffi::c_uint as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_4: uint32_t = 0x24e6e5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024E534();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_292: {
        if _fa >= _fb {
            break 's_292;
        }
        let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ebp) = ebp;
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _pv_7: uint32_t = 0x24e6fd as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        sub_00250B2D();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_292;
        }
        let mut _pv_8: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_ebp) = ebp;
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _pv_9: uint32_t = 0x24e70c as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        sub_0024E64E();
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(24 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024E716() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
