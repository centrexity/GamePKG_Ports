extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001B3210();
    fn sub_001B32A0();
    fn sub_001B3320();
    fn sub_001CFE6F();
    fn sub_001D032C();
    fn sub_001D0A32();
    fn sub_001D0C95();
    fn sub_001D0D9F();
    fn sub_001D0DE6();
    fn sub_001D0E3C();
    fn sub_001D0FC7();
    fn sub_001D10B4();
    fn sub_001D118A();
    fn sub_001D120E();
    fn sub_001D1308();
    fn sub_001D1435();
    fn sub_001D1470();
    fn sub_001D14D1();
    fn sub_001D1608();
    fn sub_001D1660();
    fn sub_001D16B2();
    fn sub_001D18B0();
    fn sub_001D192B();
    fn sub_001D19FD();
    fn sub_001D1D5F();
    fn sub_001D1E1A();
    fn sub_001D1F4E();
    fn sub_00243F9E();
    fn sub_00245DF0();
    fn sub_001D0554();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B35D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    let mut _pv_0: uint32_t = 0x1b35dc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001B3210();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_77: {
        if _fa == _fb {
            break 's_77;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = 0x1b35e9 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_211: {
            's_158: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_158;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_211;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_166: {
                if !_fn.is_none() {
                    break 's_166;
                }
                _fn = recomp_lookup(_va);
            }
            's_172: {
                if !_fn.is_none() {
                    break 's_172;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_178: {
                if _fn.is_some() {
                    break 's_178;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_211;
            }
            _fn.expect("non-null function pointer")();
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B35F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3600() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0x1b360e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_120: {
        's_71: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_71;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_120;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_79: {
            if !_fn.is_none() {
                break 's_79;
            }
            _fn = recomp_lookup(_va);
        }
        's_85: {
            if !_fn.is_none() {
                break 's_85;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_91: {
            if _fn.is_some() {
                break 's_91;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_120;
        }
        _fn.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3610() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_30: {
        if !_fn.is_none() {
            break 's_30;
        }
        _fn = recomp_lookup(_va);
    }
    's_36: {
        if !_fn.is_none() {
            break 's_36;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_63: {
        's_42: {
            if _fn.is_some() {
                break 's_42;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_63;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3620() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3630() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi);
    let mut _pv_0: uint32_t = 0x1b363e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001B3950();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x10 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_87: {
        if _fa != 0 as uint32_t {
            break 's_87;
        }
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        let mut _pv_4: uint32_t = 0x1b368d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001B3990();
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_369: {
            if _fa == _fb {
                break 's_369;
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_369;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _icall_target: uint32_t = (*__gamepkg_tls_g_eax);
            let mut _pv_7: uint32_t = 0x1b36a7 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_355: {
                's_306: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_306;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_355;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_314: {
                    if !_fn.is_none() {
                        break 's_314;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_320: {
                    if !_fn.is_none() {
                        break 's_320;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_326: {
                    if _fn.is_some() {
                        break 's_326;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_355;
                }
                _fn.expect("non-null function pointer")();
            }
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1b367f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D14D1();
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B36C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1b36cc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D19FD();
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0xffffffff as ::core::ffi::c_uint as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B36E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = 2 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x144 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint8_t,
    );
    's_73: {
        if _fa != _fb {
            break 's_73;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_001B3722();
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1b371c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D14D1();
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3722() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1b372e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001B39F0();
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_248: {
        if _fa != _fb {
            break 's_248;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_248;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 6 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _icall_target: uint32_t = (*__gamepkg_tls_g_eax);
        let mut _pv_4: uint32_t = 0x1b374b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_234: {
            's_185: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_185;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_234;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_193: {
                if !_fn.is_none() {
                    break 's_193;
                }
                _fn = recomp_lookup(_va);
            }
            's_199: {
                if !_fn.is_none() {
                    break 's_199;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_205: {
                if _fn.is_some() {
                    break 's_205;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_234;
            }
            _fn.expect("non-null function pointer")();
        }
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3760() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3770() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(0 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_164: {
        's_57: {
            if _fa != 0 as uint32_t {
                break 's_57;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_164;
        }
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(2 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        's_142: {
            if _fa == 0 as uint32_t {
                break 's_142;
            }
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_134: {
                if _fa != _fb {
                    break 's_134;
                }
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_134;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            break 's_164;
        }
        (*__gamepkg_tls_g_eax) = 2 as uint32_t;
    }
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        2 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x144 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint8_t,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_291: {
        if _fa == _fb {
            break 's_291;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x40 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x148 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x38 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_esi),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x3c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            3 as uint32_t,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1b37e2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001D14D1();
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
        return;
    }
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_6: uint32_t = 0x1b37f4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001B3A80();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3800() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    's_139: {
        if _fa == _fb {
            break 's_139;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_139;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = 0x1b3822 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            sub_001D1608();
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa != _fb {
                break 's_139;
            }
        }
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3830() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_66: {
        if _fa == _fb {
            break 's_66;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_66;
        }
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x144 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3850() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1b3856 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001D192B();
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x7b as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_275: {
        if _fa > _fb {
            break 's_275;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x1b38cc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        let mut _jt: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x1b38b8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_167: {
            if _jt == 0x1b386b as uint32_t {
                break 's_167;
            }
            's_96: {
                if _jt != 0x1b387b as uint32_t {
                    break 's_96;
                }
                (*__gamepkg_tls_g_eax) = 5 as uint32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            's_219: {
                if _jt == 0x1b388b as uint32_t {
                    break 's_219;
                }
                's_245: {
                    if _jt == 0x1b389b as uint32_t {
                        break 's_245;
                    }
                    if _jt == 0x1b38a8 as uint32_t {
                        break 's_275;
                    }
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    let mut _va: uint32_t = _jt;
                    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                    's_127: {
                        if !_fn.is_none() {
                            break 's_127;
                        }
                        _fn = recomp_lookup(_va);
                    }
                    's_133: {
                        if !_fn.is_none() {
                            break 's_133;
                        }
                        _fn = recomp_lookup_kernel(_va);
                    }
                    's_160: {
                        's_139: {
                            if _fn.is_some() {
                                break 's_139;
                            }
                            recomp_icall_fail_log(_va);
                            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                .wrapping_add(4 as uint32_t);
                            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                            break 's_160;
                        }
                        _fn.expect("non-null function pointer")();
                    }
                    return;
                }
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_eax) = 3 as uint32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = 2 as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3950() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        2 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x144 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    's_90: loop {
        _fa = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_ecx))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fb = 0x3a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_80: {
            if _fa == _fb {
                break 's_80;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa < _fb {
                continue 's_90;
            } else {
                break 's_90;
            }
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
            .wrapping_add((*__gamepkg_tls_g_ecx))
            .wrapping_add(1 as uint32_t);
        break;
    }
    let mut _pv: uint32_t = 0x5c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x104 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx).wrapping_add(0x38 as uint32_t);
    (*__gamepkg_tls_g_ecx) = 0x3b12e4 as uint32_t;
    let mut _pv_2: uint32_t = 0x1b3987 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001B32A0();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3990() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x28000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 3 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    let mut _pv_5: uint32_t = 0x80000000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t);
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0x1b39ae as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_001D0E3C();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_217: {
        if _fa != _fb {
            break 's_217;
        }
        let mut _pv_8: uint32_t = 0x1b39bb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_001B3850();
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_9: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = 0x1b39c5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_001D1435();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B39F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    let mut _pv_6: uint32_t = 0x1b3a09 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001D0FC7();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_221: {
        if _fa != _fb {
            break 's_221;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = 6 as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            3 as uint32_t,
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
        .wrapping_add((*__gamepkg_tls_g_eax) as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    let mut _t: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
        .wrapping_add((*__gamepkg_tls_g_ebx) as uint64_t)
        .wrapping_add(_cf as uint64_t);
    _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_edx) = _t as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    _cf = (_fa < _fb) as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    's_308: {
        's_296: {
            if _fa != _fb {
                break 's_296;
            }
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            _cf = (_fa < _fb) as ::core::ffi::c_int;
            if _fa >= _fb {
                break 's_308;
            }
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
    }
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3A80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    's_307: {
        's_207: {
            if _fa != _fb {
                break 's_207;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                | ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            if _fa != 0 as uint32_t {
                break 's_207;
            }
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x800 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = ebp;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = 0x1b3aa8 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_00245DF0();
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | (*__gamepkg_tls_g_edx);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            if _fa == 0 as uint32_t {
                break 's_207;
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(0x18 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ebx),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ebp,
            );
            break 's_307;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t);
        let mut _pv_8: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        let mut _pv_11: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_11,
        );
        let mut _pv_12: uint32_t = 0x1b3ad2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_12,
        );
        sub_001D1308();
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3AF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_93: {
        if _fa == _fb {
            break 's_93;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_93;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_93;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x144 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x144 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3B40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _jt: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    enum C2Rust_Block_21 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_73,
        S_79,
        S_81,
        S_83,
        S_89,
        S_95,
        S_97,
        S_103,
        S_105,
        S_107,
        S_117,
        S_119,
        S_121,
        S_127,
        S_137,
        S_139,
        S_149,
        S_151,
        S_157,
        S_159,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_187,
        S_189,
        S_191,
        S_197,
        S_207,
        S_209,
        S_214,
        S_219,
        S_224,
        S_229,
        S_234,
        S_240,
        S_242,
        S_244,
        S_246,
        S_250,
        S_252,
        S_256,
        S_262,
        S_269,
        S_271,
        S_273,
        S_283,
        S_290,
        S_296,
        S_298,
        S_300,
        S_306,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_337,
        S_345,
        S_347,
        S_353,
        S_355,
        S_361,
        S_363,
        S_365,
        S_375,
        S_377,
        S_379,
        S_385,
        S_391,
        S_393,
        S_395,
        S_398,
        S_401,
        S_407,
        S_409,
        S_411,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_432,
        S_434,
        S_436,
        S_444,
        S_446,
        S_448,
        S_452,
        S_454,
        S_458,
        S_464,
        S_471,
        S_473,
        S_475,
        S_493,
        S_495,
        S_497,
        S_499,
        S_501,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_536,
        S_544,
        S_546,
        S_548,
        S_554,
        S_556,
        S_558,
        S_568,
        S_570,
        S_572,
        S_582,
        S_584,
        S_586,
        S_596,
        S_598,
        S_600,
        S_606,
        S_618,
        S_624,
        S_626,
        S_628,
        S_638,
        S_640,
        S_642,
        S_648,
        S_654,
        S_656,
        S_658,
        S_664,
        S_666,
        S_672,
        S_674,
        S_676,
        S_686,
        S_688,
        S_690,
        S_700,
        S_702,
        S_704,
        S_714,
        S_716,
        S_718,
        S_724,
        S_730,
        S_736,
        S_742,
        S_744,
        S_746,
        S_756,
        S_758,
        S_760,
        S_770,
        S_772,
        S_774,
        S_780,
        S_786,
        S_788,
        S_790,
        S_792,
        S_794,
        S_796,
        S_809,
        S_811,
        S_813,
        S_819,
        S_835,
        S_837,
        S_839,
        S_849,
        S_851,
        S_853,
        S_863,
        S_865,
        S_867,
        S_873,
        S_879,
        S_881,
        S_883,
        S_885,
        S_891,
        S_893,
        S_895,
        S_897,
        S_899,
        S_905,
        S_907,
        S_913,
        S_922,
        S_924,
        S_930,
        S_932,
        S_934,
        S_944,
        S_946,
        S_948,
        S_954,
        S_964,
        S_966,
        S_976,
        S_978,
        S_984,
        S_986,
    }
    let mut c2rust_current_block_21: C2Rust_Block_21;
    c2rust_current_block_21 = C2Rust_Block_21::S_0;
    loop {
        match c2rust_current_block_21 {
            C2Rust_Block_21::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_2;
            }
            C2Rust_Block_21::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_21 = C2Rust_Block_21::S_4;
            }
            C2Rust_Block_21::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_21 = C2Rust_Block_21::S_6;
            }
            C2Rust_Block_21::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_8;
            }
            C2Rust_Block_21::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_18;
            }
            C2Rust_Block_21::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_21 = C2Rust_Block_21::S_28;
            }
            C2Rust_Block_21::S_28 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_21 = C2Rust_Block_21::S_30;
            }
            C2Rust_Block_21::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_32;
            }
            C2Rust_Block_21::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_42;
            }
            C2Rust_Block_21::S_42 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_21 = C2Rust_Block_21::S_44;
            }
            C2Rust_Block_21::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_46;
            }
            C2Rust_Block_21::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_52;
            }
            C2Rust_Block_21::S_52 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_54;
            }
            C2Rust_Block_21::S_54 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x144 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_56;
            }
            C2Rust_Block_21::S_56 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_58;
            }
            C2Rust_Block_21::S_58 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_60;
            }
            C2Rust_Block_21::S_60 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_62;
            }
            C2Rust_Block_21::S_62 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_64;
            }
            C2Rust_Block_21::S_64 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_165;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_73;
                }
            }
            C2Rust_Block_21::S_73 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_21 = C2Rust_Block_21::S_79;
            }
            C2Rust_Block_21::S_79 => {
                _pv_1 = 0x1b3b55 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_81;
            }
            C2Rust_Block_21::S_81 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_83;
            }
            C2Rust_Block_21::S_83 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_89;
            }
            C2Rust_Block_21::S_89 => {
                sub_001B3AF0();
                c2rust_current_block_21 = C2Rust_Block_21::S_95;
            }
            C2Rust_Block_21::S_95 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_97;
            }
            C2Rust_Block_21::S_97 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_103;
            }
            C2Rust_Block_21::S_103 => {
                _pv_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_21 = C2Rust_Block_21::S_105;
            }
            C2Rust_Block_21::S_105 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_107;
            }
            C2Rust_Block_21::S_107 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_117;
            }
            C2Rust_Block_21::S_117 => {
                _pv_3 = 0x1b3b64 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_119;
            }
            C2Rust_Block_21::S_119 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_121;
            }
            C2Rust_Block_21::S_121 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_127;
            }
            C2Rust_Block_21::S_127 => {
                sub_001D14D1();
                c2rust_current_block_21 = C2Rust_Block_21::S_137;
            }
            C2Rust_Block_21::S_137 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_139;
            }
            C2Rust_Block_21::S_139 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_149;
            }
            C2Rust_Block_21::S_149 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_151;
            }
            C2Rust_Block_21::S_151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_157;
            }
            C2Rust_Block_21::S_157 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_159;
            }
            C2Rust_Block_21::S_159 => return,
            C2Rust_Block_21::S_165 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_167;
            }
            C2Rust_Block_21::S_167 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_21 = C2Rust_Block_21::S_169;
            }
            C2Rust_Block_21::S_169 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_171;
            }
            C2Rust_Block_21::S_171 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_173;
            }
            C2Rust_Block_21::S_173 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_175;
            }
            C2Rust_Block_21::S_175 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_177;
            }
            C2Rust_Block_21::S_177 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_179;
            }
            C2Rust_Block_21::S_179 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_181;
            }
            C2Rust_Block_21::S_181 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_187;
            }
            C2Rust_Block_21::S_187 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_21 = C2Rust_Block_21::S_189;
            }
            C2Rust_Block_21::S_189 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_191;
            }
            C2Rust_Block_21::S_191 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_197;
            }
            C2Rust_Block_21::S_197 => {
                if _fa > _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_891;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_207;
                }
            }
            C2Rust_Block_21::S_207 => {
                _jt = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_mul(4 as uint32_t)
                            .wrapping_add(0x1b3c80 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_209;
            }
            C2Rust_Block_21::S_209 => {
                if _jt == 0x1b3b7f as uint32_t {
                    c2rust_current_block_21 = C2Rust_Block_21::S_290;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_214;
                }
            }
            C2Rust_Block_21::S_214 => {
                if _jt == 0x1b3b8b as uint32_t {
                    c2rust_current_block_21 = C2Rust_Block_21::S_318;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_219;
                }
            }
            C2Rust_Block_21::S_219 => {
                if _jt == 0x1b3bdf as uint32_t {
                    c2rust_current_block_21 = C2Rust_Block_21::S_544;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_224;
                }
            }
            C2Rust_Block_21::S_224 => {
                if _jt == 0x1b3bf2 as uint32_t {
                    c2rust_current_block_21 = C2Rust_Block_21::S_618;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_229;
                }
            }
            C2Rust_Block_21::S_229 => {
                if _jt == 0x1b3c21 as uint32_t {
                    c2rust_current_block_21 = C2Rust_Block_21::S_736;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_234;
                }
            }
            C2Rust_Block_21::S_234 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_21 = C2Rust_Block_21::S_240;
            }
            C2Rust_Block_21::S_240 => {
                _va = _jt;
                c2rust_current_block_21 = C2Rust_Block_21::S_242;
            }
            C2Rust_Block_21::S_242 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_21 = C2Rust_Block_21::S_244;
            }
            C2Rust_Block_21::S_244 => {
                if _fn.is_none() {
                    c2rust_current_block_21 = C2Rust_Block_21::S_246;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_250;
                }
            }
            C2Rust_Block_21::S_246 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_21 = C2Rust_Block_21::S_250;
            }
            C2Rust_Block_21::S_250 => {
                if _fn.is_none() {
                    c2rust_current_block_21 = C2Rust_Block_21::S_252;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_256;
                }
            }
            C2Rust_Block_21::S_252 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_21 = C2Rust_Block_21::S_256;
            }
            C2Rust_Block_21::S_256 => {
                if _fn.is_some() {
                    c2rust_current_block_21 = C2Rust_Block_21::S_262;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_269;
                }
            }
            C2Rust_Block_21::S_262 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_21 = C2Rust_Block_21::S_283;
            }
            C2Rust_Block_21::S_269 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_21 = C2Rust_Block_21::S_271;
            }
            C2Rust_Block_21::S_271 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_273;
            }
            C2Rust_Block_21::S_273 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_283;
            }
            C2Rust_Block_21::S_283 => return,
            C2Rust_Block_21::S_290 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_21 = C2Rust_Block_21::S_296;
            }
            C2Rust_Block_21::S_296 => {
                _pv_5 = 0x1b3b86 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_298;
            }
            C2Rust_Block_21::S_298 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_300;
            }
            C2Rust_Block_21::S_300 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_306;
            }
            C2Rust_Block_21::S_306 => {
                sub_001B3990();
                c2rust_current_block_21 = C2Rust_Block_21::S_891;
            }
            C2Rust_Block_21::S_318 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_320;
            }
            C2Rust_Block_21::S_320 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_322;
            }
            C2Rust_Block_21::S_322 => {
                _fb = 0x20000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_324;
            }
            C2Rust_Block_21::S_324 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_326;
            }
            C2Rust_Block_21::S_326 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_328;
            }
            C2Rust_Block_21::S_328 => {
                if _fa > _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_345;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_337;
                }
            }
            C2Rust_Block_21::S_337 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint8_t,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_353;
            }
            C2Rust_Block_21::S_345 => {
                (*__gamepkg_tls_g_edi) = 0x20000 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_347;
            }
            C2Rust_Block_21::S_347 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_353;
            }
            C2Rust_Block_21::S_353 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_355;
            }
            C2Rust_Block_21::S_355 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_361;
            }
            C2Rust_Block_21::S_361 => {
                _pv_6 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_21 = C2Rust_Block_21::S_363;
            }
            C2Rust_Block_21::S_363 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_365;
            }
            C2Rust_Block_21::S_365 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_375;
            }
            C2Rust_Block_21::S_375 => {
                _pv_7 = 0x1b3bb4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_377;
            }
            C2Rust_Block_21::S_377 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_379;
            }
            C2Rust_Block_21::S_379 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_385;
            }
            C2Rust_Block_21::S_385 => {
                sub_001B39F0();
                c2rust_current_block_21 = C2Rust_Block_21::S_391;
            }
            C2Rust_Block_21::S_391 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_393;
            }
            C2Rust_Block_21::S_393 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_395;
            }
            C2Rust_Block_21::S_395 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_21 = C2Rust_Block_21::S_398;
            }
            C2Rust_Block_21::S_398 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_21 = C2Rust_Block_21::S_401;
            }
            C2Rust_Block_21::S_401 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_407;
            }
            C2Rust_Block_21::S_407 => {
                _pv_8 = 0x1b3bbd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_409;
            }
            C2Rust_Block_21::S_409 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_411;
            }
            C2Rust_Block_21::S_411 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_421;
            }
            C2Rust_Block_21::S_421 => {
                _va_0 = _icall_target;
                c2rust_current_block_21 = C2Rust_Block_21::S_423;
            }
            C2Rust_Block_21::S_423 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_425;
            }
            C2Rust_Block_21::S_425 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_427;
            }
            C2Rust_Block_21::S_427 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_429;
            }
            C2Rust_Block_21::S_429 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_21 = C2Rust_Block_21::S_432;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_444;
                }
            }
            C2Rust_Block_21::S_432 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_21 = C2Rust_Block_21::S_434;
            }
            C2Rust_Block_21::S_434 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_21 = C2Rust_Block_21::S_436;
            }
            C2Rust_Block_21::S_436 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_493;
            }
            C2Rust_Block_21::S_444 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_21 = C2Rust_Block_21::S_446;
            }
            C2Rust_Block_21::S_446 => {
                if _fn_0.is_none() {
                    c2rust_current_block_21 = C2Rust_Block_21::S_448;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_452;
                }
            }
            C2Rust_Block_21::S_448 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_21 = C2Rust_Block_21::S_452;
            }
            C2Rust_Block_21::S_452 => {
                if _fn_0.is_none() {
                    c2rust_current_block_21 = C2Rust_Block_21::S_454;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_458;
                }
            }
            C2Rust_Block_21::S_454 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_21 = C2Rust_Block_21::S_458;
            }
            C2Rust_Block_21::S_458 => {
                if _fn_0.is_some() {
                    c2rust_current_block_21 = C2Rust_Block_21::S_464;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_471;
                }
            }
            C2Rust_Block_21::S_464 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_21 = C2Rust_Block_21::S_493;
            }
            C2Rust_Block_21::S_471 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_21 = C2Rust_Block_21::S_473;
            }
            C2Rust_Block_21::S_473 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_21 = C2Rust_Block_21::S_475;
            }
            C2Rust_Block_21::S_475 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_493;
            }
            C2Rust_Block_21::S_493 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_495;
            }
            C2Rust_Block_21::S_495 => {
                _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_497;
            }
            C2Rust_Block_21::S_497 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_499;
            }
            C2Rust_Block_21::S_499 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_501;
            }
            C2Rust_Block_21::S_501 => {
                if _fa == _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_891;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_510;
                }
            }
            C2Rust_Block_21::S_510 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_512;
            }
            C2Rust_Block_21::S_512 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_514;
            }
            C2Rust_Block_21::S_514 => {
                _fb = 0xfffe0000 as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_516;
            }
            C2Rust_Block_21::S_516 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_518;
            }
            C2Rust_Block_21::S_518 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0xfffe0000 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_520;
            }
            C2Rust_Block_21::S_520 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_522;
            }
            C2Rust_Block_21::S_522 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_524;
            }
            C2Rust_Block_21::S_524 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_526;
            }
            C2Rust_Block_21::S_526 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_528;
            }
            C2Rust_Block_21::S_528 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edi));
                c2rust_current_block_21 = C2Rust_Block_21::S_530;
            }
            C2Rust_Block_21::S_530 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_532;
            }
            C2Rust_Block_21::S_532 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_534;
            }
            C2Rust_Block_21::S_534 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_536;
            }
            C2Rust_Block_21::S_536 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_891;
            }
            C2Rust_Block_21::S_544 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_546;
            }
            C2Rust_Block_21::S_546 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_548;
            }
            C2Rust_Block_21::S_548 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_554;
            }
            C2Rust_Block_21::S_554 => {
                _pv_9 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_21 = C2Rust_Block_21::S_556;
            }
            C2Rust_Block_21::S_556 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_558;
            }
            C2Rust_Block_21::S_558 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_568;
            }
            C2Rust_Block_21::S_568 => {
                _pv_10 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_21 = C2Rust_Block_21::S_570;
            }
            C2Rust_Block_21::S_570 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_572;
            }
            C2Rust_Block_21::S_572 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_582;
            }
            C2Rust_Block_21::S_582 => {
                _pv_11 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_584;
            }
            C2Rust_Block_21::S_584 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_586;
            }
            C2Rust_Block_21::S_586 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_596;
            }
            C2Rust_Block_21::S_596 => {
                _pv_12 = 0x1b3bf0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_598;
            }
            C2Rust_Block_21::S_598 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_600;
            }
            C2Rust_Block_21::S_600 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_606;
            }
            C2Rust_Block_21::S_606 => {
                sub_001B3A80();
                c2rust_current_block_21 = C2Rust_Block_21::S_891;
            }
            C2Rust_Block_21::S_618 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x150 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_624;
            }
            C2Rust_Block_21::S_624 => {
                _pv_13 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_626;
            }
            C2Rust_Block_21::S_626 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_628;
            }
            C2Rust_Block_21::S_628 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_638;
            }
            C2Rust_Block_21::S_638 => {
                _pv_14 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_640;
            }
            C2Rust_Block_21::S_640 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_642;
            }
            C2Rust_Block_21::S_642 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_648;
            }
            C2Rust_Block_21::S_648 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x158 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_654;
            }
            C2Rust_Block_21::S_654 => {
                _pv_15 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_21 = C2Rust_Block_21::S_656;
            }
            C2Rust_Block_21::S_656 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_658;
            }
            C2Rust_Block_21::S_658 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_664;
            }
            C2Rust_Block_21::S_664 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_666;
            }
            C2Rust_Block_21::S_666 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x154 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_672;
            }
            C2Rust_Block_21::S_672 => {
                _pv_16 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_21 = C2Rust_Block_21::S_674;
            }
            C2Rust_Block_21::S_674 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_676;
            }
            C2Rust_Block_21::S_676 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_686;
            }
            C2Rust_Block_21::S_686 => {
                _pv_17 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_688;
            }
            C2Rust_Block_21::S_688 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_690;
            }
            C2Rust_Block_21::S_690 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_700;
            }
            C2Rust_Block_21::S_700 => {
                _pv_18 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_21 = C2Rust_Block_21::S_702;
            }
            C2Rust_Block_21::S_702 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_704;
            }
            C2Rust_Block_21::S_704 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_714;
            }
            C2Rust_Block_21::S_714 => {
                _pv_19 = 0x1b3c17 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_716;
            }
            C2Rust_Block_21::S_716 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_718;
            }
            C2Rust_Block_21::S_718 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_724;
            }
            C2Rust_Block_21::S_724 => {
                sub_001D032C();
                c2rust_current_block_21 = C2Rust_Block_21::S_730;
            }
            C2Rust_Block_21::S_730 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    5 as uint32_t,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_736;
            }
            C2Rust_Block_21::S_736 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x154 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_742;
            }
            C2Rust_Block_21::S_742 => {
                _pv_20 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_744;
            }
            C2Rust_Block_21::S_744 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_746;
            }
            C2Rust_Block_21::S_746 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_756;
            }
            C2Rust_Block_21::S_756 => {
                _pv_21 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_21 = C2Rust_Block_21::S_758;
            }
            C2Rust_Block_21::S_758 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_760;
            }
            C2Rust_Block_21::S_760 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_770;
            }
            C2Rust_Block_21::S_770 => {
                _pv_22 = 0x1b3c2f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_772;
            }
            C2Rust_Block_21::S_772 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_774;
            }
            C2Rust_Block_21::S_774 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_780;
            }
            C2Rust_Block_21::S_780 => {
                sub_001D0554();
                c2rust_current_block_21 = C2Rust_Block_21::S_786;
            }
            C2Rust_Block_21::S_786 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_788;
            }
            C2Rust_Block_21::S_788 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_790;
            }
            C2Rust_Block_21::S_790 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_792;
            }
            C2Rust_Block_21::S_792 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_794;
            }
            C2Rust_Block_21::S_794 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_796;
            }
            C2Rust_Block_21::S_796 => {
                if _fa != _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_835;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_809;
                }
            }
            C2Rust_Block_21::S_809 => {
                _pv_23 = 0x1b3c3c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_811;
            }
            C2Rust_Block_21::S_811 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_813;
            }
            C2Rust_Block_21::S_813 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_819;
            }
            C2Rust_Block_21::S_819 => {
                sub_001B3850();
                c2rust_current_block_21 = C2Rust_Block_21::S_891;
            }
            C2Rust_Block_21::S_835 => {
                _pv_24 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_837;
            }
            C2Rust_Block_21::S_837 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_839;
            }
            C2Rust_Block_21::S_839 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_849;
            }
            C2Rust_Block_21::S_849 => {
                _pv_25 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_21 = C2Rust_Block_21::S_851;
            }
            C2Rust_Block_21::S_851 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_853;
            }
            C2Rust_Block_21::S_853 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_863;
            }
            C2Rust_Block_21::S_863 => {
                _pv_26 = 0x1b3c46 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_865;
            }
            C2Rust_Block_21::S_865 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_867;
            }
            C2Rust_Block_21::S_867 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_873;
            }
            C2Rust_Block_21::S_873 => {
                sub_001D1435();
                c2rust_current_block_21 = C2Rust_Block_21::S_879;
            }
            C2Rust_Block_21::S_879 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_881;
            }
            C2Rust_Block_21::S_881 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_883;
            }
            C2Rust_Block_21::S_883 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_885;
            }
            C2Rust_Block_21::S_885 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_891;
            }
            C2Rust_Block_21::S_891 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_893;
            }
            C2Rust_Block_21::S_893 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_895;
            }
            C2Rust_Block_21::S_895 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_897;
            }
            C2Rust_Block_21::S_897 => {
                _fas = _fa as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_899;
            }
            C2Rust_Block_21::S_899 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_905;
            }
            C2Rust_Block_21::S_905 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_907;
            }
            C2Rust_Block_21::S_907 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_913;
            }
            C2Rust_Block_21::S_913 => {
                if _fa != _fb {
                    c2rust_current_block_21 = C2Rust_Block_21::S_964;
                } else {
                    c2rust_current_block_21 = C2Rust_Block_21::S_922;
                }
            }
            C2Rust_Block_21::S_922 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_924;
            }
            C2Rust_Block_21::S_924 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_930;
            }
            C2Rust_Block_21::S_930 => {
                _pv_27 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_21 = C2Rust_Block_21::S_932;
            }
            C2Rust_Block_21::S_932 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_934;
            }
            C2Rust_Block_21::S_934 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_944;
            }
            C2Rust_Block_21::S_944 => {
                _pv_28 = 0x1b3c7b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_21 = C2Rust_Block_21::S_946;
            }
            C2Rust_Block_21::S_946 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_948;
            }
            C2Rust_Block_21::S_948 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_954;
            }
            C2Rust_Block_21::S_954 => {
                sub_001D14D1();
                c2rust_current_block_21 = C2Rust_Block_21::S_964;
            }
            C2Rust_Block_21::S_964 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_966;
            }
            C2Rust_Block_21::S_966 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_976;
            }
            C2Rust_Block_21::S_976 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_21 = C2Rust_Block_21::S_978;
            }
            C2Rust_Block_21::S_978 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_984;
            }
            C2Rust_Block_21::S_984 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_21 = C2Rust_Block_21::S_986;
            }
            C2Rust_Block_21::S_986 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3CA0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_38: loop {
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        let mut _pv_0: uint32_t = 0x1b3cac as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_001B3CD0();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_103: {
            if _fa == _fb {
                break 's_103;
            }
            let mut _pv_1: uint32_t = 0x1b3cb5 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_001B3B40();
            continue 's_38;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1b3cc2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001D1608();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3CD0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    's_274: {
        's_147: {
            if _fa >= _fb {
                break 's_147;
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
            (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                * 0x160 as ::core::ffi::c_int as int32_t) as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edi));
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            loop {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_274;
                }
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fb = 0x160 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x160 as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_147;
                }
            }
        }
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_236: {
            if _fa <= _fb {
                break 's_236;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            loop {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_274;
                }
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fb = 0x160 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x160 as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_236;
                }
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3D40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3D50() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3D60() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    enum C2Rust_Block_26 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_58,
        S_60,
        S_62,
        S_68,
        S_70,
        S_72,
        S_78,
        S_80,
        S_82,
        S_92,
        S_94,
        S_96,
        S_106,
        S_108,
        S_110,
        S_120,
        S_122,
        S_124,
        S_130,
        S_136,
        S_138,
        S_140,
        S_146,
        S_156,
        S_158,
        S_160,
        S_170,
        S_172,
        S_174,
        S_184,
        S_186,
        S_188,
        S_198,
        S_200,
        S_202,
        S_208,
        S_214,
        S_216,
        S_218,
        S_224,
        S_234,
        S_236,
        S_238,
        S_248,
        S_250,
        S_252,
        S_262,
        S_264,
        S_266,
        S_276,
        S_278,
        S_280,
        S_290,
        S_292,
        S_294,
        S_304,
        S_306,
        S_308,
        S_314,
        S_320,
        S_322,
        S_324,
        S_330,
        S_340,
        S_342,
        S_344,
        S_350,
        S_356,
        S_358,
        S_360,
        S_366,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_389,
        S_391,
        S_393,
        S_395,
        S_405,
        S_407,
        S_409,
        S_415,
        S_421,
        S_423,
        S_425,
        S_435,
        S_437,
        S_439,
        S_445,
        S_451,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_463,
        S_465,
        S_474,
        S_476,
        S_478,
        S_480,
        S_482,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_535,
        S_537,
        S_539,
        S_541,
        S_547,
        S_549,
        S_551,
        S_557,
        S_567,
        S_569,
        S_579,
        S_581,
        S_591,
        S_593,
        S_599,
        S_601,
    }
    let mut c2rust_current_block_26: C2Rust_Block_26;
    c2rust_current_block_26 = C2Rust_Block_26::S_0;
    loop {
        match c2rust_current_block_26 {
            C2Rust_Block_26::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_2;
            }
            C2Rust_Block_26::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_26 = C2Rust_Block_26::S_4;
            }
            C2Rust_Block_26::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_26 = C2Rust_Block_26::S_6;
            }
            C2Rust_Block_26::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_8;
            }
            C2Rust_Block_26::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_18;
            }
            C2Rust_Block_26::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_26 = C2Rust_Block_26::S_28;
            }
            C2Rust_Block_26::S_28 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_30;
            }
            C2Rust_Block_26::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_32;
            }
            C2Rust_Block_26::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_42;
            }
            C2Rust_Block_26::S_42 => {
                _pv_0 = ebp;
                c2rust_current_block_26 = C2Rust_Block_26::S_44;
            }
            C2Rust_Block_26::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_46;
            }
            C2Rust_Block_26::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_52;
            }
            C2Rust_Block_26::S_52 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_58;
            }
            C2Rust_Block_26::S_58 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_26 = C2Rust_Block_26::S_60;
            }
            C2Rust_Block_26::S_60 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_62;
            }
            C2Rust_Block_26::S_62 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_68;
            }
            C2Rust_Block_26::S_68 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_70;
            }
            C2Rust_Block_26::S_70 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_72;
            }
            C2Rust_Block_26::S_72 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_78;
            }
            C2Rust_Block_26::S_78 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_80;
            }
            C2Rust_Block_26::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_82;
            }
            C2Rust_Block_26::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_92;
            }
            C2Rust_Block_26::S_92 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_94;
            }
            C2Rust_Block_26::S_94 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_96;
            }
            C2Rust_Block_26::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_106;
            }
            C2Rust_Block_26::S_106 => {
                _pv_4 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_108;
            }
            C2Rust_Block_26::S_108 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_110;
            }
            C2Rust_Block_26::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_120;
            }
            C2Rust_Block_26::S_120 => {
                _pv_5 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_122;
            }
            C2Rust_Block_26::S_122 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_124;
            }
            C2Rust_Block_26::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_130;
            }
            C2Rust_Block_26::S_130 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_26 = C2Rust_Block_26::S_136;
            }
            C2Rust_Block_26::S_136 => {
                _pv_6 = 0x1b3d74 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_138;
            }
            C2Rust_Block_26::S_138 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_140;
            }
            C2Rust_Block_26::S_140 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_146;
            }
            C2Rust_Block_26::S_146 => {
                sub_001D1470();
                c2rust_current_block_26 = C2Rust_Block_26::S_156;
            }
            C2Rust_Block_26::S_156 => {
                _pv_7 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_158;
            }
            C2Rust_Block_26::S_158 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_160;
            }
            C2Rust_Block_26::S_160 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_170;
            }
            C2Rust_Block_26::S_170 => {
                _pv_8 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_172;
            }
            C2Rust_Block_26::S_172 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_174;
            }
            C2Rust_Block_26::S_174 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_184;
            }
            C2Rust_Block_26::S_184 => {
                _pv_9 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_186;
            }
            C2Rust_Block_26::S_186 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_188;
            }
            C2Rust_Block_26::S_188 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_198;
            }
            C2Rust_Block_26::S_198 => {
                _pv_10 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_200;
            }
            C2Rust_Block_26::S_200 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_202;
            }
            C2Rust_Block_26::S_202 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_208;
            }
            C2Rust_Block_26::S_208 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_214;
            }
            C2Rust_Block_26::S_214 => {
                _pv_11 = 0x1b3d80 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_216;
            }
            C2Rust_Block_26::S_216 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_218;
            }
            C2Rust_Block_26::S_218 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_224;
            }
            C2Rust_Block_26::S_224 => {
                sub_001D1470();
                c2rust_current_block_26 = C2Rust_Block_26::S_234;
            }
            C2Rust_Block_26::S_234 => {
                _pv_12 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_236;
            }
            C2Rust_Block_26::S_236 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_238;
            }
            C2Rust_Block_26::S_238 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_248;
            }
            C2Rust_Block_26::S_248 => {
                _pv_13 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_250;
            }
            C2Rust_Block_26::S_250 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_252;
            }
            C2Rust_Block_26::S_252 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_262;
            }
            C2Rust_Block_26::S_262 => {
                _pv_14 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_26 = C2Rust_Block_26::S_264;
            }
            C2Rust_Block_26::S_264 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_266;
            }
            C2Rust_Block_26::S_266 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_276;
            }
            C2Rust_Block_26::S_276 => {
                _pv_15 = 0x1b3ca0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_278;
            }
            C2Rust_Block_26::S_278 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_280;
            }
            C2Rust_Block_26::S_280 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_290;
            }
            C2Rust_Block_26::S_290 => {
                _pv_16 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_292;
            }
            C2Rust_Block_26::S_292 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_294;
            }
            C2Rust_Block_26::S_294 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_304;
            }
            C2Rust_Block_26::S_304 => {
                _pv_17 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_26 = C2Rust_Block_26::S_306;
            }
            C2Rust_Block_26::S_306 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_308;
            }
            C2Rust_Block_26::S_308 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_314;
            }
            C2Rust_Block_26::S_314 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_320;
            }
            C2Rust_Block_26::S_320 => {
                _pv_18 = 0x1b3d92 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_322;
            }
            C2Rust_Block_26::S_322 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_324;
            }
            C2Rust_Block_26::S_324 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_330;
            }
            C2Rust_Block_26::S_330 => {
                sub_001D18B0();
                c2rust_current_block_26 = C2Rust_Block_26::S_340;
            }
            C2Rust_Block_26::S_340 => {
                _pv_19 = 0xfffffffe as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_342;
            }
            C2Rust_Block_26::S_342 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_344;
            }
            C2Rust_Block_26::S_344 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_350;
            }
            C2Rust_Block_26::S_350 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_356;
            }
            C2Rust_Block_26::S_356 => {
                _pv_20 = 0x1b3d9c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_358;
            }
            C2Rust_Block_26::S_358 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_360;
            }
            C2Rust_Block_26::S_360 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_366;
            }
            C2Rust_Block_26::S_366 => {
                sub_001D16B2();
                c2rust_current_block_26 = C2Rust_Block_26::S_372;
            }
            C2Rust_Block_26::S_372 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_374;
            }
            C2Rust_Block_26::S_374 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_376;
            }
            C2Rust_Block_26::S_376 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_378;
            }
            C2Rust_Block_26::S_378 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_380;
            }
            C2Rust_Block_26::S_380 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_26 = C2Rust_Block_26::S_405;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_389;
                }
            }
            C2Rust_Block_26::S_389 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_26 = C2Rust_Block_26::S_391;
            }
            C2Rust_Block_26::S_391 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_393;
            }
            C2Rust_Block_26::S_393 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_395;
            }
            C2Rust_Block_26::S_395 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_405;
            }
            C2Rust_Block_26::S_405 => {
                _pv_21 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_26 = C2Rust_Block_26::S_407;
            }
            C2Rust_Block_26::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_409;
            }
            C2Rust_Block_26::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_415;
            }
            C2Rust_Block_26::S_415 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_421;
            }
            C2Rust_Block_26::S_421 => {
                _pv_22 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_26 = C2Rust_Block_26::S_423;
            }
            C2Rust_Block_26::S_423 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_425;
            }
            C2Rust_Block_26::S_425 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_435;
            }
            C2Rust_Block_26::S_435 => {
                _pv_23 = 0x1b3dac as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_437;
            }
            C2Rust_Block_26::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_439;
            }
            C2Rust_Block_26::S_439 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_445;
            }
            C2Rust_Block_26::S_445 => {
                sub_001D1660();
                c2rust_current_block_26 = C2Rust_Block_26::S_451;
            }
            C2Rust_Block_26::S_451 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_453;
            }
            C2Rust_Block_26::S_453 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_455;
            }
            C2Rust_Block_26::S_455 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_457;
            }
            C2Rust_Block_26::S_457 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_459;
            }
            C2Rust_Block_26::S_459 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_461;
            }
            C2Rust_Block_26::S_461 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_463;
            }
            C2Rust_Block_26::S_463 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_465;
            }
            C2Rust_Block_26::S_465 => {
                if _fa <= _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_535;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_474;
                }
            }
            C2Rust_Block_26::S_474 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_476;
            }
            C2Rust_Block_26::S_476 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_478;
            }
            C2Rust_Block_26::S_478 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_480;
            }
            C2Rust_Block_26::S_480 => {
                (*__gamepkg_tls_g_edx) = ebp;
                c2rust_current_block_26 = C2Rust_Block_26::S_482;
            }
            C2Rust_Block_26::S_482 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_26 = C2Rust_Block_26::S_488;
            }
            C2Rust_Block_26::S_488 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_490;
            }
            C2Rust_Block_26::S_490 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_492;
            }
            C2Rust_Block_26::S_492 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_494;
            }
            C2Rust_Block_26::S_494 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_26 = C2Rust_Block_26::S_496;
            }
            C2Rust_Block_26::S_496 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_498;
            }
            C2Rust_Block_26::S_498 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_500;
            }
            C2Rust_Block_26::S_500 => {
                _fb = 0x160 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_502;
            }
            C2Rust_Block_26::S_502 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_504;
            }
            C2Rust_Block_26::S_504 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x160 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_506;
            }
            C2Rust_Block_26::S_506 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_508;
            }
            C2Rust_Block_26::S_508 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_510;
            }
            C2Rust_Block_26::S_510 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_26 = C2Rust_Block_26::S_512;
            }
            C2Rust_Block_26::S_512 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_514;
            }
            C2Rust_Block_26::S_514 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_516;
            }
            C2Rust_Block_26::S_516 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_518;
            }
            C2Rust_Block_26::S_518 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x148 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_520;
            }
            C2Rust_Block_26::S_520 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffffff as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_522;
            }
            C2Rust_Block_26::S_522 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_524;
            }
            C2Rust_Block_26::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x144 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_526;
            }
            C2Rust_Block_26::S_526 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_26 = C2Rust_Block_26::S_488;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_535;
                }
            }
            C2Rust_Block_26::S_535 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_537;
            }
            C2Rust_Block_26::S_537 => {
                (*__gamepkg_tls_g_eax) = ebp;
                c2rust_current_block_26 = C2Rust_Block_26::S_539;
            }
            C2Rust_Block_26::S_539 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_541;
            }
            C2Rust_Block_26::S_541 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_547;
            }
            C2Rust_Block_26::S_547 => {
                _pv_24 = 0x1b3df8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_549;
            }
            C2Rust_Block_26::S_549 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_551;
            }
            C2Rust_Block_26::S_551 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_557;
            }
            C2Rust_Block_26::S_557 => {
                sub_001B3320();
                c2rust_current_block_26 = C2Rust_Block_26::S_567;
            }
            C2Rust_Block_26::S_567 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_569;
            }
            C2Rust_Block_26::S_569 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_579;
            }
            C2Rust_Block_26::S_579 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_581;
            }
            C2Rust_Block_26::S_581 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_591;
            }
            C2Rust_Block_26::S_591 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_593;
            }
            C2Rust_Block_26::S_593 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_599;
            }
            C2Rust_Block_26::S_599 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_601;
            }
            C2Rust_Block_26::S_601 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3E00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
        * 0x160 as ::core::ffi::c_int as int32_t) as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_edx));
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3E20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    enum C2Rust_Block_28 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_30,
        S_32,
        S_34,
        S_44,
        S_46,
        S_48,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_78,
        S_80,
        S_82,
        S_88,
        S_97,
        S_103,
        S_109,
        S_111,
        S_113,
        S_119,
        S_122,
        S_125,
        S_131,
        S_133,
        S_135,
        S_145,
        S_147,
        S_149,
        S_151,
        S_153,
        S_156,
        S_158,
        S_160,
        S_168,
        S_170,
        S_172,
        S_176,
        S_178,
        S_182,
        S_188,
        S_195,
        S_197,
        S_199,
        S_217,
        S_219,
        S_221,
        S_224,
        S_227,
        S_233,
        S_235,
        S_237,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_258,
        S_260,
        S_262,
        S_270,
        S_272,
        S_274,
        S_278,
        S_280,
        S_284,
        S_290,
        S_297,
        S_299,
        S_301,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_367,
        S_369,
        S_379,
        S_381,
        S_387,
        S_389,
        S_391,
        S_393,
        S_399,
        S_401,
        S_407,
        S_409,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_451,
        S_453,
        S_455,
        S_465,
        S_467,
        S_469,
        S_475,
        S_481,
        S_483,
        S_485,
        S_491,
        S_493,
        S_503,
        S_505,
        S_515,
        S_517,
        S_523,
        S_525,
    }
    let mut c2rust_current_block_28: C2Rust_Block_28;
    c2rust_current_block_28 = C2Rust_Block_28::S_0;
    loop {
        match c2rust_current_block_28 {
            C2Rust_Block_28::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_2;
            }
            C2Rust_Block_28::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_28 = C2Rust_Block_28::S_4;
            }
            C2Rust_Block_28::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_28 = C2Rust_Block_28::S_6;
            }
            C2Rust_Block_28::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_8;
            }
            C2Rust_Block_28::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_18;
            }
            C2Rust_Block_28::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_28 = C2Rust_Block_28::S_24;
            }
            C2Rust_Block_28::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_30;
            }
            C2Rust_Block_28::S_30 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_28 = C2Rust_Block_28::S_32;
            }
            C2Rust_Block_28::S_32 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_34;
            }
            C2Rust_Block_28::S_34 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_44;
            }
            C2Rust_Block_28::S_44 => {
                _pv_0 = ebp;
                c2rust_current_block_28 = C2Rust_Block_28::S_46;
            }
            C2Rust_Block_28::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_48;
            }
            C2Rust_Block_28::S_48 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_54;
            }
            C2Rust_Block_28::S_54 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_56;
            }
            C2Rust_Block_28::S_56 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_58;
            }
            C2Rust_Block_28::S_58 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_60;
            }
            C2Rust_Block_28::S_60 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_62;
            }
            C2Rust_Block_28::S_62 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_64;
            }
            C2Rust_Block_28::S_64 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_66;
            }
            C2Rust_Block_28::S_66 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_68;
            }
            C2Rust_Block_28::S_68 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_70;
            }
            C2Rust_Block_28::S_70 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_72;
            }
            C2Rust_Block_28::S_72 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_78;
            }
            C2Rust_Block_28::S_78 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_28 = C2Rust_Block_28::S_80;
            }
            C2Rust_Block_28::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_82;
            }
            C2Rust_Block_28::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_88;
            }
            C2Rust_Block_28::S_88 => {
                if _fa <= _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_367;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_97;
                }
            }
            C2Rust_Block_28::S_97 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_28 = C2Rust_Block_28::S_103;
            }
            C2Rust_Block_28::S_103 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_109;
            }
            C2Rust_Block_28::S_109 => {
                _pv_2 = ebp;
                c2rust_current_block_28 = C2Rust_Block_28::S_111;
            }
            C2Rust_Block_28::S_111 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_113;
            }
            C2Rust_Block_28::S_113 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_119;
            }
            C2Rust_Block_28::S_119 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_28 = C2Rust_Block_28::S_122;
            }
            C2Rust_Block_28::S_122 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_28 = C2Rust_Block_28::S_125;
            }
            C2Rust_Block_28::S_125 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_131;
            }
            C2Rust_Block_28::S_131 => {
                _pv_3 = 0x1b3e38 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_133;
            }
            C2Rust_Block_28::S_133 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_135;
            }
            C2Rust_Block_28::S_135 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_145;
            }
            C2Rust_Block_28::S_145 => {
                _va = _icall_target;
                c2rust_current_block_28 = C2Rust_Block_28::S_147;
            }
            C2Rust_Block_28::S_147 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_149;
            }
            C2Rust_Block_28::S_149 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_151;
            }
            C2Rust_Block_28::S_151 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_153;
            }
            C2Rust_Block_28::S_153 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_28 = C2Rust_Block_28::S_156;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_168;
                }
            }
            C2Rust_Block_28::S_156 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_28 = C2Rust_Block_28::S_158;
            }
            C2Rust_Block_28::S_158 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_28 = C2Rust_Block_28::S_160;
            }
            C2Rust_Block_28::S_160 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_217;
            }
            C2Rust_Block_28::S_168 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_28 = C2Rust_Block_28::S_170;
            }
            C2Rust_Block_28::S_170 => {
                if _fn.is_none() {
                    c2rust_current_block_28 = C2Rust_Block_28::S_172;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_176;
                }
            }
            C2Rust_Block_28::S_172 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_28 = C2Rust_Block_28::S_176;
            }
            C2Rust_Block_28::S_176 => {
                if _fn.is_none() {
                    c2rust_current_block_28 = C2Rust_Block_28::S_178;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_182;
                }
            }
            C2Rust_Block_28::S_178 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_28 = C2Rust_Block_28::S_182;
            }
            C2Rust_Block_28::S_182 => {
                if _fn.is_some() {
                    c2rust_current_block_28 = C2Rust_Block_28::S_188;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_195;
                }
            }
            C2Rust_Block_28::S_188 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_28 = C2Rust_Block_28::S_217;
            }
            C2Rust_Block_28::S_195 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_28 = C2Rust_Block_28::S_197;
            }
            C2Rust_Block_28::S_197 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_28 = C2Rust_Block_28::S_199;
            }
            C2Rust_Block_28::S_199 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_217;
            }
            C2Rust_Block_28::S_217 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_219;
            }
            C2Rust_Block_28::S_219 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_221;
            }
            C2Rust_Block_28::S_221 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_28 = C2Rust_Block_28::S_224;
            }
            C2Rust_Block_28::S_224 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_28 = C2Rust_Block_28::S_227;
            }
            C2Rust_Block_28::S_227 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_233;
            }
            C2Rust_Block_28::S_233 => {
                _pv_4 = 0x1b3e41 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_235;
            }
            C2Rust_Block_28::S_235 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_237;
            }
            C2Rust_Block_28::S_237 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_247;
            }
            C2Rust_Block_28::S_247 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_28 = C2Rust_Block_28::S_249;
            }
            C2Rust_Block_28::S_249 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_251;
            }
            C2Rust_Block_28::S_251 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_253;
            }
            C2Rust_Block_28::S_253 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_255;
            }
            C2Rust_Block_28::S_255 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_28 = C2Rust_Block_28::S_258;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_270;
                }
            }
            C2Rust_Block_28::S_258 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_28 = C2Rust_Block_28::S_260;
            }
            C2Rust_Block_28::S_260 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_28 = C2Rust_Block_28::S_262;
            }
            C2Rust_Block_28::S_262 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_319;
            }
            C2Rust_Block_28::S_270 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_28 = C2Rust_Block_28::S_272;
            }
            C2Rust_Block_28::S_272 => {
                if _fn_0.is_none() {
                    c2rust_current_block_28 = C2Rust_Block_28::S_274;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_278;
                }
            }
            C2Rust_Block_28::S_274 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_28 = C2Rust_Block_28::S_278;
            }
            C2Rust_Block_28::S_278 => {
                if _fn_0.is_none() {
                    c2rust_current_block_28 = C2Rust_Block_28::S_280;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_284;
                }
            }
            C2Rust_Block_28::S_280 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_28 = C2Rust_Block_28::S_284;
            }
            C2Rust_Block_28::S_284 => {
                if _fn_0.is_some() {
                    c2rust_current_block_28 = C2Rust_Block_28::S_290;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_297;
                }
            }
            C2Rust_Block_28::S_290 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_28 = C2Rust_Block_28::S_319;
            }
            C2Rust_Block_28::S_297 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_28 = C2Rust_Block_28::S_299;
            }
            C2Rust_Block_28::S_299 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_28 = C2Rust_Block_28::S_301;
            }
            C2Rust_Block_28::S_301 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_319;
            }
            C2Rust_Block_28::S_319 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_321;
            }
            C2Rust_Block_28::S_321 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_323;
            }
            C2Rust_Block_28::S_323 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_325;
            }
            C2Rust_Block_28::S_325 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_327;
            }
            C2Rust_Block_28::S_327 => {
                if _fa == _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_415;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_336;
                }
            }
            C2Rust_Block_28::S_336 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_338;
            }
            C2Rust_Block_28::S_338 => {
                ebp = ebp.wrapping_add(1);
                c2rust_current_block_28 = C2Rust_Block_28::S_340;
            }
            C2Rust_Block_28::S_340 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_342;
            }
            C2Rust_Block_28::S_342 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_344;
            }
            C2Rust_Block_28::S_344 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_346;
            }
            C2Rust_Block_28::S_346 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_348;
            }
            C2Rust_Block_28::S_348 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_350;
            }
            C2Rust_Block_28::S_350 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_352;
            }
            C2Rust_Block_28::S_352 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_354;
            }
            C2Rust_Block_28::S_354 => {
                if _fa < _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_103;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_367;
                }
            }
            C2Rust_Block_28::S_367 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_369;
            }
            C2Rust_Block_28::S_369 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_379;
            }
            C2Rust_Block_28::S_379 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_381;
            }
            C2Rust_Block_28::S_381 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_387;
            }
            C2Rust_Block_28::S_387 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_389;
            }
            C2Rust_Block_28::S_389 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_391;
            }
            C2Rust_Block_28::S_391 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_393;
            }
            C2Rust_Block_28::S_393 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_399;
            }
            C2Rust_Block_28::S_399 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_401;
            }
            C2Rust_Block_28::S_401 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_407;
            }
            C2Rust_Block_28::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_409;
            }
            C2Rust_Block_28::S_409 => return,
            C2Rust_Block_28::S_415 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_417;
            }
            C2Rust_Block_28::S_417 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_419;
            }
            C2Rust_Block_28::S_419 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x148 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_421;
            }
            C2Rust_Block_28::S_421 => {
                ebp = 2 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_423;
            }
            C2Rust_Block_28::S_423 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_425;
            }
            C2Rust_Block_28::S_425 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x144 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_427;
            }
            C2Rust_Block_28::S_427 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_429;
            }
            C2Rust_Block_28::S_429 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_431;
            }
            C2Rust_Block_28::S_431 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_433;
            }
            C2Rust_Block_28::S_433 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_435;
            }
            C2Rust_Block_28::S_435 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_437;
            }
            C2Rust_Block_28::S_437 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_439;
            }
            C2Rust_Block_28::S_439 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x150 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_441;
            }
            C2Rust_Block_28::S_441 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x154 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_443;
            }
            C2Rust_Block_28::S_443 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    4 as uint32_t,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_445;
            }
            C2Rust_Block_28::S_445 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_451;
            }
            C2Rust_Block_28::S_451 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_453;
            }
            C2Rust_Block_28::S_453 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_455;
            }
            C2Rust_Block_28::S_455 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_465;
            }
            C2Rust_Block_28::S_465 => {
                _pv_6 = 0x1b3eb0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_467;
            }
            C2Rust_Block_28::S_467 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_469;
            }
            C2Rust_Block_28::S_469 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_475;
            }
            C2Rust_Block_28::S_475 => {
                sub_001D14D1();
                c2rust_current_block_28 = C2Rust_Block_28::S_481;
            }
            C2Rust_Block_28::S_481 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_483;
            }
            C2Rust_Block_28::S_483 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_485;
            }
            C2Rust_Block_28::S_485 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_28 = C2Rust_Block_28::S_491;
            }
            C2Rust_Block_28::S_491 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_493;
            }
            C2Rust_Block_28::S_493 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_503;
            }
            C2Rust_Block_28::S_503 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_505;
            }
            C2Rust_Block_28::S_505 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_515;
            }
            C2Rust_Block_28::S_515 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_517;
            }
            C2Rust_Block_28::S_517 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_523;
            }
            C2Rust_Block_28::S_523 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_525;
            }
            C2Rust_Block_28::S_525 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3EC0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
        * 0x38 as ::core::ffi::c_int as int32_t) as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_edx));
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3ED0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_165: {
        if _fa == _fb {
            break 's_165;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = 0x1b3ee1 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_116: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_116;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_165;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_124: {
            if !_fn.is_none() {
                break 's_124;
            }
            _fn = recomp_lookup(_va);
        }
        's_130: {
            if !_fn.is_none() {
                break 's_130;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_136: {
            if _fn.is_some() {
                break 's_136;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_165;
        }
        _fn.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B3EF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    enum C2Rust_Block_31 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_65,
        S_67,
        S_69,
        S_75,
        S_77,
        S_79,
        S_81,
        S_83,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_123,
        S_133,
        S_135,
        S_137,
        S_147,
        S_149,
        S_151,
        S_161,
        S_163,
        S_165,
        S_171,
        S_173,
        S_179,
        S_181,
        S_183,
        S_189,
        S_195,
        S_197,
        S_199,
        S_201,
        S_203,
        S_209,
        S_211,
        S_213,
        S_223,
        S_225,
        S_227,
        S_237,
        S_239,
        S_241,
        S_251,
        S_253,
        S_255,
        S_265,
        S_267,
        S_269,
        S_279,
        S_281,
        S_283,
        S_289,
        S_295,
        S_297,
        S_299,
        S_311,
        S_313,
        S_315,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_369,
        S_379,
        S_381,
        S_383,
        S_393,
        S_395,
        S_397,
        S_407,
        S_409,
        S_411,
        S_417,
        S_419,
        S_425,
        S_427,
        S_429,
        S_435,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_455,
        S_457,
        S_459,
        S_469,
        S_471,
        S_473,
        S_483,
        S_485,
        S_487,
        S_497,
        S_499,
        S_501,
        S_511,
        S_513,
        S_515,
        S_525,
        S_527,
        S_529,
        S_535,
        S_541,
        S_543,
        S_545,
        S_559,
        S_561,
        S_563,
        S_569,
        S_575,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_594,
        S_600,
        S_602,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_626,
        S_632,
        S_634,
        S_636,
        S_646,
        S_648,
        S_650,
        S_656,
        S_658,
        S_660,
        S_662,
        S_668,
        S_670,
        S_672,
        S_678,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_698,
        S_700,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
    }
    let mut c2rust_current_block_31: C2Rust_Block_31;
    c2rust_current_block_31 = C2Rust_Block_31::S_0;
    loop {
        match c2rust_current_block_31 {
            C2Rust_Block_31::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_2;
            }
            C2Rust_Block_31::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_4;
            }
            C2Rust_Block_31::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_18;
            }
            C2Rust_Block_31::S_18 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_20;
            }
            C2Rust_Block_31::S_20 => {
                _fb = 0x104 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_22;
            }
            C2Rust_Block_31::S_22 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_24;
            }
            C2Rust_Block_31::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x104 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_26;
            }
            C2Rust_Block_31::S_26 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_28;
            }
            C2Rust_Block_31::S_28 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_30;
            }
            C2Rust_Block_31::S_30 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_32;
            }
            C2Rust_Block_31::S_32 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_34;
            }
            C2Rust_Block_31::S_34 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_36;
            }
            C2Rust_Block_31::S_36 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_42;
            }
            C2Rust_Block_31::S_42 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_44;
            }
            C2Rust_Block_31::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_46;
            }
            C2Rust_Block_31::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_52;
            }
            C2Rust_Block_31::S_52 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_31 = C2Rust_Block_31::S_54;
            }
            C2Rust_Block_31::S_54 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x110 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_56;
            }
            C2Rust_Block_31::S_56 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_311;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_65;
                }
            }
            C2Rust_Block_31::S_65 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_67;
            }
            C2Rust_Block_31::S_67 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_69;
            }
            C2Rust_Block_31::S_69 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_75;
            }
            C2Rust_Block_31::S_75 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_ecx))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_77;
            }
            C2Rust_Block_31::S_77 => {
                _fb = 0x3a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_79;
            }
            C2Rust_Block_31::S_79 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_81;
            }
            C2Rust_Block_31::S_81 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_83;
            }
            C2Rust_Block_31::S_83 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_123;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_92;
                }
            }
            C2Rust_Block_31::S_92 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_94;
            }
            C2Rust_Block_31::S_94 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_96;
            }
            C2Rust_Block_31::S_96 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_98;
            }
            C2Rust_Block_31::S_98 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_100;
            }
            C2Rust_Block_31::S_100 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_102;
            }
            C2Rust_Block_31::S_102 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_104;
            }
            C2Rust_Block_31::S_104 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_106;
            }
            C2Rust_Block_31::S_106 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_108;
            }
            C2Rust_Block_31::S_108 => {
                if _fa < _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_75;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_133;
                }
            }
            C2Rust_Block_31::S_123 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx))
                    .wrapping_add(1 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_133;
            }
            C2Rust_Block_31::S_133 => {
                _pv_0 = 0x5c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_135;
            }
            C2Rust_Block_31::S_135 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_137;
            }
            C2Rust_Block_31::S_137 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_147;
            }
            C2Rust_Block_31::S_147 => {
                _pv_1 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_31 = C2Rust_Block_31::S_149;
            }
            C2Rust_Block_31::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_151;
            }
            C2Rust_Block_31::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_161;
            }
            C2Rust_Block_31::S_161 => {
                _pv_2 = 0x104 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_163;
            }
            C2Rust_Block_31::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_165;
            }
            C2Rust_Block_31::S_165 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_171;
            }
            C2Rust_Block_31::S_171 => {
                (*__gamepkg_tls_g_ecx) = 0x3b12ec as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_173;
            }
            C2Rust_Block_31::S_173 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_179;
            }
            C2Rust_Block_31::S_179 => {
                _pv_3 = 0x1b3f38 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_181;
            }
            C2Rust_Block_31::S_181 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_183;
            }
            C2Rust_Block_31::S_183 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_189;
            }
            C2Rust_Block_31::S_189 => {
                sub_001B32A0();
                c2rust_current_block_31 = C2Rust_Block_31::S_195;
            }
            C2Rust_Block_31::S_195 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_197;
            }
            C2Rust_Block_31::S_197 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_199;
            }
            C2Rust_Block_31::S_199 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_201;
            }
            C2Rust_Block_31::S_201 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_203;
            }
            C2Rust_Block_31::S_203 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_209;
            }
            C2Rust_Block_31::S_209 => {
                _pv_4 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_211;
            }
            C2Rust_Block_31::S_211 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_213;
            }
            C2Rust_Block_31::S_213 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_223;
            }
            C2Rust_Block_31::S_223 => {
                _pv_5 = 0x8000001 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_225;
            }
            C2Rust_Block_31::S_225 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_227;
            }
            C2Rust_Block_31::S_227 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_237;
            }
            C2Rust_Block_31::S_237 => {
                _pv_6 = 3 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_239;
            }
            C2Rust_Block_31::S_239 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_241;
            }
            C2Rust_Block_31::S_241 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_251;
            }
            C2Rust_Block_31::S_251 => {
                _pv_7 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_253;
            }
            C2Rust_Block_31::S_253 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_255;
            }
            C2Rust_Block_31::S_255 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_265;
            }
            C2Rust_Block_31::S_265 => {
                _pv_8 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_267;
            }
            C2Rust_Block_31::S_267 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_269;
            }
            C2Rust_Block_31::S_269 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_279;
            }
            C2Rust_Block_31::S_279 => {
                _pv_9 = 0x80000000 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_281;
            }
            C2Rust_Block_31::S_281 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_283;
            }
            C2Rust_Block_31::S_283 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_289;
            }
            C2Rust_Block_31::S_289 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_295;
            }
            C2Rust_Block_31::S_295 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_297;
            }
            C2Rust_Block_31::S_297 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_299;
            }
            C2Rust_Block_31::S_299 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_559;
            }
            C2Rust_Block_31::S_311 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_313;
            }
            C2Rust_Block_31::S_313 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_315;
            }
            C2Rust_Block_31::S_315 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_321;
            }
            C2Rust_Block_31::S_321 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_ecx))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_323;
            }
            C2Rust_Block_31::S_323 => {
                _fb = 0x3a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_325;
            }
            C2Rust_Block_31::S_325 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_327;
            }
            C2Rust_Block_31::S_327 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_329;
            }
            C2Rust_Block_31::S_329 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_369;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_338;
                }
            }
            C2Rust_Block_31::S_338 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_340;
            }
            C2Rust_Block_31::S_340 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_342;
            }
            C2Rust_Block_31::S_342 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_344;
            }
            C2Rust_Block_31::S_344 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_346;
            }
            C2Rust_Block_31::S_346 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_348;
            }
            C2Rust_Block_31::S_348 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_350;
            }
            C2Rust_Block_31::S_350 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_352;
            }
            C2Rust_Block_31::S_352 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_354;
            }
            C2Rust_Block_31::S_354 => {
                if _fa < _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_321;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_379;
                }
            }
            C2Rust_Block_31::S_369 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx))
                    .wrapping_add(1 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_379;
            }
            C2Rust_Block_31::S_379 => {
                _pv_11 = 0x5c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_381;
            }
            C2Rust_Block_31::S_381 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_383;
            }
            C2Rust_Block_31::S_383 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_393;
            }
            C2Rust_Block_31::S_393 => {
                _pv_12 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_31 = C2Rust_Block_31::S_395;
            }
            C2Rust_Block_31::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_397;
            }
            C2Rust_Block_31::S_397 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_407;
            }
            C2Rust_Block_31::S_407 => {
                _pv_13 = 0x104 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_409;
            }
            C2Rust_Block_31::S_409 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_411;
            }
            C2Rust_Block_31::S_411 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_417;
            }
            C2Rust_Block_31::S_417 => {
                (*__gamepkg_tls_g_ecx) = 0x3b12e8 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_419;
            }
            C2Rust_Block_31::S_419 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_425;
            }
            C2Rust_Block_31::S_425 => {
                _pv_14 = 0x1b3f7e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_427;
            }
            C2Rust_Block_31::S_427 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_429;
            }
            C2Rust_Block_31::S_429 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_435;
            }
            C2Rust_Block_31::S_435 => {
                sub_001B32A0();
                c2rust_current_block_31 = C2Rust_Block_31::S_441;
            }
            C2Rust_Block_31::S_441 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_443;
            }
            C2Rust_Block_31::S_443 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_445;
            }
            C2Rust_Block_31::S_445 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_447;
            }
            C2Rust_Block_31::S_447 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_449;
            }
            C2Rust_Block_31::S_449 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_455;
            }
            C2Rust_Block_31::S_455 => {
                _pv_15 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_457;
            }
            C2Rust_Block_31::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_459;
            }
            C2Rust_Block_31::S_459 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_469;
            }
            C2Rust_Block_31::S_469 => {
                _pv_16 = 0x8000080 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_471;
            }
            C2Rust_Block_31::S_471 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_473;
            }
            C2Rust_Block_31::S_473 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_483;
            }
            C2Rust_Block_31::S_483 => {
                _pv_17 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_485;
            }
            C2Rust_Block_31::S_485 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_487;
            }
            C2Rust_Block_31::S_487 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_497;
            }
            C2Rust_Block_31::S_497 => {
                _pv_18 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_499;
            }
            C2Rust_Block_31::S_499 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_501;
            }
            C2Rust_Block_31::S_501 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_511;
            }
            C2Rust_Block_31::S_511 => {
                _pv_19 = 3 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_513;
            }
            C2Rust_Block_31::S_513 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_515;
            }
            C2Rust_Block_31::S_515 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_525;
            }
            C2Rust_Block_31::S_525 => {
                _pv_20 = 0xc0000000 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_527;
            }
            C2Rust_Block_31::S_527 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_529;
            }
            C2Rust_Block_31::S_529 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_535;
            }
            C2Rust_Block_31::S_535 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_541;
            }
            C2Rust_Block_31::S_541 => {
                _pv_21 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_31 = C2Rust_Block_31::S_543;
            }
            C2Rust_Block_31::S_543 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_545;
            }
            C2Rust_Block_31::S_545 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_559;
            }
            C2Rust_Block_31::S_559 => {
                _pv_22 = 0x1b3f9d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_561;
            }
            C2Rust_Block_31::S_561 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_563;
            }
            C2Rust_Block_31::S_563 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_569;
            }
            C2Rust_Block_31::S_569 => {
                sub_001D0E3C();
                c2rust_current_block_31 = C2Rust_Block_31::S_575;
            }
            C2Rust_Block_31::S_575 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_577;
            }
            C2Rust_Block_31::S_577 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_579;
            }
            C2Rust_Block_31::S_579 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_581;
            }
            C2Rust_Block_31::S_581 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_583;
            }
            C2Rust_Block_31::S_583 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_585;
            }
            C2Rust_Block_31::S_585 => {
                if _fa != _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_626;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_594;
                }
            }
            C2Rust_Block_31::S_594 => {
                (*__gamepkg_tls_g_eax) = 2 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_600;
            }
            C2Rust_Block_31::S_600 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_602;
            }
            C2Rust_Block_31::S_602 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_608;
            }
            C2Rust_Block_31::S_608 => {
                _fb = 0x104 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_610;
            }
            C2Rust_Block_31::S_610 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_612;
            }
            C2Rust_Block_31::S_612 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x104 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_614;
            }
            C2Rust_Block_31::S_614 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_616;
            }
            C2Rust_Block_31::S_616 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_618;
            }
            C2Rust_Block_31::S_618 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_620;
            }
            C2Rust_Block_31::S_620 => return,
            C2Rust_Block_31::S_626 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_632;
            }
            C2Rust_Block_31::S_632 => {
                _pv_23 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_634;
            }
            C2Rust_Block_31::S_634 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_636;
            }
            C2Rust_Block_31::S_636 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_646;
            }
            C2Rust_Block_31::S_646 => {
                _pv_24 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_648;
            }
            C2Rust_Block_31::S_648 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_650;
            }
            C2Rust_Block_31::S_650 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_656;
            }
            C2Rust_Block_31::S_656 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_658;
            }
            C2Rust_Block_31::S_658 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_660;
            }
            C2Rust_Block_31::S_660 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_662;
            }
            C2Rust_Block_31::S_662 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_668;
            }
            C2Rust_Block_31::S_668 => {
                _pv_25 = 0x1b3fdb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_670;
            }
            C2Rust_Block_31::S_670 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_672;
            }
            C2Rust_Block_31::S_672 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_678;
            }
            C2Rust_Block_31::S_678 => {
                sub_001D1435();
                c2rust_current_block_31 = C2Rust_Block_31::S_684;
            }
            C2Rust_Block_31::S_684 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_686;
            }
            C2Rust_Block_31::S_686 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_688;
            }
            C2Rust_Block_31::S_688 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_690;
            }
            C2Rust_Block_31::S_690 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_692;
            }
            C2Rust_Block_31::S_692 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_698;
            }
            C2Rust_Block_31::S_698 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_700;
            }
            C2Rust_Block_31::S_700 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_706;
            }
            C2Rust_Block_31::S_706 => {
                _fb = 0x104 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_708;
            }
            C2Rust_Block_31::S_708 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_710;
            }
            C2Rust_Block_31::S_710 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x104 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_712;
            }
            C2Rust_Block_31::S_712 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_714;
            }
            C2Rust_Block_31::S_714 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_716;
            }
            C2Rust_Block_31::S_716 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_718;
            }
            C2Rust_Block_31::S_718 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4000() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1b400c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D19FD();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0xffffffff as ::core::ffi::c_uint as uint32_t,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4020() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    let mut _pv_6: uint32_t = 0x1b4046 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001D0FC7();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_205: {
        if _fa != _fb {
            break 's_205;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            3 as uint32_t,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_edx) as uint64_t)
        .wrapping_add((*__gamepkg_tls_g_eax) as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _t: uint64_t = ((*__gamepkg_tls_g_ecx) as uint64_t)
        .wrapping_add(0 as ::core::ffi::c_int as uint64_t)
        .wrapping_add(_cf as uint64_t);
    _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = _t as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4080() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1b409d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001D10B4();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_177: {
        if _fa != _fb {
            break 's_177;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            3 as uint32_t,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_edx) as uint64_t)
        .wrapping_add((*__gamepkg_tls_g_eax) as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _t: uint64_t = ((*__gamepkg_tls_g_ecx) as uint64_t)
        .wrapping_add(0 as ::core::ffi::c_int as uint64_t)
        .wrapping_add(_cf as uint64_t);
    _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = _t as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B40E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
        >> (0x1f as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(0 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    's_332: {
        's_166: {
            's_83: {
                if _fa != 0 as uint32_t {
                    break 's_83;
                }
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                break 's_166;
            }
            _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(2 as uint32_t);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            's_144: {
                if _fa == 0 as uint32_t {
                    break 's_144;
                }
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_136: {
                    if _fa != _fb {
                        break 's_136;
                    }
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    if _fa == _fb {
                        break 's_332;
                    }
                }
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                break 's_166;
            }
            (*__gamepkg_tls_g_eax) = 2 as uint32_t;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_6: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 0x1b412d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        sub_001D120E();
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = (if ((*__gamepkg_tls_g_eax) as int32_t) < 0 as int32_t {
            0xffffffff as ::core::ffi::c_uint
        } else {
            0 as ::core::ffi::c_uint
        }) as uint32_t;
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_edi) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edx) = (if ((*__gamepkg_tls_g_eax) as int32_t) < 0 as int32_t {
            0xffffffff as ::core::ffi::c_uint
        } else {
            0 as ::core::ffi::c_uint
        }) as uint32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) | (*__gamepkg_tls_g_edx);
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edi),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4160() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4170() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_edx);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_304: {
        if _fa == 0 as uint32_t {
            break 's_304;
        }
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_esi));
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_xmm0).f[0usize],
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_5: uint32_t = 0x1b41d6 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_269: {
                's_220: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_220;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_269;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_228: {
                    if !_fn.is_none() {
                        break 's_228;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_234: {
                    if !_fn.is_none() {
                        break 's_234;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_240: {
                    if _fn.is_some() {
                        break 's_240;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_269;
                }
                _fn.expect("non-null function pointer")();
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add(0x10 as uint32_t);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_edx);
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            if _fa == 0 as uint32_t {
                break 's_304;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B41F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
        | ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_274: {
        if _fa == 0 as uint32_t {
            break 's_274;
        }
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_edi))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_edi));
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_5: uint32_t = 0x1b4214 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_241: {
                's_192: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_192;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_241;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_200: {
                    if !_fn.is_none() {
                        break 's_200;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_206: {
                    if !_fn.is_none() {
                        break 's_206;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_212: {
                    if _fn.is_some() {
                        break 's_212;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_241;
                }
                _fn.expect("non-null function pointer")();
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(0x10 as uint32_t);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_eax);
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            if _fa == 0 as uint32_t {
                break 's_274;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4230() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = 0x1b424e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_217: {
            's_164: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_164;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_217;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_172: {
                if !_fn.is_none() {
                    break 's_172;
                }
                _fn = recomp_lookup(_va);
            }
            's_178: {
                if !_fn.is_none() {
                    break 's_178;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_184: {
                if _fn.is_some() {
                    break 's_184;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_217;
            }
            _fn.expect("non-null function pointer")();
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4260() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) | (*__gamepkg_tls_g_edx);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    's_166: {
        if _fa == 0 as uint32_t {
            break 's_166;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_131: {
                if _fa != _fb {
                    break 's_131;
                }
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_131;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ebx));
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add(0x10 as uint32_t);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ebp = (*__gamepkg_tls_g_ecx);
            ebp = ebp | (*__gamepkg_tls_g_edx);
            _fa = ebp & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            if _fa == 0 as uint32_t {
                break 's_166;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B42B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = 0x1b42ce as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_217: {
            's_164: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_164;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_217;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_172: {
                if !_fn.is_none() {
                    break 's_172;
                }
                _fn = recomp_lookup(_va);
            }
            's_178: {
                if !_fn.is_none() {
                    break 's_178;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_184: {
                if _fn.is_some() {
                    break 's_184;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_217;
            }
            _fn.expect("non-null function pointer")();
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B42E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa == _fb {
            break 's_229;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 3 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = 0x1b42fe as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_217: {
            's_164: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_164;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_217;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_172: {
                if !_fn.is_none() {
                    break 's_172;
                }
                _fn = recomp_lookup(_va);
            }
            's_178: {
                if !_fn.is_none() {
                    break 's_178;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_184: {
                if _fn.is_some() {
                    break 's_184;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_217;
            }
            _fn.expect("non-null function pointer")();
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4310() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t);
    loop {
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 1 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x126 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx)
                    .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x127 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x12c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0xd as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x130 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x128 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fb = 0x154 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(0x154 as uint32_t);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break;
        }
    }
    (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_edx) as int32_t
        * 0x154 as ::core::ffi::c_int as int32_t) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0xaa8 as uint32_t);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbd8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbdc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xaac as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x75 as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbd2 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbd3 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx)
                .wrapping_add((*__gamepkg_tls_g_esi))
                .wrapping_add(0x134 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc0c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc08 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B43C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0x1b43c5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001D192B();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x7b as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_229: {
        if _fa > _fb {
            break 's_229;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x1b446c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        let mut _jt: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x1b4450 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_157: {
            if _jt == 0x1b43d8 as uint32_t {
                break 's_157;
            }
            's_169: {
                if _jt == 0x1b43e9 as uint32_t {
                    break 's_169;
                }
                's_181: {
                    if _jt == 0x1b43fa as uint32_t {
                        break 's_181;
                    }
                    's_193: {
                        if _jt == 0x1b440b as uint32_t {
                            break 's_193;
                        }
                        's_205: {
                            if _jt == 0x1b441c as uint32_t {
                                break 's_205;
                            }
                            's_217: {
                                if _jt == 0x1b442d as uint32_t {
                                    break 's_217;
                                }
                                if _jt == 0x1b443e as uint32_t {
                                    break 's_229;
                                }
                                (*__gamepkg_tls_g_seh_ebp) = ebp;
                                let mut _va: uint32_t = _jt;
                                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                                's_117: {
                                    if !_fn.is_none() {
                                        break 's_117;
                                    }
                                    _fn = recomp_lookup(_va);
                                }
                                's_123: {
                                    if !_fn.is_none() {
                                        break 's_123;
                                    }
                                    _fn = recomp_lookup_kernel(_va);
                                }
                                's_150: {
                                    's_129: {
                                        if _fn.is_some() {
                                            break 's_129;
                                        }
                                        recomp_icall_fail_log(_va);
                                        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                            .wrapping_add(4 as uint32_t);
                                        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                                        break 's_150;
                                    }
                                    _fn.expect("non-null function pointer")();
                                }
                                return;
                            }
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                0 as uint32_t,
                            );
                            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            );
                            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                                .wrapping_add(4 as uint32_t);
                            return;
                        }
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            0xb as uint32_t,
                        );
                        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                            .wrapping_add(4 as uint32_t);
                        return;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa as uint32_t,
                    );
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    return;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    9 as uint32_t,
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                5 as uint32_t,
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint32_t,
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0xd as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc00 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B44F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc04 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
        * 0x154 as ::core::ffi::c_int as int32_t) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
        .wrapping_add((*__gamepkg_tls_g_ecx))
        .wrapping_add(8 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x130 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4520() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    enum C2Rust_Block_46 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_60,
        S_62,
        S_64,
        S_70,
        S_72,
        S_81,
        S_83,
        S_85,
        S_87,
        S_89,
        S_91,
        S_97,
        S_99,
        S_101,
        S_103,
        S_105,
        S_107,
        S_109,
        S_111,
        S_113,
        S_115,
        S_117,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_148,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_173,
        S_179,
        S_181,
        S_183,
        S_189,
        S_195,
        S_197,
        S_199,
        S_209,
        S_211,
        S_213,
        S_219,
        S_225,
        S_233,
        S_239,
        S_241,
        S_243,
        S_253,
        S_255,
        S_257,
        S_267,
        S_269,
        S_271,
        S_277,
        S_287,
        S_289,
        S_291,
        S_297,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_337,
        S_339,
        S_341,
        S_343,
        S_345,
        S_354,
        S_356,
        S_358,
        S_360,
        S_370,
        S_372,
        S_374,
        S_380,
        S_386,
        S_388,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_419,
        S_421,
        S_423,
        S_433,
        S_435,
        S_437,
        S_443,
        S_449,
        S_451,
        S_453,
        S_455,
        S_457,
        S_470,
        S_472,
        S_474,
        S_480,
        S_490,
        S_492,
        S_498,
        S_504,
        S_506,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
    }
    let mut c2rust_current_block_46: C2Rust_Block_46;
    c2rust_current_block_46 = C2Rust_Block_46::S_0;
    loop {
        match c2rust_current_block_46 {
            C2Rust_Block_46::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_46 = C2Rust_Block_46::S_2;
            }
            C2Rust_Block_46::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_4;
            }
            C2Rust_Block_46::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_18;
            }
            C2Rust_Block_46::S_18 => {
                _fb = 0x448 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_20;
            }
            C2Rust_Block_46::S_20 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_22;
            }
            C2Rust_Block_46::S_22 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x448 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_24;
            }
            C2Rust_Block_46::S_24 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_26;
            }
            C2Rust_Block_46::S_26 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_32;
            }
            C2Rust_Block_46::S_32 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_46 = C2Rust_Block_46::S_34;
            }
            C2Rust_Block_46::S_34 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_36;
            }
            C2Rust_Block_46::S_36 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_42;
            }
            C2Rust_Block_46::S_42 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_44;
            }
            C2Rust_Block_46::S_44 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_46;
            }
            C2Rust_Block_46::S_46 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_48;
            }
            C2Rust_Block_46::S_48 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_50;
            }
            C2Rust_Block_46::S_50 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_52;
            }
            C2Rust_Block_46::S_52 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_54;
            }
            C2Rust_Block_46::S_54 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_60;
            }
            C2Rust_Block_46::S_60 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_46 = C2Rust_Block_46::S_62;
            }
            C2Rust_Block_46::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_64;
            }
            C2Rust_Block_46::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_70;
            }
            C2Rust_Block_46::S_70 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_46 = C2Rust_Block_46::S_72;
            }
            C2Rust_Block_46::S_72 => {
                if _fa == _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_132;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_81;
                }
            }
            C2Rust_Block_46::S_81 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_83;
            }
            C2Rust_Block_46::S_83 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_85;
            }
            C2Rust_Block_46::S_85 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_87;
            }
            C2Rust_Block_46::S_87 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_46 = C2Rust_Block_46::S_89;
            }
            C2Rust_Block_46::S_89 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_91;
            }
            C2Rust_Block_46::S_91 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_97;
            }
            C2Rust_Block_46::S_97 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_99;
            }
            C2Rust_Block_46::S_99 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_eax))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_101;
            }
            C2Rust_Block_46::S_101 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_46 = C2Rust_Block_46::S_103;
            }
            C2Rust_Block_46::S_103 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_105;
            }
            C2Rust_Block_46::S_105 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_107;
            }
            C2Rust_Block_46::S_107 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_109;
            }
            C2Rust_Block_46::S_109 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_111;
            }
            C2Rust_Block_46::S_111 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_113;
            }
            C2Rust_Block_46::S_113 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_115;
            }
            C2Rust_Block_46::S_115 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_117;
            }
            C2Rust_Block_46::S_117 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_97;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_148;
                }
            }
            C2Rust_Block_46::S_132 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_134;
            }
            C2Rust_Block_46::S_134 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_136;
            }
            C2Rust_Block_46::S_136 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_138;
            }
            C2Rust_Block_46::S_138 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(9 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x3a as uint8_t,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_140;
            }
            C2Rust_Block_46::S_140 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xa as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x5c as uint8_t,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_142;
            }
            C2Rust_Block_46::S_142 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xb as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_148;
            }
            C2Rust_Block_46::S_148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffffff as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_154;
            }
            C2Rust_Block_46::S_154 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_156;
            }
            C2Rust_Block_46::S_156 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_158;
            }
            C2Rust_Block_46::S_158 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_160;
            }
            C2Rust_Block_46::S_160 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_162;
            }
            C2Rust_Block_46::S_162 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_164;
            }
            C2Rust_Block_46::S_164 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_233;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_173;
                }
            }
            C2Rust_Block_46::S_173 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10c as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_179;
            }
            C2Rust_Block_46::S_179 => {
                _pv_1 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_46 = C2Rust_Block_46::S_181;
            }
            C2Rust_Block_46::S_181 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_183;
            }
            C2Rust_Block_46::S_183 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_189;
            }
            C2Rust_Block_46::S_189 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_195;
            }
            C2Rust_Block_46::S_195 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_46 = C2Rust_Block_46::S_197;
            }
            C2Rust_Block_46::S_197 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_199;
            }
            C2Rust_Block_46::S_199 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_209;
            }
            C2Rust_Block_46::S_209 => {
                _pv_3 = 0x1b457f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_211;
            }
            C2Rust_Block_46::S_211 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_213;
            }
            C2Rust_Block_46::S_213 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_219;
            }
            C2Rust_Block_46::S_219 => {
                sub_001D0C95();
                c2rust_current_block_46 = C2Rust_Block_46::S_225;
            }
            C2Rust_Block_46::S_225 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_287;
            }
            C2Rust_Block_46::S_233 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10c as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_239;
            }
            C2Rust_Block_46::S_239 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_46 = C2Rust_Block_46::S_241;
            }
            C2Rust_Block_46::S_241 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_243;
            }
            C2Rust_Block_46::S_243 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_253;
            }
            C2Rust_Block_46::S_253 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_46 = C2Rust_Block_46::S_255;
            }
            C2Rust_Block_46::S_255 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_257;
            }
            C2Rust_Block_46::S_257 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_267;
            }
            C2Rust_Block_46::S_267 => {
                _pv_6 = 0x1b4592 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_269;
            }
            C2Rust_Block_46::S_269 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_271;
            }
            C2Rust_Block_46::S_271 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_277;
            }
            C2Rust_Block_46::S_277 => {
                sub_001D0D9F();
                c2rust_current_block_46 = C2Rust_Block_46::S_287;
            }
            C2Rust_Block_46::S_287 => {
                _pv_7 = 0x1b4597 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_289;
            }
            C2Rust_Block_46::S_289 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_291;
            }
            C2Rust_Block_46::S_291 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_297;
            }
            C2Rust_Block_46::S_297 => {
                sub_001D192B();
                c2rust_current_block_46 = C2Rust_Block_46::S_303;
            }
            C2Rust_Block_46::S_303 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_305;
            }
            C2Rust_Block_46::S_305 => {
                _fb = 0x12 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_307;
            }
            C2Rust_Block_46::S_307 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_309;
            }
            C2Rust_Block_46::S_309 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_311;
            }
            C2Rust_Block_46::S_311 => {
                if _fa == _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_396;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_320;
                }
            }
            C2Rust_Block_46::S_320 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_322;
            }
            C2Rust_Block_46::S_322 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_324;
            }
            C2Rust_Block_46::S_324 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_326;
            }
            C2Rust_Block_46::S_326 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_328;
            }
            C2Rust_Block_46::S_328 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_396;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_337;
                }
            }
            C2Rust_Block_46::S_337 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_339;
            }
            C2Rust_Block_46::S_339 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_341;
            }
            C2Rust_Block_46::S_341 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_343;
            }
            C2Rust_Block_46::S_343 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_345;
            }
            C2Rust_Block_46::S_345 => {
                if _fa == _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_370;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_354;
                }
            }
            C2Rust_Block_46::S_354 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                c2rust_current_block_46 = C2Rust_Block_46::S_356;
            }
            C2Rust_Block_46::S_356 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_358;
            }
            C2Rust_Block_46::S_358 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_360;
            }
            C2Rust_Block_46::S_360 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_370;
            }
            C2Rust_Block_46::S_370 => {
                _pv_8 = 0x1b45ac as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_372;
            }
            C2Rust_Block_46::S_372 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_374;
            }
            C2Rust_Block_46::S_374 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_380;
            }
            C2Rust_Block_46::S_380 => {
                sub_001B43C0();
                c2rust_current_block_46 = C2Rust_Block_46::S_386;
            }
            C2Rust_Block_46::S_386 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_388;
            }
            C2Rust_Block_46::S_388 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_154;
            }
            C2Rust_Block_46::S_396 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_398;
            }
            C2Rust_Block_46::S_398 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_400;
            }
            C2Rust_Block_46::S_400 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_402;
            }
            C2Rust_Block_46::S_402 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_404;
            }
            C2Rust_Block_46::S_404 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_406;
            }
            C2Rust_Block_46::S_406 => {
                if _fa == _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_490;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_419;
                }
            }
            C2Rust_Block_46::S_419 => {
                _pv_9 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_46 = C2Rust_Block_46::S_421;
            }
            C2Rust_Block_46::S_421 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_423;
            }
            C2Rust_Block_46::S_423 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_433;
            }
            C2Rust_Block_46::S_433 => {
                _pv_10 = 0x1b45c8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_435;
            }
            C2Rust_Block_46::S_435 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_437;
            }
            C2Rust_Block_46::S_437 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_443;
            }
            C2Rust_Block_46::S_443 => {
                sub_001D0DE6();
                c2rust_current_block_46 = C2Rust_Block_46::S_449;
            }
            C2Rust_Block_46::S_449 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_451;
            }
            C2Rust_Block_46::S_451 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_453;
            }
            C2Rust_Block_46::S_453 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_455;
            }
            C2Rust_Block_46::S_455 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_457;
            }
            C2Rust_Block_46::S_457 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_490;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_470;
                }
            }
            C2Rust_Block_46::S_470 => {
                _pv_11 = 0x1b45d1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_472;
            }
            C2Rust_Block_46::S_472 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_474;
            }
            C2Rust_Block_46::S_474 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_480;
            }
            C2Rust_Block_46::S_480 => {
                sub_001D192B();
                c2rust_current_block_46 = C2Rust_Block_46::S_490;
            }
            C2Rust_Block_46::S_490 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_492;
            }
            C2Rust_Block_46::S_492 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_498;
            }
            C2Rust_Block_46::S_498 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_46 = C2Rust_Block_46::S_504;
            }
            C2Rust_Block_46::S_504 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_506;
            }
            C2Rust_Block_46::S_506 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_512;
            }
            C2Rust_Block_46::S_512 => {
                _fb = 0x448 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_514;
            }
            C2Rust_Block_46::S_514 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_516;
            }
            C2Rust_Block_46::S_516 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x448 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_518;
            }
            C2Rust_Block_46::S_518 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_520;
            }
            C2Rust_Block_46::S_520 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_522;
            }
            C2Rust_Block_46::S_522 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_524;
            }
            C2Rust_Block_46::S_524 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B45E0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _t: uint64_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _d_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_0: uint32_t = 0;
    let mut _i_1: uint32_t = 0;
    let mut _i_2: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    enum C2Rust_Block_47 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_20,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_125,
        S_131,
        S_133,
        S_135,
        S_141,
        S_147,
        S_149,
        S_151,
        S_161,
        S_163,
        S_165,
        S_171,
        S_177,
        S_185,
        S_191,
        S_193,
        S_195,
        S_205,
        S_207,
        S_209,
        S_219,
        S_221,
        S_223,
        S_229,
        S_239,
        S_241,
        S_243,
        S_249,
        S_255,
        S_257,
        S_259,
        S_261,
        S_263,
        S_265,
        S_267,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_314,
        S_320,
        S_322,
        S_324,
        S_334,
        S_336,
        S_338,
        S_344,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_366,
        S_368,
        S_370,
        S_380,
        S_382,
        S_384,
        S_394,
        S_396,
        S_398,
        S_404,
        S_410,
        S_412,
        S_414,
        S_424,
        S_426,
        S_428,
        S_434,
        S_440,
        S_442,
        S_444,
        S_454,
        S_456,
        S_458,
        S_468,
        S_470,
        S_472,
        S_482,
        S_484,
        S_486,
        S_492,
        S_498,
        S_500,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_529,
        S_531,
        S_533,
        S_535,
        S_537,
        S_539,
        S_548,
        S_550,
        S_552,
        S_554,
        S_556,
        S_558,
        S_560,
        S_562,
        S_571,
        S_573,
        S_575,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_605,
        S_614,
        S_616,
        S_618,
        S_620,
        S_628,
        S_630,
        S_632,
        S_635,
        S_637,
        S_639,
        S_643,
        S_645,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_670,
        S_676,
        S_678,
        S_680,
        S_686,
        S_692,
        S_694,
        S_696,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_721,
        S_723,
        S_725,
        S_727,
        S_729,
        S_735,
        S_737,
        S_739,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_753,
        S_755,
        S_757,
        S_766,
        S_768,
        S_774,
        S_776,
        S_778,
        S_780,
        S_782,
        S_784,
        S_786,
        S_788,
        S_790,
        S_792,
        S_794,
        S_803,
        S_805,
        S_807,
        S_809,
        S_811,
        S_813,
        S_815,
        S_817,
        S_819,
        S_821,
        S_823,
        S_825,
        S_831,
        S_833,
        S_835,
        S_837,
        S_839,
        S_841,
        S_843,
        S_845,
        S_847,
        S_849,
        S_851,
        S_860,
        S_864,
        S_868,
        S_870,
        S_872,
        S_874,
        S_876,
        S_880,
        S_882,
        S_884,
        S_886,
        S_890,
        S_893,
        S_894,
        S_895,
        S_896,
        S_907,
        S_909,
        S_914,
        S_917,
        S_918,
        S_919,
        S_920,
        S_927,
        S_929,
        S_935,
        S_937,
        S_939,
        S_945,
        S_947,
        S_949,
        S_955,
        S_957,
        S_959,
        S_961,
        S_963,
        S_969,
        S_971,
        S_973,
        S_979,
        S_983,
        S_985,
        S_987,
        S_989,
        S_993,
        S_996,
        S_997,
        S_998,
        S_999,
        S_1010,
        S_1012,
        S_1017,
        S_1020,
        S_1021,
        S_1022,
        S_1023,
        S_1030,
        S_1032,
        S_1038,
        S_1044,
        S_1046,
        S_1048,
        S_1054,
        S_1060,
        S_1062,
        S_1068,
        S_1070,
        S_1072,
        S_1078,
        S_1084,
        S_1086,
        S_1088,
        S_1090,
        S_1092,
        S_1094,
        S_1096,
        S_1098,
        S_1107,
        S_1109,
        S_1111,
        S_1113,
        S_1121,
        S_1123,
        S_1125,
        S_1127,
        S_1133,
        S_1135,
        S_1137,
        S_1143,
        S_1149,
        S_1155,
        S_1157,
        S_1159,
        S_1165,
        S_1171,
        S_1173,
        S_1175,
        S_1181,
        S_1187,
        S_1189,
        S_1191,
        S_1193,
        S_1195,
        S_1197,
        S_1203,
        S_1205,
        S_1215,
        S_1217,
        S_1223,
        S_1236,
        S_1238,
        S_1240,
        S_1250,
        S_1252,
        S_1254,
        S_1260,
        S_1266,
        S_1268,
        S_1270,
        S_1276,
        S_1278,
        S_1284,
        S_1286,
        S_1288,
        S_1290,
        S_1292,
        S_1294,
        S_1296,
        S_1298,
    }
    let mut c2rust_current_block_47: C2Rust_Block_47;
    c2rust_current_block_47 = C2Rust_Block_47::S_0;
    loop {
        match c2rust_current_block_47 {
            C2Rust_Block_47::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_2;
            }
            C2Rust_Block_47::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_47 = C2Rust_Block_47::S_4;
            }
            C2Rust_Block_47::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_6;
            }
            C2Rust_Block_47::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_8;
            }
            C2Rust_Block_47::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_18;
            }
            C2Rust_Block_47::S_18 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_20;
            }
            C2Rust_Block_47::S_20 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_47 = C2Rust_Block_47::S_26;
            }
            C2Rust_Block_47::S_26 => {
                _fb = 0x690 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_28;
            }
            C2Rust_Block_47::S_28 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_30;
            }
            C2Rust_Block_47::S_30 => {
                _cf = ((*__gamepkg_tls_g_esp) < 0x690 as ::core::ffi::c_int as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_32;
            }
            C2Rust_Block_47::S_32 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x690 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_34;
            }
            C2Rust_Block_47::S_34 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_36;
            }
            C2Rust_Block_47::S_36 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_42;
            }
            C2Rust_Block_47::S_42 => {
                _pv = ebp;
                c2rust_current_block_47 = C2Rust_Block_47::S_44;
            }
            C2Rust_Block_47::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_46;
            }
            C2Rust_Block_47::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_52;
            }
            C2Rust_Block_47::S_52 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x698 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_54;
            }
            C2Rust_Block_47::S_54 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_56;
            }
            C2Rust_Block_47::S_56 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_62;
            }
            C2Rust_Block_47::S_62 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_47 = C2Rust_Block_47::S_64;
            }
            C2Rust_Block_47::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_66;
            }
            C2Rust_Block_47::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_72;
            }
            C2Rust_Block_47::S_72 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_74;
            }
            C2Rust_Block_47::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_76;
            }
            C2Rust_Block_47::S_76 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xd as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x3a as uint8_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_78;
            }
            C2Rust_Block_47::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xe as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x5c as uint8_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_80;
            }
            C2Rust_Block_47::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xf as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_82;
            }
            C2Rust_Block_47::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffffff as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_88;
            }
            C2Rust_Block_47::S_88 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_47 = C2Rust_Block_47::S_90;
            }
            C2Rust_Block_47::S_90 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_92;
            }
            C2Rust_Block_47::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_104;
            }
            C2Rust_Block_47::S_104 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_106;
            }
            C2Rust_Block_47::S_106 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_108;
            }
            C2Rust_Block_47::S_108 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_110;
            }
            C2Rust_Block_47::S_110 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_112;
            }
            C2Rust_Block_47::S_112 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_114;
            }
            C2Rust_Block_47::S_114 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_116;
            }
            C2Rust_Block_47::S_116 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_185;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_125;
                }
            }
            C2Rust_Block_47::S_125 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x358 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_131;
            }
            C2Rust_Block_47::S_131 => {
                _pv_2 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_133;
            }
            C2Rust_Block_47::S_133 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_135;
            }
            C2Rust_Block_47::S_135 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_141;
            }
            C2Rust_Block_47::S_141 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_147;
            }
            C2Rust_Block_47::S_147 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_149;
            }
            C2Rust_Block_47::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_151;
            }
            C2Rust_Block_47::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_161;
            }
            C2Rust_Block_47::S_161 => {
                _pv_4 = 0x1b463a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_163;
            }
            C2Rust_Block_47::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_165;
            }
            C2Rust_Block_47::S_165 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_171;
            }
            C2Rust_Block_47::S_171 => {
                sub_001D0C95();
                c2rust_current_block_47 = C2Rust_Block_47::S_177;
            }
            C2Rust_Block_47::S_177 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_239;
            }
            C2Rust_Block_47::S_185 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x358 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_191;
            }
            C2Rust_Block_47::S_191 => {
                _pv_5 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_193;
            }
            C2Rust_Block_47::S_193 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_195;
            }
            C2Rust_Block_47::S_195 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_205;
            }
            C2Rust_Block_47::S_205 => {
                _pv_6 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_207;
            }
            C2Rust_Block_47::S_207 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_209;
            }
            C2Rust_Block_47::S_209 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_219;
            }
            C2Rust_Block_47::S_219 => {
                _pv_7 = 0x1b464d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_221;
            }
            C2Rust_Block_47::S_221 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_223;
            }
            C2Rust_Block_47::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_229;
            }
            C2Rust_Block_47::S_229 => {
                sub_001D0D9F();
                c2rust_current_block_47 = C2Rust_Block_47::S_239;
            }
            C2Rust_Block_47::S_239 => {
                _pv_8 = 0x1b4652 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_241;
            }
            C2Rust_Block_47::S_241 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_243;
            }
            C2Rust_Block_47::S_243 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_249;
            }
            C2Rust_Block_47::S_249 => {
                sub_001D192B();
                c2rust_current_block_47 = C2Rust_Block_47::S_255;
            }
            C2Rust_Block_47::S_255 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_257;
            }
            C2Rust_Block_47::S_257 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_259;
            }
            C2Rust_Block_47::S_259 => {
                _fb = 0x12 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_261;
            }
            C2Rust_Block_47::S_261 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_263;
            }
            C2Rust_Block_47::S_263 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_265;
            }
            C2Rust_Block_47::S_265 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_267;
            }
            C2Rust_Block_47::S_267 => {
                if _fa == _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_295;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_276;
                }
            }
            C2Rust_Block_47::S_276 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_278;
            }
            C2Rust_Block_47::S_278 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_280;
            }
            C2Rust_Block_47::S_280 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_282;
            }
            C2Rust_Block_47::S_282 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_284;
            }
            C2Rust_Block_47::S_284 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_286;
            }
            C2Rust_Block_47::S_286 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1187;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_295;
                }
            }
            C2Rust_Block_47::S_295 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_297;
            }
            C2Rust_Block_47::S_297 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_299;
            }
            C2Rust_Block_47::S_299 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_301;
            }
            C2Rust_Block_47::S_301 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_303;
            }
            C2Rust_Block_47::S_303 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_305;
            }
            C2Rust_Block_47::S_305 => {
                if _fa == _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_670;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_314;
                }
            }
            C2Rust_Block_47::S_314 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x59c as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_320;
            }
            C2Rust_Block_47::S_320 => {
                _pv_9 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_322;
            }
            C2Rust_Block_47::S_322 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_324;
            }
            C2Rust_Block_47::S_324 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_334;
            }
            C2Rust_Block_47::S_334 => {
                _pv_10 = 0x1b4674 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_336;
            }
            C2Rust_Block_47::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_338;
            }
            C2Rust_Block_47::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_344;
            }
            C2Rust_Block_47::S_344 => {
                sub_00243F9E();
                c2rust_current_block_47 = C2Rust_Block_47::S_350;
            }
            C2Rust_Block_47::S_350 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_352;
            }
            C2Rust_Block_47::S_352 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_354;
            }
            C2Rust_Block_47::S_354 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(4 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_356;
            }
            C2Rust_Block_47::S_356 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_358;
            }
            C2Rust_Block_47::S_358 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_360;
            }
            C2Rust_Block_47::S_360 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_366;
            }
            C2Rust_Block_47::S_366 => {
                _pv_11 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_368;
            }
            C2Rust_Block_47::S_368 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_370;
            }
            C2Rust_Block_47::S_370 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_380;
            }
            C2Rust_Block_47::S_380 => {
                _pv_12 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_382;
            }
            C2Rust_Block_47::S_382 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_384;
            }
            C2Rust_Block_47::S_384 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_394;
            }
            C2Rust_Block_47::S_394 => {
                _pv_13 = 0x104 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_396;
            }
            C2Rust_Block_47::S_396 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_398;
            }
            C2Rust_Block_47::S_398 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_404;
            }
            C2Rust_Block_47::S_404 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x120 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_410;
            }
            C2Rust_Block_47::S_410 => {
                _pv_14 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_412;
            }
            C2Rust_Block_47::S_412 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_414;
            }
            C2Rust_Block_47::S_414 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_424;
            }
            C2Rust_Block_47::S_424 => {
                _pv_15 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_426;
            }
            C2Rust_Block_47::S_426 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_428;
            }
            C2Rust_Block_47::S_428 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_434;
            }
            C2Rust_Block_47::S_434 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x5b0 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_440;
            }
            C2Rust_Block_47::S_440 => {
                _pv_16 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_442;
            }
            C2Rust_Block_47::S_442 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_444;
            }
            C2Rust_Block_47::S_444 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_454;
            }
            C2Rust_Block_47::S_454 => {
                _pv_17 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_456;
            }
            C2Rust_Block_47::S_456 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_458;
            }
            C2Rust_Block_47::S_458 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_468;
            }
            C2Rust_Block_47::S_468 => {
                _pv_18 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_470;
            }
            C2Rust_Block_47::S_470 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_472;
            }
            C2Rust_Block_47::S_472 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_482;
            }
            C2Rust_Block_47::S_482 => {
                _pv_19 = 0x1b469a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_484;
            }
            C2Rust_Block_47::S_484 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_486;
            }
            C2Rust_Block_47::S_486 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_492;
            }
            C2Rust_Block_47::S_492 => {
                sub_001D1E1A();
                c2rust_current_block_47 = C2Rust_Block_47::S_498;
            }
            C2Rust_Block_47::S_498 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x6a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_500;
            }
            C2Rust_Block_47::S_500 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x114 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_506;
            }
            C2Rust_Block_47::S_506 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_508;
            }
            C2Rust_Block_47::S_508 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_510;
            }
            C2Rust_Block_47::S_510 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_512;
            }
            C2Rust_Block_47::S_512 => {
                _fb = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_514;
            }
            C2Rust_Block_47::S_514 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_516;
            }
            C2Rust_Block_47::S_516 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_518;
            }
            C2Rust_Block_47::S_518 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_520;
            }
            C2Rust_Block_47::S_520 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_628;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_529;
                }
            }
            C2Rust_Block_47::S_529 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_531;
            }
            C2Rust_Block_47::S_531 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_533;
            }
            C2Rust_Block_47::S_533 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_535;
            }
            C2Rust_Block_47::S_535 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_537;
            }
            C2Rust_Block_47::S_537 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_539;
            }
            C2Rust_Block_47::S_539 => {
                if _fa == _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_614;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_548;
                }
            }
            C2Rust_Block_47::S_548 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(1 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_550;
            }
            C2Rust_Block_47::S_550 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_552;
            }
            C2Rust_Block_47::S_552 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_554;
            }
            C2Rust_Block_47::S_554 => {
                _fb = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(1 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_556;
            }
            C2Rust_Block_47::S_556 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_558;
            }
            C2Rust_Block_47::S_558 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_560;
            }
            C2Rust_Block_47::S_560 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_562;
            }
            C2Rust_Block_47::S_562 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_628;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_571;
                }
            }
            C2Rust_Block_47::S_571 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_573;
            }
            C2Rust_Block_47::S_573 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_575;
            }
            C2Rust_Block_47::S_575 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(2 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_577;
            }
            C2Rust_Block_47::S_577 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(2 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_579;
            }
            C2Rust_Block_47::S_579 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_581;
            }
            C2Rust_Block_47::S_581 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_583;
            }
            C2Rust_Block_47::S_583 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_585;
            }
            C2Rust_Block_47::S_585 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_587;
            }
            C2Rust_Block_47::S_587 => {
                _cf = (((*__gamepkg_tls_g_esi) as uint64_t)
                    .wrapping_add(2 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_589;
            }
            C2Rust_Block_47::S_589 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(2 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_591;
            }
            C2Rust_Block_47::S_591 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_593;
            }
            C2Rust_Block_47::S_593 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_595;
            }
            C2Rust_Block_47::S_595 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_597;
            }
            C2Rust_Block_47::S_597 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_599;
            }
            C2Rust_Block_47::S_599 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_601;
            }
            C2Rust_Block_47::S_601 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_603;
            }
            C2Rust_Block_47::S_603 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_605;
            }
            C2Rust_Block_47::S_605 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_506;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_614;
                }
            }
            C2Rust_Block_47::S_614 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_616;
            }
            C2Rust_Block_47::S_616 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_618;
            }
            C2Rust_Block_47::S_618 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_620;
            }
            C2Rust_Block_47::S_620 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_651;
            }
            C2Rust_Block_47::S_628 => {
                (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                    0xffffffff as ::core::ffi::c_uint
                } else {
                    0 as ::core::ffi::c_uint
                }) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_630;
            }
            C2Rust_Block_47::S_630 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_632;
            }
            C2Rust_Block_47::S_632 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_635;
            }
            C2Rust_Block_47::S_635 => {
                _t = ((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_sub(0xffffffff as ::core::ffi::c_uint as uint64_t)
                    .wrapping_sub(_cf as uint64_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_637;
            }
            C2Rust_Block_47::S_637 => {
                _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_639;
            }
            C2Rust_Block_47::S_639 => {
                (*__gamepkg_tls_g_eax) = _t as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_643;
            }
            C2Rust_Block_47::S_643 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_645;
            }
            C2Rust_Block_47::S_645 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_651;
            }
            C2Rust_Block_47::S_651 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_653;
            }
            C2Rust_Block_47::S_653 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_655;
            }
            C2Rust_Block_47::S_655 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_657;
            }
            C2Rust_Block_47::S_657 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_659;
            }
            C2Rust_Block_47::S_659 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_661;
            }
            C2Rust_Block_47::S_661 => {
                if _fa == _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_721;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_670;
                }
            }
            C2Rust_Block_47::S_670 => {
                (*__gamepkg_tls_g_esi) = ebp;
                c2rust_current_block_47 = C2Rust_Block_47::S_676;
            }
            C2Rust_Block_47::S_676 => {
                _pv_20 = 0x1b46dc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_678;
            }
            C2Rust_Block_47::S_678 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_680;
            }
            C2Rust_Block_47::S_680 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_686;
            }
            C2Rust_Block_47::S_686 => {
                sub_001B43C0();
                c2rust_current_block_47 = C2Rust_Block_47::S_692;
            }
            C2Rust_Block_47::S_692 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_694;
            }
            C2Rust_Block_47::S_694 => {
                _fb = 0x12 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_696;
            }
            C2Rust_Block_47::S_696 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_698;
            }
            C2Rust_Block_47::S_698 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_700;
            }
            C2Rust_Block_47::S_700 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_702;
            }
            C2Rust_Block_47::S_702 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_704;
            }
            C2Rust_Block_47::S_704 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_706;
            }
            C2Rust_Block_47::S_706 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_104;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1187;
                }
            }
            C2Rust_Block_47::S_721 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_723;
            }
            C2Rust_Block_47::S_723 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_725;
            }
            C2Rust_Block_47::S_725 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_727;
            }
            C2Rust_Block_47::S_727 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_729;
            }
            C2Rust_Block_47::S_729 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_735;
            }
            C2Rust_Block_47::S_735 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp)
                                .wrapping_add((*__gamepkg_tls_g_eax))
                                .wrapping_add(0x498 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_737;
            }
            C2Rust_Block_47::S_737 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp)
                            .wrapping_add((*__gamepkg_tls_g_eax))
                            .wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_739;
            }
            C2Rust_Block_47::S_739 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_741;
            }
            C2Rust_Block_47::S_741 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_743;
            }
            C2Rust_Block_47::S_743 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_745;
            }
            C2Rust_Block_47::S_745 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_747;
            }
            C2Rust_Block_47::S_747 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_749;
            }
            C2Rust_Block_47::S_749 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_751;
            }
            C2Rust_Block_47::S_751 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_753;
            }
            C2Rust_Block_47::S_753 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_755;
            }
            C2Rust_Block_47::S_755 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_757;
            }
            C2Rust_Block_47::S_757 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_735;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_766;
                }
            }
            C2Rust_Block_47::S_766 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x114 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_768;
            }
            C2Rust_Block_47::S_768 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_774;
            }
            C2Rust_Block_47::S_774 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_776;
            }
            C2Rust_Block_47::S_776 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_778;
            }
            C2Rust_Block_47::S_778 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_780;
            }
            C2Rust_Block_47::S_780 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_782;
            }
            C2Rust_Block_47::S_782 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_784;
            }
            C2Rust_Block_47::S_784 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_786;
            }
            C2Rust_Block_47::S_786 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_788;
            }
            C2Rust_Block_47::S_788 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_790;
            }
            C2Rust_Block_47::S_790 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_792;
            }
            C2Rust_Block_47::S_792 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_794;
            }
            C2Rust_Block_47::S_794 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_774;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_803;
                }
            }
            C2Rust_Block_47::S_803 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_805;
            }
            C2Rust_Block_47::S_805 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_807;
            }
            C2Rust_Block_47::S_807 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_809;
            }
            C2Rust_Block_47::S_809 => {
                _cf = ((*__gamepkg_tls_g_eax) < (*__gamepkg_tls_g_edx))
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_811;
            }
            C2Rust_Block_47::S_811 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_47 = C2Rust_Block_47::S_813;
            }
            C2Rust_Block_47::S_813 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_815;
            }
            C2Rust_Block_47::S_815 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_817;
            }
            C2Rust_Block_47::S_817 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_819;
            }
            C2Rust_Block_47::S_819 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_821;
            }
            C2Rust_Block_47::S_821 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_823;
            }
            C2Rust_Block_47::S_823 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_825;
            }
            C2Rust_Block_47::S_825 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_47 = C2Rust_Block_47::S_831;
            }
            C2Rust_Block_47::S_831 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(1 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_833;
            }
            C2Rust_Block_47::S_833 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_835;
            }
            C2Rust_Block_47::S_835 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_837;
            }
            C2Rust_Block_47::S_837 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_839;
            }
            C2Rust_Block_47::S_839 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_841;
            }
            C2Rust_Block_47::S_841 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_843;
            }
            C2Rust_Block_47::S_843 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_845;
            }
            C2Rust_Block_47::S_845 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_847;
            }
            C2Rust_Block_47::S_847 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_849;
            }
            C2Rust_Block_47::S_849 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_851;
            }
            C2Rust_Block_47::S_851 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_831;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_860;
                }
            }
            C2Rust_Block_47::S_860 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_864;
            }
            C2Rust_Block_47::S_864 => {
                _cf = ((*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_868;
            }
            C2Rust_Block_47::S_868 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_870;
            }
            C2Rust_Block_47::S_870 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_872;
            }
            C2Rust_Block_47::S_872 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_874;
            }
            C2Rust_Block_47::S_874 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_876;
            }
            C2Rust_Block_47::S_876 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_47 = C2Rust_Block_47::S_880;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_914;
                }
            }
            C2Rust_Block_47::S_880 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_882;
            }
            C2Rust_Block_47::S_882 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_884;
            }
            C2Rust_Block_47::S_884 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_47 = C2Rust_Block_47::S_886;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_890;
                }
            }
            C2Rust_Block_47::S_886 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_907;
            }
            C2Rust_Block_47::S_890 => {
                _i = 0;
                c2rust_current_block_47 = C2Rust_Block_47::S_893;
            }
            C2Rust_Block_47::S_893 => {
                _i = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_894;
            }
            C2Rust_Block_47::S_894 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_47 = C2Rust_Block_47::S_895;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_907;
                }
            }
            C2Rust_Block_47::S_895 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_896;
            }
            C2Rust_Block_47::S_896 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_894;
            }
            C2Rust_Block_47::S_907 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_47 = C2Rust_Block_47::S_909;
            }
            C2Rust_Block_47::S_909 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_47 = C2Rust_Block_47::S_935;
            }
            C2Rust_Block_47::S_914 => {
                _i_0 = 0;
                c2rust_current_block_47 = C2Rust_Block_47::S_917;
            }
            C2Rust_Block_47::S_917 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_918;
            }
            C2Rust_Block_47::S_918 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_47 = C2Rust_Block_47::S_919;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_927;
                }
            }
            C2Rust_Block_47::S_919 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_920;
            }
            C2Rust_Block_47::S_920 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_918;
            }
            C2Rust_Block_47::S_927 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_47 = C2Rust_Block_47::S_929;
            }
            C2Rust_Block_47::S_929 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_47 = C2Rust_Block_47::S_935;
            }
            C2Rust_Block_47::S_935 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_937;
            }
            C2Rust_Block_47::S_937 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_939;
            }
            C2Rust_Block_47::S_939 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x218 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_945;
            }
            C2Rust_Block_47::S_945 => {
                _pv_21 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_947;
            }
            C2Rust_Block_47::S_947 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_949;
            }
            C2Rust_Block_47::S_949 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_955;
            }
            C2Rust_Block_47::S_955 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_957;
            }
            C2Rust_Block_47::S_957 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_959;
            }
            C2Rust_Block_47::S_959 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_961;
            }
            C2Rust_Block_47::S_961 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_963;
            }
            C2Rust_Block_47::S_963 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_969;
            }
            C2Rust_Block_47::S_969 => {
                _pv_22 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_971;
            }
            C2Rust_Block_47::S_971 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_973;
            }
            C2Rust_Block_47::S_973 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_979;
            }
            C2Rust_Block_47::S_979 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_47 = C2Rust_Block_47::S_983;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1017;
                }
            }
            C2Rust_Block_47::S_983 => {
                _d_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_985;
            }
            C2Rust_Block_47::S_985 => {
                _n_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_987;
            }
            C2Rust_Block_47::S_987 => {
                if _d_0.offset(_n_0 as isize) <= _s_0
                    || _s_0.offset(_n_0 as isize) <= _d_0
                {
                    c2rust_current_block_47 = C2Rust_Block_47::S_989;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_993;
                }
            }
            C2Rust_Block_47::S_989 => {
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1010;
            }
            C2Rust_Block_47::S_993 => {
                _i_1 = 0;
                c2rust_current_block_47 = C2Rust_Block_47::S_996;
            }
            C2Rust_Block_47::S_996 => {
                _i_1 = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_997;
            }
            C2Rust_Block_47::S_997 => {
                if _i_1 < _n_0 {
                    c2rust_current_block_47 = C2Rust_Block_47::S_998;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1010;
                }
            }
            C2Rust_Block_47::S_998 => {
                *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                c2rust_current_block_47 = C2Rust_Block_47::S_999;
            }
            C2Rust_Block_47::S_999 => {
                _i_1 = _i_1.wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_997;
            }
            C2Rust_Block_47::S_1010 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_47 = C2Rust_Block_47::S_1012;
            }
            C2Rust_Block_47::S_1012 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_47 = C2Rust_Block_47::S_1038;
            }
            C2Rust_Block_47::S_1017 => {
                _i_2 = 0;
                c2rust_current_block_47 = C2Rust_Block_47::S_1020;
            }
            C2Rust_Block_47::S_1020 => {
                _i_2 = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1021;
            }
            C2Rust_Block_47::S_1021 => {
                if _i_2 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1022;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1030;
                }
            }
            C2Rust_Block_47::S_1022 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1023;
            }
            C2Rust_Block_47::S_1023 => {
                _i_2 = _i_2.wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_1021;
            }
            C2Rust_Block_47::S_1030 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_47 = C2Rust_Block_47::S_1032;
            }
            C2Rust_Block_47::S_1032 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_47 = C2Rust_Block_47::S_1038;
            }
            C2Rust_Block_47::S_1038 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1044;
            }
            C2Rust_Block_47::S_1044 => {
                _pv_23 = 0x1b475a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1046;
            }
            C2Rust_Block_47::S_1046 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1048;
            }
            C2Rust_Block_47::S_1048 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1054;
            }
            C2Rust_Block_47::S_1054 => {
                sub_001D1F4E();
                c2rust_current_block_47 = C2Rust_Block_47::S_1060;
            }
            C2Rust_Block_47::S_1060 => {
                (*__gamepkg_tls_g_esi) = ebp;
                c2rust_current_block_47 = C2Rust_Block_47::S_1062;
            }
            C2Rust_Block_47::S_1062 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_1068;
            }
            C2Rust_Block_47::S_1068 => {
                _pv_24 = 0x1b4763 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1070;
            }
            C2Rust_Block_47::S_1070 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1072;
            }
            C2Rust_Block_47::S_1072 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1078;
            }
            C2Rust_Block_47::S_1078 => {
                sub_001B43C0();
                c2rust_current_block_47 = C2Rust_Block_47::S_1084;
            }
            C2Rust_Block_47::S_1084 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1086;
            }
            C2Rust_Block_47::S_1086 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1088;
            }
            C2Rust_Block_47::S_1088 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1090;
            }
            C2Rust_Block_47::S_1090 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1092;
            }
            C2Rust_Block_47::S_1092 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_1094;
            }
            C2Rust_Block_47::S_1094 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1096;
            }
            C2Rust_Block_47::S_1096 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1098;
            }
            C2Rust_Block_47::S_1098 => {
                if _fa != _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1121;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1107;
                }
            }
            C2Rust_Block_47::S_1107 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1109;
            }
            C2Rust_Block_47::S_1109 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xa as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1111;
            }
            C2Rust_Block_47::S_1111 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1113;
            }
            C2Rust_Block_47::S_1113 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x14c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1187;
            }
            C2Rust_Block_47::S_1121 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1123;
            }
            C2Rust_Block_47::S_1123 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x238 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1125;
            }
            C2Rust_Block_47::S_1125 => {
                (*__gamepkg_tls_g_esi) = ebp;
                c2rust_current_block_47 = C2Rust_Block_47::S_1127;
            }
            C2Rust_Block_47::S_1127 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1133;
            }
            C2Rust_Block_47::S_1133 => {
                _pv_25 = 0x1b47b0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1135;
            }
            C2Rust_Block_47::S_1135 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1137;
            }
            C2Rust_Block_47::S_1137 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1143;
            }
            C2Rust_Block_47::S_1143 => {
                sub_001B43C0();
                c2rust_current_block_47 = C2Rust_Block_47::S_1149;
            }
            C2Rust_Block_47::S_1149 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1155;
            }
            C2Rust_Block_47::S_1155 => {
                _pv_26 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_47 = C2Rust_Block_47::S_1157;
            }
            C2Rust_Block_47::S_1157 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1159;
            }
            C2Rust_Block_47::S_1159 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1165;
            }
            C2Rust_Block_47::S_1165 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1171;
            }
            C2Rust_Block_47::S_1171 => {
                _pv_27 = 0x1b47c2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1173;
            }
            C2Rust_Block_47::S_1173 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1175;
            }
            C2Rust_Block_47::S_1175 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1181;
            }
            C2Rust_Block_47::S_1181 => {
                sub_001D19FD();
                c2rust_current_block_47 = C2Rust_Block_47::S_1187;
            }
            C2Rust_Block_47::S_1187 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1189;
            }
            C2Rust_Block_47::S_1189 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1191;
            }
            C2Rust_Block_47::S_1191 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1193;
            }
            C2Rust_Block_47::S_1193 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1195;
            }
            C2Rust_Block_47::S_1195 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1197;
            }
            C2Rust_Block_47::S_1197 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_1203;
            }
            C2Rust_Block_47::S_1203 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1205;
            }
            C2Rust_Block_47::S_1205 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1215;
            }
            C2Rust_Block_47::S_1215 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1217;
            }
            C2Rust_Block_47::S_1217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1223;
            }
            C2Rust_Block_47::S_1223 => {
                if _fa == _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1266;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_1236;
                }
            }
            C2Rust_Block_47::S_1236 => {
                _pv_28 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_1238;
            }
            C2Rust_Block_47::S_1238 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1240;
            }
            C2Rust_Block_47::S_1240 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1250;
            }
            C2Rust_Block_47::S_1250 => {
                _pv_29 = 0x1b47d2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1252;
            }
            C2Rust_Block_47::S_1252 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1254;
            }
            C2Rust_Block_47::S_1254 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1260;
            }
            C2Rust_Block_47::S_1260 => {
                sub_001D0DE6();
                c2rust_current_block_47 = C2Rust_Block_47::S_1266;
            }
            C2Rust_Block_47::S_1266 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xbfc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1268;
            }
            C2Rust_Block_47::S_1268 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1270;
            }
            C2Rust_Block_47::S_1270 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xb as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1276;
            }
            C2Rust_Block_47::S_1276 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_1278;
            }
            C2Rust_Block_47::S_1278 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1284;
            }
            C2Rust_Block_47::S_1284 => {
                _fb = 0x690 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1286;
            }
            C2Rust_Block_47::S_1286 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1288;
            }
            C2Rust_Block_47::S_1288 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x690 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_1290;
            }
            C2Rust_Block_47::S_1290 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x690 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1292;
            }
            C2Rust_Block_47::S_1292 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1294;
            }
            C2Rust_Block_47::S_1294 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_1296;
            }
            C2Rust_Block_47::S_1296 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_1298;
            }
            C2Rust_Block_47::S_1298 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B47F0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    enum C2Rust_Block_48 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_64,
        S_66,
        S_68,
        S_78,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_112,
        S_114,
        S_116,
        S_122,
        S_124,
        S_126,
        S_128,
        S_137,
        S_139,
        S_141,
        S_143,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_170,
        S_172,
        S_174,
        S_176,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_201,
        S_203,
        S_205,
        S_207,
        S_213,
        S_219,
        S_221,
        S_223,
        S_225,
        S_227,
        S_230,
        S_232,
        S_235,
        S_236,
        S_237,
        S_238,
        S_245,
        S_249,
        S_251,
        S_253,
        S_255,
        S_261,
        S_263,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_292,
        S_294,
        S_296,
        S_302,
        S_308,
        S_310,
        S_312,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_332,
        S_334,
        S_336,
        S_346,
        S_348,
        S_350,
        S_360,
        S_362,
        S_364,
        S_374,
        S_376,
        S_378,
        S_384,
        S_386,
        S_392,
        S_394,
        S_396,
        S_402,
        S_412,
        S_414,
        S_416,
        S_422,
        S_428,
        S_430,
        S_432,
        S_442,
        S_444,
        S_446,
        S_456,
        S_458,
        S_460,
        S_466,
        S_472,
        S_474,
        S_476,
        S_486,
        S_488,
        S_490,
        S_496,
        S_498,
        S_504,
        S_506,
        S_508,
        S_514,
        S_520,
        S_522,
        S_524,
        S_526,
        S_528,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_557,
        S_559,
        S_561,
        S_563,
        S_565,
        S_567,
        S_569,
        S_571,
        S_573,
        S_575,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_594,
        S_596,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_629,
        S_631,
        S_633,
        S_635,
        S_637,
        S_639,
        S_641,
        S_643,
        S_645,
        S_647,
        S_649,
        S_651,
        S_657,
        S_659,
        S_661,
        S_663,
        S_665,
        S_667,
        S_669,
        S_671,
        S_673,
        S_675,
        S_677,
        S_686,
        S_688,
        S_690,
        S_696,
        S_698,
        S_700,
        S_710,
        S_712,
        S_714,
        S_724,
        S_726,
        S_728,
        S_738,
        S_740,
        S_742,
        S_752,
        S_754,
        S_756,
        S_766,
        S_768,
        S_770,
        S_776,
        S_782,
        S_784,
        S_786,
        S_792,
        S_794,
        S_800,
        S_802,
        S_804,
        S_810,
        S_816,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_828,
        S_830,
        S_839,
        S_841,
        S_847,
        S_849,
        S_851,
        S_857,
        S_863,
        S_865,
        S_871,
        S_873,
        S_875,
        S_881,
        S_887,
        S_889,
        S_891,
        S_893,
        S_895,
        S_897,
        S_899,
        S_905,
        S_907,
        S_917,
        S_919,
        S_929,
        S_931,
        S_937,
        S_943,
        S_945,
        S_951,
        S_953,
        S_959,
        S_961,
        S_963,
        S_969,
        S_971,
        S_981,
        S_983,
        S_993,
        S_995,
        S_1001,
        S_1007,
        S_1009,
        S_1015,
        S_1017,
        S_1023,
        S_1025,
        S_1027,
        S_1029,
        S_1031,
        S_1037,
        S_1039,
        S_1049,
        S_1051,
        S_1057,
        S_1059,
        S_1061,
        S_1063,
        S_1069,
        S_1071,
        S_1077,
        S_1083,
        S_1085,
        S_1091,
        S_1093,
    }
    let mut c2rust_current_block_48: C2Rust_Block_48;
    c2rust_current_block_48 = C2Rust_Block_48::S_0;
    loop {
        match c2rust_current_block_48 {
            C2Rust_Block_48::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_2;
            }
            C2Rust_Block_48::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_48 = C2Rust_Block_48::S_4;
            }
            C2Rust_Block_48::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_48 = C2Rust_Block_48::S_6;
            }
            C2Rust_Block_48::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_8;
            }
            C2Rust_Block_48::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_26;
            }
            C2Rust_Block_48::S_26 => {
                _pv = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_28;
            }
            C2Rust_Block_48::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_30;
            }
            C2Rust_Block_48::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_36;
            }
            C2Rust_Block_48::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_48 = C2Rust_Block_48::S_38;
            }
            C2Rust_Block_48::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_40;
            }
            C2Rust_Block_48::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_42;
            }
            C2Rust_Block_48::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp) & 0xfffffff8 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_44;
            }
            C2Rust_Block_48::S_44 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_46;
            }
            C2Rust_Block_48::S_46 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_48;
            }
            C2Rust_Block_48::S_48 => {
                _fb = 0x214 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_50;
            }
            C2Rust_Block_48::S_50 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_52;
            }
            C2Rust_Block_48::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x214 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_54;
            }
            C2Rust_Block_48::S_54 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_56;
            }
            C2Rust_Block_48::S_56 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_58;
            }
            C2Rust_Block_48::S_58 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_64;
            }
            C2Rust_Block_48::S_64 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_48 = C2Rust_Block_48::S_66;
            }
            C2Rust_Block_48::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_68;
            }
            C2Rust_Block_48::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_78;
            }
            C2Rust_Block_48::S_78 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_48 = C2Rust_Block_48::S_80;
            }
            C2Rust_Block_48::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_82;
            }
            C2Rust_Block_48::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_88;
            }
            C2Rust_Block_48::S_88 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_90;
            }
            C2Rust_Block_48::S_90 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_92;
            }
            C2Rust_Block_48::S_92 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_94;
            }
            C2Rust_Block_48::S_94 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_96;
            }
            C2Rust_Block_48::S_96 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_98;
            }
            C2Rust_Block_48::S_98 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_100;
            }
            C2Rust_Block_48::S_100 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_102;
            }
            C2Rust_Block_48::S_102 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_104;
            }
            C2Rust_Block_48::S_104 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_106;
            }
            C2Rust_Block_48::S_106 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_112;
            }
            C2Rust_Block_48::S_112 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_48 = C2Rust_Block_48::S_114;
            }
            C2Rust_Block_48::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_116;
            }
            C2Rust_Block_48::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_122;
            }
            C2Rust_Block_48::S_122 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_124;
            }
            C2Rust_Block_48::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_126;
            }
            C2Rust_Block_48::S_126 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_128;
            }
            C2Rust_Block_48::S_128 => {
                if _fa == _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_151;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_137;
                }
            }
            C2Rust_Block_48::S_137 => {
                (*__gamepkg_tls_g_ebx) = 3 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_139;
            }
            C2Rust_Block_48::S_139 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_141;
            }
            C2Rust_Block_48::S_141 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x80000000 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_143;
            }
            C2Rust_Block_48::S_143 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_219;
            }
            C2Rust_Block_48::S_151 => {
                (*__gamepkg_tls_g_ecx) = 2 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_153;
            }
            C2Rust_Block_48::S_153 => {
                _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int
                    & ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_155;
            }
            C2Rust_Block_48::S_155 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_157;
            }
            C2Rust_Block_48::S_157 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_159;
            }
            C2Rust_Block_48::S_159 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_161;
            }
            C2Rust_Block_48::S_161 => {
                if _fa == _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_184;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_170;
                }
            }
            C2Rust_Block_48::S_170 => {
                (*__gamepkg_tls_g_ebx) = 4 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_172;
            }
            C2Rust_Block_48::S_172 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_174;
            }
            C2Rust_Block_48::S_174 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x40000000 as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_176;
            }
            C2Rust_Block_48::S_176 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_213;
            }
            C2Rust_Block_48::S_184 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_186;
            }
            C2Rust_Block_48::S_186 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_188;
            }
            C2Rust_Block_48::S_188 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_190;
            }
            C2Rust_Block_48::S_190 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_192;
            }
            C2Rust_Block_48::S_192 => {
                if _fa == _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_219;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_201;
                }
            }
            C2Rust_Block_48::S_201 => {
                (*__gamepkg_tls_g_ebx) = 4 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_203;
            }
            C2Rust_Block_48::S_203 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_205;
            }
            C2Rust_Block_48::S_205 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xc0000000 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_207;
            }
            C2Rust_Block_48::S_207 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_213;
            }
            C2Rust_Block_48::S_213 => {
                (*__gamepkg_tls_g_esi) = 1 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_219;
            }
            C2Rust_Block_48::S_219 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_221;
            }
            C2Rust_Block_48::S_221 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_223;
            }
            C2Rust_Block_48::S_223 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_225;
            }
            C2Rust_Block_48::S_225 => {
                (*__gamepkg_tls_g_ecx) = 0x41 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_227;
            }
            C2Rust_Block_48::S_227 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_230;
            }
            C2Rust_Block_48::S_230 => {
                _i = 0;
                c2rust_current_block_48 = C2Rust_Block_48::S_232;
            }
            C2Rust_Block_48::S_232 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_48 = C2Rust_Block_48::S_235;
            }
            C2Rust_Block_48::S_235 => {
                _i = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_236;
            }
            C2Rust_Block_48::S_236 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_48 = C2Rust_Block_48::S_237;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_245;
                }
            }
            C2Rust_Block_48::S_237 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_238;
            }
            C2Rust_Block_48::S_238 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_48 = C2Rust_Block_48::S_236;
            }
            C2Rust_Block_48::S_245 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_48 = C2Rust_Block_48::S_249;
            }
            C2Rust_Block_48::S_249 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_251;
            }
            C2Rust_Block_48::S_251 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_253;
            }
            C2Rust_Block_48::S_253 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_48 = C2Rust_Block_48::S_255;
            }
            C2Rust_Block_48::S_255 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(1 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_261;
            }
            C2Rust_Block_48::S_261 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_263;
            }
            C2Rust_Block_48::S_263 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_48 = C2Rust_Block_48::S_265;
            }
            C2Rust_Block_48::S_265 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_267;
            }
            C2Rust_Block_48::S_267 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_269;
            }
            C2Rust_Block_48::S_269 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_271;
            }
            C2Rust_Block_48::S_271 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_273;
            }
            C2Rust_Block_48::S_273 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_275;
            }
            C2Rust_Block_48::S_275 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_277;
            }
            C2Rust_Block_48::S_277 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_279;
            }
            C2Rust_Block_48::S_279 => {
                if _fa != _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_261;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_292;
                }
            }
            C2Rust_Block_48::S_292 => {
                _pv_3 = 0x80 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_294;
            }
            C2Rust_Block_48::S_294 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_296;
            }
            C2Rust_Block_48::S_296 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_302;
            }
            C2Rust_Block_48::S_302 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x124 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_308;
            }
            C2Rust_Block_48::S_308 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_48 = C2Rust_Block_48::S_310;
            }
            C2Rust_Block_48::S_310 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_312;
            }
            C2Rust_Block_48::S_312 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_318;
            }
            C2Rust_Block_48::S_318 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_320;
            }
            C2Rust_Block_48::S_320 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_322;
            }
            C2Rust_Block_48::S_322 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_48 = C2Rust_Block_48::S_324;
            }
            C2Rust_Block_48::S_324 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_326;
            }
            C2Rust_Block_48::S_326 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_332;
            }
            C2Rust_Block_48::S_332 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_48 = C2Rust_Block_48::S_334;
            }
            C2Rust_Block_48::S_334 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_336;
            }
            C2Rust_Block_48::S_336 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_346;
            }
            C2Rust_Block_48::S_346 => {
                _pv_6 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_48 = C2Rust_Block_48::S_348;
            }
            C2Rust_Block_48::S_348 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_350;
            }
            C2Rust_Block_48::S_350 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_360;
            }
            C2Rust_Block_48::S_360 => {
                _pv_7 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_362;
            }
            C2Rust_Block_48::S_362 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_364;
            }
            C2Rust_Block_48::S_364 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_374;
            }
            C2Rust_Block_48::S_374 => {
                _pv_8 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_376;
            }
            C2Rust_Block_48::S_376 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_378;
            }
            C2Rust_Block_48::S_378 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_384;
            }
            C2Rust_Block_48::S_384 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_386;
            }
            C2Rust_Block_48::S_386 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_392;
            }
            C2Rust_Block_48::S_392 => {
                _pv_9 = 0x1b48a9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_394;
            }
            C2Rust_Block_48::S_394 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_396;
            }
            C2Rust_Block_48::S_396 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_402;
            }
            C2Rust_Block_48::S_402 => {
                sub_001D1D5F();
                c2rust_current_block_48 = C2Rust_Block_48::S_412;
            }
            C2Rust_Block_48::S_412 => {
                _pv_10 = 0x104 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_414;
            }
            C2Rust_Block_48::S_414 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_416;
            }
            C2Rust_Block_48::S_416 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_422;
            }
            C2Rust_Block_48::S_422 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_428;
            }
            C2Rust_Block_48::S_428 => {
                _pv_11 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_48 = C2Rust_Block_48::S_430;
            }
            C2Rust_Block_48::S_430 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_432;
            }
            C2Rust_Block_48::S_432 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_442;
            }
            C2Rust_Block_48::S_442 => {
                _pv_12 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_48 = C2Rust_Block_48::S_444;
            }
            C2Rust_Block_48::S_444 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_446;
            }
            C2Rust_Block_48::S_446 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_456;
            }
            C2Rust_Block_48::S_456 => {
                _pv_13 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_48 = C2Rust_Block_48::S_458;
            }
            C2Rust_Block_48::S_458 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_460;
            }
            C2Rust_Block_48::S_460 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_466;
            }
            C2Rust_Block_48::S_466 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x130 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_472;
            }
            C2Rust_Block_48::S_472 => {
                _pv_14 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_48 = C2Rust_Block_48::S_474;
            }
            C2Rust_Block_48::S_474 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_476;
            }
            C2Rust_Block_48::S_476 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_486;
            }
            C2Rust_Block_48::S_486 => {
                _pv_15 = 0x3aadc4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_488;
            }
            C2Rust_Block_48::S_488 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_490;
            }
            C2Rust_Block_48::S_490 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_496;
            }
            C2Rust_Block_48::S_496 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_498;
            }
            C2Rust_Block_48::S_498 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_504;
            }
            C2Rust_Block_48::S_504 => {
                _pv_16 = 0x1b48c7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_506;
            }
            C2Rust_Block_48::S_506 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_508;
            }
            C2Rust_Block_48::S_508 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_514;
            }
            C2Rust_Block_48::S_514 => {
                sub_001D0A32();
                c2rust_current_block_48 = C2Rust_Block_48::S_520;
            }
            C2Rust_Block_48::S_520 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_522;
            }
            C2Rust_Block_48::S_522 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_524;
            }
            C2Rust_Block_48::S_524 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_526;
            }
            C2Rust_Block_48::S_526 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_528;
            }
            C2Rust_Block_48::S_528 => {
                if _fa != _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_1023;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_537;
                }
            }
            C2Rust_Block_48::S_537 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_539;
            }
            C2Rust_Block_48::S_539 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_541;
            }
            C2Rust_Block_48::S_541 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_543;
            }
            C2Rust_Block_48::S_543 => {
                _fb = 0x26 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_545;
            }
            C2Rust_Block_48::S_545 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_547;
            }
            C2Rust_Block_48::S_547 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x26 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_549;
            }
            C2Rust_Block_48::S_549 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_551;
            }
            C2Rust_Block_48::S_551 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_557;
            }
            C2Rust_Block_48::S_557 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_edx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_559;
            }
            C2Rust_Block_48::S_559 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                c2rust_current_block_48 = C2Rust_Block_48::S_561;
            }
            C2Rust_Block_48::S_561 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_563;
            }
            C2Rust_Block_48::S_563 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_565;
            }
            C2Rust_Block_48::S_565 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_567;
            }
            C2Rust_Block_48::S_567 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_569;
            }
            C2Rust_Block_48::S_569 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_48 = C2Rust_Block_48::S_571;
            }
            C2Rust_Block_48::S_571 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_573;
            }
            C2Rust_Block_48::S_573 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_575;
            }
            C2Rust_Block_48::S_575 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_577;
            }
            C2Rust_Block_48::S_577 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_579;
            }
            C2Rust_Block_48::S_579 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_581;
            }
            C2Rust_Block_48::S_581 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_583;
            }
            C2Rust_Block_48::S_583 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_585;
            }
            C2Rust_Block_48::S_585 => {
                if _fa != _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_557;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_594;
                }
            }
            C2Rust_Block_48::S_594 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_596;
            }
            C2Rust_Block_48::S_596 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(1 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_602;
            }
            C2Rust_Block_48::S_602 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_604;
            }
            C2Rust_Block_48::S_604 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_48 = C2Rust_Block_48::S_606;
            }
            C2Rust_Block_48::S_606 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_608;
            }
            C2Rust_Block_48::S_608 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_610;
            }
            C2Rust_Block_48::S_610 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_612;
            }
            C2Rust_Block_48::S_612 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_614;
            }
            C2Rust_Block_48::S_614 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_616;
            }
            C2Rust_Block_48::S_616 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_618;
            }
            C2Rust_Block_48::S_618 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_620;
            }
            C2Rust_Block_48::S_620 => {
                if _fa != _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_602;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_629;
                }
            }
            C2Rust_Block_48::S_629 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_631;
            }
            C2Rust_Block_48::S_631 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_633;
            }
            C2Rust_Block_48::S_633 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_48 = C2Rust_Block_48::S_635;
            }
            C2Rust_Block_48::S_635 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_637;
            }
            C2Rust_Block_48::S_637 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_639;
            }
            C2Rust_Block_48::S_639 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add((*__gamepkg_tls_g_eax))
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_641;
            }
            C2Rust_Block_48::S_641 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_48 = C2Rust_Block_48::S_643;
            }
            C2Rust_Block_48::S_643 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_645;
            }
            C2Rust_Block_48::S_645 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_647;
            }
            C2Rust_Block_48::S_647 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_sub((*__gamepkg_tls_g_edi));
                c2rust_current_block_48 = C2Rust_Block_48::S_649;
            }
            C2Rust_Block_48::S_649 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_651;
            }
            C2Rust_Block_48::S_651 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_657;
            }
            C2Rust_Block_48::S_657 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_659;
            }
            C2Rust_Block_48::S_659 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_ecx))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_661;
            }
            C2Rust_Block_48::S_661 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_48 = C2Rust_Block_48::S_663;
            }
            C2Rust_Block_48::S_663 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_665;
            }
            C2Rust_Block_48::S_665 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_667;
            }
            C2Rust_Block_48::S_667 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_669;
            }
            C2Rust_Block_48::S_669 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_671;
            }
            C2Rust_Block_48::S_671 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_673;
            }
            C2Rust_Block_48::S_673 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_675;
            }
            C2Rust_Block_48::S_675 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_677;
            }
            C2Rust_Block_48::S_677 => {
                if _fa != _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_657;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_686;
                }
            }
            C2Rust_Block_48::S_686 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_688;
            }
            C2Rust_Block_48::S_688 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_690;
            }
            C2Rust_Block_48::S_690 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_696;
            }
            C2Rust_Block_48::S_696 => {
                _pv_17 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_698;
            }
            C2Rust_Block_48::S_698 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_700;
            }
            C2Rust_Block_48::S_700 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_710;
            }
            C2Rust_Block_48::S_710 => {
                _pv_18 = 0x60000000 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_712;
            }
            C2Rust_Block_48::S_712 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_714;
            }
            C2Rust_Block_48::S_714 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_724;
            }
            C2Rust_Block_48::S_724 => {
                _pv_19 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_48 = C2Rust_Block_48::S_726;
            }
            C2Rust_Block_48::S_726 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_728;
            }
            C2Rust_Block_48::S_728 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_738;
            }
            C2Rust_Block_48::S_738 => {
                _pv_20 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_740;
            }
            C2Rust_Block_48::S_740 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_742;
            }
            C2Rust_Block_48::S_742 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_752;
            }
            C2Rust_Block_48::S_752 => {
                _pv_21 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_48 = C2Rust_Block_48::S_754;
            }
            C2Rust_Block_48::S_754 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_756;
            }
            C2Rust_Block_48::S_756 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_766;
            }
            C2Rust_Block_48::S_766 => {
                _pv_22 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_48 = C2Rust_Block_48::S_768;
            }
            C2Rust_Block_48::S_768 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_770;
            }
            C2Rust_Block_48::S_770 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_776;
            }
            C2Rust_Block_48::S_776 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_782;
            }
            C2Rust_Block_48::S_782 => {
                _pv_23 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_48 = C2Rust_Block_48::S_784;
            }
            C2Rust_Block_48::S_784 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_786;
            }
            C2Rust_Block_48::S_786 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_792;
            }
            C2Rust_Block_48::S_792 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_794;
            }
            C2Rust_Block_48::S_794 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_800;
            }
            C2Rust_Block_48::S_800 => {
                _pv_24 = 0x1b492e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_802;
            }
            C2Rust_Block_48::S_802 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_804;
            }
            C2Rust_Block_48::S_804 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_810;
            }
            C2Rust_Block_48::S_810 => {
                sub_001D0E3C();
                c2rust_current_block_48 = C2Rust_Block_48::S_816;
            }
            C2Rust_Block_48::S_816 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_818;
            }
            C2Rust_Block_48::S_818 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_820;
            }
            C2Rust_Block_48::S_820 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_822;
            }
            C2Rust_Block_48::S_822 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_824;
            }
            C2Rust_Block_48::S_824 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_826;
            }
            C2Rust_Block_48::S_826 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_828;
            }
            C2Rust_Block_48::S_828 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_830;
            }
            C2Rust_Block_48::S_830 => {
                if _fa != _fb {
                    c2rust_current_block_48 = C2Rust_Block_48::S_959;
                } else {
                    c2rust_current_block_48 = C2Rust_Block_48::S_839;
                }
            }
            C2Rust_Block_48::S_839 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_841;
            }
            C2Rust_Block_48::S_841 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_847;
            }
            C2Rust_Block_48::S_847 => {
                _pv_25 = 0x1b4946 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_849;
            }
            C2Rust_Block_48::S_849 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_851;
            }
            C2Rust_Block_48::S_851 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_857;
            }
            C2Rust_Block_48::S_857 => {
                sub_001D192B();
                c2rust_current_block_48 = C2Rust_Block_48::S_863;
            }
            C2Rust_Block_48::S_863 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_865;
            }
            C2Rust_Block_48::S_865 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_871;
            }
            C2Rust_Block_48::S_871 => {
                _pv_26 = 0x1b494b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_873;
            }
            C2Rust_Block_48::S_873 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_875;
            }
            C2Rust_Block_48::S_875 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_881;
            }
            C2Rust_Block_48::S_881 => {
                sub_001B43C0();
                c2rust_current_block_48 = C2Rust_Block_48::S_887;
            }
            C2Rust_Block_48::S_887 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_889;
            }
            C2Rust_Block_48::S_889 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_891;
            }
            C2Rust_Block_48::S_891 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_893;
            }
            C2Rust_Block_48::S_893 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_895;
            }
            C2Rust_Block_48::S_895 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_897;
            }
            C2Rust_Block_48::S_897 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_899;
            }
            C2Rust_Block_48::S_899 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_905;
            }
            C2Rust_Block_48::S_905 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_907;
            }
            C2Rust_Block_48::S_907 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_917;
            }
            C2Rust_Block_48::S_917 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_919;
            }
            C2Rust_Block_48::S_919 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_929;
            }
            C2Rust_Block_48::S_929 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_931;
            }
            C2Rust_Block_48::S_931 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_937;
            }
            C2Rust_Block_48::S_937 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_943;
            }
            C2Rust_Block_48::S_943 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_945;
            }
            C2Rust_Block_48::S_945 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_951;
            }
            C2Rust_Block_48::S_951 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_953;
            }
            C2Rust_Block_48::S_953 => return,
            C2Rust_Block_48::S_959 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_961;
            }
            C2Rust_Block_48::S_961 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    4 as uint32_t,
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_963;
            }
            C2Rust_Block_48::S_963 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_969;
            }
            C2Rust_Block_48::S_969 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_971;
            }
            C2Rust_Block_48::S_971 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_981;
            }
            C2Rust_Block_48::S_981 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_983;
            }
            C2Rust_Block_48::S_983 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_993;
            }
            C2Rust_Block_48::S_993 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_995;
            }
            C2Rust_Block_48::S_995 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1001;
            }
            C2Rust_Block_48::S_1001 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_1007;
            }
            C2Rust_Block_48::S_1007 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1009;
            }
            C2Rust_Block_48::S_1009 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1015;
            }
            C2Rust_Block_48::S_1015 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1017;
            }
            C2Rust_Block_48::S_1017 => return,
            C2Rust_Block_48::S_1023 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1025;
            }
            C2Rust_Block_48::S_1025 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1027;
            }
            C2Rust_Block_48::S_1027 => {
                (*__gamepkg_tls_g_ecx) = 0xd as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_1029;
            }
            C2Rust_Block_48::S_1029 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1031;
            }
            C2Rust_Block_48::S_1031 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1037;
            }
            C2Rust_Block_48::S_1037 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1039;
            }
            C2Rust_Block_48::S_1039 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1049;
            }
            C2Rust_Block_48::S_1049 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1051;
            }
            C2Rust_Block_48::S_1051 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1057;
            }
            C2Rust_Block_48::S_1057 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1059;
            }
            C2Rust_Block_48::S_1059 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_1061;
            }
            C2Rust_Block_48::S_1061 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_1063;
            }
            C2Rust_Block_48::S_1063 => {
                _fas = _fa as int32_t;
                c2rust_current_block_48 = C2Rust_Block_48::S_1069;
            }
            C2Rust_Block_48::S_1069 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1071;
            }
            C2Rust_Block_48::S_1071 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1077;
            }
            C2Rust_Block_48::S_1077 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_48 = C2Rust_Block_48::S_1083;
            }
            C2Rust_Block_48::S_1083 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_48 = C2Rust_Block_48::S_1085;
            }
            C2Rust_Block_48::S_1085 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1091;
            }
            C2Rust_Block_48::S_1091 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_48 = C2Rust_Block_48::S_1093;
            }
            C2Rust_Block_48::S_1093 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B49C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x148 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_97: {
        if _fa == _fb {
            break 's_97;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x1b49d9 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_001D19FD();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x148 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1b49f7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001D19FD();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_182: {
        if _fa == _fb {
            break 's_182;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x130 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            5 as uint32_t,
        );
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_4: uint32_t = 0x1b4a17 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001B43C0();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x134 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4A30() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    enum C2Rust_Block_50 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_36,
        S_38,
        S_40,
        S_50,
        S_52,
        S_54,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_91,
        S_93,
        S_95,
        S_97,
        S_99,
        S_112,
        S_114,
        S_116,
        S_126,
        S_128,
        S_130,
        S_140,
        S_142,
        S_144,
        S_154,
        S_156,
        S_158,
        S_168,
        S_170,
        S_172,
        S_178,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_205,
        S_207,
        S_209,
        S_215,
        S_221,
        S_227,
        S_229,
        S_235,
        S_237,
        S_243,
        S_245,
        S_255,
        S_257,
        S_263,
        S_265,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_293,
        S_295,
        S_297,
        S_303,
        S_305,
        S_311,
        S_313,
        S_315,
        S_321,
        S_323,
        S_329,
        S_331,
        S_333,
        S_339,
        S_345,
        S_347,
        S_349,
        S_359,
        S_361,
        S_363,
        S_373,
        S_375,
        S_377,
        S_387,
        S_389,
        S_391,
        S_397,
        S_403,
        S_409,
        S_411,
        S_413,
        S_419,
        S_425,
        S_427,
        S_429,
        S_431,
        S_437,
        S_439,
        S_445,
        S_454,
        S_456,
        S_458,
        S_464,
        S_466,
        S_468,
        S_478,
        S_480,
        S_482,
        S_492,
        S_494,
        S_496,
        S_506,
        S_508,
        S_510,
        S_520,
        S_522,
        S_524,
        S_530,
        S_536,
        S_542,
        S_544,
        S_550,
        S_552,
        S_558,
        S_560,
        S_570,
        S_572,
        S_578,
        S_580,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_603,
        S_605,
        S_607,
        S_609,
        S_611,
        S_620,
        S_622,
        S_624,
        S_626,
        S_632,
        S_634,
        S_640,
        S_642,
        S_648,
        S_650,
        S_660,
        S_662,
        S_668,
        S_670,
        S_676,
        S_678,
        S_688,
        S_690,
        S_696,
        S_702,
        S_704,
        S_714,
        S_716,
        S_722,
        S_724,
    }
    let mut c2rust_current_block_50: C2Rust_Block_50;
    c2rust_current_block_50 = C2Rust_Block_50::S_0;
    loop {
        match c2rust_current_block_50 {
            C2Rust_Block_50::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_50 = C2Rust_Block_50::S_2;
            }
            C2Rust_Block_50::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_4;
            }
            C2Rust_Block_50::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_22;
            }
            C2Rust_Block_50::S_22 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_24;
            }
            C2Rust_Block_50::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_26;
            }
            C2Rust_Block_50::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_36;
            }
            C2Rust_Block_50::S_36 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_38;
            }
            C2Rust_Block_50::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_40;
            }
            C2Rust_Block_50::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_50;
            }
            C2Rust_Block_50::S_50 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_50 = C2Rust_Block_50::S_52;
            }
            C2Rust_Block_50::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_54;
            }
            C2Rust_Block_50::S_54 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_60;
            }
            C2Rust_Block_50::S_60 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_62;
            }
            C2Rust_Block_50::S_62 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_64;
            }
            C2Rust_Block_50::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffffff as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_66;
            }
            C2Rust_Block_50::S_66 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_68;
            }
            C2Rust_Block_50::S_68 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_70;
            }
            C2Rust_Block_50::S_70 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_72;
            }
            C2Rust_Block_50::S_72 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_74;
            }
            C2Rust_Block_50::S_74 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_76;
            }
            C2Rust_Block_50::S_76 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_78;
            }
            C2Rust_Block_50::S_78 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_80;
            }
            C2Rust_Block_50::S_80 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_82;
            }
            C2Rust_Block_50::S_82 => {
                if _fa == _fb {
                    c2rust_current_block_50 = C2Rust_Block_50::S_688;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_91;
                }
            }
            C2Rust_Block_50::S_91 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_93;
            }
            C2Rust_Block_50::S_93 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_95;
            }
            C2Rust_Block_50::S_95 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_97;
            }
            C2Rust_Block_50::S_97 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_99;
            }
            C2Rust_Block_50::S_99 => {
                if _fa == _fb {
                    c2rust_current_block_50 = C2Rust_Block_50::S_271;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_112;
                }
            }
            C2Rust_Block_50::S_112 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_114;
            }
            C2Rust_Block_50::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_116;
            }
            C2Rust_Block_50::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_126;
            }
            C2Rust_Block_50::S_126 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_128;
            }
            C2Rust_Block_50::S_128 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_130;
            }
            C2Rust_Block_50::S_130 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_140;
            }
            C2Rust_Block_50::S_140 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_142;
            }
            C2Rust_Block_50::S_142 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_144;
            }
            C2Rust_Block_50::S_144 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_154;
            }
            C2Rust_Block_50::S_154 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_156;
            }
            C2Rust_Block_50::S_156 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_158;
            }
            C2Rust_Block_50::S_158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_168;
            }
            C2Rust_Block_50::S_168 => {
                _pv_6 = 0x1b4a5c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_170;
            }
            C2Rust_Block_50::S_170 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_172;
            }
            C2Rust_Block_50::S_172 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_178;
            }
            C2Rust_Block_50::S_178 => {
                sub_001D120E();
                c2rust_current_block_50 = C2Rust_Block_50::S_184;
            }
            C2Rust_Block_50::S_184 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_186;
            }
            C2Rust_Block_50::S_186 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_188;
            }
            C2Rust_Block_50::S_188 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_190;
            }
            C2Rust_Block_50::S_190 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_192;
            }
            C2Rust_Block_50::S_192 => {
                if _fa != _fb {
                    c2rust_current_block_50 = C2Rust_Block_50::S_271;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_205;
                }
            }
            C2Rust_Block_50::S_205 => {
                _pv_7 = 0x1b4a66 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_207;
            }
            C2Rust_Block_50::S_207 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_209;
            }
            C2Rust_Block_50::S_209 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_215;
            }
            C2Rust_Block_50::S_215 => {
                sub_001B43C0();
                c2rust_current_block_50 = C2Rust_Block_50::S_221;
            }
            C2Rust_Block_50::S_221 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_227;
            }
            C2Rust_Block_50::S_227 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_229;
            }
            C2Rust_Block_50::S_229 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_235;
            }
            C2Rust_Block_50::S_235 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_237;
            }
            C2Rust_Block_50::S_237 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_243;
            }
            C2Rust_Block_50::S_243 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_245;
            }
            C2Rust_Block_50::S_245 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_255;
            }
            C2Rust_Block_50::S_255 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_257;
            }
            C2Rust_Block_50::S_257 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_263;
            }
            C2Rust_Block_50::S_263 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_265;
            }
            C2Rust_Block_50::S_265 => return,
            C2Rust_Block_50::S_271 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_273;
            }
            C2Rust_Block_50::S_273 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x148 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_275;
            }
            C2Rust_Block_50::S_275 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_277;
            }
            C2Rust_Block_50::S_277 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_279;
            }
            C2Rust_Block_50::S_279 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_281;
            }
            C2Rust_Block_50::S_281 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x144 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_283;
            }
            C2Rust_Block_50::S_283 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_285;
            }
            C2Rust_Block_50::S_285 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    7 as uint32_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_287;
            }
            C2Rust_Block_50::S_287 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_293;
            }
            C2Rust_Block_50::S_293 => {
                _pv_8 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_50 = C2Rust_Block_50::S_295;
            }
            C2Rust_Block_50::S_295 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_297;
            }
            C2Rust_Block_50::S_297 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_303;
            }
            C2Rust_Block_50::S_303 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x138 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_305;
            }
            C2Rust_Block_50::S_305 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_311;
            }
            C2Rust_Block_50::S_311 => {
                _pv_9 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_313;
            }
            C2Rust_Block_50::S_313 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_315;
            }
            C2Rust_Block_50::S_315 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_321;
            }
            C2Rust_Block_50::S_321 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_323;
            }
            C2Rust_Block_50::S_323 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_329;
            }
            C2Rust_Block_50::S_329 => {
                _pv_10 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_50 = C2Rust_Block_50::S_331;
            }
            C2Rust_Block_50::S_331 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_333;
            }
            C2Rust_Block_50::S_333 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_339;
            }
            C2Rust_Block_50::S_339 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_345;
            }
            C2Rust_Block_50::S_345 => {
                _pv_11 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_347;
            }
            C2Rust_Block_50::S_347 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_349;
            }
            C2Rust_Block_50::S_349 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_359;
            }
            C2Rust_Block_50::S_359 => {
                _pv_12 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_50 = C2Rust_Block_50::S_361;
            }
            C2Rust_Block_50::S_361 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_363;
            }
            C2Rust_Block_50::S_363 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_373;
            }
            C2Rust_Block_50::S_373 => {
                _pv_13 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_375;
            }
            C2Rust_Block_50::S_375 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_377;
            }
            C2Rust_Block_50::S_377 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_387;
            }
            C2Rust_Block_50::S_387 => {
                _pv_14 = 0x1b4ad5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_389;
            }
            C2Rust_Block_50::S_389 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_391;
            }
            C2Rust_Block_50::S_391 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_397;
            }
            C2Rust_Block_50::S_397 => {
                sub_001D0FC7();
                c2rust_current_block_50 = C2Rust_Block_50::S_403;
            }
            C2Rust_Block_50::S_403 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_409;
            }
            C2Rust_Block_50::S_409 => {
                _pv_15 = 0x1b4adc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_411;
            }
            C2Rust_Block_50::S_411 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_413;
            }
            C2Rust_Block_50::S_413 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_419;
            }
            C2Rust_Block_50::S_419 => {
                sub_001D192B();
                c2rust_current_block_50 = C2Rust_Block_50::S_425;
            }
            C2Rust_Block_50::S_425 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_427;
            }
            C2Rust_Block_50::S_427 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_429;
            }
            C2Rust_Block_50::S_429 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_431;
            }
            C2Rust_Block_50::S_431 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_437;
            }
            C2Rust_Block_50::S_437 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_439;
            }
            C2Rust_Block_50::S_439 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_445;
            }
            C2Rust_Block_50::S_445 => {
                if _fa == _fb {
                    c2rust_current_block_50 = C2Rust_Block_50::S_586;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_454;
                }
            }
            C2Rust_Block_50::S_454 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_456;
            }
            C2Rust_Block_50::S_456 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_458;
            }
            C2Rust_Block_50::S_458 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_464;
            }
            C2Rust_Block_50::S_464 => {
                _pv_16 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_466;
            }
            C2Rust_Block_50::S_466 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_468;
            }
            C2Rust_Block_50::S_468 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_478;
            }
            C2Rust_Block_50::S_478 => {
                _pv_17 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_480;
            }
            C2Rust_Block_50::S_480 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_482;
            }
            C2Rust_Block_50::S_482 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_492;
            }
            C2Rust_Block_50::S_492 => {
                _pv_18 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_494;
            }
            C2Rust_Block_50::S_494 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_496;
            }
            C2Rust_Block_50::S_496 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_506;
            }
            C2Rust_Block_50::S_506 => {
                _pv_19 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_508;
            }
            C2Rust_Block_50::S_508 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_510;
            }
            C2Rust_Block_50::S_510 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_520;
            }
            C2Rust_Block_50::S_520 => {
                _pv_20 = 0x1b4af6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_522;
            }
            C2Rust_Block_50::S_522 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_524;
            }
            C2Rust_Block_50::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_530;
            }
            C2Rust_Block_50::S_530 => {
                sub_001D120E();
                c2rust_current_block_50 = C2Rust_Block_50::S_536;
            }
            C2Rust_Block_50::S_536 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_542;
            }
            C2Rust_Block_50::S_542 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_544;
            }
            C2Rust_Block_50::S_544 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_550;
            }
            C2Rust_Block_50::S_550 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_552;
            }
            C2Rust_Block_50::S_552 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_558;
            }
            C2Rust_Block_50::S_558 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_560;
            }
            C2Rust_Block_50::S_560 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_570;
            }
            C2Rust_Block_50::S_570 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_572;
            }
            C2Rust_Block_50::S_572 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_578;
            }
            C2Rust_Block_50::S_578 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_580;
            }
            C2Rust_Block_50::S_580 => return,
            C2Rust_Block_50::S_586 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_588;
            }
            C2Rust_Block_50::S_588 => {
                _fb = 0x3e5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_590;
            }
            C2Rust_Block_50::S_590 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_592;
            }
            C2Rust_Block_50::S_592 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_594;
            }
            C2Rust_Block_50::S_594 => {
                if _fa == _fb {
                    c2rust_current_block_50 = C2Rust_Block_50::S_676;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_603;
                }
            }
            C2Rust_Block_50::S_603 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_605;
            }
            C2Rust_Block_50::S_605 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_607;
            }
            C2Rust_Block_50::S_607 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_609;
            }
            C2Rust_Block_50::S_609 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_611;
            }
            C2Rust_Block_50::S_611 => {
                if _fa == _fb {
                    c2rust_current_block_50 = C2Rust_Block_50::S_676;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_620;
                }
            }
            C2Rust_Block_50::S_620 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_622;
            }
            C2Rust_Block_50::S_622 => {
                (*__gamepkg_tls_g_eax) = 0xd as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_624;
            }
            C2Rust_Block_50::S_624 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_626;
            }
            C2Rust_Block_50::S_626 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_632;
            }
            C2Rust_Block_50::S_632 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_634;
            }
            C2Rust_Block_50::S_634 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_640;
            }
            C2Rust_Block_50::S_640 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_642;
            }
            C2Rust_Block_50::S_642 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_648;
            }
            C2Rust_Block_50::S_648 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_650;
            }
            C2Rust_Block_50::S_650 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_660;
            }
            C2Rust_Block_50::S_660 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_662;
            }
            C2Rust_Block_50::S_662 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_668;
            }
            C2Rust_Block_50::S_668 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_670;
            }
            C2Rust_Block_50::S_670 => return,
            C2Rust_Block_50::S_676 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_678;
            }
            C2Rust_Block_50::S_678 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    7 as uint32_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_688;
            }
            C2Rust_Block_50::S_688 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_690;
            }
            C2Rust_Block_50::S_690 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_696;
            }
            C2Rust_Block_50::S_696 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_702;
            }
            C2Rust_Block_50::S_702 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_704;
            }
            C2Rust_Block_50::S_704 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_714;
            }
            C2Rust_Block_50::S_714 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_716;
            }
            C2Rust_Block_50::S_716 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_722;
            }
            C2Rust_Block_50::S_722 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_724;
            }
            C2Rust_Block_50::S_724 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001B4B60() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    enum C2Rust_Block_51 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_36,
        S_38,
        S_40,
        S_50,
        S_52,
        S_54,
        S_64,
        S_66,
        S_68,
        S_74,
        S_76,
        S_82,
        S_84,
        S_86,
        S_92,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_109,
        S_111,
        S_113,
        S_117,
        S_119,
        S_121,
        S_123,
        S_125,
        S_127,
        S_136,
        S_138,
        S_140,
        S_146,
        S_148,
        S_154,
        S_156,
        S_158,
        S_160,
        S_166,
        S_168,
        S_178,
        S_180,
        S_186,
        S_188,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_217,
        S_219,
        S_221,
        S_223,
        S_225,
        S_238,
        S_240,
        S_242,
        S_252,
        S_254,
        S_256,
        S_262,
        S_264,
        S_270,
        S_272,
        S_274,
        S_284,
        S_286,
        S_288,
        S_298,
        S_300,
        S_302,
        S_308,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_335,
        S_337,
        S_339,
        S_345,
        S_351,
        S_357,
        S_359,
        S_365,
        S_367,
        S_373,
        S_375,
        S_385,
        S_387,
        S_393,
        S_395,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_415,
        S_417,
        S_419,
        S_425,
        S_427,
        S_429,
        S_435,
        S_437,
        S_439,
        S_449,
        S_451,
        S_453,
        S_463,
        S_465,
        S_467,
        S_477,
        S_479,
        S_481,
        S_487,
        S_493,
        S_495,
        S_501,
        S_503,
        S_505,
        S_515,
        S_517,
        S_519,
        S_525,
        S_531,
        S_533,
        S_539,
        S_541,
        S_543,
        S_553,
        S_555,
        S_557,
        S_567,
        S_569,
        S_571,
        S_581,
        S_583,
        S_585,
        S_595,
        S_597,
        S_599,
        S_605,
        S_611,
        S_613,
        S_615,
        S_621,
        S_623,
        S_625,
        S_631,
        S_633,
        S_639,
        S_641,
        S_643,
        S_653,
        S_655,
        S_657,
        S_667,
        S_669,
        S_671,
        S_681,
        S_683,
        S_685,
        S_695,
        S_697,
        S_699,
        S_705,
        S_711,
        S_717,
        S_719,
        S_721,
        S_727,
        S_733,
        S_735,
        S_737,
        S_739,
        S_741,
        S_750,
        S_752,
        S_758,
        S_760,
        S_762,
        S_772,
        S_774,
        S_776,
        S_786,
        S_788,
        S_790,
        S_800,
        S_802,
        S_804,
        S_814,
        S_816,
        S_818,
        S_824,
        S_834,
        S_836,
        S_842,
        S_848,
        S_850,
        S_860,
        S_862,
        S_868,
        S_870,
        S_876,
        S_878,
        S_880,
        S_882,
        S_884,
        S_893,
        S_895,
        S_897,
        S_899,
        S_901,
        S_910,
        S_912,
        S_914,
        S_916,
        S_922,
        S_924,
        S_930,
        S_932,
        S_938,
        S_940,
        S_950,
        S_952,
        S_958,
        S_960,
        S_966,
        S_968,
        S_978,
        S_980,
        S_986,
        S_992,
        S_994,
        S_1004,
        S_1006,
        S_1012,
        S_1014,
    }
    let mut c2rust_current_block_51: C2Rust_Block_51;
    c2rust_current_block_51 = C2Rust_Block_51::S_0;
    loop {
        match c2rust_current_block_51 {
            C2Rust_Block_51::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_51 = C2Rust_Block_51::S_2;
            }
            C2Rust_Block_51::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_4;
            }
            C2Rust_Block_51::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_22;
            }
            C2Rust_Block_51::S_22 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_51 = C2Rust_Block_51::S_24;
            }
            C2Rust_Block_51::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_26;
            }
            C2Rust_Block_51::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_36;
            }
            C2Rust_Block_51::S_36 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_51 = C2Rust_Block_51::S_38;
            }
            C2Rust_Block_51::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_40;
            }
            C2Rust_Block_51::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_50;
            }
            C2Rust_Block_51::S_50 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_52;
            }
            C2Rust_Block_51::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_54;
            }
            C2Rust_Block_51::S_54 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_64;
            }
            C2Rust_Block_51::S_64 => {
                _pv_2 = 0x3aadc4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_66;
            }
            C2Rust_Block_51::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_68;
            }
            C2Rust_Block_51::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_74;
            }
            C2Rust_Block_51::S_74 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_76;
            }
            C2Rust_Block_51::S_76 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_51 = C2Rust_Block_51::S_82;
            }
            C2Rust_Block_51::S_82 => {
                _pv_3 = 0x1b4b71 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_84;
            }
            C2Rust_Block_51::S_84 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_86;
            }
            C2Rust_Block_51::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_92;
            }
            C2Rust_Block_51::S_92 => {
                sub_001CFE6F();
                c2rust_current_block_51 = C2Rust_Block_51::S_98;
            }
            C2Rust_Block_51::S_98 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_100;
            }
            C2Rust_Block_51::S_100 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_102;
            }
            C2Rust_Block_51::S_102 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_104;
            }
            C2Rust_Block_51::S_104 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_106;
            }
            C2Rust_Block_51::S_106 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_109;
            }
            C2Rust_Block_51::S_109 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_111;
            }
            C2Rust_Block_51::S_111 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_113;
            }
            C2Rust_Block_51::S_113 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_117;
            }
            C2Rust_Block_51::S_117 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_119;
            }
            C2Rust_Block_51::S_119 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_121;
            }
            C2Rust_Block_51::S_121 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_123;
            }
            C2Rust_Block_51::S_123 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_125;
            }
            C2Rust_Block_51::S_125 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_127;
            }
            C2Rust_Block_51::S_127 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_194;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_136;
                }
            }
            C2Rust_Block_51::S_136 => {
                (*__gamepkg_tls_g_eax) = 0xd as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_138;
            }
            C2Rust_Block_51::S_138 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_140;
            }
            C2Rust_Block_51::S_140 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_146;
            }
            C2Rust_Block_51::S_146 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_148;
            }
            C2Rust_Block_51::S_148 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_154;
            }
            C2Rust_Block_51::S_154 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_156;
            }
            C2Rust_Block_51::S_156 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_158;
            }
            C2Rust_Block_51::S_158 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_160;
            }
            C2Rust_Block_51::S_160 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_166;
            }
            C2Rust_Block_51::S_166 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_168;
            }
            C2Rust_Block_51::S_168 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_178;
            }
            C2Rust_Block_51::S_178 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_180;
            }
            C2Rust_Block_51::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_186;
            }
            C2Rust_Block_51::S_186 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_188;
            }
            C2Rust_Block_51::S_188 => return,
            C2Rust_Block_51::S_194 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffffff as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_196;
            }
            C2Rust_Block_51::S_196 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    8 as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_198;
            }
            C2Rust_Block_51::S_198 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_200;
            }
            C2Rust_Block_51::S_200 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_202;
            }
            C2Rust_Block_51::S_202 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_204;
            }
            C2Rust_Block_51::S_204 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_206;
            }
            C2Rust_Block_51::S_206 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_208;
            }
            C2Rust_Block_51::S_208 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_978;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_217;
                }
            }
            C2Rust_Block_51::S_217 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_219;
            }
            C2Rust_Block_51::S_219 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_221;
            }
            C2Rust_Block_51::S_221 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_223;
            }
            C2Rust_Block_51::S_223 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_225;
            }
            C2Rust_Block_51::S_225 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_401;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_238;
                }
            }
            C2Rust_Block_51::S_238 => {
                _pv_4 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_240;
            }
            C2Rust_Block_51::S_240 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_242;
            }
            C2Rust_Block_51::S_242 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_252;
            }
            C2Rust_Block_51::S_252 => {
                _pv_5 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_254;
            }
            C2Rust_Block_51::S_254 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_256;
            }
            C2Rust_Block_51::S_256 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_262;
            }
            C2Rust_Block_51::S_262 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_264;
            }
            C2Rust_Block_51::S_264 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_270;
            }
            C2Rust_Block_51::S_270 => {
                _pv_6 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_51 = C2Rust_Block_51::S_272;
            }
            C2Rust_Block_51::S_272 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_274;
            }
            C2Rust_Block_51::S_274 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_284;
            }
            C2Rust_Block_51::S_284 => {
                _pv_7 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_51 = C2Rust_Block_51::S_286;
            }
            C2Rust_Block_51::S_286 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_288;
            }
            C2Rust_Block_51::S_288 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_298;
            }
            C2Rust_Block_51::S_298 => {
                _pv_8 = 0x1b4bd6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_300;
            }
            C2Rust_Block_51::S_300 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_302;
            }
            C2Rust_Block_51::S_302 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_308;
            }
            C2Rust_Block_51::S_308 => {
                sub_001D120E();
                c2rust_current_block_51 = C2Rust_Block_51::S_314;
            }
            C2Rust_Block_51::S_314 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_316;
            }
            C2Rust_Block_51::S_316 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_318;
            }
            C2Rust_Block_51::S_318 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_320;
            }
            C2Rust_Block_51::S_320 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_322;
            }
            C2Rust_Block_51::S_322 => {
                if _fa != _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_401;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_335;
                }
            }
            C2Rust_Block_51::S_335 => {
                _pv_9 = 0x1b4be0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_337;
            }
            C2Rust_Block_51::S_337 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_339;
            }
            C2Rust_Block_51::S_339 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_345;
            }
            C2Rust_Block_51::S_345 => {
                sub_001B43C0();
                c2rust_current_block_51 = C2Rust_Block_51::S_351;
            }
            C2Rust_Block_51::S_351 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_357;
            }
            C2Rust_Block_51::S_357 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_359;
            }
            C2Rust_Block_51::S_359 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_365;
            }
            C2Rust_Block_51::S_365 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_367;
            }
            C2Rust_Block_51::S_367 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_373;
            }
            C2Rust_Block_51::S_373 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_375;
            }
            C2Rust_Block_51::S_375 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_385;
            }
            C2Rust_Block_51::S_385 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_387;
            }
            C2Rust_Block_51::S_387 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_393;
            }
            C2Rust_Block_51::S_393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_395;
            }
            C2Rust_Block_51::S_395 => return,
            C2Rust_Block_51::S_401 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_403;
            }
            C2Rust_Block_51::S_403 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x148 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_405;
            }
            C2Rust_Block_51::S_405 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_407;
            }
            C2Rust_Block_51::S_407 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x140 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_409;
            }
            C2Rust_Block_51::S_409 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_415;
            }
            C2Rust_Block_51::S_415 => {
                _pv_10 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_417;
            }
            C2Rust_Block_51::S_417 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_419;
            }
            C2Rust_Block_51::S_419 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_425;
            }
            C2Rust_Block_51::S_425 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x144 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_427;
            }
            C2Rust_Block_51::S_427 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_429;
            }
            C2Rust_Block_51::S_429 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_435;
            }
            C2Rust_Block_51::S_435 => {
                _pv_11 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_437;
            }
            C2Rust_Block_51::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_439;
            }
            C2Rust_Block_51::S_439 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_449;
            }
            C2Rust_Block_51::S_449 => {
                _pv_12 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_451;
            }
            C2Rust_Block_51::S_451 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_453;
            }
            C2Rust_Block_51::S_453 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_463;
            }
            C2Rust_Block_51::S_463 => {
                _pv_13 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_465;
            }
            C2Rust_Block_51::S_465 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_467;
            }
            C2Rust_Block_51::S_467 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_477;
            }
            C2Rust_Block_51::S_477 => {
                _pv_14 = 0x1b4c35 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_479;
            }
            C2Rust_Block_51::S_479 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_481;
            }
            C2Rust_Block_51::S_481 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_487;
            }
            C2Rust_Block_51::S_487 => {
                sub_001D120E();
                c2rust_current_block_51 = C2Rust_Block_51::S_493;
            }
            C2Rust_Block_51::S_493 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_495;
            }
            C2Rust_Block_51::S_495 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_501;
            }
            C2Rust_Block_51::S_501 => {
                _pv_15 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_51 = C2Rust_Block_51::S_503;
            }
            C2Rust_Block_51::S_503 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_505;
            }
            C2Rust_Block_51::S_505 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_515;
            }
            C2Rust_Block_51::S_515 => {
                _pv_16 = 0x1b4c43 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_517;
            }
            C2Rust_Block_51::S_517 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_519;
            }
            C2Rust_Block_51::S_519 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_525;
            }
            C2Rust_Block_51::S_525 => {
                sub_001D118A();
                c2rust_current_block_51 = C2Rust_Block_51::S_531;
            }
            C2Rust_Block_51::S_531 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_533;
            }
            C2Rust_Block_51::S_533 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_539;
            }
            C2Rust_Block_51::S_539 => {
                _pv_17 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_541;
            }
            C2Rust_Block_51::S_541 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_543;
            }
            C2Rust_Block_51::S_543 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_553;
            }
            C2Rust_Block_51::S_553 => {
                _pv_18 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_555;
            }
            C2Rust_Block_51::S_555 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_557;
            }
            C2Rust_Block_51::S_557 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_567;
            }
            C2Rust_Block_51::S_567 => {
                _pv_19 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_569;
            }
            C2Rust_Block_51::S_569 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_571;
            }
            C2Rust_Block_51::S_571 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_581;
            }
            C2Rust_Block_51::S_581 => {
                _pv_20 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_51 = C2Rust_Block_51::S_583;
            }
            C2Rust_Block_51::S_583 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_585;
            }
            C2Rust_Block_51::S_585 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_595;
            }
            C2Rust_Block_51::S_595 => {
                _pv_21 = 0x1b4c57 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_597;
            }
            C2Rust_Block_51::S_597 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_599;
            }
            C2Rust_Block_51::S_599 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_605;
            }
            C2Rust_Block_51::S_605 => {
                sub_001D120E();
                c2rust_current_block_51 = C2Rust_Block_51::S_611;
            }
            C2Rust_Block_51::S_611 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_613;
            }
            C2Rust_Block_51::S_613 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x138 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_615;
            }
            C2Rust_Block_51::S_615 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_621;
            }
            C2Rust_Block_51::S_621 => {
                _pv_22 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_51 = C2Rust_Block_51::S_623;
            }
            C2Rust_Block_51::S_623 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_625;
            }
            C2Rust_Block_51::S_625 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_631;
            }
            C2Rust_Block_51::S_631 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_633;
            }
            C2Rust_Block_51::S_633 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_639;
            }
            C2Rust_Block_51::S_639 => {
                _pv_23 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_51 = C2Rust_Block_51::S_641;
            }
            C2Rust_Block_51::S_641 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_643;
            }
            C2Rust_Block_51::S_643 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_653;
            }
            C2Rust_Block_51::S_653 => {
                _pv_24 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_655;
            }
            C2Rust_Block_51::S_655 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_657;
            }
            C2Rust_Block_51::S_657 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_667;
            }
            C2Rust_Block_51::S_667 => {
                _pv_25 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_51 = C2Rust_Block_51::S_669;
            }
            C2Rust_Block_51::S_669 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_671;
            }
            C2Rust_Block_51::S_671 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_681;
            }
            C2Rust_Block_51::S_681 => {
                _pv_26 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_683;
            }
            C2Rust_Block_51::S_683 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_685;
            }
            C2Rust_Block_51::S_685 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_695;
            }
            C2Rust_Block_51::S_695 => {
                _pv_27 = 0x1b4c77 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_697;
            }
            C2Rust_Block_51::S_697 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_699;
            }
            C2Rust_Block_51::S_699 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_705;
            }
            C2Rust_Block_51::S_705 => {
                sub_001D10B4();
                c2rust_current_block_51 = C2Rust_Block_51::S_711;
            }
            C2Rust_Block_51::S_711 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_717;
            }
            C2Rust_Block_51::S_717 => {
                _pv_28 = 0x1b4c7e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_719;
            }
            C2Rust_Block_51::S_719 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_721;
            }
            C2Rust_Block_51::S_721 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_727;
            }
            C2Rust_Block_51::S_727 => {
                sub_001D192B();
                c2rust_current_block_51 = C2Rust_Block_51::S_733;
            }
            C2Rust_Block_51::S_733 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_735;
            }
            C2Rust_Block_51::S_735 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_737;
            }
            C2Rust_Block_51::S_737 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_739;
            }
            C2Rust_Block_51::S_739 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_741;
            }
            C2Rust_Block_51::S_741 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_876;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_750;
                }
            }
            C2Rust_Block_51::S_750 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_752;
            }
            C2Rust_Block_51::S_752 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_758;
            }
            C2Rust_Block_51::S_758 => {
                _pv_29 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_760;
            }
            C2Rust_Block_51::S_760 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_762;
            }
            C2Rust_Block_51::S_762 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_772;
            }
            C2Rust_Block_51::S_772 => {
                _pv_30 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_774;
            }
            C2Rust_Block_51::S_774 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_776;
            }
            C2Rust_Block_51::S_776 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_786;
            }
            C2Rust_Block_51::S_786 => {
                _pv_31 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_51 = C2Rust_Block_51::S_788;
            }
            C2Rust_Block_51::S_788 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_790;
            }
            C2Rust_Block_51::S_790 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_800;
            }
            C2Rust_Block_51::S_800 => {
                _pv_32 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_51 = C2Rust_Block_51::S_802;
            }
            C2Rust_Block_51::S_802 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_804;
            }
            C2Rust_Block_51::S_804 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_814;
            }
            C2Rust_Block_51::S_814 => {
                _pv_33 = 0x1b4c95 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_816;
            }
            C2Rust_Block_51::S_816 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_818;
            }
            C2Rust_Block_51::S_818 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_824;
            }
            C2Rust_Block_51::S_824 => {
                sub_001D120E();
                c2rust_current_block_51 = C2Rust_Block_51::S_834;
            }
            C2Rust_Block_51::S_834 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_836;
            }
            C2Rust_Block_51::S_836 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_842;
            }
            C2Rust_Block_51::S_842 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_848;
            }
            C2Rust_Block_51::S_848 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_850;
            }
            C2Rust_Block_51::S_850 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_860;
            }
            C2Rust_Block_51::S_860 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_862;
            }
            C2Rust_Block_51::S_862 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_868;
            }
            C2Rust_Block_51::S_868 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_870;
            }
            C2Rust_Block_51::S_870 => return,
            C2Rust_Block_51::S_876 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_878;
            }
            C2Rust_Block_51::S_878 => {
                _fb = 0x3e5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_880;
            }
            C2Rust_Block_51::S_880 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_882;
            }
            C2Rust_Block_51::S_882 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_884;
            }
            C2Rust_Block_51::S_884 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_966;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_893;
                }
            }
            C2Rust_Block_51::S_893 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_895;
            }
            C2Rust_Block_51::S_895 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_897;
            }
            C2Rust_Block_51::S_897 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_899;
            }
            C2Rust_Block_51::S_899 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_901;
            }
            C2Rust_Block_51::S_901 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_966;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_910;
                }
            }
            C2Rust_Block_51::S_910 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_912;
            }
            C2Rust_Block_51::S_912 => {
                (*__gamepkg_tls_g_eax) = 0xd as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_914;
            }
            C2Rust_Block_51::S_914 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x134 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_916;
            }
            C2Rust_Block_51::S_916 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_922;
            }
            C2Rust_Block_51::S_922 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_924;
            }
            C2Rust_Block_51::S_924 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_930;
            }
            C2Rust_Block_51::S_930 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_932;
            }
            C2Rust_Block_51::S_932 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_938;
            }
            C2Rust_Block_51::S_938 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_940;
            }
            C2Rust_Block_51::S_940 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_950;
            }
            C2Rust_Block_51::S_950 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_952;
            }
            C2Rust_Block_51::S_952 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_958;
            }
            C2Rust_Block_51::S_958 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_960;
            }
            C2Rust_Block_51::S_960 => return,
            C2Rust_Block_51::S_966 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xbfc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_968;
            }
            C2Rust_Block_51::S_968 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x130 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    8 as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_978;
            }
            C2Rust_Block_51::S_978 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_980;
            }
            C2Rust_Block_51::S_980 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_986;
            }
            C2Rust_Block_51::S_986 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_992;
            }
            C2Rust_Block_51::S_992 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_994;
            }
            C2Rust_Block_51::S_994 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1004;
            }
            C2Rust_Block_51::S_1004 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1006;
            }
            C2Rust_Block_51::S_1006 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1012;
            }
            C2Rust_Block_51::S_1012 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1014;
            }
            C2Rust_Block_51::S_1014 => return,
        }
    };
}
