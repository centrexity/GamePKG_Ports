extern "C" {
    fn memset(
        __s: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001F8690();
    fn sub_001F8B10();
    fn sub_001FABB0();
    fn sub_001FE2A0();
    fn sub_0020BC80();
    fn sub_0020BCB0();
    fn sub_0020BD20();
    fn sub_0020BD30();
    fn sub_0020BDB0();
    fn sub_0020BDC0();
    fn sub_0024419D();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn sub_001FE3E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_141: {
        if _fa == _fb {
            break 's_141;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1fe412 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001FE2A0();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE420() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
    loop {
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0x61 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_138: {
            's_94: {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_94;
                }
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                _fb = 0x41 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_138;
                }
            }
            _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                & 0xff as uint32_t;
            _fb = 0x7a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_128: {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    <= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_128;
                }
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                _fb = 0x5a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    > if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_138;
                }
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0xdf as ::core::ffi::c_int) as uint8_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0x61 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_220: {
            's_176: {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_176;
                }
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                _fb = 0x41 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    > if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_220;
                }
            }
            _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                & 0xff as uint32_t;
            _fb = 0x7a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_210: {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    <= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_210;
                }
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                _fb = 0x5a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    > if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_220;
                }
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0xdf as ::core::ffi::c_int) as uint8_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
        }
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_237: {
            if _fa == _fb {
                break 's_237;
            }
            (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t)
                as uint8_t as int8_t as int32_t as uint32_t;
            (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t)
                as uint8_t as int8_t as int32_t as uint32_t;
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_sub((*__gamepkg_tls_g_edx));
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        if _fa != 0 as uint32_t {
            continue;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE480() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_128: {
        if _fa == _fb {
            break 's_128;
        }
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa == _fb {
            break 's_128;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x1fe498 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_001FEDC0();
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffd as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xfffffffd as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE4C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_142: {
        if _fa == _fb {
            break 's_142;
        }
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa == _fb {
            break 's_142;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x41c530 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1fe4dc as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001FEA30();
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffe as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xfffffffe as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE500() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_142: {
        if _fa == _fb {
            break 's_142;
        }
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa == _fb {
            break 's_142;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x41c530 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1fe51c as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001FEA30();
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffe as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_236: {
        if _fa == _fb {
            break 's_236;
        }
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa == _fb {
            break 's_236;
        }
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fe53b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001FEDC0();
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffffd as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE550() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x40800 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41c560 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_eax) = 0x41c558 as uint32_t;
    let mut _pv_3: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c55c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_5: uint32_t = 0x1fe576 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001FEBF0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_167: {
        if _fa == _fb {
            break 's_167;
        }
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41c584 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE590() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    enum C2Rust_Block_12 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_42,
        S_48,
        S_50,
        S_52,
        S_58,
        S_64,
        S_66,
        S_68,
        S_78,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_155,
        S_157,
        S_159,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_225,
        S_227,
        S_229,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_252,
        S_254,
        S_264,
        S_266,
        S_276,
        S_278,
        S_284,
        S_286,
        S_288,
        S_294,
        S_296,
        S_302,
        S_304,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_352,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_377,
        S_383,
        S_389,
        S_391,
        S_401,
        S_403,
        S_413,
        S_415,
        S_421,
        S_423,
        S_429,
        S_431,
        S_437,
        S_439,
    }
    let mut c2rust_current_block_12: C2Rust_Block_12;
    c2rust_current_block_12 = C2Rust_Block_12::S_0;
    loop {
        match c2rust_current_block_12 {
            C2Rust_Block_12::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_2;
            }
            C2Rust_Block_12::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_12 = C2Rust_Block_12::S_4;
            }
            C2Rust_Block_12::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_6;
            }
            C2Rust_Block_12::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_8;
            }
            C2Rust_Block_12::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_18;
            }
            C2Rust_Block_12::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_12 = C2Rust_Block_12::S_24;
            }
            C2Rust_Block_12::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_26;
            }
            C2Rust_Block_12::S_26 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_32;
            }
            C2Rust_Block_12::S_32 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_12 = C2Rust_Block_12::S_34;
            }
            C2Rust_Block_12::S_34 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_36;
            }
            C2Rust_Block_12::S_36 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_42;
            }
            C2Rust_Block_12::S_42 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_48;
            }
            C2Rust_Block_12::S_48 => {
                _pv_0 = ebp;
                c2rust_current_block_12 = C2Rust_Block_12::S_50;
            }
            C2Rust_Block_12::S_50 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_52;
            }
            C2Rust_Block_12::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_58;
            }
            C2Rust_Block_12::S_58 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_64;
            }
            C2Rust_Block_12::S_64 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_12 = C2Rust_Block_12::S_66;
            }
            C2Rust_Block_12::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_68;
            }
            C2Rust_Block_12::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_78;
            }
            C2Rust_Block_12::S_78 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_12 = C2Rust_Block_12::S_80;
            }
            C2Rust_Block_12::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_82;
            }
            C2Rust_Block_12::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_88;
            }
            C2Rust_Block_12::S_88 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_90;
            }
            C2Rust_Block_12::S_90 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_92;
            }
            C2Rust_Block_12::S_92 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_94;
            }
            C2Rust_Block_12::S_94 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_96;
            }
            C2Rust_Block_12::S_96 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_102;
            }
            C2Rust_Block_12::S_102 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_104;
            }
            C2Rust_Block_12::S_104 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_106;
            }
            C2Rust_Block_12::S_106 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_12 = C2Rust_Block_12::S_108;
            }
            C2Rust_Block_12::S_108 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_110;
            }
            C2Rust_Block_12::S_110 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_112;
            }
            C2Rust_Block_12::S_112 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_12 = C2Rust_Block_12::S_114;
            }
            C2Rust_Block_12::S_114 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_116;
            }
            C2Rust_Block_12::S_116 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_118;
            }
            C2Rust_Block_12::S_118 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_120;
            }
            C2Rust_Block_12::S_120 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_122;
            }
            C2Rust_Block_12::S_122 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_12 = C2Rust_Block_12::S_124;
            }
            C2Rust_Block_12::S_124 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_126;
            }
            C2Rust_Block_12::S_126 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_128;
            }
            C2Rust_Block_12::S_128 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_130;
            }
            C2Rust_Block_12::S_130 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_132;
            }
            C2Rust_Block_12::S_132 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_134;
            }
            C2Rust_Block_12::S_134 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_136;
            }
            C2Rust_Block_12::S_136 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_138;
            }
            C2Rust_Block_12::S_138 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_140;
            }
            C2Rust_Block_12::S_140 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_142;
            }
            C2Rust_Block_12::S_142 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_144;
            }
            C2Rust_Block_12::S_144 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_146;
            }
            C2Rust_Block_12::S_146 => {
                if _fa < _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_225;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_155;
                }
            }
            C2Rust_Block_12::S_155 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_edx));
                c2rust_current_block_12 = C2Rust_Block_12::S_157;
            }
            C2Rust_Block_12::S_157 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-1 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_159;
            }
            C2Rust_Block_12::S_159 => {
                (*__gamepkg_tls_g_eax) = !(*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_161;
            }
            C2Rust_Block_12::S_161 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(ebp)
                    .wrapping_add(0x17 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_163;
            }
            C2Rust_Block_12::S_163 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_165;
            }
            C2Rust_Block_12::S_165 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_167;
            }
            C2Rust_Block_12::S_167 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_169;
            }
            C2Rust_Block_12::S_169 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_171;
            }
            C2Rust_Block_12::S_171 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_173;
            }
            C2Rust_Block_12::S_173 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_175;
            }
            C2Rust_Block_12::S_175 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_177;
            }
            C2Rust_Block_12::S_177 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_179;
            }
            C2Rust_Block_12::S_179 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_12 = C2Rust_Block_12::S_181;
            }
            C2Rust_Block_12::S_181 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_183;
            }
            C2Rust_Block_12::S_183 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_185;
            }
            C2Rust_Block_12::S_185 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_187;
            }
            C2Rust_Block_12::S_187 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_189;
            }
            C2Rust_Block_12::S_189 => {
                if _fa > _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_225;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_198;
                }
            }
            C2Rust_Block_12::S_198 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_200;
            }
            C2Rust_Block_12::S_200 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_202;
            }
            C2Rust_Block_12::S_202 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_204;
            }
            C2Rust_Block_12::S_204 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_206;
            }
            C2Rust_Block_12::S_206 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_208;
            }
            C2Rust_Block_12::S_208 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_210;
            }
            C2Rust_Block_12::S_210 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_212;
            }
            C2Rust_Block_12::S_212 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_214;
            }
            C2Rust_Block_12::S_214 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_216;
            }
            C2Rust_Block_12::S_216 => {
                if _fa >= _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_310;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_225;
                }
            }
            C2Rust_Block_12::S_225 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_227;
            }
            C2Rust_Block_12::S_227 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_229;
            }
            C2Rust_Block_12::S_229 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_12 = C2Rust_Block_12::S_231;
            }
            C2Rust_Block_12::S_231 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_233;
            }
            C2Rust_Block_12::S_233 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_235;
            }
            C2Rust_Block_12::S_235 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_237;
            }
            C2Rust_Block_12::S_237 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_239;
            }
            C2Rust_Block_12::S_239 => {
                if _fa != _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_102;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_252;
                }
            }
            C2Rust_Block_12::S_252 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_254;
            }
            C2Rust_Block_12::S_254 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_264;
            }
            C2Rust_Block_12::S_264 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_266;
            }
            C2Rust_Block_12::S_266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_276;
            }
            C2Rust_Block_12::S_276 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_278;
            }
            C2Rust_Block_12::S_278 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_284;
            }
            C2Rust_Block_12::S_284 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_286;
            }
            C2Rust_Block_12::S_286 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_288;
            }
            C2Rust_Block_12::S_288 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_294;
            }
            C2Rust_Block_12::S_294 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_296;
            }
            C2Rust_Block_12::S_296 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_302;
            }
            C2Rust_Block_12::S_302 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_304;
            }
            C2Rust_Block_12::S_304 => return,
            C2Rust_Block_12::S_310 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_312;
            }
            C2Rust_Block_12::S_312 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_314;
            }
            C2Rust_Block_12::S_314 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_316;
            }
            C2Rust_Block_12::S_316 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_318;
            }
            C2Rust_Block_12::S_318 => {
                if _fa == _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_252;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_327;
                }
            }
            C2Rust_Block_12::S_327 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_329;
            }
            C2Rust_Block_12::S_329 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_331;
            }
            C2Rust_Block_12::S_331 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_333;
            }
            C2Rust_Block_12::S_333 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_335;
            }
            C2Rust_Block_12::S_335 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_337;
            }
            C2Rust_Block_12::S_337 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_339;
            }
            C2Rust_Block_12::S_339 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_341;
            }
            C2Rust_Block_12::S_341 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_343;
            }
            C2Rust_Block_12::S_343 => {
                if _fa == _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_358;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_352;
                }
            }
            C2Rust_Block_12::S_352 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_358;
            }
            C2Rust_Block_12::S_358 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_360;
            }
            C2Rust_Block_12::S_360 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_362;
            }
            C2Rust_Block_12::S_362 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_364;
            }
            C2Rust_Block_12::S_364 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_366;
            }
            C2Rust_Block_12::S_366 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_368;
            }
            C2Rust_Block_12::S_368 => {
                if _fa == _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_383;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_377;
                }
            }
            C2Rust_Block_12::S_377 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_383;
            }
            C2Rust_Block_12::S_383 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_389;
            }
            C2Rust_Block_12::S_389 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_391;
            }
            C2Rust_Block_12::S_391 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_401;
            }
            C2Rust_Block_12::S_401 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_403;
            }
            C2Rust_Block_12::S_403 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_413;
            }
            C2Rust_Block_12::S_413 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_415;
            }
            C2Rust_Block_12::S_415 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_421;
            }
            C2Rust_Block_12::S_421 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_423;
            }
            C2Rust_Block_12::S_423 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_429;
            }
            C2Rust_Block_12::S_429 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_431;
            }
            C2Rust_Block_12::S_431 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_437;
            }
            C2Rust_Block_12::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_439;
            }
            C2Rust_Block_12::S_439 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE620() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    loop {
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_63: {
            if _fa != _fb {
                break 's_63;
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_129: {
                if _fa == _fb {
                    break 's_129;
                }
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_160: {
                if _fa == _fb {
                    break 's_160;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            continue;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE660() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0x30800 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1fe66f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FED80();
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_177: {
        if _fa == _fb {
            break 's_177;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_add((*__gamepkg_tls_g_eax));
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_esi),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE6B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_144: {
        if _fa == _fb {
            break 's_144;
        }
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            let mut _pv_2: uint32_t = 0x1fe6d5 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            sub_001FEDC0();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_144;
            }
        }
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_239: {
        if _fa != _fb {
            break 's_239;
        }
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x41c560 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x1fe6ff as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_001FEA30();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE710() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ebp = (*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t);
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = ebp & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_396: {
        's_227: {
            if _fa == _fb {
                break 's_227;
            }
            loop {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                let mut _pv_6: uint32_t = 0x1fe733 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                sub_001FE590();
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_396;
                }
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = ebp & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_227;
                }
            }
        }
        let mut _pv_7: uint32_t = 0x1fe747 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        sub_001FE660();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_396;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_8: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        let mut _pv_11: uint32_t = 0x1fe75a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_11,
        );
        sub_001FE590();
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE770() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_378: {
        if _fa == _fb {
            break 's_378;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_121: {
                if _fa <= _fb {
                    break 's_121;
                }
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_esi));
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_121;
                }
                let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                let mut _pv_3: uint32_t = 0x1fe7a1 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                sub_001FE620();
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_378;
                }
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_284: {
                    if _fa == _fb {
                        break 's_284;
                    }
                    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    let mut _pv_5: uint32_t = 0x1fe7da as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    sub_001FEDC0();
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    break 's_378;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa != _fb {
                continue;
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE7E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x41c558 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_118: {
        if _fa == _fb {
            break 's_118;
        }
        loop {
            _fb = 0xffffffec as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add(0xffffffec as uint32_t);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv,
            );
            let mut _pv_0: uint32_t = 0x1fe7f9 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            sub_001FE6B0();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41c558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0x41c558 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_118;
            }
        }
    }
    let mut _pv_1: uint32_t = 0x41c560 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1fe812 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FEB70();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c584 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE820() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    enum C2Rust_Block_20 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_61,
        S_63,
        S_65,
        S_75,
        S_77,
        S_79,
        S_89,
        S_91,
        S_93,
        S_99,
        S_105,
        S_107,
        S_109,
        S_111,
        S_113,
        S_115,
        S_117,
        S_119,
        S_121,
        S_123,
        S_125,
        S_138,
        S_140,
        S_146,
        S_148,
        S_154,
        S_162,
        S_168,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_188,
        S_190,
        S_192,
        S_202,
        S_204,
        S_206,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_230,
        S_232,
        S_234,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_271,
        S_277,
        S_283,
        S_285,
        S_287,
        S_297,
        S_299,
        S_301,
        S_307,
        S_309,
        S_311,
        S_313,
        S_319,
        S_321,
        S_323,
        S_329,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_429,
        S_431,
        S_441,
        S_443,
        S_453,
        S_455,
        S_461,
        S_467,
        S_469,
        S_475,
        S_477,
        S_487,
        S_489,
        S_491,
        S_501,
        S_503,
        S_505,
        S_511,
        S_517,
        S_519,
        S_521,
        S_523,
        S_525,
        S_531,
        S_533,
        S_543,
        S_545,
        S_555,
        S_557,
        S_563,
        S_565,
        S_567,
        S_573,
        S_575,
        S_581,
        S_583,
    }
    let mut c2rust_current_block_20: C2Rust_Block_20;
    c2rust_current_block_20 = C2Rust_Block_20::S_0;
    loop {
        match c2rust_current_block_20 {
            C2Rust_Block_20::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_2;
            }
            C2Rust_Block_20::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_20 = C2Rust_Block_20::S_4;
            }
            C2Rust_Block_20::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_20 = C2Rust_Block_20::S_6;
            }
            C2Rust_Block_20::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_8;
            }
            C2Rust_Block_20::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_18;
            }
            C2Rust_Block_20::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_20 = C2Rust_Block_20::S_28;
            }
            C2Rust_Block_20::S_28 => {
                _pv = (*__gamepkg_tls_g_edi);
                c2rust_current_block_20 = C2Rust_Block_20::S_30;
            }
            C2Rust_Block_20::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_32;
            }
            C2Rust_Block_20::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_38;
            }
            C2Rust_Block_20::S_38 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_40;
            }
            C2Rust_Block_20::S_40 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_42;
            }
            C2Rust_Block_20::S_42 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_44;
            }
            C2Rust_Block_20::S_44 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_46;
            }
            C2Rust_Block_20::S_46 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_48;
            }
            C2Rust_Block_20::S_48 => {
                if _fa != _fb {
                    c2rust_current_block_20 = C2Rust_Block_20::S_162;
                } else {
                    c2rust_current_block_20 = C2Rust_Block_20::S_61;
                }
            }
            C2Rust_Block_20::S_61 => {
                _pv_0 = 0x30800 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_63;
            }
            C2Rust_Block_20::S_63 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_65;
            }
            C2Rust_Block_20::S_65 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_75;
            }
            C2Rust_Block_20::S_75 => {
                _pv_1 = 0x41c560 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_77;
            }
            C2Rust_Block_20::S_77 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_79;
            }
            C2Rust_Block_20::S_79 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_89;
            }
            C2Rust_Block_20::S_89 => {
                _pv_2 = 0x1fe838 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_91;
            }
            C2Rust_Block_20::S_91 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_93;
            }
            C2Rust_Block_20::S_93 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_99;
            }
            C2Rust_Block_20::S_99 => {
                sub_001FE900();
                c2rust_current_block_20 = C2Rust_Block_20::S_105;
            }
            C2Rust_Block_20::S_105 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_20 = C2Rust_Block_20::S_107;
            }
            C2Rust_Block_20::S_107 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_109;
            }
            C2Rust_Block_20::S_109 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_111;
            }
            C2Rust_Block_20::S_111 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_113;
            }
            C2Rust_Block_20::S_113 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_115;
            }
            C2Rust_Block_20::S_115 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_117;
            }
            C2Rust_Block_20::S_117 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_119;
            }
            C2Rust_Block_20::S_119 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_121;
            }
            C2Rust_Block_20::S_121 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_123;
            }
            C2Rust_Block_20::S_123 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_125;
            }
            C2Rust_Block_20::S_125 => {
                if _fa != _fb {
                    c2rust_current_block_20 = C2Rust_Block_20::S_154;
                } else {
                    c2rust_current_block_20 = C2Rust_Block_20::S_138;
                }
            }
            C2Rust_Block_20::S_138 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_140;
            }
            C2Rust_Block_20::S_140 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_146;
            }
            C2Rust_Block_20::S_146 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_148;
            }
            C2Rust_Block_20::S_148 => return,
            C2Rust_Block_20::S_154 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_168;
            }
            C2Rust_Block_20::S_162 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_168;
            }
            C2Rust_Block_20::S_168 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_170;
            }
            C2Rust_Block_20::S_170 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_172;
            }
            C2Rust_Block_20::S_172 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_174;
            }
            C2Rust_Block_20::S_174 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_176;
            }
            C2Rust_Block_20::S_176 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_178;
            }
            C2Rust_Block_20::S_178 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_180;
            }
            C2Rust_Block_20::S_180 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_182;
            }
            C2Rust_Block_20::S_182 => {
                (*__gamepkg_tls_g_ecx) = ((*__gamepkg_tls_g_ecx) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_188;
            }
            C2Rust_Block_20::S_188 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_20 = C2Rust_Block_20::S_190;
            }
            C2Rust_Block_20::S_190 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_192;
            }
            C2Rust_Block_20::S_192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_202;
            }
            C2Rust_Block_20::S_202 => {
                _pv_4 = ebp;
                c2rust_current_block_20 = C2Rust_Block_20::S_204;
            }
            C2Rust_Block_20::S_204 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_206;
            }
            C2Rust_Block_20::S_206 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_212;
            }
            C2Rust_Block_20::S_212 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_214;
            }
            C2Rust_Block_20::S_214 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_216;
            }
            C2Rust_Block_20::S_216 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_218;
            }
            C2Rust_Block_20::S_218 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_220;
            }
            C2Rust_Block_20::S_220 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_222;
            }
            C2Rust_Block_20::S_222 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax))
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_224;
            }
            C2Rust_Block_20::S_224 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_230;
            }
            C2Rust_Block_20::S_230 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_20 = C2Rust_Block_20::S_232;
            }
            C2Rust_Block_20::S_232 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_234;
            }
            C2Rust_Block_20::S_234 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_240;
            }
            C2Rust_Block_20::S_240 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_242;
            }
            C2Rust_Block_20::S_242 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_244;
            }
            C2Rust_Block_20::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_246;
            }
            C2Rust_Block_20::S_246 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_248;
            }
            C2Rust_Block_20::S_248 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_250;
            }
            C2Rust_Block_20::S_250 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_252;
            }
            C2Rust_Block_20::S_252 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_254;
            }
            C2Rust_Block_20::S_254 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x41c558 as uint32_t,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_256;
            }
            C2Rust_Block_20::S_256 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_258;
            }
            C2Rust_Block_20::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_260;
            }
            C2Rust_Block_20::S_260 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_262;
            }
            C2Rust_Block_20::S_262 => {
                if _fa <= _fb {
                    c2rust_current_block_20 = C2Rust_Block_20::S_429;
                } else {
                    c2rust_current_block_20 = C2Rust_Block_20::S_271;
                }
            }
            C2Rust_Block_20::S_271 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_20 = C2Rust_Block_20::S_277;
            }
            C2Rust_Block_20::S_277 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_283;
            }
            C2Rust_Block_20::S_283 => {
                _pv_6 = 0x30800 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_285;
            }
            C2Rust_Block_20::S_285 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_287;
            }
            C2Rust_Block_20::S_287 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_297;
            }
            C2Rust_Block_20::S_297 => {
                _pv_7 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_20 = C2Rust_Block_20::S_299;
            }
            C2Rust_Block_20::S_299 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_301;
            }
            C2Rust_Block_20::S_301 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_307;
            }
            C2Rust_Block_20::S_307 => {
                ebp = ebp.wrapping_sub(1);
                c2rust_current_block_20 = C2Rust_Block_20::S_309;
            }
            C2Rust_Block_20::S_309 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_311;
            }
            C2Rust_Block_20::S_311 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_313;
            }
            C2Rust_Block_20::S_313 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_319;
            }
            C2Rust_Block_20::S_319 => {
                _pv_8 = 0x1fe8af as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_321;
            }
            C2Rust_Block_20::S_321 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_323;
            }
            C2Rust_Block_20::S_323 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_329;
            }
            C2Rust_Block_20::S_329 => {
                sub_001FED80();
                c2rust_current_block_20 = C2Rust_Block_20::S_335;
            }
            C2Rust_Block_20::S_335 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_337;
            }
            C2Rust_Block_20::S_337 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_339;
            }
            C2Rust_Block_20::S_339 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_341;
            }
            C2Rust_Block_20::S_341 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_343;
            }
            C2Rust_Block_20::S_343 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_345;
            }
            C2Rust_Block_20::S_345 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_347;
            }
            C2Rust_Block_20::S_347 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_349;
            }
            C2Rust_Block_20::S_349 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_351;
            }
            C2Rust_Block_20::S_351 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_353;
            }
            C2Rust_Block_20::S_353 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_355;
            }
            C2Rust_Block_20::S_355 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_357;
            }
            C2Rust_Block_20::S_357 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_359;
            }
            C2Rust_Block_20::S_359 => {
                if _fa == _fb {
                    c2rust_current_block_20 = C2Rust_Block_20::S_487;
                } else {
                    c2rust_current_block_20 = C2Rust_Block_20::S_368;
                }
            }
            C2Rust_Block_20::S_368 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_370;
            }
            C2Rust_Block_20::S_370 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_372;
            }
            C2Rust_Block_20::S_372 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_374;
            }
            C2Rust_Block_20::S_374 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_376;
            }
            C2Rust_Block_20::S_376 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_20 = C2Rust_Block_20::S_378;
            }
            C2Rust_Block_20::S_378 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_380;
            }
            C2Rust_Block_20::S_380 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_382;
            }
            C2Rust_Block_20::S_382 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_384;
            }
            C2Rust_Block_20::S_384 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_386;
            }
            C2Rust_Block_20::S_386 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_388;
            }
            C2Rust_Block_20::S_388 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_390;
            }
            C2Rust_Block_20::S_390 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_392;
            }
            C2Rust_Block_20::S_392 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_394;
            }
            C2Rust_Block_20::S_394 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_396;
            }
            C2Rust_Block_20::S_396 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_398;
            }
            C2Rust_Block_20::S_398 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_400;
            }
            C2Rust_Block_20::S_400 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_402;
            }
            C2Rust_Block_20::S_402 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_404;
            }
            C2Rust_Block_20::S_404 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_406;
            }
            C2Rust_Block_20::S_406 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_408;
            }
            C2Rust_Block_20::S_408 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_410;
            }
            C2Rust_Block_20::S_410 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_412;
            }
            C2Rust_Block_20::S_412 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_414;
            }
            C2Rust_Block_20::S_414 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_416;
            }
            C2Rust_Block_20::S_416 => {
                if _fa > _fb {
                    c2rust_current_block_20 = C2Rust_Block_20::S_277;
                } else {
                    c2rust_current_block_20 = C2Rust_Block_20::S_429;
                }
            }
            C2Rust_Block_20::S_429 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_431;
            }
            C2Rust_Block_20::S_431 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_441;
            }
            C2Rust_Block_20::S_441 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_443;
            }
            C2Rust_Block_20::S_443 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_453;
            }
            C2Rust_Block_20::S_453 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_455;
            }
            C2Rust_Block_20::S_455 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_461;
            }
            C2Rust_Block_20::S_461 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_20 = C2Rust_Block_20::S_467;
            }
            C2Rust_Block_20::S_467 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_469;
            }
            C2Rust_Block_20::S_469 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_475;
            }
            C2Rust_Block_20::S_475 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_477;
            }
            C2Rust_Block_20::S_477 => return,
            C2Rust_Block_20::S_487 => {
                _pv_9 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_20 = C2Rust_Block_20::S_489;
            }
            C2Rust_Block_20::S_489 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_491;
            }
            C2Rust_Block_20::S_491 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_501;
            }
            C2Rust_Block_20::S_501 => {
                _pv_10 = 0x1fe8f3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_503;
            }
            C2Rust_Block_20::S_503 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_505;
            }
            C2Rust_Block_20::S_505 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_511;
            }
            C2Rust_Block_20::S_511 => {
                sub_001FE6B0();
                c2rust_current_block_20 = C2Rust_Block_20::S_517;
            }
            C2Rust_Block_20::S_517 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_519;
            }
            C2Rust_Block_20::S_519 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_521;
            }
            C2Rust_Block_20::S_521 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_523;
            }
            C2Rust_Block_20::S_523 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_525;
            }
            C2Rust_Block_20::S_525 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_531;
            }
            C2Rust_Block_20::S_531 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_533;
            }
            C2Rust_Block_20::S_533 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_543;
            }
            C2Rust_Block_20::S_543 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_545;
            }
            C2Rust_Block_20::S_545 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_555;
            }
            C2Rust_Block_20::S_555 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_557;
            }
            C2Rust_Block_20::S_557 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_563;
            }
            C2Rust_Block_20::S_563 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_565;
            }
            C2Rust_Block_20::S_565 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_567;
            }
            C2Rust_Block_20::S_567 => {
                _fas = _fa as int32_t;
                c2rust_current_block_20 = C2Rust_Block_20::S_573;
            }
            C2Rust_Block_20::S_573 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_20 = C2Rust_Block_20::S_575;
            }
            C2Rust_Block_20::S_575 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_581;
            }
            C2Rust_Block_20::S_581 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_20 = C2Rust_Block_20::S_583;
            }
            C2Rust_Block_20::S_583 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FE900() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    let mut _i_0: uint32_t = 0;
    enum C2Rust_Block_11 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_74,
        S_76,
        S_78,
        S_84,
        S_90,
        S_92,
        S_94,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_131,
        S_133,
        S_135,
        S_137,
        S_139,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_183,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_202,
        S_204,
        S_206,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_241,
        S_243,
        S_245,
        S_247,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_389,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_455,
        S_457,
        S_459,
        S_465,
        S_471,
        S_473,
        S_475,
        S_485,
        S_487,
        S_489,
        S_495,
        S_501,
        S_503,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_517,
        S_519,
        S_521,
        S_523,
        S_525,
        S_527,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_547,
        S_549,
        S_552,
        S_553,
        S_554,
        S_555,
        S_562,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_580,
        S_582,
        S_587,
        S_590,
        S_591,
        S_592,
        S_593,
        S_600,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_624,
        S_626,
        S_628,
        S_630,
        S_632,
        S_634,
        S_636,
        S_638,
        S_640,
        S_642,
        S_644,
        S_646,
        S_648,
        S_650,
        S_652,
        S_662,
        S_664,
        S_674,
        S_676,
        S_686,
        S_688,
        S_698,
        S_700,
        S_710,
        S_712,
        S_718,
        S_720,
        S_726,
        S_728,
        S_730,
        S_732,
        S_734,
    }
    let mut c2rust_current_block_11: C2Rust_Block_11;
    c2rust_current_block_11 = C2Rust_Block_11::S_0;
    loop {
        match c2rust_current_block_11 {
            C2Rust_Block_11::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_2;
            }
            C2Rust_Block_11::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_11 = C2Rust_Block_11::S_4;
            }
            C2Rust_Block_11::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_11 = C2Rust_Block_11::S_6;
            }
            C2Rust_Block_11::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_8;
            }
            C2Rust_Block_11::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_18;
            }
            C2Rust_Block_11::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_11 = C2Rust_Block_11::S_28;
            }
            C2Rust_Block_11::S_28 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_11 = C2Rust_Block_11::S_30;
            }
            C2Rust_Block_11::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_32;
            }
            C2Rust_Block_11::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_42;
            }
            C2Rust_Block_11::S_42 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_11 = C2Rust_Block_11::S_44;
            }
            C2Rust_Block_11::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_46;
            }
            C2Rust_Block_11::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_56;
            }
            C2Rust_Block_11::S_56 => {
                _pv_1 = ebp;
                c2rust_current_block_11 = C2Rust_Block_11::S_58;
            }
            C2Rust_Block_11::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_60;
            }
            C2Rust_Block_11::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_66;
            }
            C2Rust_Block_11::S_66 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_68;
            }
            C2Rust_Block_11::S_68 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_74;
            }
            C2Rust_Block_11::S_74 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_11 = C2Rust_Block_11::S_76;
            }
            C2Rust_Block_11::S_76 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_78;
            }
            C2Rust_Block_11::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_84;
            }
            C2Rust_Block_11::S_84 => {
                (*__gamepkg_tls_g_esi) = ebp.wrapping_add(0x10 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_90;
            }
            C2Rust_Block_11::S_90 => {
                _pv_3 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_11 = C2Rust_Block_11::S_92;
            }
            C2Rust_Block_11::S_92 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_94;
            }
            C2Rust_Block_11::S_94 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_100;
            }
            C2Rust_Block_11::S_100 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_102;
            }
            C2Rust_Block_11::S_102 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_104;
            }
            C2Rust_Block_11::S_104 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_106;
            }
            C2Rust_Block_11::S_106 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_108;
            }
            C2Rust_Block_11::S_108 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_110;
            }
            C2Rust_Block_11::S_110 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_112;
            }
            C2Rust_Block_11::S_112 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_114;
            }
            C2Rust_Block_11::S_114 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_116;
            }
            C2Rust_Block_11::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_118;
            }
            C2Rust_Block_11::S_118 => {
                if _fa == _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_433;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_131;
                }
            }
            C2Rust_Block_11::S_131 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_133;
            }
            C2Rust_Block_11::S_133 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_135;
            }
            C2Rust_Block_11::S_135 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_137;
            }
            C2Rust_Block_11::S_137 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_139;
            }
            C2Rust_Block_11::S_139 => {
                if _fa != _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_662;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_148;
                }
            }
            C2Rust_Block_11::S_148 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_150;
            }
            C2Rust_Block_11::S_150 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_152;
            }
            C2Rust_Block_11::S_152 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_154;
            }
            C2Rust_Block_11::S_154 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_156;
            }
            C2Rust_Block_11::S_156 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_158;
            }
            C2Rust_Block_11::S_158 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_160;
            }
            C2Rust_Block_11::S_160 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_162;
            }
            C2Rust_Block_11::S_162 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_164;
            }
            C2Rust_Block_11::S_164 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_166;
            }
            C2Rust_Block_11::S_166 => {
                if _fa <= _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_395;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_183;
                }
            }
            C2Rust_Block_11::S_183 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add((*__gamepkg_tls_g_edi))
                                .wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_185;
            }
            C2Rust_Block_11::S_185 => {
                _fa = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_187;
            }
            C2Rust_Block_11::S_187 => {
                _fb = 0xff as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_189;
            }
            C2Rust_Block_11::S_189 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_191;
            }
            C2Rust_Block_11::S_191 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_193;
            }
            C2Rust_Block_11::S_193 => {
                if _fa == _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_726;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_202;
                }
            }
            C2Rust_Block_11::S_202 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_204;
            }
            C2Rust_Block_11::S_204 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_206;
            }
            C2Rust_Block_11::S_206 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_212;
            }
            C2Rust_Block_11::S_212 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_214;
            }
            C2Rust_Block_11::S_214 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_216;
            }
            C2Rust_Block_11::S_216 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_218;
            }
            C2Rust_Block_11::S_218 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_220;
            }
            C2Rust_Block_11::S_220 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_222;
            }
            C2Rust_Block_11::S_222 => {
                if _fa <= _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_362;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_231;
                }
            }
            C2Rust_Block_11::S_231 => {
                (*__gamepkg_tls_g_edx) = 0x80 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_233;
            }
            C2Rust_Block_11::S_233 => {
                (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_edx) as int32_t
                    >> (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_235;
            }
            C2Rust_Block_11::S_235 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_237;
            }
            C2Rust_Block_11::S_237 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_239;
            }
            C2Rust_Block_11::S_239 => {
                _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int
                    & ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_241;
            }
            C2Rust_Block_11::S_241 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_243;
            }
            C2Rust_Block_11::S_243 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_245;
            }
            C2Rust_Block_11::S_245 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_247;
            }
            C2Rust_Block_11::S_247 => {
                if _fa == _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_299;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_256;
                }
            }
            C2Rust_Block_11::S_256 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_258;
            }
            C2Rust_Block_11::S_258 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_260;
            }
            C2Rust_Block_11::S_260 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_262;
            }
            C2Rust_Block_11::S_262 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_264;
            }
            C2Rust_Block_11::S_264 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_266;
            }
            C2Rust_Block_11::S_266 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_268;
            }
            C2Rust_Block_11::S_268 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_270;
            }
            C2Rust_Block_11::S_270 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_272;
            }
            C2Rust_Block_11::S_272 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_274;
            }
            C2Rust_Block_11::S_274 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_276;
            }
            C2Rust_Block_11::S_276 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_278;
            }
            C2Rust_Block_11::S_278 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_280;
            }
            C2Rust_Block_11::S_280 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_282;
            }
            C2Rust_Block_11::S_282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_284;
            }
            C2Rust_Block_11::S_284 => {
                if _fa < _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_212;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_362;
                }
            }
            C2Rust_Block_11::S_299 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_301;
            }
            C2Rust_Block_11::S_301 => {
                _fa = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_303;
            }
            C2Rust_Block_11::S_303 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_305;
            }
            C2Rust_Block_11::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add((*__gamepkg_tls_g_edi))
                            .wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_307;
            }
            C2Rust_Block_11::S_307 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_309;
            }
            C2Rust_Block_11::S_309 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_311;
            }
            C2Rust_Block_11::S_311 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(8 as uint32_t));
                c2rust_current_block_11 = C2Rust_Block_11::S_313;
            }
            C2Rust_Block_11::S_313 => {
                (*__gamepkg_tls_g_ecx) = ((*__gamepkg_tls_g_ecx) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_315;
            }
            C2Rust_Block_11::S_315 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_edi));
                c2rust_current_block_11 = C2Rust_Block_11::S_317;
            }
            C2Rust_Block_11::S_317 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_319;
            }
            C2Rust_Block_11::S_319 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_321;
            }
            C2Rust_Block_11::S_321 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_323;
            }
            C2Rust_Block_11::S_323 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_325;
            }
            C2Rust_Block_11::S_325 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ebx))
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_327;
            }
            C2Rust_Block_11::S_327 => {
                (*__gamepkg_tls_g_edx) = !(*__gamepkg_tls_g_edx);
                c2rust_current_block_11 = C2Rust_Block_11::S_329;
            }
            C2Rust_Block_11::S_329 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_edx);
                c2rust_current_block_11 = C2Rust_Block_11::S_331;
            }
            C2Rust_Block_11::S_331 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_333;
            }
            C2Rust_Block_11::S_333 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_335;
            }
            C2Rust_Block_11::S_335 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_337;
            }
            C2Rust_Block_11::S_337 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_339;
            }
            C2Rust_Block_11::S_339 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_11 = C2Rust_Block_11::S_341;
            }
            C2Rust_Block_11::S_341 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_343;
            }
            C2Rust_Block_11::S_343 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_345;
            }
            C2Rust_Block_11::S_345 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_347;
            }
            C2Rust_Block_11::S_347 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_349;
            }
            C2Rust_Block_11::S_349 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_351;
            }
            C2Rust_Block_11::S_351 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_353;
            }
            C2Rust_Block_11::S_353 => {
                if _fa != _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_389;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_362;
                }
            }
            C2Rust_Block_11::S_362 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_364;
            }
            C2Rust_Block_11::S_364 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_366;
            }
            C2Rust_Block_11::S_366 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_368;
            }
            C2Rust_Block_11::S_368 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_370;
            }
            C2Rust_Block_11::S_370 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_372;
            }
            C2Rust_Block_11::S_372 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_374;
            }
            C2Rust_Block_11::S_374 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_376;
            }
            C2Rust_Block_11::S_376 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_378;
            }
            C2Rust_Block_11::S_378 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_380;
            }
            C2Rust_Block_11::S_380 => {
                if _fa < _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_183;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_389;
                }
            }
            C2Rust_Block_11::S_389 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_395;
            }
            C2Rust_Block_11::S_395 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_397;
            }
            C2Rust_Block_11::S_397 => {
                (*__gamepkg_tls_g_esi) = ebp.wrapping_add(0x10 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_399;
            }
            C2Rust_Block_11::S_399 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_401;
            }
            C2Rust_Block_11::S_401 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_403;
            }
            C2Rust_Block_11::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_405;
            }
            C2Rust_Block_11::S_405 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_407;
            }
            C2Rust_Block_11::S_407 => {
                if _fa != _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_131;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_416;
                }
            }
            C2Rust_Block_11::S_416 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_418;
            }
            C2Rust_Block_11::S_418 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_420;
            }
            C2Rust_Block_11::S_420 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_422;
            }
            C2Rust_Block_11::S_422 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_424;
            }
            C2Rust_Block_11::S_424 => {
                if _fa != _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_662;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_433;
                }
            }
            C2Rust_Block_11::S_433 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_435;
            }
            C2Rust_Block_11::S_435 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_437;
            }
            C2Rust_Block_11::S_437 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_439;
            }
            C2Rust_Block_11::S_439 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_441;
            }
            C2Rust_Block_11::S_441 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_443;
            }
            C2Rust_Block_11::S_443 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_445;
            }
            C2Rust_Block_11::S_445 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edi));
                c2rust_current_block_11 = C2Rust_Block_11::S_447;
            }
            C2Rust_Block_11::S_447 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_449;
            }
            C2Rust_Block_11::S_449 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_455;
            }
            C2Rust_Block_11::S_455 => {
                _pv_4 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_11 = C2Rust_Block_11::S_457;
            }
            C2Rust_Block_11::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_459;
            }
            C2Rust_Block_11::S_459 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_465;
            }
            C2Rust_Block_11::S_465 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ebx))
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_471;
            }
            C2Rust_Block_11::S_471 => {
                _pv_5 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_11 = C2Rust_Block_11::S_473;
            }
            C2Rust_Block_11::S_473 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_475;
            }
            C2Rust_Block_11::S_475 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_485;
            }
            C2Rust_Block_11::S_485 => {
                _pv_6 = 0x1fe9d3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_487;
            }
            C2Rust_Block_11::S_487 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_489;
            }
            C2Rust_Block_11::S_489 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_495;
            }
            C2Rust_Block_11::S_495 => {
                sub_001FED80();
                c2rust_current_block_11 = C2Rust_Block_11::S_501;
            }
            C2Rust_Block_11::S_501 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_11 = C2Rust_Block_11::S_503;
            }
            C2Rust_Block_11::S_503 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_505;
            }
            C2Rust_Block_11::S_505 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_507;
            }
            C2Rust_Block_11::S_507 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_509;
            }
            C2Rust_Block_11::S_509 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_511;
            }
            C2Rust_Block_11::S_511 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_513;
            }
            C2Rust_Block_11::S_513 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_515;
            }
            C2Rust_Block_11::S_515 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_517;
            }
            C2Rust_Block_11::S_517 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_519;
            }
            C2Rust_Block_11::S_519 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_521;
            }
            C2Rust_Block_11::S_521 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_523;
            }
            C2Rust_Block_11::S_523 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_525;
            }
            C2Rust_Block_11::S_525 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_527;
            }
            C2Rust_Block_11::S_527 => {
                if _fa == _fb {
                    c2rust_current_block_11 = C2Rust_Block_11::S_662;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_536;
                }
            }
            C2Rust_Block_11::S_536 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_11 = C2Rust_Block_11::S_538;
            }
            C2Rust_Block_11::S_538 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_11 = C2Rust_Block_11::S_540;
            }
            C2Rust_Block_11::S_540 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_542;
            }
            C2Rust_Block_11::S_542 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_544;
            }
            C2Rust_Block_11::S_544 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_547;
            }
            C2Rust_Block_11::S_547 => {
                _i = 0;
                c2rust_current_block_11 = C2Rust_Block_11::S_549;
            }
            C2Rust_Block_11::S_549 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_11 = C2Rust_Block_11::S_552;
            }
            C2Rust_Block_11::S_552 => {
                _i = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_553;
            }
            C2Rust_Block_11::S_553 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_11 = C2Rust_Block_11::S_554;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_562;
                }
            }
            C2Rust_Block_11::S_554 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_555;
            }
            C2Rust_Block_11::S_555 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_553;
            }
            C2Rust_Block_11::S_562 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_11 = C2Rust_Block_11::S_566;
            }
            C2Rust_Block_11::S_566 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_568;
            }
            C2Rust_Block_11::S_568 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_11 = C2Rust_Block_11::S_570;
            }
            C2Rust_Block_11::S_570 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_572;
            }
            C2Rust_Block_11::S_572 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_574;
            }
            C2Rust_Block_11::S_574 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_576;
            }
            C2Rust_Block_11::S_576 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_11 = C2Rust_Block_11::S_580;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_587;
                }
            }
            C2Rust_Block_11::S_580 => {
                memset(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_void,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax) as uint8_t as ::core::ffi::c_int,
                    (*__gamepkg_tls_g_ecx) as size_t,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_582;
            }
            C2Rust_Block_11::S_582 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_11 = C2Rust_Block_11::S_606;
            }
            C2Rust_Block_11::S_587 => {
                _i_0 = 0;
                c2rust_current_block_11 = C2Rust_Block_11::S_590;
            }
            C2Rust_Block_11::S_590 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_591;
            }
            C2Rust_Block_11::S_591 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_11 = C2Rust_Block_11::S_592;
                } else {
                    c2rust_current_block_11 = C2Rust_Block_11::S_600;
                }
            }
            C2Rust_Block_11::S_592 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_0) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_593;
            }
            C2Rust_Block_11::S_593 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_591;
            }
            C2Rust_Block_11::S_600 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_11 = C2Rust_Block_11::S_606;
            }
            C2Rust_Block_11::S_606 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_608;
            }
            C2Rust_Block_11::S_608 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_610;
            }
            C2Rust_Block_11::S_610 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_612;
            }
            C2Rust_Block_11::S_612 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_614;
            }
            C2Rust_Block_11::S_614 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_616;
            }
            C2Rust_Block_11::S_616 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_618;
            }
            C2Rust_Block_11::S_618 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_620;
            }
            C2Rust_Block_11::S_620 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_622;
            }
            C2Rust_Block_11::S_622 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x80 as uint8_t,
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_624;
            }
            C2Rust_Block_11::S_624 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_626;
            }
            C2Rust_Block_11::S_626 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_628;
            }
            C2Rust_Block_11::S_628 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_630;
            }
            C2Rust_Block_11::S_630 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(ebp);
                c2rust_current_block_11 = C2Rust_Block_11::S_632;
            }
            C2Rust_Block_11::S_632 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_634;
            }
            C2Rust_Block_11::S_634 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_636;
            }
            C2Rust_Block_11::S_636 => {
                ebp = ebp.wrapping_sub(1);
                c2rust_current_block_11 = C2Rust_Block_11::S_638;
            }
            C2Rust_Block_11::S_638 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_640;
            }
            C2Rust_Block_11::S_640 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_642;
            }
            C2Rust_Block_11::S_642 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_644;
            }
            C2Rust_Block_11::S_644 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_eax))
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_646;
            }
            C2Rust_Block_11::S_646 => {
                ebp = !ebp;
                c2rust_current_block_11 = C2Rust_Block_11::S_648;
            }
            C2Rust_Block_11::S_648 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & ebp;
                c2rust_current_block_11 = C2Rust_Block_11::S_650;
            }
            C2Rust_Block_11::S_650 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_652;
            }
            C2Rust_Block_11::S_652 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_662;
            }
            C2Rust_Block_11::S_662 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_664;
            }
            C2Rust_Block_11::S_664 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_674;
            }
            C2Rust_Block_11::S_674 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_676;
            }
            C2Rust_Block_11::S_676 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_686;
            }
            C2Rust_Block_11::S_686 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_688;
            }
            C2Rust_Block_11::S_688 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_698;
            }
            C2Rust_Block_11::S_698 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_700;
            }
            C2Rust_Block_11::S_700 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_710;
            }
            C2Rust_Block_11::S_710 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_712;
            }
            C2Rust_Block_11::S_712 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_718;
            }
            C2Rust_Block_11::S_718 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_11 = C2Rust_Block_11::S_720;
            }
            C2Rust_Block_11::S_720 => return,
            C2Rust_Block_11::S_726 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_728;
            }
            C2Rust_Block_11::S_728 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_730;
            }
            C2Rust_Block_11::S_730 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub(8 as uint32_t),
                );
                c2rust_current_block_11 = C2Rust_Block_11::S_732;
            }
            C2Rust_Block_11::S_732 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_734;
            }
            C2Rust_Block_11::S_734 => {
                _fas = _fa as int32_t;
                c2rust_current_block_11 = C2Rust_Block_11::S_362;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEA30() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    enum C2Rust_Block_5 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_60,
        S_62,
        S_64,
        S_70,
        S_76,
        S_78,
        S_80,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_105,
        S_111,
        S_113,
        S_115,
        S_117,
        S_119,
        S_121,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_184,
        S_186,
        S_196,
        S_198,
        S_208,
        S_210,
        S_220,
        S_222,
        S_228,
        S_230,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_253,
        S_255,
        S_257,
        S_261,
        S_263,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_442,
        S_444,
        S_446,
        S_456,
        S_458,
        S_460,
        S_466,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_486,
        S_488,
        S_498,
        S_500,
        S_510,
        S_512,
        S_522,
        S_524,
        S_530,
        S_532,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_552,
        S_554,
        S_564,
        S_566,
        S_576,
        S_578,
        S_588,
        S_590,
        S_596,
        S_598,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_622,
        S_624,
        S_634,
        S_636,
        S_646,
        S_648,
        S_658,
        S_660,
        S_666,
        S_668,
    }
    let mut c2rust_current_block_5: C2Rust_Block_5;
    c2rust_current_block_5 = C2Rust_Block_5::S_0;
    loop {
        match c2rust_current_block_5 {
            C2Rust_Block_5::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_2;
            }
            C2Rust_Block_5::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_5 = C2Rust_Block_5::S_4;
            }
            C2Rust_Block_5::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_6;
            }
            C2Rust_Block_5::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_8;
            }
            C2Rust_Block_5::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_18;
            }
            C2Rust_Block_5::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_5 = C2Rust_Block_5::S_28;
            }
            C2Rust_Block_5::S_28 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_5 = C2Rust_Block_5::S_30;
            }
            C2Rust_Block_5::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_32;
            }
            C2Rust_Block_5::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_42;
            }
            C2Rust_Block_5::S_42 => {
                _pv_0 = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_44;
            }
            C2Rust_Block_5::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_46;
            }
            C2Rust_Block_5::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_52;
            }
            C2Rust_Block_5::S_52 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_54;
            }
            C2Rust_Block_5::S_54 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_60;
            }
            C2Rust_Block_5::S_60 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_62;
            }
            C2Rust_Block_5::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_64;
            }
            C2Rust_Block_5::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_70;
            }
            C2Rust_Block_5::S_70 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_76;
            }
            C2Rust_Block_5::S_76 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_78;
            }
            C2Rust_Block_5::S_78 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_80;
            }
            C2Rust_Block_5::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_86;
            }
            C2Rust_Block_5::S_86 => {
                (*__gamepkg_tls_g_edi) = ebp.wrapping_add(0x10 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_88;
            }
            C2Rust_Block_5::S_88 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_90;
            }
            C2Rust_Block_5::S_90 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_92;
            }
            C2Rust_Block_5::S_92 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_94;
            }
            C2Rust_Block_5::S_94 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_96;
            }
            C2Rust_Block_5::S_96 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_622;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_105;
                }
            }
            C2Rust_Block_5::S_105 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_111;
            }
            C2Rust_Block_5::S_111 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add((*__gamepkg_tls_g_esi))
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_113;
            }
            C2Rust_Block_5::S_113 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_115;
            }
            C2Rust_Block_5::S_115 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_117;
            }
            C2Rust_Block_5::S_117 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_119;
            }
            C2Rust_Block_5::S_119 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_121;
            }
            C2Rust_Block_5::S_121 => {
                if _fa < _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_161;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_130;
                }
            }
            C2Rust_Block_5::S_130 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_132;
            }
            C2Rust_Block_5::S_132 => {
                (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_edx) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_134;
            }
            C2Rust_Block_5::S_134 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_136;
            }
            C2Rust_Block_5::S_136 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_138;
            }
            C2Rust_Block_5::S_138 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_5 = C2Rust_Block_5::S_140;
            }
            C2Rust_Block_5::S_140 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_142;
            }
            C2Rust_Block_5::S_142 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_144;
            }
            C2Rust_Block_5::S_144 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_146;
            }
            C2Rust_Block_5::S_146 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_148;
            }
            C2Rust_Block_5::S_148 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_150;
            }
            C2Rust_Block_5::S_150 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_152;
            }
            C2Rust_Block_5::S_152 => {
                if _fa <= _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_236;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_161;
                }
            }
            C2Rust_Block_5::S_161 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_163;
            }
            C2Rust_Block_5::S_163 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_165;
            }
            C2Rust_Block_5::S_165 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_167;
            }
            C2Rust_Block_5::S_167 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_169;
            }
            C2Rust_Block_5::S_169 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_171;
            }
            C2Rust_Block_5::S_171 => {
                if _fa != _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_111;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_184;
                }
            }
            C2Rust_Block_5::S_184 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_186;
            }
            C2Rust_Block_5::S_186 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_196;
            }
            C2Rust_Block_5::S_196 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_198;
            }
            C2Rust_Block_5::S_198 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_208;
            }
            C2Rust_Block_5::S_208 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_210;
            }
            C2Rust_Block_5::S_210 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_220;
            }
            C2Rust_Block_5::S_220 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_222;
            }
            C2Rust_Block_5::S_222 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_228;
            }
            C2Rust_Block_5::S_228 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_230;
            }
            C2Rust_Block_5::S_230 => return,
            C2Rust_Block_5::S_236 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_238;
            }
            C2Rust_Block_5::S_238 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_240;
            }
            C2Rust_Block_5::S_240 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_5 = C2Rust_Block_5::S_242;
            }
            C2Rust_Block_5::S_242 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_244;
            }
            C2Rust_Block_5::S_244 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_246;
            }
            C2Rust_Block_5::S_246 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_248;
            }
            C2Rust_Block_5::S_248 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_250;
            }
            C2Rust_Block_5::S_250 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_253;
            }
            C2Rust_Block_5::S_253 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_255;
            }
            C2Rust_Block_5::S_255 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_257;
            }
            C2Rust_Block_5::S_257 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_261;
            }
            C2Rust_Block_5::S_261 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_263;
            }
            C2Rust_Block_5::S_263 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    >> 3 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_265;
            }
            C2Rust_Block_5::S_265 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_267;
            }
            C2Rust_Block_5::S_267 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_269;
            }
            C2Rust_Block_5::S_269 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx)
                    .wrapping_mul(8 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_271;
            }
            C2Rust_Block_5::S_271 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_273;
            }
            C2Rust_Block_5::S_273 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_275;
            }
            C2Rust_Block_5::S_275 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_277;
            }
            C2Rust_Block_5::S_277 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_279;
            }
            C2Rust_Block_5::S_279 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_281;
            }
            C2Rust_Block_5::S_281 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_5 = C2Rust_Block_5::S_283;
            }
            C2Rust_Block_5::S_283 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_285;
            }
            C2Rust_Block_5::S_285 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_287;
            }
            C2Rust_Block_5::S_287 => {
                (*__gamepkg_tls_g_eax) = 0x80 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_289;
            }
            C2Rust_Block_5::S_289 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_291;
            }
            C2Rust_Block_5::S_291 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_293;
            }
            C2Rust_Block_5::S_293 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_295;
            }
            C2Rust_Block_5::S_295 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add((*__gamepkg_tls_g_edx))
                                .wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_297;
            }
            C2Rust_Block_5::S_297 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | !(((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int) as uint8_t as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_299;
            }
            C2Rust_Block_5::S_299 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int
                        & ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_301;
            }
            C2Rust_Block_5::S_301 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_303;
            }
            C2Rust_Block_5::S_303 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_305;
            }
            C2Rust_Block_5::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add((*__gamepkg_tls_g_edx))
                            .wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_307;
            }
            C2Rust_Block_5::S_307 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_309;
            }
            C2Rust_Block_5::S_309 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_311;
            }
            C2Rust_Block_5::S_311 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_313;
            }
            C2Rust_Block_5::S_313 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_315;
            }
            C2Rust_Block_5::S_315 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_317;
            }
            C2Rust_Block_5::S_317 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_319;
            }
            C2Rust_Block_5::S_319 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_321;
            }
            C2Rust_Block_5::S_321 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_323;
            }
            C2Rust_Block_5::S_323 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_325;
            }
            C2Rust_Block_5::S_325 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_327;
            }
            C2Rust_Block_5::S_327 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_329;
            }
            C2Rust_Block_5::S_329 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_604;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_338;
                }
            }
            C2Rust_Block_5::S_338 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_340;
            }
            C2Rust_Block_5::S_340 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_342;
            }
            C2Rust_Block_5::S_342 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_344;
            }
            C2Rust_Block_5::S_344 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_346;
            }
            C2Rust_Block_5::S_346 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_604;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_355;
                }
            }
            C2Rust_Block_5::S_355 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_357;
            }
            C2Rust_Block_5::S_357 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_359;
            }
            C2Rust_Block_5::S_359 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_361;
            }
            C2Rust_Block_5::S_361 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_363;
            }
            C2Rust_Block_5::S_363 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_365;
            }
            C2Rust_Block_5::S_365 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_367;
            }
            C2Rust_Block_5::S_367 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_369;
            }
            C2Rust_Block_5::S_369 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_371;
            }
            C2Rust_Block_5::S_371 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_373;
            }
            C2Rust_Block_5::S_373 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_375;
            }
            C2Rust_Block_5::S_375 => {
                if _fa <= _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_442;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_384;
                }
            }
            C2Rust_Block_5::S_384 => {
                ebp = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add((*__gamepkg_tls_g_esi))
                            .wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_386;
            }
            C2Rust_Block_5::S_386 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_388;
            }
            C2Rust_Block_5::S_388 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_390;
            }
            C2Rust_Block_5::S_390 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(ebp);
                c2rust_current_block_5 = C2Rust_Block_5::S_392;
            }
            C2Rust_Block_5::S_392 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_394;
            }
            C2Rust_Block_5::S_394 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_396;
            }
            C2Rust_Block_5::S_396 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_398;
            }
            C2Rust_Block_5::S_398 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_400;
            }
            C2Rust_Block_5::S_400 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_402;
            }
            C2Rust_Block_5::S_402 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_404;
            }
            C2Rust_Block_5::S_404 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_406;
            }
            C2Rust_Block_5::S_406 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_408;
            }
            C2Rust_Block_5::S_408 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_410;
            }
            C2Rust_Block_5::S_410 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_412;
            }
            C2Rust_Block_5::S_412 => {
                if _fa < _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_384;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_421;
                }
            }
            C2Rust_Block_5::S_421 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_423;
            }
            C2Rust_Block_5::S_423 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_425;
            }
            C2Rust_Block_5::S_425 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_427;
            }
            C2Rust_Block_5::S_427 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_429;
            }
            C2Rust_Block_5::S_429 => {
                if _fa != _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_538;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_442;
                }
            }
            C2Rust_Block_5::S_442 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_444;
            }
            C2Rust_Block_5::S_444 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_446;
            }
            C2Rust_Block_5::S_446 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_456;
            }
            C2Rust_Block_5::S_456 => {
                _pv_4 = 0x1feadb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_458;
            }
            C2Rust_Block_5::S_458 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_460;
            }
            C2Rust_Block_5::S_460 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_466;
            }
            C2Rust_Block_5::S_466 => {
                sub_001FEDC0();
                c2rust_current_block_5 = C2Rust_Block_5::S_472;
            }
            C2Rust_Block_5::S_472 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_474;
            }
            C2Rust_Block_5::S_474 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_476;
            }
            C2Rust_Block_5::S_476 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_478;
            }
            C2Rust_Block_5::S_478 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_480;
            }
            C2Rust_Block_5::S_480 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_486;
            }
            C2Rust_Block_5::S_486 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_488;
            }
            C2Rust_Block_5::S_488 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_498;
            }
            C2Rust_Block_5::S_498 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_500;
            }
            C2Rust_Block_5::S_500 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_510;
            }
            C2Rust_Block_5::S_510 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_512;
            }
            C2Rust_Block_5::S_512 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_522;
            }
            C2Rust_Block_5::S_522 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_524;
            }
            C2Rust_Block_5::S_524 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_530;
            }
            C2Rust_Block_5::S_530 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_532;
            }
            C2Rust_Block_5::S_532 => return,
            C2Rust_Block_5::S_538 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_540;
            }
            C2Rust_Block_5::S_540 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_542;
            }
            C2Rust_Block_5::S_542 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_544;
            }
            C2Rust_Block_5::S_544 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_546;
            }
            C2Rust_Block_5::S_546 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_552;
            }
            C2Rust_Block_5::S_552 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_554;
            }
            C2Rust_Block_5::S_554 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_564;
            }
            C2Rust_Block_5::S_564 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_566;
            }
            C2Rust_Block_5::S_566 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_576;
            }
            C2Rust_Block_5::S_576 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_578;
            }
            C2Rust_Block_5::S_578 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_588;
            }
            C2Rust_Block_5::S_588 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_590;
            }
            C2Rust_Block_5::S_590 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_596;
            }
            C2Rust_Block_5::S_596 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_598;
            }
            C2Rust_Block_5::S_598 => return,
            C2Rust_Block_5::S_604 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_606;
            }
            C2Rust_Block_5::S_606 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_608;
            }
            C2Rust_Block_5::S_608 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_610;
            }
            C2Rust_Block_5::S_610 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_612;
            }
            C2Rust_Block_5::S_612 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_622;
            }
            C2Rust_Block_5::S_622 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_624;
            }
            C2Rust_Block_5::S_624 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_634;
            }
            C2Rust_Block_5::S_634 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_636;
            }
            C2Rust_Block_5::S_636 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_646;
            }
            C2Rust_Block_5::S_646 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_648;
            }
            C2Rust_Block_5::S_648 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_658;
            }
            C2Rust_Block_5::S_658 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_660;
            }
            C2Rust_Block_5::S_660 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_666;
            }
            C2Rust_Block_5::S_666 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_668;
            }
            C2Rust_Block_5::S_668 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEB10() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_134: {
        if _fa == _fb {
            break 's_134;
        }
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edx),
            );
            let mut _pv_1: uint32_t = 0x1feb35 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_001FEDC0();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_134;
            }
        }
    }
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_315: {
        if _fa != _fb {
            break 's_315;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41c5b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_269: {
            if _fa == _fb {
                break 's_269;
            }
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_269;
            }
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 0x1feb59 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_001FEA30();
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1feb63 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_001FEDC0();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEB70() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_0: uint32_t = 0x1feb8b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FEB10();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEB90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x41c588 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    's_108: {
        if _fa == _fb {
            break 's_108;
        }
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax)
                .wrapping_add(-28 as ::core::ffi::c_int as uint32_t);
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            let mut _pv_0: uint32_t = 0x1febb8 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            sub_001FEB10();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41c588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0x41c588 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_108;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _pv_1: uint32_t = 0x1febe0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001FEB10();
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEBF0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    enum C2Rust_Block_8 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_71,
        S_77,
        S_79,
        S_81,
        S_83,
        S_85,
        S_87,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_119,
        S_121,
        S_123,
        S_133,
        S_135,
        S_137,
        S_147,
        S_149,
        S_151,
        S_157,
        S_169,
        S_175,
        S_177,
        S_179,
        S_189,
        S_191,
        S_193,
        S_203,
        S_205,
        S_207,
        S_213,
        S_219,
        S_221,
        S_223,
        S_225,
        S_227,
        S_229,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_252,
        S_254,
        S_264,
        S_266,
        S_272,
        S_274,
        S_280,
        S_288,
        S_294,
        S_296,
        S_298,
        S_300,
        S_306,
        S_308,
        S_310,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_332,
        S_334,
        S_336,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_401,
        S_403,
        S_409,
        S_411,
        S_413,
        S_423,
        S_425,
        S_427,
        S_437,
        S_439,
        S_441,
        S_447,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_473,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_517,
        S_519,
        S_522,
        S_523,
        S_524,
        S_525,
        S_532,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_550,
        S_552,
        S_557,
        S_560,
        S_561,
        S_562,
        S_563,
        S_570,
        S_576,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_609,
        S_611,
        S_621,
        S_623,
        S_629,
        S_631,
        S_637,
        S_639,
        S_645,
        S_651,
        S_653,
        S_659,
        S_661,
        S_667,
        S_673,
        S_675,
        S_677,
        S_683,
        S_693,
        S_695,
        S_705,
        S_707,
        S_717,
        S_719,
        S_725,
        S_727,
        S_729,
        S_735,
        S_737,
        S_743,
        S_745,
    }
    let mut c2rust_current_block_8: C2Rust_Block_8;
    c2rust_current_block_8 = C2Rust_Block_8::S_0;
    loop {
        match c2rust_current_block_8 {
            C2Rust_Block_8::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_2;
            }
            C2Rust_Block_8::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_8 = C2Rust_Block_8::S_4;
            }
            C2Rust_Block_8::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_8 = C2Rust_Block_8::S_6;
            }
            C2Rust_Block_8::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_8;
            }
            C2Rust_Block_8::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_18;
            }
            C2Rust_Block_8::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_8 = C2Rust_Block_8::S_28;
            }
            C2Rust_Block_8::S_28 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_8 = C2Rust_Block_8::S_30;
            }
            C2Rust_Block_8::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_32;
            }
            C2Rust_Block_8::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_42;
            }
            C2Rust_Block_8::S_42 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_8 = C2Rust_Block_8::S_44;
            }
            C2Rust_Block_8::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_46;
            }
            C2Rust_Block_8::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_52;
            }
            C2Rust_Block_8::S_52 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_54;
            }
            C2Rust_Block_8::S_54 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_56;
            }
            C2Rust_Block_8::S_56 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_58;
            }
            C2Rust_Block_8::S_58 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_60;
            }
            C2Rust_Block_8::S_60 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_62;
            }
            C2Rust_Block_8::S_62 => {
                if _fa != _fb {
                    c2rust_current_block_8 = C2Rust_Block_8::S_77;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_71;
                }
            }
            C2Rust_Block_8::S_71 => {
                (*__gamepkg_tls_g_edi) = 1 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_77;
            }
            C2Rust_Block_8::S_77 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_79;
            }
            C2Rust_Block_8::S_79 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_81;
            }
            C2Rust_Block_8::S_81 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_83;
            }
            C2Rust_Block_8::S_83 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_85;
            }
            C2Rust_Block_8::S_85 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_87;
            }
            C2Rust_Block_8::S_87 => {
                if _fa != _fb {
                    c2rust_current_block_8 = C2Rust_Block_8::S_288;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_96;
                }
            }
            C2Rust_Block_8::S_96 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c5b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_98;
            }
            C2Rust_Block_8::S_98 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_100;
            }
            C2Rust_Block_8::S_100 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_102;
            }
            C2Rust_Block_8::S_102 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_104;
            }
            C2Rust_Block_8::S_104 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_106;
            }
            C2Rust_Block_8::S_106 => {
                if _fa == _fb {
                    c2rust_current_block_8 = C2Rust_Block_8::S_169;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_119;
                }
            }
            C2Rust_Block_8::S_119 => {
                _pv_1 = 0x30800 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_121;
            }
            C2Rust_Block_8::S_121 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_123;
            }
            C2Rust_Block_8::S_123 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_133;
            }
            C2Rust_Block_8::S_133 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_8 = C2Rust_Block_8::S_135;
            }
            C2Rust_Block_8::S_135 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_137;
            }
            C2Rust_Block_8::S_137 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_147;
            }
            C2Rust_Block_8::S_147 => {
                _pv_3 = 0x1fec1b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_149;
            }
            C2Rust_Block_8::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_151;
            }
            C2Rust_Block_8::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_157;
            }
            C2Rust_Block_8::S_157 => {
                sub_001FE900();
                c2rust_current_block_8 = C2Rust_Block_8::S_219;
            }
            C2Rust_Block_8::S_169 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_175;
            }
            C2Rust_Block_8::S_175 => {
                _pv_4 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_8 = C2Rust_Block_8::S_177;
            }
            C2Rust_Block_8::S_177 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_179;
            }
            C2Rust_Block_8::S_179 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_189;
            }
            C2Rust_Block_8::S_189 => {
                _pv_5 = 0x24 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_191;
            }
            C2Rust_Block_8::S_191 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_193;
            }
            C2Rust_Block_8::S_193 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_203;
            }
            C2Rust_Block_8::S_203 => {
                _pv_6 = 0x1fec29 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_205;
            }
            C2Rust_Block_8::S_205 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_207;
            }
            C2Rust_Block_8::S_207 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_213;
            }
            C2Rust_Block_8::S_213 => {
                sub_001FED80();
                c2rust_current_block_8 = C2Rust_Block_8::S_219;
            }
            C2Rust_Block_8::S_219 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_8 = C2Rust_Block_8::S_221;
            }
            C2Rust_Block_8::S_221 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_223;
            }
            C2Rust_Block_8::S_223 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_225;
            }
            C2Rust_Block_8::S_225 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_227;
            }
            C2Rust_Block_8::S_227 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_229;
            }
            C2Rust_Block_8::S_229 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_231;
            }
            C2Rust_Block_8::S_231 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_233;
            }
            C2Rust_Block_8::S_233 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_235;
            }
            C2Rust_Block_8::S_235 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_237;
            }
            C2Rust_Block_8::S_237 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_239;
            }
            C2Rust_Block_8::S_239 => {
                if _fa != _fb {
                    c2rust_current_block_8 = C2Rust_Block_8::S_280;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_252;
                }
            }
            C2Rust_Block_8::S_252 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_254;
            }
            C2Rust_Block_8::S_254 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_264;
            }
            C2Rust_Block_8::S_264 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_266;
            }
            C2Rust_Block_8::S_266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_272;
            }
            C2Rust_Block_8::S_272 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_274;
            }
            C2Rust_Block_8::S_274 => return,
            C2Rust_Block_8::S_280 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    2 as uint32_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_294;
            }
            C2Rust_Block_8::S_288 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_294;
            }
            C2Rust_Block_8::S_294 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_296;
            }
            C2Rust_Block_8::S_296 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_edi))
                    .wrapping_add(-1 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_298;
            }
            C2Rust_Block_8::S_298 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_300;
            }
            C2Rust_Block_8::S_300 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(-1 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_306;
            }
            C2Rust_Block_8::S_306 => {
                _pv_7 = ebp;
                c2rust_current_block_8 = C2Rust_Block_8::S_308;
            }
            C2Rust_Block_8::S_308 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_310;
            }
            C2Rust_Block_8::S_310 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_316;
            }
            C2Rust_Block_8::S_316 => {
                (*__gamepkg_tls_g_edx) = !(*__gamepkg_tls_g_edx);
                c2rust_current_block_8 = C2Rust_Block_8::S_318;
            }
            C2Rust_Block_8::S_318 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_edx);
                c2rust_current_block_8 = C2Rust_Block_8::S_320;
            }
            C2Rust_Block_8::S_320 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_322;
            }
            C2Rust_Block_8::S_322 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_324;
            }
            C2Rust_Block_8::S_324 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_326;
            }
            C2Rust_Block_8::S_326 => {
                ebp = (*__gamepkg_tls_g_ecx).wrapping_add(7 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_332;
            }
            C2Rust_Block_8::S_332 => {
                _pv_8 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_8 = C2Rust_Block_8::S_334;
            }
            C2Rust_Block_8::S_334 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_336;
            }
            C2Rust_Block_8::S_336 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_342;
            }
            C2Rust_Block_8::S_342 => {
                ebp = ebp >> 3 as ::core::ffi::c_int;
                c2rust_current_block_8 = C2Rust_Block_8::S_344;
            }
            C2Rust_Block_8::S_344 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_346;
            }
            C2Rust_Block_8::S_346 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_348;
            }
            C2Rust_Block_8::S_348 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_350;
            }
            C2Rust_Block_8::S_350 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_352;
            }
            C2Rust_Block_8::S_352 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_354;
            }
            C2Rust_Block_8::S_354 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_356;
            }
            C2Rust_Block_8::S_356 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_358;
            }
            C2Rust_Block_8::S_358 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_360;
            }
            C2Rust_Block_8::S_360 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_362;
            }
            C2Rust_Block_8::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_364;
            }
            C2Rust_Block_8::S_364 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_366;
            }
            C2Rust_Block_8::S_366 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_368;
            }
            C2Rust_Block_8::S_368 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_370;
            }
            C2Rust_Block_8::S_370 => {
                if _fa <= _fb {
                    c2rust_current_block_8 = C2Rust_Block_8::S_595;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_379;
                }
            }
            C2Rust_Block_8::S_379 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    * (*__gamepkg_tls_g_ecx) as int32_t) as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_381;
            }
            C2Rust_Block_8::S_381 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_383;
            }
            C2Rust_Block_8::S_383 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_385;
            }
            C2Rust_Block_8::S_385 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(ebp);
                c2rust_current_block_8 = C2Rust_Block_8::S_387;
            }
            C2Rust_Block_8::S_387 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_389;
            }
            C2Rust_Block_8::S_389 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_391;
            }
            C2Rust_Block_8::S_391 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edi))
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_393;
            }
            C2Rust_Block_8::S_393 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_401;
            }
            C2Rust_Block_8::S_401 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_403;
            }
            C2Rust_Block_8::S_403 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_409;
            }
            C2Rust_Block_8::S_409 => {
                _pv_9 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_8 = C2Rust_Block_8::S_411;
            }
            C2Rust_Block_8::S_411 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_413;
            }
            C2Rust_Block_8::S_413 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_423;
            }
            C2Rust_Block_8::S_423 => {
                _pv_10 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_8 = C2Rust_Block_8::S_425;
            }
            C2Rust_Block_8::S_425 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_427;
            }
            C2Rust_Block_8::S_427 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_437;
            }
            C2Rust_Block_8::S_437 => {
                _pv_11 = 0x1fec9f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_439;
            }
            C2Rust_Block_8::S_439 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_441;
            }
            C2Rust_Block_8::S_441 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_447;
            }
            C2Rust_Block_8::S_447 => {
                sub_001FED80();
                c2rust_current_block_8 = C2Rust_Block_8::S_453;
            }
            C2Rust_Block_8::S_453 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_8 = C2Rust_Block_8::S_455;
            }
            C2Rust_Block_8::S_455 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_457;
            }
            C2Rust_Block_8::S_457 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_459;
            }
            C2Rust_Block_8::S_459 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_461;
            }
            C2Rust_Block_8::S_461 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_463;
            }
            C2Rust_Block_8::S_463 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_465;
            }
            C2Rust_Block_8::S_465 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_467;
            }
            C2Rust_Block_8::S_467 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_469;
            }
            C2Rust_Block_8::S_469 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_471;
            }
            C2Rust_Block_8::S_471 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_473;
            }
            C2Rust_Block_8::S_473 => {
                if _fa == _fb {
                    c2rust_current_block_8 = C2Rust_Block_8::S_667;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_482;
                }
            }
            C2Rust_Block_8::S_482 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_484;
            }
            C2Rust_Block_8::S_484 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_486;
            }
            C2Rust_Block_8::S_486 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_488;
            }
            C2Rust_Block_8::S_488 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_490;
            }
            C2Rust_Block_8::S_490 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_492;
            }
            C2Rust_Block_8::S_492 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_494;
            }
            C2Rust_Block_8::S_494 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_496;
            }
            C2Rust_Block_8::S_496 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_498;
            }
            C2Rust_Block_8::S_498 => {
                (*__gamepkg_tls_g_ecx) = ebp;
                c2rust_current_block_8 = C2Rust_Block_8::S_500;
            }
            C2Rust_Block_8::S_500 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_502;
            }
            C2Rust_Block_8::S_502 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_8 = C2Rust_Block_8::S_504;
            }
            C2Rust_Block_8::S_504 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_8 = C2Rust_Block_8::S_506;
            }
            C2Rust_Block_8::S_506 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_508;
            }
            C2Rust_Block_8::S_508 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_510;
            }
            C2Rust_Block_8::S_510 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_512;
            }
            C2Rust_Block_8::S_512 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_514;
            }
            C2Rust_Block_8::S_514 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_517;
            }
            C2Rust_Block_8::S_517 => {
                _i = 0;
                c2rust_current_block_8 = C2Rust_Block_8::S_519;
            }
            C2Rust_Block_8::S_519 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_8 = C2Rust_Block_8::S_522;
            }
            C2Rust_Block_8::S_522 => {
                _i = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_523;
            }
            C2Rust_Block_8::S_523 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_8 = C2Rust_Block_8::S_524;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_532;
                }
            }
            C2Rust_Block_8::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_525;
            }
            C2Rust_Block_8::S_525 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_8 = C2Rust_Block_8::S_523;
            }
            C2Rust_Block_8::S_532 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_8 = C2Rust_Block_8::S_536;
            }
            C2Rust_Block_8::S_536 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_538;
            }
            C2Rust_Block_8::S_538 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_8 = C2Rust_Block_8::S_540;
            }
            C2Rust_Block_8::S_540 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_542;
            }
            C2Rust_Block_8::S_542 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_544;
            }
            C2Rust_Block_8::S_544 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_546;
            }
            C2Rust_Block_8::S_546 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_8 = C2Rust_Block_8::S_550;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_557;
                }
            }
            C2Rust_Block_8::S_550 => {
                memset(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_void,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax) as uint8_t as ::core::ffi::c_int,
                    (*__gamepkg_tls_g_ecx) as size_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_552;
            }
            C2Rust_Block_8::S_552 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_8 = C2Rust_Block_8::S_576;
            }
            C2Rust_Block_8::S_557 => {
                _i_0 = 0;
                c2rust_current_block_8 = C2Rust_Block_8::S_560;
            }
            C2Rust_Block_8::S_560 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_561;
            }
            C2Rust_Block_8::S_561 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_8 = C2Rust_Block_8::S_562;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_570;
                }
            }
            C2Rust_Block_8::S_562 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_0) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_563;
            }
            C2Rust_Block_8::S_563 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_8 = C2Rust_Block_8::S_561;
            }
            C2Rust_Block_8::S_570 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_8 = C2Rust_Block_8::S_576;
            }
            C2Rust_Block_8::S_576 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_578;
            }
            C2Rust_Block_8::S_578 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub(1 as uint32_t),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_580;
            }
            C2Rust_Block_8::S_580 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_582;
            }
            C2Rust_Block_8::S_582 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_584;
            }
            C2Rust_Block_8::S_584 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_586;
            }
            C2Rust_Block_8::S_586 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_8 = C2Rust_Block_8::S_401;
                } else {
                    c2rust_current_block_8 = C2Rust_Block_8::S_595;
                }
            }
            C2Rust_Block_8::S_595 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_597;
            }
            C2Rust_Block_8::S_597 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_599;
            }
            C2Rust_Block_8::S_599 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_601;
            }
            C2Rust_Block_8::S_601 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x41c588 as uint32_t,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_603;
            }
            C2Rust_Block_8::S_603 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_609;
            }
            C2Rust_Block_8::S_609 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_611;
            }
            C2Rust_Block_8::S_611 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_621;
            }
            C2Rust_Block_8::S_621 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_623;
            }
            C2Rust_Block_8::S_623 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_629;
            }
            C2Rust_Block_8::S_629 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_631;
            }
            C2Rust_Block_8::S_631 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41c588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_637;
            }
            C2Rust_Block_8::S_637 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_639;
            }
            C2Rust_Block_8::S_639 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_645;
            }
            C2Rust_Block_8::S_645 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_8 = C2Rust_Block_8::S_651;
            }
            C2Rust_Block_8::S_651 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_653;
            }
            C2Rust_Block_8::S_653 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_659;
            }
            C2Rust_Block_8::S_659 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_661;
            }
            C2Rust_Block_8::S_661 => return,
            C2Rust_Block_8::S_667 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_8 = C2Rust_Block_8::S_673;
            }
            C2Rust_Block_8::S_673 => {
                _pv_12 = 0x1fed0c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_675;
            }
            C2Rust_Block_8::S_675 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_677;
            }
            C2Rust_Block_8::S_677 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_683;
            }
            C2Rust_Block_8::S_683 => {
                sub_001FEB10();
                c2rust_current_block_8 = C2Rust_Block_8::S_693;
            }
            C2Rust_Block_8::S_693 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_695;
            }
            C2Rust_Block_8::S_695 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_705;
            }
            C2Rust_Block_8::S_705 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_707;
            }
            C2Rust_Block_8::S_707 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_717;
            }
            C2Rust_Block_8::S_717 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_719;
            }
            C2Rust_Block_8::S_719 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_725;
            }
            C2Rust_Block_8::S_725 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_727;
            }
            C2Rust_Block_8::S_727 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_729;
            }
            C2Rust_Block_8::S_729 => {
                _fas = _fa as int32_t;
                c2rust_current_block_8 = C2Rust_Block_8::S_735;
            }
            C2Rust_Block_8::S_735 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_8 = C2Rust_Block_8::S_737;
            }
            C2Rust_Block_8::S_737 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_743;
            }
            C2Rust_Block_8::S_743 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_8 = C2Rust_Block_8::S_745;
            }
            C2Rust_Block_8::S_745 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FED20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x40800 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41c590 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_eax) = 0x41c588 as uint32_t;
    let mut _pv_3: uint32_t = 0x10 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x24 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c58c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    let mut _pv_5: uint32_t = 0x1fed50 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001FEBF0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_169: {
        if _fa != _fb {
            break 's_169;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41c5b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FED80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_26: {
        if !_fn.is_none() {
            break 's_26;
        }
        _fn = recomp_lookup(_va);
    }
    's_32: {
        if !_fn.is_none() {
            break 's_32;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_59: {
        's_38: {
            if _fn.is_some() {
                break 's_38;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_59;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FED90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = 0x1feda3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_156: {
        's_95: {
            if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
            {
                break 's_95;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_115: {
                if !_fn.is_none() {
                    break 's_115;
                }
                _fn = recomp_lookup(_va);
            }
            's_121: {
                if !_fn.is_none() {
                    break 's_121;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_127: {
                if _fn.is_some() {
                    break 's_127;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_156;
            }
            _fn.expect("non-null function pointer")();
            break 's_156;
        }
        recomp_icall_not_code_log(_va);
        (*__gamepkg_tls_g_esp) = _icall_esp;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    }
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_209: {
        if _fa <= _fb {
            break 's_209;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 3 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << 3 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEDC0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_26: {
        if !_fn.is_none() {
            break 's_26;
        }
        _fn = recomp_lookup(_va);
    }
    's_32: {
        if !_fn.is_none() {
            break 's_32;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_59: {
        's_38: {
            if _fn.is_some() {
                break 's_38;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_59;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEDD0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_26: {
        if !_fn.is_none() {
            break 's_26;
        }
        _fn = recomp_lookup(_va);
    }
    's_32: {
        if !_fn.is_none() {
            break 's_32;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_59: {
        's_38: {
            if _fn.is_some() {
                break 's_38;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_59;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEDE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fedea as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024419D();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEDF0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ((*__gamepkg_tls_g_esi) as int32_t
        * ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as int32_t) as uint32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1fee00 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024419D();
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_207: {
        if _fa == _fb {
            break 's_207;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx);
        let mut _i: uint32_t = 0;
        let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
            -(4 as ::core::ffi::c_int as int32_t)
        } else {
            4 as ::core::ffi::c_int as int32_t
        };
        _i = 0 as uint32_t;
        while _i < (*__gamepkg_tls_g_ecx) {
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi)
                        .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            _i = _i.wrapping_add(1);
        }
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        's_189: {
            's_170: {
                if (*__gamepkg_tls_g_df) != 0 {
                    break 's_170;
                }
                memset(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_void,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax) as uint8_t as ::core::ffi::c_int,
                    (*__gamepkg_tls_g_ecx) as size_t,
                );
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                break 's_189;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_0) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEE30() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_63: {
        if _fa == _fb {
            break 's_63;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x7593e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1fede0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x2440a5 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1e0dc0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1fedf0 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEE90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x7593d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_32: {
        if !_fn.is_none() {
            break 's_32;
        }
        _fn = recomp_lookup(_va);
    }
    's_38: {
        if !_fn.is_none() {
            break 's_38;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_65: {
        's_44: {
            if _fn.is_some() {
                break 's_44;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_65;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEEB0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_211: {
        if _fa != _fb {
            break 's_211;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0x30809 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41c5c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        let mut _pv_2: uint32_t = 0x1feece as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001FED90();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41c5c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41c5c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edi),
        );
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _i: uint32_t = 0;
        let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
            -(4 as ::core::ffi::c_int as int32_t)
        } else {
            4 as ::core::ffi::c_int as int32_t
        };
        _i = 0 as uint32_t;
        while _i < (*__gamepkg_tls_g_ecx) {
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi)
                        .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            _i = _i.wrapping_add(1);
        }
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        's_193: {
            's_174: {
                if (*__gamepkg_tls_g_df) != 0 {
                    break 's_174;
                }
                memset(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_void,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax) as uint8_t as ::core::ffi::c_int,
                    (*__gamepkg_tls_g_ecx) as size_t,
                );
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                break 's_193;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_0) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEF00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xb0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_315: {
        if _fa == _fb {
            break 's_315;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = ebp;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                .wrapping_add(-180 as ::core::ffi::c_int as uint32_t);
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _icall_target: uint32_t = ebp;
            let mut _pv_5: uint32_t = 0x1fef2a as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_237: {
                's_188: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_188;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_237;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_196: {
                    if !_fn.is_none() {
                        break 's_196;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_202: {
                    if !_fn.is_none() {
                        break 's_202;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_208: {
                    if _fn.is_some() {
                        break 's_208;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_237;
                }
                _fn.expect("non-null function pointer")();
            }
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
        }
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEF40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_51: {
        if _fa == _fb {
            break 's_51;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint32_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEF70() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xbc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEF90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xbc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_227: {
        if _fa >= _fb {
            break 's_227;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1fef40 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fefb7 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001FEF00();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1fef70 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edi),
        );
        let mut _pv_8: uint32_t = 0x1fefd3 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_001FEF00();
        _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FEFF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x74 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_88: {
        if _fa == _fb {
            break 's_88;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x74 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa >= _fb {
            break 's_88;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF020() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xcc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF050() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_213: {
        if _fa >= _fb {
            break 's_213;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x74 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x1feff0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        let mut _pv_3: uint32_t = 0x1ff087 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001FEF00();
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x1ff020 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 0x1ff097 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        sub_001FEF00();
        _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xcc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_287: {
        if _fa != _fb {
            break 's_287;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x74 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa < _fb {
            break 's_287;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF0C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x36ea4c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1ff0d0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001F8B10();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_151: {
        if _fa != _fb {
            break 's_151;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 0x400000 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x3f800000 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_403: {
        's_393: {
            if _fa == _fb {
                break 's_393;
            }
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            let mut _icall_target: uint32_t = (*__gamepkg_tls_g_ecx);
            let mut _pv_10: uint32_t = 0x1ff10b as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_354: {
                's_305: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_305;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_354;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_313: {
                    if !_fn.is_none() {
                        break 's_313;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_319: {
                    if !_fn.is_none() {
                        break 's_319;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_325: {
                    if _fn.is_some() {
                        break 's_325;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_354;
                }
                _fn.expect("non-null function pointer")();
            }
            _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x10 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            if _fa != _fb {
                break 's_403;
            }
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF120() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_59: {
        if _fa != _fb {
            break 's_59;
        }
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x36ea4c as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x1ff143 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001F8B10();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_297: {
            if _fa != _fb {
                break 's_297;
            }
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = 0x6f as uint32_t;
            (*__gamepkg_tls_g_eax) = 0xcdcdcdcd as ::core::ffi::c_uint as uint32_t;
            let mut _i: uint32_t = 0;
            let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            };
            _i = 0 as uint32_t;
            while _i < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                _i = _i.wrapping_add(1);
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
            (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x1ff170 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_001F8690();
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = (*__gamepkg_tls_g_eax);
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_91: {
        if !_fn.is_none() {
            break 's_91;
        }
        _fn = recomp_lookup(_va);
    }
    's_97: {
        if !_fn.is_none() {
            break 's_97;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_124: {
        's_103: {
            if _fn.is_some() {
                break 's_103;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_124;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF180() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff195 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0020BD20();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_212: {
        if _fa == _fb {
            break 's_212;
        }
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1ff1a2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_0020BDB0();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _dividend: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
            << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
        (*__gamepkg_tls_g_eax) = _dividend
            .wrapping_div(
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint64_t,
            ) as uint32_t;
        (*__gamepkg_tls_g_edx) = _dividend
            .wrapping_rem(
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint64_t,
            ) as uint32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _dividend_0: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
        << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
    (*__gamepkg_tls_g_eax) = _dividend_0
        .wrapping_div(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0xa4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint64_t,
        ) as uint32_t;
    (*__gamepkg_tls_g_edx) = _dividend_0
        .wrapping_rem(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0xa4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint64_t,
        ) as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF1C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    enum C2Rust_Block_40 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_24,
        S_26,
        S_28,
        S_38,
        S_40,
        S_42,
        S_48,
        S_54,
        S_56,
        S_58,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_82,
        S_84,
        S_86,
        S_96,
        S_98,
        S_100,
        S_106,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_147,
        S_149,
        S_151,
        S_161,
        S_163,
        S_165,
        S_171,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_195,
        S_201,
        S_203,
        S_205,
        S_207,
        S_210,
        S_212,
        S_214,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_239,
        S_241,
        S_245,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_259,
        S_261,
        S_263,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_316,
        S_318,
        S_328,
        S_330,
        S_340,
        S_342,
        S_348,
        S_350,
        S_356,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_396,
        S_400,
        S_404,
        S_406,
        S_408,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_459,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_529,
        S_531,
        S_541,
        S_543,
        S_553,
        S_555,
        S_561,
        S_563,
    }
    let mut c2rust_current_block_40: C2Rust_Block_40;
    c2rust_current_block_40 = C2Rust_Block_40::S_0;
    loop {
        match c2rust_current_block_40 {
            C2Rust_Block_40::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_2;
            }
            C2Rust_Block_40::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_4;
            }
            C2Rust_Block_40::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_14;
            }
            C2Rust_Block_40::S_14 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_24;
            }
            C2Rust_Block_40::S_24 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_40 = C2Rust_Block_40::S_26;
            }
            C2Rust_Block_40::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_28;
            }
            C2Rust_Block_40::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_38;
            }
            C2Rust_Block_40::S_38 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_40 = C2Rust_Block_40::S_40;
            }
            C2Rust_Block_40::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_42;
            }
            C2Rust_Block_40::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_48;
            }
            C2Rust_Block_40::S_48 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_54;
            }
            C2Rust_Block_40::S_54 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_40 = C2Rust_Block_40::S_56;
            }
            C2Rust_Block_40::S_56 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_58;
            }
            C2Rust_Block_40::S_58 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_64;
            }
            C2Rust_Block_40::S_64 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_66;
            }
            C2Rust_Block_40::S_66 => {
                _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_68;
            }
            C2Rust_Block_40::S_68 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_70;
            }
            C2Rust_Block_40::S_70 => {
                _cf = (((*__gamepkg_tls_g_edi) as uint64_t)
                    .wrapping_add(0x5c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_72;
            }
            C2Rust_Block_40::S_72 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_74;
            }
            C2Rust_Block_40::S_74 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_76;
            }
            C2Rust_Block_40::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_82;
            }
            C2Rust_Block_40::S_82 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_40 = C2Rust_Block_40::S_84;
            }
            C2Rust_Block_40::S_84 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_86;
            }
            C2Rust_Block_40::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_96;
            }
            C2Rust_Block_40::S_96 => {
                _pv_3 = 0x1ff1d6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_98;
            }
            C2Rust_Block_40::S_98 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_100;
            }
            C2Rust_Block_40::S_100 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_106;
            }
            C2Rust_Block_40::S_106 => {
                sub_0020BD20();
                c2rust_current_block_40 = C2Rust_Block_40::S_112;
            }
            C2Rust_Block_40::S_112 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_114;
            }
            C2Rust_Block_40::S_114 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_116;
            }
            C2Rust_Block_40::S_116 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(4 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_118;
            }
            C2Rust_Block_40::S_118 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_120;
            }
            C2Rust_Block_40::S_120 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_122;
            }
            C2Rust_Block_40::S_122 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_124;
            }
            C2Rust_Block_40::S_124 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_126;
            }
            C2Rust_Block_40::S_126 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_128;
            }
            C2Rust_Block_40::S_128 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_130;
            }
            C2Rust_Block_40::S_130 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_132;
            }
            C2Rust_Block_40::S_132 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_134;
            }
            C2Rust_Block_40::S_134 => {
                if _fa == _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_195;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_147;
                }
            }
            C2Rust_Block_40::S_147 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_40 = C2Rust_Block_40::S_149;
            }
            C2Rust_Block_40::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_151;
            }
            C2Rust_Block_40::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_161;
            }
            C2Rust_Block_40::S_161 => {
                _pv_5 = 0x1ff1e3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_163;
            }
            C2Rust_Block_40::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_165;
            }
            C2Rust_Block_40::S_165 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_171;
            }
            C2Rust_Block_40::S_171 => {
                sub_0020BDB0();
                c2rust_current_block_40 = C2Rust_Block_40::S_177;
            }
            C2Rust_Block_40::S_177 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_179;
            }
            C2Rust_Block_40::S_179 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_181;
            }
            C2Rust_Block_40::S_181 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(4 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_183;
            }
            C2Rust_Block_40::S_183 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_185;
            }
            C2Rust_Block_40::S_185 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_187;
            }
            C2Rust_Block_40::S_187 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_201;
            }
            C2Rust_Block_40::S_195 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_201;
            }
            C2Rust_Block_40::S_201 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_203;
            }
            C2Rust_Block_40::S_203 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_205;
            }
            C2Rust_Block_40::S_205 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_207;
            }
            C2Rust_Block_40::S_207 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_210;
            }
            C2Rust_Block_40::S_210 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_212;
            }
            C2Rust_Block_40::S_212 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_214;
            }
            C2Rust_Block_40::S_214 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_218;
            }
            C2Rust_Block_40::S_218 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_220;
            }
            C2Rust_Block_40::S_220 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_222;
            }
            C2Rust_Block_40::S_222 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_224;
            }
            C2Rust_Block_40::S_224 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_226;
            }
            C2Rust_Block_40::S_226 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_228;
            }
            C2Rust_Block_40::S_228 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_230;
            }
            C2Rust_Block_40::S_230 => {
                if _fa >= _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_356;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_239;
                }
            }
            C2Rust_Block_40::S_239 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(2 as uint32_t));
                c2rust_current_block_40 = C2Rust_Block_40::S_241;
            }
            C2Rust_Block_40::S_241 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_40 = C2Rust_Block_40::S_245;
            }
            C2Rust_Block_40::S_245 => {
                _cf = ((*__gamepkg_tls_g_edx)
                    >> 32 as ::core::ffi::c_int - 3 as ::core::ffi::c_int
                    & 1 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_249;
            }
            C2Rust_Block_40::S_249 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_251;
            }
            C2Rust_Block_40::S_251 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_253;
            }
            C2Rust_Block_40::S_253 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_255;
            }
            C2Rust_Block_40::S_255 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_257;
            }
            C2Rust_Block_40::S_257 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_259;
            }
            C2Rust_Block_40::S_259 => {
                _cf = ((*__gamepkg_tls_g_edi) < (*__gamepkg_tls_g_ecx))
                    as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_261;
            }
            C2Rust_Block_40::S_261 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_40 = C2Rust_Block_40::S_263;
            }
            C2Rust_Block_40::S_263 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_265;
            }
            C2Rust_Block_40::S_265 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_267;
            }
            C2Rust_Block_40::S_267 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_269;
            }
            C2Rust_Block_40::S_269 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_271;
            }
            C2Rust_Block_40::S_271 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_273;
            }
            C2Rust_Block_40::S_273 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_279;
            }
            C2Rust_Block_40::S_279 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_281;
            }
            C2Rust_Block_40::S_281 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add((*__gamepkg_tls_g_edx))
                            .wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_283;
            }
            C2Rust_Block_40::S_283 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_285;
            }
            C2Rust_Block_40::S_285 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_287;
            }
            C2Rust_Block_40::S_287 => {
                _cf = (((*__gamepkg_tls_g_edx) as uint64_t)
                    .wrapping_add(0x18 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_289;
            }
            C2Rust_Block_40::S_289 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_291;
            }
            C2Rust_Block_40::S_291 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_293;
            }
            C2Rust_Block_40::S_293 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_295;
            }
            C2Rust_Block_40::S_295 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
                c2rust_current_block_40 = C2Rust_Block_40::S_297;
            }
            C2Rust_Block_40::S_297 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_299;
            }
            C2Rust_Block_40::S_299 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_301;
            }
            C2Rust_Block_40::S_301 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_303;
            }
            C2Rust_Block_40::S_303 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_40 = C2Rust_Block_40::S_279;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_316;
                }
            }
            C2Rust_Block_40::S_316 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_318;
            }
            C2Rust_Block_40::S_318 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_328;
            }
            C2Rust_Block_40::S_328 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_330;
            }
            C2Rust_Block_40::S_330 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_340;
            }
            C2Rust_Block_40::S_340 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_342;
            }
            C2Rust_Block_40::S_342 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_348;
            }
            C2Rust_Block_40::S_348 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_350;
            }
            C2Rust_Block_40::S_350 => return,
            C2Rust_Block_40::S_356 => {
                if _fa <= _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_529;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_365;
                }
            }
            C2Rust_Block_40::S_365 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_367;
            }
            C2Rust_Block_40::S_367 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_369;
            }
            C2Rust_Block_40::S_369 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_371;
            }
            C2Rust_Block_40::S_371 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_373;
            }
            C2Rust_Block_40::S_373 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_375;
            }
            C2Rust_Block_40::S_375 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_377;
            }
            C2Rust_Block_40::S_377 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_379;
            }
            C2Rust_Block_40::S_379 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_381;
            }
            C2Rust_Block_40::S_381 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_383;
            }
            C2Rust_Block_40::S_383 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_385;
            }
            C2Rust_Block_40::S_385 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_40 = C2Rust_Block_40::S_387;
            }
            C2Rust_Block_40::S_387 => {
                if _fa >= _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_459;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_396;
                }
            }
            C2Rust_Block_40::S_396 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(2 as uint32_t));
                c2rust_current_block_40 = C2Rust_Block_40::S_400;
            }
            C2Rust_Block_40::S_400 => {
                _cf = ((*__gamepkg_tls_g_ecx)
                    >> 32 as ::core::ffi::c_int - 3 as ::core::ffi::c_int
                    & 1 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_404;
            }
            C2Rust_Block_40::S_404 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_406;
            }
            C2Rust_Block_40::S_406 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_408;
            }
            C2Rust_Block_40::S_408 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_414;
            }
            C2Rust_Block_40::S_414 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_416;
            }
            C2Rust_Block_40::S_416 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add((*__gamepkg_tls_g_ecx))
                            .wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_418;
            }
            C2Rust_Block_40::S_418 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_420;
            }
            C2Rust_Block_40::S_420 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                c2rust_current_block_40 = C2Rust_Block_40::S_422;
            }
            C2Rust_Block_40::S_422 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_424;
            }
            C2Rust_Block_40::S_424 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_426;
            }
            C2Rust_Block_40::S_426 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_428;
            }
            C2Rust_Block_40::S_428 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_430;
            }
            C2Rust_Block_40::S_430 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_432;
            }
            C2Rust_Block_40::S_432 => {
                _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
                    .wrapping_add(0x18 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_434;
            }
            C2Rust_Block_40::S_434 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_436;
            }
            C2Rust_Block_40::S_436 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_438;
            }
            C2Rust_Block_40::S_438 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_440;
            }
            C2Rust_Block_40::S_440 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_442;
            }
            C2Rust_Block_40::S_442 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_444;
            }
            C2Rust_Block_40::S_444 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_446;
            }
            C2Rust_Block_40::S_446 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_448;
            }
            C2Rust_Block_40::S_448 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_450;
            }
            C2Rust_Block_40::S_450 => {
                if _fa < _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_414;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_459;
                }
            }
            C2Rust_Block_40::S_459 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_461;
            }
            C2Rust_Block_40::S_461 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_463;
            }
            C2Rust_Block_40::S_463 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_465;
            }
            C2Rust_Block_40::S_465 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_467;
            }
            C2Rust_Block_40::S_467 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_469;
            }
            C2Rust_Block_40::S_469 => {
                if _fa <= _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_529;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_478;
                }
            }
            C2Rust_Block_40::S_478 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_480;
            }
            C2Rust_Block_40::S_480 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_482;
            }
            C2Rust_Block_40::S_482 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_484;
            }
            C2Rust_Block_40::S_484 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_486;
            }
            C2Rust_Block_40::S_486 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_40 = C2Rust_Block_40::S_492;
            }
            C2Rust_Block_40::S_492 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_494;
            }
            C2Rust_Block_40::S_494 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add((*__gamepkg_tls_g_ecx))
                            .wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_496;
            }
            C2Rust_Block_40::S_496 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_498;
            }
            C2Rust_Block_40::S_498 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_500;
            }
            C2Rust_Block_40::S_500 => {
                _cf = (((*__gamepkg_tls_g_ecx) as uint64_t)
                    .wrapping_add(0x18 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_502;
            }
            C2Rust_Block_40::S_502 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_504;
            }
            C2Rust_Block_40::S_504 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_506;
            }
            C2Rust_Block_40::S_506 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_508;
            }
            C2Rust_Block_40::S_508 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_40 = C2Rust_Block_40::S_510;
            }
            C2Rust_Block_40::S_510 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_512;
            }
            C2Rust_Block_40::S_512 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_514;
            }
            C2Rust_Block_40::S_514 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_516;
            }
            C2Rust_Block_40::S_516 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_40 = C2Rust_Block_40::S_492;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_529;
                }
            }
            C2Rust_Block_40::S_529 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_531;
            }
            C2Rust_Block_40::S_531 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_541;
            }
            C2Rust_Block_40::S_541 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_543;
            }
            C2Rust_Block_40::S_543 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_553;
            }
            C2Rust_Block_40::S_553 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_555;
            }
            C2Rust_Block_40::S_555 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_561;
            }
            C2Rust_Block_40::S_561 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_563;
            }
            C2Rust_Block_40::S_563 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF270() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(2 as uint32_t));
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << 3 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = 0x30809 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff289 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FED80();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF2A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_001FEDC0();
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF2B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x88 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x84 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x80 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41c5c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | 0x20 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF2F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    enum C2Rust_Block_44 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_24,
        S_26,
        S_28,
        S_38,
        S_40,
        S_42,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_88,
        S_98,
        S_100,
        S_102,
        S_108,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_136,
        S_149,
        S_151,
        S_153,
        S_163,
        S_165,
        S_167,
        S_173,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_197,
        S_203,
        S_205,
        S_207,
        S_209,
        S_212,
        S_214,
        S_216,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_243,
        S_249,
        S_251,
        S_261,
        S_263,
        S_273,
        S_275,
        S_281,
        S_283,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_312,
        S_314,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_336,
        S_338,
        S_344,
        S_350,
        S_352,
        S_358,
        S_360,
        S_366,
        S_375,
        S_381,
        S_383,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_405,
        S_407,
        S_413,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_429,
        S_431,
        S_437,
        S_439,
        S_449,
        S_451,
        S_461,
        S_463,
        S_469,
        S_471,
        S_473,
        S_475,
        S_481,
        S_483,
        S_489,
        S_491,
    }
    let mut c2rust_current_block_44: C2Rust_Block_44;
    c2rust_current_block_44 = C2Rust_Block_44::S_0;
    loop {
        match c2rust_current_block_44 {
            C2Rust_Block_44::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_2;
            }
            C2Rust_Block_44::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_4;
            }
            C2Rust_Block_44::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_14;
            }
            C2Rust_Block_44::S_14 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_24;
            }
            C2Rust_Block_44::S_24 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_44 = C2Rust_Block_44::S_26;
            }
            C2Rust_Block_44::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_28;
            }
            C2Rust_Block_44::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_38;
            }
            C2Rust_Block_44::S_38 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_40;
            }
            C2Rust_Block_44::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_42;
            }
            C2Rust_Block_44::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_48;
            }
            C2Rust_Block_44::S_48 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_50;
            }
            C2Rust_Block_44::S_50 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_56;
            }
            C2Rust_Block_44::S_56 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_58;
            }
            C2Rust_Block_44::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_60;
            }
            C2Rust_Block_44::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_66;
            }
            C2Rust_Block_44::S_66 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x98 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_68;
            }
            C2Rust_Block_44::S_68 => {
                _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_70;
            }
            C2Rust_Block_44::S_70 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_72;
            }
            C2Rust_Block_44::S_72 => {
                _cf = (((*__gamepkg_tls_g_edi) as uint64_t)
                    .wrapping_add(0x5c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_74;
            }
            C2Rust_Block_44::S_74 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_76;
            }
            C2Rust_Block_44::S_76 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_78;
            }
            C2Rust_Block_44::S_78 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_84;
            }
            C2Rust_Block_44::S_84 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_86;
            }
            C2Rust_Block_44::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_88;
            }
            C2Rust_Block_44::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_98;
            }
            C2Rust_Block_44::S_98 => {
                _pv_3 = 0x1ff309 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_100;
            }
            C2Rust_Block_44::S_100 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_102;
            }
            C2Rust_Block_44::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_108;
            }
            C2Rust_Block_44::S_108 => {
                sub_0020BD20();
                c2rust_current_block_44 = C2Rust_Block_44::S_114;
            }
            C2Rust_Block_44::S_114 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_116;
            }
            C2Rust_Block_44::S_116 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_118;
            }
            C2Rust_Block_44::S_118 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(4 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_120;
            }
            C2Rust_Block_44::S_120 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_122;
            }
            C2Rust_Block_44::S_122 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_124;
            }
            C2Rust_Block_44::S_124 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_126;
            }
            C2Rust_Block_44::S_126 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_128;
            }
            C2Rust_Block_44::S_128 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_130;
            }
            C2Rust_Block_44::S_130 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_132;
            }
            C2Rust_Block_44::S_132 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_134;
            }
            C2Rust_Block_44::S_134 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_136;
            }
            C2Rust_Block_44::S_136 => {
                if _fa == _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_197;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_149;
                }
            }
            C2Rust_Block_44::S_149 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_151;
            }
            C2Rust_Block_44::S_151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_153;
            }
            C2Rust_Block_44::S_153 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_163;
            }
            C2Rust_Block_44::S_163 => {
                _pv_5 = 0x1ff316 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_165;
            }
            C2Rust_Block_44::S_165 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_167;
            }
            C2Rust_Block_44::S_167 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_173;
            }
            C2Rust_Block_44::S_173 => {
                sub_0020BDB0();
                c2rust_current_block_44 = C2Rust_Block_44::S_179;
            }
            C2Rust_Block_44::S_179 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_181;
            }
            C2Rust_Block_44::S_181 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_183;
            }
            C2Rust_Block_44::S_183 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(4 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_185;
            }
            C2Rust_Block_44::S_185 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_187;
            }
            C2Rust_Block_44::S_187 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_189;
            }
            C2Rust_Block_44::S_189 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_203;
            }
            C2Rust_Block_44::S_197 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_203;
            }
            C2Rust_Block_44::S_203 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_205;
            }
            C2Rust_Block_44::S_205 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_207;
            }
            C2Rust_Block_44::S_207 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_209;
            }
            C2Rust_Block_44::S_209 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_212;
            }
            C2Rust_Block_44::S_212 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_214;
            }
            C2Rust_Block_44::S_214 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_216;
            }
            C2Rust_Block_44::S_216 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_220;
            }
            C2Rust_Block_44::S_220 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_44 = C2Rust_Block_44::S_222;
            }
            C2Rust_Block_44::S_222 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_224;
            }
            C2Rust_Block_44::S_224 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_226;
            }
            C2Rust_Block_44::S_226 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_228;
            }
            C2Rust_Block_44::S_228 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_230;
            }
            C2Rust_Block_44::S_230 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_232;
            }
            C2Rust_Block_44::S_232 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_234;
            }
            C2Rust_Block_44::S_234 => {
                if _fa != _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_289;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_243;
                }
            }
            C2Rust_Block_44::S_243 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_249;
            }
            C2Rust_Block_44::S_249 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_251;
            }
            C2Rust_Block_44::S_251 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_261;
            }
            C2Rust_Block_44::S_261 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_263;
            }
            C2Rust_Block_44::S_263 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_273;
            }
            C2Rust_Block_44::S_273 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_275;
            }
            C2Rust_Block_44::S_275 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_281;
            }
            C2Rust_Block_44::S_281 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_283;
            }
            C2Rust_Block_44::S_283 => return,
            C2Rust_Block_44::S_289 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_291;
            }
            C2Rust_Block_44::S_291 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_293;
            }
            C2Rust_Block_44::S_293 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_295;
            }
            C2Rust_Block_44::S_295 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_297;
            }
            C2Rust_Block_44::S_297 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_299;
            }
            C2Rust_Block_44::S_299 => {
                if _fa >= _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_366;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_312;
                }
            }
            C2Rust_Block_44::S_312 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_314;
            }
            C2Rust_Block_44::S_314 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_320;
            }
            C2Rust_Block_44::S_320 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_322;
            }
            C2Rust_Block_44::S_322 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_324;
            }
            C2Rust_Block_44::S_324 => {
                _cf = ((*__gamepkg_tls_g_ecx) < (*__gamepkg_tls_g_ebx))
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_326;
            }
            C2Rust_Block_44::S_326 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_ebx));
                c2rust_current_block_44 = C2Rust_Block_44::S_328;
            }
            C2Rust_Block_44::S_328 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_330;
            }
            C2Rust_Block_44::S_330 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_336;
            }
            C2Rust_Block_44::S_336 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_338;
            }
            C2Rust_Block_44::S_338 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_344;
            }
            C2Rust_Block_44::S_344 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_44 = C2Rust_Block_44::S_350;
            }
            C2Rust_Block_44::S_350 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_352;
            }
            C2Rust_Block_44::S_352 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_358;
            }
            C2Rust_Block_44::S_358 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_360;
            }
            C2Rust_Block_44::S_360 => return,
            C2Rust_Block_44::S_366 => {
                if _fa <= _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_449;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_375;
                }
            }
            C2Rust_Block_44::S_375 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_381;
            }
            C2Rust_Block_44::S_381 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_383;
            }
            C2Rust_Block_44::S_383 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_389;
            }
            C2Rust_Block_44::S_389 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_391;
            }
            C2Rust_Block_44::S_391 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_393;
            }
            C2Rust_Block_44::S_393 => {
                _cf = ((*__gamepkg_tls_g_eax) < (*__gamepkg_tls_g_ebx))
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_395;
            }
            C2Rust_Block_44::S_395 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_ebx));
                c2rust_current_block_44 = C2Rust_Block_44::S_397;
            }
            C2Rust_Block_44::S_397 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_399;
            }
            C2Rust_Block_44::S_399 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_405;
            }
            C2Rust_Block_44::S_405 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_407;
            }
            C2Rust_Block_44::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_413;
            }
            C2Rust_Block_44::S_413 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_415;
            }
            C2Rust_Block_44::S_415 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_417;
            }
            C2Rust_Block_44::S_417 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add((*__gamepkg_tls_g_ecx) as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_419;
            }
            C2Rust_Block_44::S_419 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_44 = C2Rust_Block_44::S_421;
            }
            C2Rust_Block_44::S_421 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_423;
            }
            C2Rust_Block_44::S_423 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_429;
            }
            C2Rust_Block_44::S_429 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_431;
            }
            C2Rust_Block_44::S_431 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_437;
            }
            C2Rust_Block_44::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_439;
            }
            C2Rust_Block_44::S_439 => return,
            C2Rust_Block_44::S_449 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_451;
            }
            C2Rust_Block_44::S_451 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_461;
            }
            C2Rust_Block_44::S_461 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_463;
            }
            C2Rust_Block_44::S_463 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_469;
            }
            C2Rust_Block_44::S_469 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_471;
            }
            C2Rust_Block_44::S_471 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_473;
            }
            C2Rust_Block_44::S_473 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_475;
            }
            C2Rust_Block_44::S_475 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_481;
            }
            C2Rust_Block_44::S_481 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_483;
            }
            C2Rust_Block_44::S_483 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_489;
            }
            C2Rust_Block_44::S_489 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_491;
            }
            C2Rust_Block_44::S_491 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF360() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x9c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x98 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_195: {
        's_97: {
            if _fa <= _fb {
                break 's_195;
            }
        }
        's_97: loop {
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x1ff386 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            sub_001FABB0();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_245: {
                if _fa != _fb {
                    break 's_245;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x9c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 0x218 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x218 as uint32_t);
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa < _fb {
                    continue 's_97;
                } else {
                    break 's_195;
                }
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF3B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x9c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x98 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_325: {
        if _fa <= _fb {
            break 's_325;
        }
        let mut _pv_2: uint32_t = ebp;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
        loop {
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_3: uint32_t = ebp;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_5: uint32_t = 0x1ff3d6 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_241: {
                's_192: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_192;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_241;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_200: {
                    if !_fn.is_none() {
                        break 's_200;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_206: {
                    if !_fn.is_none() {
                        break 's_206;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_212: {
                    if _fn.is_some() {
                        break 's_212;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_241;
                }
                _fn.expect("non-null function pointer")();
            }
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ebx).wrapping_add(0x9c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 0x218 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(0x218 as uint32_t);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF400() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff415 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0020BC80();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF420() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1ff435 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0020BCB0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FF440() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi).wrapping_add(0x5c as uint32_t);
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1ff456 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0020BD30();
    let mut _pv_4: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x1ff45e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_0020BDC0();
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
