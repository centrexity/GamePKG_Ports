extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001B35F0();
    fn sub_001B9070();
    fn sub_001CF843();
    fn sub_001CF857();
    fn sub_001CF8A5();
    fn sub_001CFF88();
    fn sub_001D10B4();
    fn sub_001D118A();
    fn sub_001D120E();
    fn sub_001D1953();
    fn sub_001D19FD();
    fn sub_001D407C();
    fn sub_001D7012();
    fn sub_001D7018();
    fn sub_001D701E();
    fn sub_001FEDC0();
    fn sub_0020FA6B();
    fn sub_0020FB03();
    fn sub_002134B0();
    fn sub_00213630();
    fn sub_00213970();
    fn sub_00213DA0();
    fn sub_00214040();
    fn sub_002152A0();
    fn sub_002153B0();
    fn sub_00215530();
    fn sub_002155A0();
    fn sub_00215910();
    fn sub_00215960();
    fn sub_0021BFF0();
    fn sub_0021C030();
    fn sub_0021C0C0();
    fn sub_0021C190();
    fn sub_0021C240();
    fn sub_0021C2F0();
    fn sub_0021DDE0();
    fn sub_0021DE00();
    fn sub_0021E1A0();
    fn sub_0021E2D0();
    fn sub_0021EFA0();
    fn sub_002205E0();
    fn sub_00243210();
    fn sub_002434C0();
    fn sub_00243880();
    fn sub_0031AAD1();
    fn sub_0031ABF3();
    fn sub_0031B080();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn sub_00210094() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b364 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b368 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b36c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b370 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b360 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b378 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_esi),
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x2100d1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001D407C();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_343: {
        if _fa == _fb {
            break 's_343;
        }
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        's_238: {
            's_217: {
                if (*__gamepkg_tls_g_df) != 0 {
                    break 's_217;
                }
                let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _n: uint32_t = (*__gamepkg_tls_g_ecx)
                    .wrapping_mul(4 as uint32_t);
                's_210: {
                    's_189: {
                        if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                            break 's_189;
                        }
                        let mut _i: uint32_t = 0;
                        _i = 0 as uint32_t;
                        loop {
                            if _i >= (*__gamepkg_tls_g_ecx) {
                                break 's_210;
                            }
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_edi)
                                        .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                ::core::ptr::read_volatile::<
                                    uint32_t,
                                >(
                                    ::core::ptr::with_exposed_provenance_mut::<
                                        uint32_t,
                                    >(
                                        ((*__gamepkg_tls_g_esi)
                                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                    ),
                                ),
                            );
                            _i = _i.wrapping_add(1);
                        }
                    }
                    memcpy(
                        _d as *mut ::core::ffi::c_void,
                        _s as *const ::core::ffi::c_void,
                        _n as size_t,
                    );
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                break 's_238;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        's_313: {
            's_292: {
                if (*__gamepkg_tls_g_df) != 0 {
                    break 's_292;
                }
                let mut _d_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _s_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _n_0: uint32_t = (*__gamepkg_tls_g_ecx);
                's_285: {
                    's_264: {
                        if _d_0.offset(_n_0 as isize) <= _s_0
                            || _s_0.offset(_n_0 as isize) <= _d_0
                        {
                            break 's_264;
                        }
                        let mut _i_1: uint32_t = 0;
                        _i_1 = 0 as uint32_t;
                        loop {
                            if _i_1 >= _n_0 {
                                break 's_285;
                            }
                            *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                            _i_1 = _i_1.wrapping_add(1);
                        }
                    }
                    memcpy(
                        _d_0 as *mut ::core::ffi::c_void,
                        _s_0 as *const ::core::ffi::c_void,
                        _n_0 as size_t,
                    );
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                break 's_313;
            }
            let mut _i_2: uint32_t = 0;
            _i_2 = 0 as uint32_t;
            while _i_2 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_2 = _i_2.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx));
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(32 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002100F9() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    enum C2Rust_Block_1 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_58,
        S_60,
        S_62,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_86,
        S_88,
        S_90,
        S_100,
        S_102,
        S_104,
        S_110,
        S_112,
        S_114,
        S_116,
        S_125,
        S_127,
        S_129,
        S_131,
        S_133,
        S_135,
        S_137,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_182,
        S_188,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_217,
        S_219,
        S_221,
        S_223,
        S_225,
        S_231,
        S_233,
        S_235,
        S_237,
        S_239,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_267,
        S_269,
        S_275,
        S_277,
        S_279,
        S_289,
        S_291,
        S_293,
        S_299,
        S_301,
        S_303,
        S_309,
        S_311,
        S_313,
        S_319,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_375,
        S_381,
        S_383,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_440,
        S_442,
        S_452,
        S_454,
        S_464,
        S_466,
        S_472,
        S_478,
        S_480,
        S_486,
        S_488,
        S_494,
        S_496,
        S_498,
    }
    let mut c2rust_current_block_1: C2Rust_Block_1;
    c2rust_current_block_1 = C2Rust_Block_1::S_0;
    loop {
        match c2rust_current_block_1 {
            C2Rust_Block_1::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_2;
            }
            C2Rust_Block_1::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_1 = C2Rust_Block_1::S_4;
            }
            C2Rust_Block_1::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_1 = C2Rust_Block_1::S_6;
            }
            C2Rust_Block_1::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_8;
            }
            C2Rust_Block_1::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_26;
            }
            C2Rust_Block_1::S_26 => {
                _pv = ebp;
                c2rust_current_block_1 = C2Rust_Block_1::S_28;
            }
            C2Rust_Block_1::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_30;
            }
            C2Rust_Block_1::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_36;
            }
            C2Rust_Block_1::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_1 = C2Rust_Block_1::S_38;
            }
            C2Rust_Block_1::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_1 = C2Rust_Block_1::S_40;
            }
            C2Rust_Block_1::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_1 = C2Rust_Block_1::S_42;
            }
            C2Rust_Block_1::S_42 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_44;
            }
            C2Rust_Block_1::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_46;
            }
            C2Rust_Block_1::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x10 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_48;
            }
            C2Rust_Block_1::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_50;
            }
            C2Rust_Block_1::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_52;
            }
            C2Rust_Block_1::S_52 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41cd2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_58;
            }
            C2Rust_Block_1::S_58 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_1 = C2Rust_Block_1::S_60;
            }
            C2Rust_Block_1::S_60 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_62;
            }
            C2Rust_Block_1::S_62 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_68;
            }
            C2Rust_Block_1::S_68 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_70;
            }
            C2Rust_Block_1::S_70 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_72;
            }
            C2Rust_Block_1::S_72 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_74;
            }
            C2Rust_Block_1::S_74 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_76;
            }
            C2Rust_Block_1::S_76 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_78;
            }
            C2Rust_Block_1::S_78 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_80;
            }
            C2Rust_Block_1::S_80 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_86;
            }
            C2Rust_Block_1::S_86 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_1 = C2Rust_Block_1::S_88;
            }
            C2Rust_Block_1::S_88 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_90;
            }
            C2Rust_Block_1::S_90 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_100;
            }
            C2Rust_Block_1::S_100 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_1 = C2Rust_Block_1::S_102;
            }
            C2Rust_Block_1::S_102 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_104;
            }
            C2Rust_Block_1::S_104 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_110;
            }
            C2Rust_Block_1::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_112;
            }
            C2Rust_Block_1::S_112 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_114;
            }
            C2Rust_Block_1::S_114 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_116;
            }
            C2Rust_Block_1::S_116 => {
                if _fa <= _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_418;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_125;
                }
            }
            C2Rust_Block_1::S_125 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_127;
            }
            C2Rust_Block_1::S_127 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_129;
            }
            C2Rust_Block_1::S_129 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_131;
            }
            C2Rust_Block_1::S_131 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_133;
            }
            C2Rust_Block_1::S_133 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_135;
            }
            C2Rust_Block_1::S_135 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_137;
            }
            C2Rust_Block_1::S_137 => {
                if _fa == _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_389;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_146;
                }
            }
            C2Rust_Block_1::S_146 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_148;
            }
            C2Rust_Block_1::S_148 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_150;
            }
            C2Rust_Block_1::S_150 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_152;
            }
            C2Rust_Block_1::S_152 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_154;
            }
            C2Rust_Block_1::S_154 => {
                if _fa > _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_389;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_163;
                }
            }
            C2Rust_Block_1::S_163 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_165;
            }
            C2Rust_Block_1::S_165 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_167;
            }
            C2Rust_Block_1::S_167 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_169;
            }
            C2Rust_Block_1::S_169 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_171;
            }
            C2Rust_Block_1::S_171 => {
                (*__gamepkg_tls_g_esi) = ebp
                    .wrapping_add(-4 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_173;
            }
            C2Rust_Block_1::S_173 => {
                if _fa != _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_188;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_182;
                }
            }
            C2Rust_Block_1::S_182 => {
                (*__gamepkg_tls_g_esi) = ebp
                    .wrapping_add(-8 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_188;
            }
            C2Rust_Block_1::S_188 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b594 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_231;
            }
            C2Rust_Block_1::S_196 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_198;
            }
            C2Rust_Block_1::S_198 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b590 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_200;
            }
            C2Rust_Block_1::S_200 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_202;
            }
            C2Rust_Block_1::S_202 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_204;
            }
            C2Rust_Block_1::S_204 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_206;
            }
            C2Rust_Block_1::S_206 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_208;
            }
            C2Rust_Block_1::S_208 => {
                if _fa == _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_248;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_217;
                }
            }
            C2Rust_Block_1::S_217 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_1 = C2Rust_Block_1::S_219;
            }
            C2Rust_Block_1::S_219 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_221;
            }
            C2Rust_Block_1::S_221 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_223;
            }
            C2Rust_Block_1::S_223 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_225;
            }
            C2Rust_Block_1::S_225 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_231;
            }
            C2Rust_Block_1::S_231 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_233;
            }
            C2Rust_Block_1::S_233 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_235;
            }
            C2Rust_Block_1::S_235 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_237;
            }
            C2Rust_Block_1::S_237 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_239;
            }
            C2Rust_Block_1::S_239 => {
                if _fa < _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_196;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_248;
                }
            }
            C2Rust_Block_1::S_248 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_250;
            }
            C2Rust_Block_1::S_250 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_252;
            }
            C2Rust_Block_1::S_252 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_254;
            }
            C2Rust_Block_1::S_254 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_256;
            }
            C2Rust_Block_1::S_256 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_258;
            }
            C2Rust_Block_1::S_258 => {
                if _fa < _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_494;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_267;
                }
            }
            C2Rust_Block_1::S_267 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_269;
            }
            C2Rust_Block_1::S_269 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(1 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_275;
            }
            C2Rust_Block_1::S_275 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_1 = C2Rust_Block_1::S_277;
            }
            C2Rust_Block_1::S_277 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_279;
            }
            C2Rust_Block_1::S_279 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_289;
            }
            C2Rust_Block_1::S_289 => {
                _pv_4 = 0x76b590 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_291;
            }
            C2Rust_Block_1::S_291 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_293;
            }
            C2Rust_Block_1::S_293 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_299;
            }
            C2Rust_Block_1::S_299 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_301;
            }
            C2Rust_Block_1::S_301 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_1 = C2Rust_Block_1::S_303;
            }
            C2Rust_Block_1::S_303 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_1 = C2Rust_Block_1::S_309;
            }
            C2Rust_Block_1::S_309 => {
                _pv_5 = 0x210176 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_311;
            }
            C2Rust_Block_1::S_311 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_313;
            }
            C2Rust_Block_1::S_313 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_319;
            }
            C2Rust_Block_1::S_319 => {
                sub_0020FB03();
                c2rust_current_block_1 = C2Rust_Block_1::S_325;
            }
            C2Rust_Block_1::S_325 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_327;
            }
            C2Rust_Block_1::S_327 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_329;
            }
            C2Rust_Block_1::S_329 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_331;
            }
            C2Rust_Block_1::S_331 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_333;
            }
            C2Rust_Block_1::S_333 => {
                if _fa == _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_494;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_342;
                }
            }
            C2Rust_Block_1::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_344;
            }
            C2Rust_Block_1::S_344 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b590 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_346;
            }
            C2Rust_Block_1::S_346 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_ebx).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_348;
            }
            C2Rust_Block_1::S_348 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_350;
            }
            C2Rust_Block_1::S_350 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_352;
            }
            C2Rust_Block_1::S_352 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_354;
            }
            C2Rust_Block_1::S_354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_356;
            }
            C2Rust_Block_1::S_356 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_358;
            }
            C2Rust_Block_1::S_358 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_360;
            }
            C2Rust_Block_1::S_360 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_362;
            }
            C2Rust_Block_1::S_362 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_364;
            }
            C2Rust_Block_1::S_364 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_366;
            }
            C2Rust_Block_1::S_366 => {
                if _fa >= _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_381;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_375;
                }
            }
            C2Rust_Block_1::S_375 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_381;
            }
            C2Rust_Block_1::S_381 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_383;
            }
            C2Rust_Block_1::S_383 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_389;
            }
            C2Rust_Block_1::S_389 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_391;
            }
            C2Rust_Block_1::S_391 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_1 = C2Rust_Block_1::S_393;
            }
            C2Rust_Block_1::S_393 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_395;
            }
            C2Rust_Block_1::S_395 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_397;
            }
            C2Rust_Block_1::S_397 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_399;
            }
            C2Rust_Block_1::S_399 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_401;
            }
            C2Rust_Block_1::S_401 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_403;
            }
            C2Rust_Block_1::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_405;
            }
            C2Rust_Block_1::S_405 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_407;
            }
            C2Rust_Block_1::S_407 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_409;
            }
            C2Rust_Block_1::S_409 => {
                if _fa < _fb {
                    c2rust_current_block_1 = C2Rust_Block_1::S_125;
                } else {
                    c2rust_current_block_1 = C2Rust_Block_1::S_418;
                }
            }
            C2Rust_Block_1::S_418 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_420;
            }
            C2Rust_Block_1::S_420 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_422;
            }
            C2Rust_Block_1::S_422 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_424;
            }
            C2Rust_Block_1::S_424 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_1 = C2Rust_Block_1::S_426;
            }
            C2Rust_Block_1::S_426 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_428;
            }
            C2Rust_Block_1::S_428 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_430;
            }
            C2Rust_Block_1::S_430 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_440;
            }
            C2Rust_Block_1::S_440 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_442;
            }
            C2Rust_Block_1::S_442 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_452;
            }
            C2Rust_Block_1::S_452 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_454;
            }
            C2Rust_Block_1::S_454 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_464;
            }
            C2Rust_Block_1::S_464 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_466;
            }
            C2Rust_Block_1::S_466 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_472;
            }
            C2Rust_Block_1::S_472 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_1 = C2Rust_Block_1::S_478;
            }
            C2Rust_Block_1::S_478 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_1 = C2Rust_Block_1::S_480;
            }
            C2Rust_Block_1::S_480 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_486;
            }
            C2Rust_Block_1::S_486 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_1 = C2Rust_Block_1::S_488;
            }
            C2Rust_Block_1::S_488 => return,
            C2Rust_Block_1::S_494 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_496;
            }
            C2Rust_Block_1::S_496 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_498;
            }
            C2Rust_Block_1::S_498 => {
                _fas = _fa as int32_t;
                c2rust_current_block_1 = C2Rust_Block_1::S_440;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002101BB() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _d_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_0: uint32_t = 0;
    let mut _i_1: uint32_t = 0;
    let mut _i_2: uint32_t = 0;
    enum C2Rust_Block_2 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_68,
        S_70,
        S_72,
        S_82,
        S_84,
        S_86,
        S_92,
        S_94,
        S_96,
        S_102,
        S_104,
        S_106,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_130,
        S_132,
        S_134,
        S_136,
        S_140,
        S_143,
        S_144,
        S_145,
        S_146,
        S_157,
        S_159,
        S_164,
        S_167,
        S_168,
        S_169,
        S_170,
        S_177,
        S_179,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_199,
        S_201,
        S_203,
        S_205,
        S_209,
        S_212,
        S_213,
        S_214,
        S_215,
        S_226,
        S_228,
        S_233,
        S_236,
        S_237,
        S_238,
        S_239,
        S_246,
        S_248,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_279,
        S_281,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_389,
        S_395,
        S_397,
        S_407,
        S_409,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_429,
        S_431,
        S_441,
        S_443,
        S_449,
        S_451,
    }
    let mut c2rust_current_block_2: C2Rust_Block_2;
    c2rust_current_block_2 = C2Rust_Block_2::S_0;
    loop {
        match c2rust_current_block_2 {
            C2Rust_Block_2::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_2;
            }
            C2Rust_Block_2::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_2 = C2Rust_Block_2::S_4;
            }
            C2Rust_Block_2::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_2 = C2Rust_Block_2::S_6;
            }
            C2Rust_Block_2::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_8;
            }
            C2Rust_Block_2::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_26;
            }
            C2Rust_Block_2::S_26 => {
                _pv = ebp;
                c2rust_current_block_2 = C2Rust_Block_2::S_28;
            }
            C2Rust_Block_2::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_30;
            }
            C2Rust_Block_2::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_36;
            }
            C2Rust_Block_2::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_2 = C2Rust_Block_2::S_38;
            }
            C2Rust_Block_2::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_2 = C2Rust_Block_2::S_40;
            }
            C2Rust_Block_2::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_2 = C2Rust_Block_2::S_42;
            }
            C2Rust_Block_2::S_42 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_44;
            }
            C2Rust_Block_2::S_44 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_46;
            }
            C2Rust_Block_2::S_46 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_48;
            }
            C2Rust_Block_2::S_48 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_50;
            }
            C2Rust_Block_2::S_50 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_52;
            }
            C2Rust_Block_2::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_54;
            }
            C2Rust_Block_2::S_54 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_56;
            }
            C2Rust_Block_2::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_58;
            }
            C2Rust_Block_2::S_58 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_60;
            }
            C2Rust_Block_2::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_62;
            }
            C2Rust_Block_2::S_62 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_68;
            }
            C2Rust_Block_2::S_68 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_2 = C2Rust_Block_2::S_70;
            }
            C2Rust_Block_2::S_70 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_72;
            }
            C2Rust_Block_2::S_72 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_82;
            }
            C2Rust_Block_2::S_82 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_2 = C2Rust_Block_2::S_84;
            }
            C2Rust_Block_2::S_84 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_86;
            }
            C2Rust_Block_2::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_92;
            }
            C2Rust_Block_2::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(6 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_94;
            }
            C2Rust_Block_2::S_94 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_96;
            }
            C2Rust_Block_2::S_96 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_102;
            }
            C2Rust_Block_2::S_102 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_2 = C2Rust_Block_2::S_104;
            }
            C2Rust_Block_2::S_104 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_106;
            }
            C2Rust_Block_2::S_106 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_112;
            }
            C2Rust_Block_2::S_112 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_114;
            }
            C2Rust_Block_2::S_114 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_2 = C2Rust_Block_2::S_116;
            }
            C2Rust_Block_2::S_116 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_2 = C2Rust_Block_2::S_118;
            }
            C2Rust_Block_2::S_118 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_2 = C2Rust_Block_2::S_120;
            }
            C2Rust_Block_2::S_120 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_122;
            }
            C2Rust_Block_2::S_122 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_124;
            }
            C2Rust_Block_2::S_124 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(2 as uint32_t))
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_126;
            }
            C2Rust_Block_2::S_126 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_2 = C2Rust_Block_2::S_130;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_164;
                }
            }
            C2Rust_Block_2::S_130 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_132;
            }
            C2Rust_Block_2::S_132 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_134;
            }
            C2Rust_Block_2::S_134 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_2 = C2Rust_Block_2::S_136;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_140;
                }
            }
            C2Rust_Block_2::S_136 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_157;
            }
            C2Rust_Block_2::S_140 => {
                _i = 0;
                c2rust_current_block_2 = C2Rust_Block_2::S_143;
            }
            C2Rust_Block_2::S_143 => {
                _i = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_144;
            }
            C2Rust_Block_2::S_144 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_2 = C2Rust_Block_2::S_145;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_157;
                }
            }
            C2Rust_Block_2::S_145 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_146;
            }
            C2Rust_Block_2::S_146 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_2 = C2Rust_Block_2::S_144;
            }
            C2Rust_Block_2::S_157 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_2 = C2Rust_Block_2::S_159;
            }
            C2Rust_Block_2::S_159 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_2 = C2Rust_Block_2::S_185;
            }
            C2Rust_Block_2::S_164 => {
                _i_0 = 0;
                c2rust_current_block_2 = C2Rust_Block_2::S_167;
            }
            C2Rust_Block_2::S_167 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_168;
            }
            C2Rust_Block_2::S_168 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_2 = C2Rust_Block_2::S_169;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_177;
                }
            }
            C2Rust_Block_2::S_169 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_170;
            }
            C2Rust_Block_2::S_170 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_2 = C2Rust_Block_2::S_168;
            }
            C2Rust_Block_2::S_177 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_2 = C2Rust_Block_2::S_179;
            }
            C2Rust_Block_2::S_179 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_2 = C2Rust_Block_2::S_185;
            }
            C2Rust_Block_2::S_185 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_187;
            }
            C2Rust_Block_2::S_187 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_2 = C2Rust_Block_2::S_189;
            }
            C2Rust_Block_2::S_189 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_191;
            }
            C2Rust_Block_2::S_191 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_193;
            }
            C2Rust_Block_2::S_193 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_195;
            }
            C2Rust_Block_2::S_195 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_2 = C2Rust_Block_2::S_199;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_233;
                }
            }
            C2Rust_Block_2::S_199 => {
                _d_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_201;
            }
            C2Rust_Block_2::S_201 => {
                _n_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_2 = C2Rust_Block_2::S_203;
            }
            C2Rust_Block_2::S_203 => {
                if _d_0.offset(_n_0 as isize) <= _s_0
                    || _s_0.offset(_n_0 as isize) <= _d_0
                {
                    c2rust_current_block_2 = C2Rust_Block_2::S_205;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_209;
                }
            }
            C2Rust_Block_2::S_205 => {
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_226;
            }
            C2Rust_Block_2::S_209 => {
                _i_1 = 0;
                c2rust_current_block_2 = C2Rust_Block_2::S_212;
            }
            C2Rust_Block_2::S_212 => {
                _i_1 = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_213;
            }
            C2Rust_Block_2::S_213 => {
                if _i_1 < _n_0 {
                    c2rust_current_block_2 = C2Rust_Block_2::S_214;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_226;
                }
            }
            C2Rust_Block_2::S_214 => {
                *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                c2rust_current_block_2 = C2Rust_Block_2::S_215;
            }
            C2Rust_Block_2::S_215 => {
                _i_1 = _i_1.wrapping_add(1);
                c2rust_current_block_2 = C2Rust_Block_2::S_213;
            }
            C2Rust_Block_2::S_226 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_2 = C2Rust_Block_2::S_228;
            }
            C2Rust_Block_2::S_228 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_2 = C2Rust_Block_2::S_254;
            }
            C2Rust_Block_2::S_233 => {
                _i_2 = 0;
                c2rust_current_block_2 = C2Rust_Block_2::S_236;
            }
            C2Rust_Block_2::S_236 => {
                _i_2 = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_237;
            }
            C2Rust_Block_2::S_237 => {
                if _i_2 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_2 = C2Rust_Block_2::S_238;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_246;
                }
            }
            C2Rust_Block_2::S_238 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_239;
            }
            C2Rust_Block_2::S_239 => {
                _i_2 = _i_2.wrapping_add(1);
                c2rust_current_block_2 = C2Rust_Block_2::S_237;
            }
            C2Rust_Block_2::S_246 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_2 = C2Rust_Block_2::S_248;
            }
            C2Rust_Block_2::S_248 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_2 = C2Rust_Block_2::S_254;
            }
            C2Rust_Block_2::S_254 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_256;
            }
            C2Rust_Block_2::S_256 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_258;
            }
            C2Rust_Block_2::S_258 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_260;
            }
            C2Rust_Block_2::S_260 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_262;
            }
            C2Rust_Block_2::S_262 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_264;
            }
            C2Rust_Block_2::S_264 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_266;
            }
            C2Rust_Block_2::S_266 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_268;
            }
            C2Rust_Block_2::S_268 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_270;
            }
            C2Rust_Block_2::S_270 => {
                if _fa <= _fb {
                    c2rust_current_block_2 = C2Rust_Block_2::S_389;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_279;
                }
            }
            C2Rust_Block_2::S_279 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_281;
            }
            C2Rust_Block_2::S_281 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_287;
            }
            C2Rust_Block_2::S_287 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_289;
            }
            C2Rust_Block_2::S_289 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_291;
            }
            C2Rust_Block_2::S_291 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_293;
            }
            C2Rust_Block_2::S_293 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_295;
            }
            C2Rust_Block_2::S_295 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_297;
            }
            C2Rust_Block_2::S_297 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_299;
            }
            C2Rust_Block_2::S_299 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_301;
            }
            C2Rust_Block_2::S_301 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_2 = C2Rust_Block_2::S_336;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_310;
                }
            }
            C2Rust_Block_2::S_310 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_312;
            }
            C2Rust_Block_2::S_312 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_314;
            }
            C2Rust_Block_2::S_314 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_316;
            }
            C2Rust_Block_2::S_316 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_318;
            }
            C2Rust_Block_2::S_318 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_sub((*__gamepkg_tls_g_edi));
                c2rust_current_block_2 = C2Rust_Block_2::S_320;
            }
            C2Rust_Block_2::S_320 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_322;
            }
            C2Rust_Block_2::S_322 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_324;
            }
            C2Rust_Block_2::S_324 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_326;
            }
            C2Rust_Block_2::S_326 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_328;
            }
            C2Rust_Block_2::S_328 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_330;
            }
            C2Rust_Block_2::S_330 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_336;
            }
            C2Rust_Block_2::S_336 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_338;
            }
            C2Rust_Block_2::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_340;
            }
            C2Rust_Block_2::S_340 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_342;
            }
            C2Rust_Block_2::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_344;
            }
            C2Rust_Block_2::S_344 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_346;
            }
            C2Rust_Block_2::S_346 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_348;
            }
            C2Rust_Block_2::S_348 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ebx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_2 = C2Rust_Block_2::S_350;
            }
            C2Rust_Block_2::S_350 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_2 = C2Rust_Block_2::S_352;
            }
            C2Rust_Block_2::S_352 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_354;
            }
            C2Rust_Block_2::S_354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_356;
            }
            C2Rust_Block_2::S_356 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_358;
            }
            C2Rust_Block_2::S_358 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_360;
            }
            C2Rust_Block_2::S_360 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_362;
            }
            C2Rust_Block_2::S_362 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_364;
            }
            C2Rust_Block_2::S_364 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_366;
            }
            C2Rust_Block_2::S_366 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_368;
            }
            C2Rust_Block_2::S_368 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_ebx).wrapping_mul(2 as uint32_t),
                            )
                            .wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_370;
            }
            C2Rust_Block_2::S_370 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_372;
            }
            C2Rust_Block_2::S_372 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_374;
            }
            C2Rust_Block_2::S_374 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_376;
            }
            C2Rust_Block_2::S_376 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_378;
            }
            C2Rust_Block_2::S_378 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_380;
            }
            C2Rust_Block_2::S_380 => {
                if _fa < _fb {
                    c2rust_current_block_2 = C2Rust_Block_2::S_287;
                } else {
                    c2rust_current_block_2 = C2Rust_Block_2::S_389;
                }
            }
            C2Rust_Block_2::S_389 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_395;
            }
            C2Rust_Block_2::S_395 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_397;
            }
            C2Rust_Block_2::S_397 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_407;
            }
            C2Rust_Block_2::S_407 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_409;
            }
            C2Rust_Block_2::S_409 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_415;
            }
            C2Rust_Block_2::S_415 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_417;
            }
            C2Rust_Block_2::S_417 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_419;
            }
            C2Rust_Block_2::S_419 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edx));
                c2rust_current_block_2 = C2Rust_Block_2::S_421;
            }
            C2Rust_Block_2::S_421 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_423;
            }
            C2Rust_Block_2::S_423 => {
                _fas = _fa as int32_t;
                c2rust_current_block_2 = C2Rust_Block_2::S_429;
            }
            C2Rust_Block_2::S_429 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_431;
            }
            C2Rust_Block_2::S_431 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_441;
            }
            C2Rust_Block_2::S_441 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_2 = C2Rust_Block_2::S_443;
            }
            C2Rust_Block_2::S_443 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_449;
            }
            C2Rust_Block_2::S_449 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(16 as uint32_t);
                c2rust_current_block_2 = C2Rust_Block_2::S_451;
            }
            C2Rust_Block_2::S_451 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0021026F() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_331: {
        's_63: {
            if _fa >= _fb {
                break 's_63;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_ecx));
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x76b3d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) >> 1 as ::core::ffi::c_int;
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add(
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_6: uint32_t = 0x2102a2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_0021026F();
            let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_10: uint32_t = 0x2102b2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            sub_0021026F();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(2 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            break 's_331;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | 0 as ::core::ffi::c_int as uint16_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
            & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
    }
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002102C1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0x74 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x74 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_eax) = ebp.wrapping_add(-116 as ::core::ffi::c_int as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_2: uint32_t = 0x2102d1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D7018();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_eax) = ebp.wrapping_add(-116 as ::core::ffi::c_int as uint32_t);
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_6: uint32_t = 0x2102e3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001D7012();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    (*__gamepkg_tls_g_eax) = ebp.wrapping_add(-116 as ::core::ffi::c_int as uint32_t);
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x2102f0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_001D701E();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002102F5() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    enum C2Rust_Block_5 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_66,
        S_72,
        S_74,
        S_76,
        S_86,
        S_88,
        S_90,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_125,
        S_127,
        S_129,
        S_131,
        S_133,
        S_135,
        S_137,
        S_139,
        S_141,
        S_143,
        S_152,
        S_154,
        S_156,
        S_158,
        S_164,
        S_166,
        S_168,
        S_178,
        S_180,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_240,
        S_242,
        S_244,
        S_254,
        S_256,
        S_262,
        S_264,
        S_266,
        S_268,
        S_271,
        S_273,
        S_276,
        S_277,
        S_278,
        S_279,
        S_286,
        S_290,
        S_296,
        S_298,
        S_300,
        S_310,
        S_312,
        S_314,
        S_324,
        S_326,
        S_328,
        S_338,
        S_340,
        S_342,
        S_352,
        S_354,
        S_356,
        S_362,
        S_364,
        S_370,
        S_372,
        S_374,
        S_380,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_407,
        S_409,
        S_411,
        S_417,
        S_423,
        S_425,
        S_427,
        S_437,
        S_439,
        S_441,
        S_451,
        S_453,
        S_455,
        S_465,
        S_467,
        S_469,
        S_475,
        S_477,
        S_483,
        S_485,
        S_487,
        S_493,
        S_499,
        S_501,
        S_503,
        S_505,
        S_507,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_570,
        S_572,
        S_574,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_596,
        S_598,
        S_600,
        S_606,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_631,
        S_633,
        S_635,
        S_637,
        S_639,
        S_641,
        S_647,
        S_649,
        S_651,
        S_661,
        S_663,
        S_665,
        S_675,
        S_677,
        S_679,
        S_685,
        S_687,
        S_693,
        S_695,
        S_697,
        S_703,
        S_713,
        S_715,
        S_717,
        S_723,
        S_729,
        S_731,
        S_733,
        S_743,
        S_745,
        S_747,
        S_753,
        S_755,
        S_761,
        S_763,
        S_765,
        S_771,
        S_781,
        S_783,
        S_785,
        S_795,
        S_797,
        S_799,
        S_805,
        S_807,
        S_813,
        S_815,
        S_817,
        S_823,
        S_833,
        S_835,
        S_837,
        S_843,
        S_849,
        S_851,
        S_853,
        S_863,
        S_865,
        S_867,
        S_877,
        S_879,
        S_881,
        S_891,
        S_893,
        S_895,
        S_901,
        S_903,
        S_909,
        S_911,
        S_913,
        S_919,
        S_925,
        S_927,
        S_929,
        S_931,
        S_933,
        S_942,
        S_944,
        S_946,
        S_948,
        S_950,
        S_959,
        S_961,
        S_963,
        S_965,
        S_967,
        S_969,
        S_971,
        S_979,
        S_981,
        S_983,
        S_993,
        S_995,
        S_1005,
        S_1007,
        S_1017,
        S_1019,
        S_1025,
        S_1031,
        S_1033,
        S_1039,
        S_1041,
    }
    let mut c2rust_current_block_5: C2Rust_Block_5;
    c2rust_current_block_5 = C2Rust_Block_5::S_0;
    loop {
        match c2rust_current_block_5 {
            C2Rust_Block_5::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_2;
            }
            C2Rust_Block_5::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_5 = C2Rust_Block_5::S_4;
            }
            C2Rust_Block_5::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_6;
            }
            C2Rust_Block_5::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_8;
            }
            C2Rust_Block_5::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_26;
            }
            C2Rust_Block_5::S_26 => {
                _pv = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_28;
            }
            C2Rust_Block_5::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_30;
            }
            C2Rust_Block_5::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_36;
            }
            C2Rust_Block_5::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_5 = C2Rust_Block_5::S_38;
            }
            C2Rust_Block_5::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_40;
            }
            C2Rust_Block_5::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_42;
            }
            C2Rust_Block_5::S_42 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_44;
            }
            C2Rust_Block_5::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_46;
            }
            C2Rust_Block_5::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x1c as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_48;
            }
            C2Rust_Block_5::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_50;
            }
            C2Rust_Block_5::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_56;
            }
            C2Rust_Block_5::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_5 = C2Rust_Block_5::S_58;
            }
            C2Rust_Block_5::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_60;
            }
            C2Rust_Block_5::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_66;
            }
            C2Rust_Block_5::S_66 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_72;
            }
            C2Rust_Block_5::S_72 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_74;
            }
            C2Rust_Block_5::S_74 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_76;
            }
            C2Rust_Block_5::S_76 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_86;
            }
            C2Rust_Block_5::S_86 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_88;
            }
            C2Rust_Block_5::S_88 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_90;
            }
            C2Rust_Block_5::S_90 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_96;
            }
            C2Rust_Block_5::S_96 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_98;
            }
            C2Rust_Block_5::S_98 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_100;
            }
            C2Rust_Block_5::S_100 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_102;
            }
            C2Rust_Block_5::S_102 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_104;
            }
            C2Rust_Block_5::S_104 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_106;
            }
            C2Rust_Block_5::S_106 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_108;
            }
            C2Rust_Block_5::S_108 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_110;
            }
            C2Rust_Block_5::S_110 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_112;
            }
            C2Rust_Block_5::S_112 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_114;
            }
            C2Rust_Block_5::S_114 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_116;
            }
            C2Rust_Block_5::S_116 => {
                if _fa != _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_310;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_125;
                }
            }
            C2Rust_Block_5::S_125 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b360 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_127;
            }
            C2Rust_Block_5::S_127 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    >> 0x1f as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_129;
            }
            C2Rust_Block_5::S_129 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_131;
            }
            C2Rust_Block_5::S_131 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_133;
            }
            C2Rust_Block_5::S_133 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b358 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_135;
            }
            C2Rust_Block_5::S_135 => {
                (*__gamepkg_tls_g_ebx) = ebp
                    .wrapping_add(-28 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_137;
            }
            C2Rust_Block_5::S_137 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_139;
            }
            C2Rust_Block_5::S_139 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_141;
            }
            C2Rust_Block_5::S_141 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x76b340 as uint32_t,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_143;
            }
            C2Rust_Block_5::S_143 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_5 = C2Rust_Block_5::S_240;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_152;
                }
            }
            C2Rust_Block_5::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_154;
            }
            C2Rust_Block_5::S_154 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_156;
            }
            C2Rust_Block_5::S_156 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_158;
            }
            C2Rust_Block_5::S_158 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_164;
            }
            C2Rust_Block_5::S_164 => {
                _pv_3 = 0x70 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_166;
            }
            C2Rust_Block_5::S_166 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_168;
            }
            C2Rust_Block_5::S_168 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_178;
            }
            C2Rust_Block_5::S_178 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_180;
            }
            C2Rust_Block_5::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_186;
            }
            C2Rust_Block_5::S_186 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_188;
            }
            C2Rust_Block_5::S_188 => {
                (*__gamepkg_tls_g_edi) = 0x76b3b4 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_190;
            }
            C2Rust_Block_5::S_190 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_192;
            }
            C2Rust_Block_5::S_192 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_5 = C2Rust_Block_5::S_194;
            }
            C2Rust_Block_5::S_194 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_196;
            }
            C2Rust_Block_5::S_196 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_5 = C2Rust_Block_5::S_198;
            }
            C2Rust_Block_5::S_198 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_200;
            }
            C2Rust_Block_5::S_200 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_5 = C2Rust_Block_5::S_202;
            }
            C2Rust_Block_5::S_202 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_204;
            }
            C2Rust_Block_5::S_204 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_5 = C2Rust_Block_5::S_206;
            }
            C2Rust_Block_5::S_206 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_208;
            }
            C2Rust_Block_5::S_208 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_5 = C2Rust_Block_5::S_210;
            }
            C2Rust_Block_5::S_210 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_212;
            }
            C2Rust_Block_5::S_212 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_214;
            }
            C2Rust_Block_5::S_214 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_ecx)),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_216;
            }
            C2Rust_Block_5::S_216 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_218;
            }
            C2Rust_Block_5::S_218 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_220;
            }
            C2Rust_Block_5::S_220 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_222;
            }
            C2Rust_Block_5::S_222 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_224;
            }
            C2Rust_Block_5::S_224 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (0x76b390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_ecx)),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_226;
            }
            C2Rust_Block_5::S_226 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_228;
            }
            C2Rust_Block_5::S_228 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_296;
            }
            C2Rust_Block_5::S_240 => {
                _pv_4 = 0x1c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_242;
            }
            C2Rust_Block_5::S_242 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_244;
            }
            C2Rust_Block_5::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_254;
            }
            C2Rust_Block_5::S_254 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_256;
            }
            C2Rust_Block_5::S_256 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_262;
            }
            C2Rust_Block_5::S_262 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_264;
            }
            C2Rust_Block_5::S_264 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_266;
            }
            C2Rust_Block_5::S_266 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_268;
            }
            C2Rust_Block_5::S_268 => {
                (*__gamepkg_tls_g_edi) = 0x76b3ac as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_271;
            }
            C2Rust_Block_5::S_271 => {
                _i = 0;
                c2rust_current_block_5 = C2Rust_Block_5::S_273;
            }
            C2Rust_Block_5::S_273 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_5 = C2Rust_Block_5::S_276;
            }
            C2Rust_Block_5::S_276 => {
                _i = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_277;
            }
            C2Rust_Block_5::S_277 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_5 = C2Rust_Block_5::S_278;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_286;
                }
            }
            C2Rust_Block_5::S_278 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_279;
            }
            C2Rust_Block_5::S_279 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_277;
            }
            C2Rust_Block_5::S_286 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_5 = C2Rust_Block_5::S_290;
            }
            C2Rust_Block_5::S_290 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_296;
            }
            C2Rust_Block_5::S_296 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_298;
            }
            C2Rust_Block_5::S_298 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_300;
            }
            C2Rust_Block_5::S_300 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_310;
            }
            C2Rust_Block_5::S_310 => {
                _pv_5 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_312;
            }
            C2Rust_Block_5::S_312 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_314;
            }
            C2Rust_Block_5::S_314 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_324;
            }
            C2Rust_Block_5::S_324 => {
                _pv_6 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_326;
            }
            C2Rust_Block_5::S_326 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_328;
            }
            C2Rust_Block_5::S_328 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_338;
            }
            C2Rust_Block_5::S_338 => {
                _pv_7 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_340;
            }
            C2Rust_Block_5::S_340 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_342;
            }
            C2Rust_Block_5::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_352;
            }
            C2Rust_Block_5::S_352 => {
                _pv_8 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_354;
            }
            C2Rust_Block_5::S_354 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_356;
            }
            C2Rust_Block_5::S_356 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_362;
            }
            C2Rust_Block_5::S_362 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_364;
            }
            C2Rust_Block_5::S_364 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_370;
            }
            C2Rust_Block_5::S_370 => {
                _pv_9 = 0x21036e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_372;
            }
            C2Rust_Block_5::S_372 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_374;
            }
            C2Rust_Block_5::S_374 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_380;
            }
            C2Rust_Block_5::S_380 => {
                sub_001D120E();
                c2rust_current_block_5 = C2Rust_Block_5::S_386;
            }
            C2Rust_Block_5::S_386 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_388;
            }
            C2Rust_Block_5::S_388 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_390;
            }
            C2Rust_Block_5::S_390 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_392;
            }
            C2Rust_Block_5::S_392 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_394;
            }
            C2Rust_Block_5::S_394 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_979;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_407;
                }
            }
            C2Rust_Block_5::S_407 => {
                _pv_10 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_409;
            }
            C2Rust_Block_5::S_409 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_411;
            }
            C2Rust_Block_5::S_411 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_417;
            }
            C2Rust_Block_5::S_417 => {
                (*__gamepkg_tls_g_eax) = ebp.wrapping_add(8 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_423;
            }
            C2Rust_Block_5::S_423 => {
                _pv_11 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_425;
            }
            C2Rust_Block_5::S_425 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_427;
            }
            C2Rust_Block_5::S_427 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_437;
            }
            C2Rust_Block_5::S_437 => {
                _pv_12 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_439;
            }
            C2Rust_Block_5::S_439 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_441;
            }
            C2Rust_Block_5::S_441 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_451;
            }
            C2Rust_Block_5::S_451 => {
                _pv_13 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_453;
            }
            C2Rust_Block_5::S_453 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_455;
            }
            C2Rust_Block_5::S_455 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_465;
            }
            C2Rust_Block_5::S_465 => {
                _pv_14 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_467;
            }
            C2Rust_Block_5::S_467 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_469;
            }
            C2Rust_Block_5::S_469 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_475;
            }
            C2Rust_Block_5::S_475 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_477;
            }
            C2Rust_Block_5::S_477 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_483;
            }
            C2Rust_Block_5::S_483 => {
                _pv_15 = 0x21038d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_485;
            }
            C2Rust_Block_5::S_485 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_487;
            }
            C2Rust_Block_5::S_487 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_493;
            }
            C2Rust_Block_5::S_493 => {
                sub_001D10B4();
                c2rust_current_block_5 = C2Rust_Block_5::S_499;
            }
            C2Rust_Block_5::S_499 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_501;
            }
            C2Rust_Block_5::S_501 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_503;
            }
            C2Rust_Block_5::S_503 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_505;
            }
            C2Rust_Block_5::S_505 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_507;
            }
            C2Rust_Block_5::S_507 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_979;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_516;
                }
            }
            C2Rust_Block_5::S_516 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_518;
            }
            C2Rust_Block_5::S_518 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_520;
            }
            C2Rust_Block_5::S_520 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_522;
            }
            C2Rust_Block_5::S_522 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_524;
            }
            C2Rust_Block_5::S_524 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_526;
            }
            C2Rust_Block_5::S_526 => {
                if _fa != _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_979;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_535;
                }
            }
            C2Rust_Block_5::S_535 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_537;
            }
            C2Rust_Block_5::S_537 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_539;
            }
            C2Rust_Block_5::S_539 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_541;
            }
            C2Rust_Block_5::S_541 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_543;
            }
            C2Rust_Block_5::S_543 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_545;
            }
            C2Rust_Block_5::S_545 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_547;
            }
            C2Rust_Block_5::S_547 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_549;
            }
            C2Rust_Block_5::S_549 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_551;
            }
            C2Rust_Block_5::S_551 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_553;
            }
            C2Rust_Block_5::S_553 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_555;
            }
            C2Rust_Block_5::S_555 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_557;
            }
            C2Rust_Block_5::S_557 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_993;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_570;
                }
            }
            C2Rust_Block_5::S_570 => {
                _pv_16 = 8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_572;
            }
            C2Rust_Block_5::S_572 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_574;
            }
            C2Rust_Block_5::S_574 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_580;
            }
            C2Rust_Block_5::S_580 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        (0x76b400 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x70 as uint16_t,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_582;
            }
            C2Rust_Block_5::S_582 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        (0x76b402 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_584;
            }
            C2Rust_Block_5::S_584 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b408 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_586;
            }
            C2Rust_Block_5::S_586 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b404 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_588;
            }
            C2Rust_Block_5::S_588 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_590;
            }
            C2Rust_Block_5::S_590 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_596;
            }
            C2Rust_Block_5::S_596 => {
                _pv_17 = 0x2103c6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_598;
            }
            C2Rust_Block_5::S_598 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_600;
            }
            C2Rust_Block_5::S_600 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_606;
            }
            C2Rust_Block_5::S_606 => {
                sub_001CF843();
                c2rust_current_block_5 = C2Rust_Block_5::S_612;
            }
            C2Rust_Block_5::S_612 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_614;
            }
            C2Rust_Block_5::S_614 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_616;
            }
            C2Rust_Block_5::S_616 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_618;
            }
            C2Rust_Block_5::S_618 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_620;
            }
            C2Rust_Block_5::S_620 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_622;
            }
            C2Rust_Block_5::S_622 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_979;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_631;
                }
            }
            C2Rust_Block_5::S_631 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b358 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_633;
            }
            C2Rust_Block_5::S_633 => {
                _fb = 0xffffffdc as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_635;
            }
            C2Rust_Block_5::S_635 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_637;
            }
            C2Rust_Block_5::S_637 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0xffffffdc as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_639;
            }
            C2Rust_Block_5::S_639 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_641;
            }
            C2Rust_Block_5::S_641 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_647;
            }
            C2Rust_Block_5::S_647 => {
                _pv_18 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_649;
            }
            C2Rust_Block_5::S_649 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_651;
            }
            C2Rust_Block_5::S_651 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_661;
            }
            C2Rust_Block_5::S_661 => {
                _pv_19 = 0x76b364 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_663;
            }
            C2Rust_Block_5::S_663 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_665;
            }
            C2Rust_Block_5::S_665 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_675;
            }
            C2Rust_Block_5::S_675 => {
                _pv_20 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_5 = C2Rust_Block_5::S_677;
            }
            C2Rust_Block_5::S_677 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_679;
            }
            C2Rust_Block_5::S_679 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_685;
            }
            C2Rust_Block_5::S_685 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_687;
            }
            C2Rust_Block_5::S_687 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_693;
            }
            C2Rust_Block_5::S_693 => {
                _pv_21 = 0x2103e1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_695;
            }
            C2Rust_Block_5::S_695 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_697;
            }
            C2Rust_Block_5::S_697 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_703;
            }
            C2Rust_Block_5::S_703 => {
                sub_001CF857();
                c2rust_current_block_5 = C2Rust_Block_5::S_713;
            }
            C2Rust_Block_5::S_713 => {
                _pv_22 = 0xc as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_715;
            }
            C2Rust_Block_5::S_715 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_717;
            }
            C2Rust_Block_5::S_717 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_723;
            }
            C2Rust_Block_5::S_723 => {
                (*__gamepkg_tls_g_esi) = 0x76b400 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_729;
            }
            C2Rust_Block_5::S_729 => {
                _pv_23 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_731;
            }
            C2Rust_Block_5::S_731 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_733;
            }
            C2Rust_Block_5::S_733 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_743;
            }
            C2Rust_Block_5::S_743 => {
                _pv_24 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_5 = C2Rust_Block_5::S_745;
            }
            C2Rust_Block_5::S_745 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_747;
            }
            C2Rust_Block_5::S_747 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_753;
            }
            C2Rust_Block_5::S_753 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_755;
            }
            C2Rust_Block_5::S_755 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_761;
            }
            C2Rust_Block_5::S_761 => {
                _pv_25 = 0x2103ef as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_763;
            }
            C2Rust_Block_5::S_763 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_765;
            }
            C2Rust_Block_5::S_765 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_771;
            }
            C2Rust_Block_5::S_771 => {
                sub_001CF857();
                c2rust_current_block_5 = C2Rust_Block_5::S_781;
            }
            C2Rust_Block_5::S_781 => {
                _pv_26 = 0x76b40c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_783;
            }
            C2Rust_Block_5::S_783 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_785;
            }
            C2Rust_Block_5::S_785 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_795;
            }
            C2Rust_Block_5::S_795 => {
                _pv_27 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_5 = C2Rust_Block_5::S_797;
            }
            C2Rust_Block_5::S_797 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_799;
            }
            C2Rust_Block_5::S_799 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_805;
            }
            C2Rust_Block_5::S_805 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_807;
            }
            C2Rust_Block_5::S_807 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_813;
            }
            C2Rust_Block_5::S_813 => {
                _pv_28 = 0x2103fa as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_815;
            }
            C2Rust_Block_5::S_815 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_817;
            }
            C2Rust_Block_5::S_817 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_823;
            }
            C2Rust_Block_5::S_823 => {
                sub_001CF8A5();
                c2rust_current_block_5 = C2Rust_Block_5::S_833;
            }
            C2Rust_Block_5::S_833 => {
                _pv_29 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_835;
            }
            C2Rust_Block_5::S_835 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_837;
            }
            C2Rust_Block_5::S_837 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_843;
            }
            C2Rust_Block_5::S_843 => {
                (*__gamepkg_tls_g_eax) = ebp.wrapping_add(8 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_849;
            }
            C2Rust_Block_5::S_849 => {
                _pv_30 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_851;
            }
            C2Rust_Block_5::S_851 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_853;
            }
            C2Rust_Block_5::S_853 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_863;
            }
            C2Rust_Block_5::S_863 => {
                _pv_31 = 0x70 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_865;
            }
            C2Rust_Block_5::S_865 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_867;
            }
            C2Rust_Block_5::S_867 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_877;
            }
            C2Rust_Block_5::S_877 => {
                _pv_32 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_879;
            }
            C2Rust_Block_5::S_879 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_881;
            }
            C2Rust_Block_5::S_881 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_891;
            }
            C2Rust_Block_5::S_891 => {
                _pv_33 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_893;
            }
            C2Rust_Block_5::S_893 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_895;
            }
            C2Rust_Block_5::S_895 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_901;
            }
            C2Rust_Block_5::S_901 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_903;
            }
            C2Rust_Block_5::S_903 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_909;
            }
            C2Rust_Block_5::S_909 => {
                _pv_34 = 0x21040d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_911;
            }
            C2Rust_Block_5::S_911 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_913;
            }
            C2Rust_Block_5::S_913 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_919;
            }
            C2Rust_Block_5::S_919 => {
                sub_001D10B4();
                c2rust_current_block_5 = C2Rust_Block_5::S_925;
            }
            C2Rust_Block_5::S_925 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_927;
            }
            C2Rust_Block_5::S_927 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_929;
            }
            C2Rust_Block_5::S_929 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_931;
            }
            C2Rust_Block_5::S_931 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_933;
            }
            C2Rust_Block_5::S_933 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_979;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_942;
                }
            }
            C2Rust_Block_5::S_942 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_944;
            }
            C2Rust_Block_5::S_944 => {
                _fb = 0x70 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_946;
            }
            C2Rust_Block_5::S_946 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_948;
            }
            C2Rust_Block_5::S_948 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_950;
            }
            C2Rust_Block_5::S_950 => {
                if _fa != _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_979;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_959;
                }
            }
            C2Rust_Block_5::S_959 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_961;
            }
            C2Rust_Block_5::S_961 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_963;
            }
            C2Rust_Block_5::S_963 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_965;
            }
            C2Rust_Block_5::S_965 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_967;
            }
            C2Rust_Block_5::S_967 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_969;
            }
            C2Rust_Block_5::S_969 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_971;
            }
            C2Rust_Block_5::S_971 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_993;
            }
            C2Rust_Block_5::S_979 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_981;
            }
            C2Rust_Block_5::S_981 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_983;
            }
            C2Rust_Block_5::S_983 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_993;
            }
            C2Rust_Block_5::S_993 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_995;
            }
            C2Rust_Block_5::S_995 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_1005;
            }
            C2Rust_Block_5::S_1005 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_1007;
            }
            C2Rust_Block_5::S_1007 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_1017;
            }
            C2Rust_Block_5::S_1017 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_1019;
            }
            C2Rust_Block_5::S_1019 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_1025;
            }
            C2Rust_Block_5::S_1025 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_1031;
            }
            C2Rust_Block_5::S_1031 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_1033;
            }
            C2Rust_Block_5::S_1033 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_1039;
            }
            C2Rust_Block_5::S_1039 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_1041;
            }
            C2Rust_Block_5::S_1041 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210425() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _d_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_0: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_0: uint32_t = 0;
    let mut _i_1: uint32_t = 0;
    let mut _i_2: uint32_t = 0;
    let mut _d_1: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_1: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_1: uint32_t = 0;
    let mut _i_3: uint32_t = 0;
    let mut _i_4: uint32_t = 0;
    let mut _d_2: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s_2: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n_2: uint32_t = 0;
    let mut _i_5: uint32_t = 0;
    let mut _i_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    let mut _pv_36: uint32_t = 0;
    let mut _pv_37: uint32_t = 0;
    let mut _pv_38: uint32_t = 0;
    let mut _pv_39: uint32_t = 0;
    let mut _pv_40: uint32_t = 0;
    let mut _pv_41: uint32_t = 0;
    let mut _pv_42: uint32_t = 0;
    let mut _pv_43: uint32_t = 0;
    let mut _pv_44: uint32_t = 0;
    let mut _pv_45: uint32_t = 0;
    let mut _pv_46: uint32_t = 0;
    let mut _pv_47: uint32_t = 0;
    let mut _pv_48: uint32_t = 0;
    let mut _pv_49: uint32_t = 0;
    let mut _pv_50: uint32_t = 0;
    let mut _pv_51: uint32_t = 0;
    let mut _pv_52: uint32_t = 0;
    let mut _pv_53: uint32_t = 0;
    let mut _pv_54: uint32_t = 0;
    enum C2Rust_Block_6 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_60,
        S_62,
        S_64,
        S_70,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_93,
        S_99,
        S_101,
        S_107,
        S_109,
        S_115,
        S_117,
        S_123,
        S_125,
        S_127,
        S_133,
        S_135,
        S_137,
        S_139,
        S_141,
        S_147,
        S_149,
        S_151,
        S_157,
        S_159,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_221,
        S_223,
        S_225,
        S_227,
        S_229,
        S_235,
        S_237,
        S_239,
        S_241,
        S_243,
        S_245,
        S_247,
        S_249,
        S_251,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_286,
        S_288,
        S_290,
        S_296,
        S_298,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_395,
        S_397,
        S_399,
        S_409,
        S_411,
        S_413,
        S_419,
        S_421,
        S_423,
        S_429,
        S_431,
        S_433,
        S_439,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_455,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_517,
        S_519,
        S_528,
        S_530,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_546,
        S_548,
        S_550,
        S_552,
        S_556,
        S_559,
        S_560,
        S_561,
        S_562,
        S_573,
        S_575,
        S_580,
        S_583,
        S_584,
        S_585,
        S_586,
        S_593,
        S_595,
        S_601,
        S_603,
        S_605,
        S_607,
        S_609,
        S_611,
        S_615,
        S_617,
        S_619,
        S_621,
        S_625,
        S_628,
        S_629,
        S_630,
        S_631,
        S_642,
        S_644,
        S_649,
        S_652,
        S_653,
        S_654,
        S_655,
        S_662,
        S_664,
        S_670,
        S_672,
        S_674,
        S_676,
        S_678,
        S_680,
        S_682,
        S_688,
        S_690,
        S_692,
        S_694,
        S_696,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_717,
        S_723,
        S_725,
        S_727,
        S_729,
        S_731,
        S_733,
        S_735,
        S_737,
        S_739,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_753,
        S_755,
        S_757,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_776,
        S_778,
        S_787,
        S_789,
        S_791,
        S_793,
        S_795,
        S_797,
        S_799,
        S_801,
        S_803,
        S_805,
        S_807,
        S_809,
        S_811,
        S_813,
        S_815,
        S_817,
        S_819,
        S_821,
        S_823,
        S_825,
        S_827,
        S_829,
        S_831,
        S_833,
        S_835,
        S_837,
        S_841,
        S_843,
        S_845,
        S_847,
        S_851,
        S_854,
        S_855,
        S_856,
        S_857,
        S_868,
        S_870,
        S_875,
        S_878,
        S_879,
        S_880,
        S_881,
        S_888,
        S_890,
        S_896,
        S_898,
        S_900,
        S_902,
        S_904,
        S_906,
        S_908,
        S_912,
        S_914,
        S_916,
        S_918,
        S_922,
        S_925,
        S_926,
        S_927,
        S_928,
        S_939,
        S_941,
        S_946,
        S_949,
        S_950,
        S_951,
        S_952,
        S_959,
        S_961,
        S_967,
        S_969,
        S_971,
        S_973,
        S_975,
        S_977,
        S_979,
        S_981,
        S_987,
        S_989,
        S_991,
        S_993,
        S_995,
        S_997,
        S_999,
        S_1001,
        S_1003,
        S_1005,
        S_1007,
        S_1020,
        S_1022,
        S_1024,
        S_1034,
        S_1036,
        S_1038,
        S_1048,
        S_1050,
        S_1052,
        S_1062,
        S_1064,
        S_1066,
        S_1072,
        S_1074,
        S_1080,
        S_1082,
        S_1084,
        S_1090,
        S_1096,
        S_1098,
        S_1100,
        S_1102,
        S_1104,
        S_1106,
        S_1108,
        S_1110,
        S_1112,
        S_1114,
        S_1116,
        S_1122,
        S_1124,
        S_1126,
        S_1136,
        S_1138,
        S_1140,
        S_1146,
        S_1148,
        S_1150,
        S_1156,
        S_1158,
        S_1160,
        S_1166,
        S_1168,
        S_1174,
        S_1176,
        S_1178,
        S_1184,
        S_1190,
        S_1192,
        S_1194,
        S_1196,
        S_1198,
        S_1200,
        S_1202,
        S_1204,
        S_1213,
        S_1215,
        S_1217,
        S_1219,
        S_1221,
        S_1234,
        S_1236,
        S_1238,
        S_1244,
        S_1246,
        S_1248,
        S_1250,
        S_1252,
        S_1258,
        S_1260,
        S_1262,
        S_1272,
        S_1274,
        S_1276,
        S_1282,
        S_1284,
        S_1290,
        S_1292,
        S_1294,
        S_1300,
        S_1306,
        S_1308,
        S_1310,
        S_1312,
        S_1314,
        S_1316,
        S_1318,
        S_1320,
        S_1322,
        S_1324,
        S_1337,
        S_1339,
        S_1341,
        S_1351,
        S_1353,
        S_1355,
        S_1365,
        S_1367,
        S_1369,
        S_1375,
        S_1377,
        S_1383,
        S_1385,
        S_1387,
        S_1393,
        S_1399,
        S_1405,
        S_1407,
        S_1409,
        S_1415,
        S_1417,
        S_1419,
        S_1421,
        S_1427,
        S_1429,
        S_1431,
        S_1441,
        S_1443,
        S_1445,
        S_1451,
        S_1453,
        S_1459,
        S_1461,
        S_1463,
        S_1469,
        S_1475,
        S_1477,
        S_1479,
        S_1485,
        S_1487,
        S_1489,
        S_1495,
        S_1501,
        S_1503,
        S_1505,
        S_1511,
        S_1513,
        S_1515,
        S_1517,
        S_1519,
        S_1521,
        S_1523,
        S_1529,
        S_1531,
        S_1533,
        S_1539,
        S_1545,
        S_1547,
        S_1549,
        S_1551,
        S_1553,
        S_1555,
        S_1557,
        S_1559,
        S_1565,
        S_1567,
        S_1569,
        S_1575,
        S_1581,
        S_1583,
        S_1585,
        S_1591,
        S_1593,
        S_1595,
        S_1601,
        S_1603,
        S_1605,
        S_1611,
        S_1617,
        S_1619,
        S_1621,
        S_1627,
        S_1629,
        S_1631,
        S_1641,
        S_1643,
        S_1645,
        S_1651,
        S_1653,
        S_1655,
        S_1661,
        S_1663,
        S_1665,
        S_1671,
        S_1677,
        S_1679,
        S_1681,
        S_1683,
        S_1685,
        S_1698,
        S_1700,
        S_1702,
        S_1712,
        S_1714,
        S_1716,
        S_1722,
        S_1724,
        S_1730,
        S_1732,
        S_1734,
        S_1740,
        S_1746,
        S_1748,
        S_1750,
        S_1752,
        S_1754,
        S_1767,
        S_1769,
        S_1771,
        S_1781,
        S_1783,
        S_1785,
        S_1791,
        S_1793,
        S_1799,
        S_1801,
        S_1803,
        S_1809,
        S_1815,
        S_1817,
        S_1819,
        S_1821,
        S_1823,
        S_1832,
        S_1844,
        S_1846,
        S_1848,
        S_1854,
        S_1856,
        S_1862,
        S_1864,
        S_1866,
        S_1872,
        S_1878,
        S_1880,
        S_1882,
        S_1890,
        S_1892,
        S_1894,
        S_1900,
        S_1902,
        S_1904,
        S_1914,
        S_1916,
        S_1918,
        S_1928,
        S_1930,
        S_1932,
        S_1942,
        S_1944,
        S_1946,
        S_1952,
        S_1954,
        S_1960,
        S_1962,
        S_1964,
        S_1970,
        S_1980,
        S_1982,
        S_1984,
        S_1990,
        S_1992,
        S_1998,
        S_2000,
        S_2002,
        S_2008,
        S_2018,
        S_2020,
        S_2022,
        S_2028,
        S_2030,
        S_2036,
        S_2038,
        S_2040,
        S_2046,
        S_2052,
        S_2054,
        S_2056,
        S_2058,
        S_2060,
        S_2062,
        S_2064,
        S_2070,
        S_2072,
        S_2074,
        S_2080,
        S_2086,
        S_2096,
        S_2098,
        S_2108,
        S_2110,
        S_2120,
        S_2122,
        S_2128,
        S_2134,
        S_2136,
        S_2142,
        S_2144,
    }
    let mut c2rust_current_block_6: C2Rust_Block_6;
    c2rust_current_block_6 = C2Rust_Block_6::S_0;
    loop {
        match c2rust_current_block_6 {
            C2Rust_Block_6::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2;
            }
            C2Rust_Block_6::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_6 = C2Rust_Block_6::S_4;
            }
            C2Rust_Block_6::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_6;
            }
            C2Rust_Block_6::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_8;
            }
            C2Rust_Block_6::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_26;
            }
            C2Rust_Block_6::S_26 => {
                _pv = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_28;
            }
            C2Rust_Block_6::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_30;
            }
            C2Rust_Block_6::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_36;
            }
            C2Rust_Block_6::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_6 = C2Rust_Block_6::S_38;
            }
            C2Rust_Block_6::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_40;
            }
            C2Rust_Block_6::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_42;
            }
            C2Rust_Block_6::S_42 => {
                _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_44;
            }
            C2Rust_Block_6::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_46;
            }
            C2Rust_Block_6::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x14 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_48;
            }
            C2Rust_Block_6::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_50;
            }
            C2Rust_Block_6::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_52;
            }
            C2Rust_Block_6::S_52 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_54;
            }
            C2Rust_Block_6::S_54 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_60;
            }
            C2Rust_Block_6::S_60 => {
                _pv_0 = 0x210430 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_62;
            }
            C2Rust_Block_6::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_64;
            }
            C2Rust_Block_6::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_70;
            }
            C2Rust_Block_6::S_70 => {
                sub_002100F9();
                c2rust_current_block_6 = C2Rust_Block_6::S_76;
            }
            C2Rust_Block_6::S_76 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_78;
            }
            C2Rust_Block_6::S_78 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_80;
            }
            C2Rust_Block_6::S_80 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_82;
            }
            C2Rust_Block_6::S_82 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_84;
            }
            C2Rust_Block_6::S_84 => {
                if _fa != _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_115;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_93;
                }
            }
            C2Rust_Block_6::S_93 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_99;
            }
            C2Rust_Block_6::S_99 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_101;
            }
            C2Rust_Block_6::S_101 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_107;
            }
            C2Rust_Block_6::S_107 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_109;
            }
            C2Rust_Block_6::S_109 => return,
            C2Rust_Block_6::S_115 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_117;
            }
            C2Rust_Block_6::S_117 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b594 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_123;
            }
            C2Rust_Block_6::S_123 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_125;
            }
            C2Rust_Block_6::S_125 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_127;
            }
            C2Rust_Block_6::S_127 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_133;
            }
            C2Rust_Block_6::S_133 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_135;
            }
            C2Rust_Block_6::S_135 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_137;
            }
            C2Rust_Block_6::S_137 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_139;
            }
            C2Rust_Block_6::S_139 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_141;
            }
            C2Rust_Block_6::S_141 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_147;
            }
            C2Rust_Block_6::S_147 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_149;
            }
            C2Rust_Block_6::S_149 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_151;
            }
            C2Rust_Block_6::S_151 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_157;
            }
            C2Rust_Block_6::S_157 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_159;
            }
            C2Rust_Block_6::S_159 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_161;
            }
            C2Rust_Block_6::S_161 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_163;
            }
            C2Rust_Block_6::S_163 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_165;
            }
            C2Rust_Block_6::S_165 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_167;
            }
            C2Rust_Block_6::S_167 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_169;
            }
            C2Rust_Block_6::S_169 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_171;
            }
            C2Rust_Block_6::S_171 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_173;
            }
            C2Rust_Block_6::S_173 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_175;
            }
            C2Rust_Block_6::S_175 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_177;
            }
            C2Rust_Block_6::S_177 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_179;
            }
            C2Rust_Block_6::S_179 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_181;
            }
            C2Rust_Block_6::S_181 => {
                if _fa <= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_260;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_190;
                }
            }
            C2Rust_Block_6::S_190 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b590 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_192;
            }
            C2Rust_Block_6::S_192 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_194;
            }
            C2Rust_Block_6::S_194 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_196;
            }
            C2Rust_Block_6::S_196 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_198;
            }
            C2Rust_Block_6::S_198 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_200;
            }
            C2Rust_Block_6::S_200 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_202;
            }
            C2Rust_Block_6::S_202 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_204;
            }
            C2Rust_Block_6::S_204 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_206;
            }
            C2Rust_Block_6::S_206 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_208;
            }
            C2Rust_Block_6::S_208 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_210;
            }
            C2Rust_Block_6::S_210 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_212;
            }
            C2Rust_Block_6::S_212 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_235;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_221;
                }
            }
            C2Rust_Block_6::S_221 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_223;
            }
            C2Rust_Block_6::S_223 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_225;
            }
            C2Rust_Block_6::S_225 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_227;
            }
            C2Rust_Block_6::S_227 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_229;
            }
            C2Rust_Block_6::S_229 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_235;
            }
            C2Rust_Block_6::S_235 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_237;
            }
            C2Rust_Block_6::S_237 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_239;
            }
            C2Rust_Block_6::S_239 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_241;
            }
            C2Rust_Block_6::S_241 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_243;
            }
            C2Rust_Block_6::S_243 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_245;
            }
            C2Rust_Block_6::S_245 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_247;
            }
            C2Rust_Block_6::S_247 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_249;
            }
            C2Rust_Block_6::S_249 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_251;
            }
            C2Rust_Block_6::S_251 => {
                if _fa < _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_190;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_260;
                }
            }
            C2Rust_Block_6::S_260 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(3 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_262;
            }
            C2Rust_Block_6::S_262 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) & 0xfffffffc as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_264;
            }
            C2Rust_Block_6::S_264 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_266;
            }
            C2Rust_Block_6::S_266 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_268;
            }
            C2Rust_Block_6::S_268 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_270;
            }
            C2Rust_Block_6::S_270 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_272;
            }
            C2Rust_Block_6::S_272 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_274;
            }
            C2Rust_Block_6::S_274 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_276;
            }
            C2Rust_Block_6::S_276 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_278;
            }
            C2Rust_Block_6::S_278 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_280;
            }
            C2Rust_Block_6::S_280 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_286;
            }
            C2Rust_Block_6::S_286 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_6 = C2Rust_Block_6::S_288;
            }
            C2Rust_Block_6::S_288 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_290;
            }
            C2Rust_Block_6::S_290 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_296;
            }
            C2Rust_Block_6::S_296 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_298;
            }
            C2Rust_Block_6::S_298 => {
                if _fa <= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_381;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_307;
                }
            }
            C2Rust_Block_6::S_307 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edi) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_309;
            }
            C2Rust_Block_6::S_309 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_311;
            }
            C2Rust_Block_6::S_311 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_313;
            }
            C2Rust_Block_6::S_313 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_315;
            }
            C2Rust_Block_6::S_315 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_317;
            }
            C2Rust_Block_6::S_317 => {
                if _fa != _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1844;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_326;
                }
            }
            C2Rust_Block_6::S_326 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_328;
            }
            C2Rust_Block_6::S_328 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_330;
            }
            C2Rust_Block_6::S_330 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_332;
            }
            C2Rust_Block_6::S_332 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_334;
            }
            C2Rust_Block_6::S_334 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_336;
            }
            C2Rust_Block_6::S_336 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(2 as uint32_t))
                    .wrapping_add(0xf as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_338;
            }
            C2Rust_Block_6::S_338 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xfffffffc as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_340;
            }
            C2Rust_Block_6::S_340 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_342;
            }
            C2Rust_Block_6::S_342 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_344;
            }
            C2Rust_Block_6::S_344 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_346;
            }
            C2Rust_Block_6::S_346 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_348;
            }
            C2Rust_Block_6::S_348 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_350;
            }
            C2Rust_Block_6::S_350 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_352;
            }
            C2Rust_Block_6::S_352 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_354;
            }
            C2Rust_Block_6::S_354 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_356;
            }
            C2Rust_Block_6::S_356 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_358;
            }
            C2Rust_Block_6::S_358 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_360;
            }
            C2Rust_Block_6::S_360 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_362;
            }
            C2Rust_Block_6::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_364;
            }
            C2Rust_Block_6::S_364 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_366;
            }
            C2Rust_Block_6::S_366 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_368;
            }
            C2Rust_Block_6::S_368 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_370;
            }
            C2Rust_Block_6::S_370 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_372;
            }
            C2Rust_Block_6::S_372 => {
                if _fa < _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_307;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_381;
                }
            }
            C2Rust_Block_6::S_381 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_383;
            }
            C2Rust_Block_6::S_383 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_385;
            }
            C2Rust_Block_6::S_385 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_esi));
                c2rust_current_block_6 = C2Rust_Block_6::S_387;
            }
            C2Rust_Block_6::S_387 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_389;
            }
            C2Rust_Block_6::S_389 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_395;
            }
            C2Rust_Block_6::S_395 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_397;
            }
            C2Rust_Block_6::S_397 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_399;
            }
            C2Rust_Block_6::S_399 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_409;
            }
            C2Rust_Block_6::S_409 => {
                _pv_5 = 0x40 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_411;
            }
            C2Rust_Block_6::S_411 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_413;
            }
            C2Rust_Block_6::S_413 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_419;
            }
            C2Rust_Block_6::S_419 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_421;
            }
            C2Rust_Block_6::S_421 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_423;
            }
            C2Rust_Block_6::S_423 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_429;
            }
            C2Rust_Block_6::S_429 => {
                _pv_6 = 0x2104c1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_431;
            }
            C2Rust_Block_6::S_431 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_433;
            }
            C2Rust_Block_6::S_433 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_439;
            }
            C2Rust_Block_6::S_439 => {
                sub_001D407C();
                c2rust_current_block_6 = C2Rust_Block_6::S_445;
            }
            C2Rust_Block_6::S_445 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_447;
            }
            C2Rust_Block_6::S_447 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_449;
            }
            C2Rust_Block_6::S_449 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_451;
            }
            C2Rust_Block_6::S_451 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_453;
            }
            C2Rust_Block_6::S_453 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_455;
            }
            C2Rust_Block_6::S_455 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1878;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_464;
                }
            }
            C2Rust_Block_6::S_464 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_466;
            }
            C2Rust_Block_6::S_466 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_468;
            }
            C2Rust_Block_6::S_468 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b594 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_470;
            }
            C2Rust_Block_6::S_470 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_472;
            }
            C2Rust_Block_6::S_472 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_474;
            }
            C2Rust_Block_6::S_474 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_476;
            }
            C2Rust_Block_6::S_476 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_478;
            }
            C2Rust_Block_6::S_478 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_480;
            }
            C2Rust_Block_6::S_480 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_482;
            }
            C2Rust_Block_6::S_482 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_484;
            }
            C2Rust_Block_6::S_484 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_486;
            }
            C2Rust_Block_6::S_486 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_488;
            }
            C2Rust_Block_6::S_488 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b594 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_490;
            }
            C2Rust_Block_6::S_490 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_492;
            }
            C2Rust_Block_6::S_492 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_494;
            }
            C2Rust_Block_6::S_494 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_496;
            }
            C2Rust_Block_6::S_496 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_498;
            }
            C2Rust_Block_6::S_498 => {
                if _fa >= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_723;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_507;
                }
            }
            C2Rust_Block_6::S_507 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b590 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_509;
            }
            C2Rust_Block_6::S_509 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_511;
            }
            C2Rust_Block_6::S_511 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_513;
            }
            C2Rust_Block_6::S_513 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_515;
            }
            C2Rust_Block_6::S_515 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_517;
            }
            C2Rust_Block_6::S_517 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_519;
            }
            C2Rust_Block_6::S_519 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_688;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_528;
                }
            }
            C2Rust_Block_6::S_528 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_530;
            }
            C2Rust_Block_6::S_530 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_532;
            }
            C2Rust_Block_6::S_532 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_534;
            }
            C2Rust_Block_6::S_534 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_536;
            }
            C2Rust_Block_6::S_536 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_538;
            }
            C2Rust_Block_6::S_538 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_540;
            }
            C2Rust_Block_6::S_540 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_6 = C2Rust_Block_6::S_542;
            }
            C2Rust_Block_6::S_542 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_546;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_580;
                }
            }
            C2Rust_Block_6::S_546 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_548;
            }
            C2Rust_Block_6::S_548 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_550;
            }
            C2Rust_Block_6::S_550 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_6 = C2Rust_Block_6::S_552;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_556;
                }
            }
            C2Rust_Block_6::S_552 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_573;
            }
            C2Rust_Block_6::S_556 => {
                _i = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_559;
            }
            C2Rust_Block_6::S_559 => {
                _i = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_560;
            }
            C2Rust_Block_6::S_560 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_6 = C2Rust_Block_6::S_561;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_573;
                }
            }
            C2Rust_Block_6::S_561 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_562;
            }
            C2Rust_Block_6::S_562 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_560;
            }
            C2Rust_Block_6::S_573 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_575;
            }
            C2Rust_Block_6::S_575 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_601;
            }
            C2Rust_Block_6::S_580 => {
                _i_0 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_583;
            }
            C2Rust_Block_6::S_583 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_584;
            }
            C2Rust_Block_6::S_584 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_6 = C2Rust_Block_6::S_585;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_593;
                }
            }
            C2Rust_Block_6::S_585 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_586;
            }
            C2Rust_Block_6::S_586 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_584;
            }
            C2Rust_Block_6::S_593 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_595;
            }
            C2Rust_Block_6::S_595 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_601;
            }
            C2Rust_Block_6::S_601 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_603;
            }
            C2Rust_Block_6::S_603 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_605;
            }
            C2Rust_Block_6::S_605 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_607;
            }
            C2Rust_Block_6::S_607 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_609;
            }
            C2Rust_Block_6::S_609 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_611;
            }
            C2Rust_Block_6::S_611 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_615;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_649;
                }
            }
            C2Rust_Block_6::S_615 => {
                _d_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_0 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_617;
            }
            C2Rust_Block_6::S_617 => {
                _n_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_619;
            }
            C2Rust_Block_6::S_619 => {
                if _d_0.offset(_n_0 as isize) <= _s_0
                    || _s_0.offset(_n_0 as isize) <= _d_0
                {
                    c2rust_current_block_6 = C2Rust_Block_6::S_621;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_625;
                }
            }
            C2Rust_Block_6::S_621 => {
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_642;
            }
            C2Rust_Block_6::S_625 => {
                _i_1 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_628;
            }
            C2Rust_Block_6::S_628 => {
                _i_1 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_629;
            }
            C2Rust_Block_6::S_629 => {
                if _i_1 < _n_0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_630;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_642;
                }
            }
            C2Rust_Block_6::S_630 => {
                *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                c2rust_current_block_6 = C2Rust_Block_6::S_631;
            }
            C2Rust_Block_6::S_631 => {
                _i_1 = _i_1.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_629;
            }
            C2Rust_Block_6::S_642 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_644;
            }
            C2Rust_Block_6::S_644 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_670;
            }
            C2Rust_Block_6::S_649 => {
                _i_2 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_652;
            }
            C2Rust_Block_6::S_652 => {
                _i_2 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_653;
            }
            C2Rust_Block_6::S_653 => {
                if _i_2 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_6 = C2Rust_Block_6::S_654;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_662;
                }
            }
            C2Rust_Block_6::S_654 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_655;
            }
            C2Rust_Block_6::S_655 => {
                _i_2 = _i_2.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_653;
            }
            C2Rust_Block_6::S_662 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_664;
            }
            C2Rust_Block_6::S_664 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_670;
            }
            C2Rust_Block_6::S_670 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_672;
            }
            C2Rust_Block_6::S_672 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_674;
            }
            C2Rust_Block_6::S_674 => {
                _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_676;
            }
            C2Rust_Block_6::S_676 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_678;
            }
            C2Rust_Block_6::S_678 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_680;
            }
            C2Rust_Block_6::S_680 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_682;
            }
            C2Rust_Block_6::S_682 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_688;
            }
            C2Rust_Block_6::S_688 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_690;
            }
            C2Rust_Block_6::S_690 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_692;
            }
            C2Rust_Block_6::S_692 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_694;
            }
            C2Rust_Block_6::S_694 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_696;
            }
            C2Rust_Block_6::S_696 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_698;
            }
            C2Rust_Block_6::S_698 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_700;
            }
            C2Rust_Block_6::S_700 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b594 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_702;
            }
            C2Rust_Block_6::S_702 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_704;
            }
            C2Rust_Block_6::S_704 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_706;
            }
            C2Rust_Block_6::S_706 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_708;
            }
            C2Rust_Block_6::S_708 => {
                if _fa < _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_507;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_717;
                }
            }
            C2Rust_Block_6::S_717 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_723;
            }
            C2Rust_Block_6::S_723 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_725;
            }
            C2Rust_Block_6::S_725 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_727;
            }
            C2Rust_Block_6::S_727 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_729;
            }
            C2Rust_Block_6::S_729 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_731;
            }
            C2Rust_Block_6::S_731 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_733;
            }
            C2Rust_Block_6::S_733 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_735;
            }
            C2Rust_Block_6::S_735 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_737;
            }
            C2Rust_Block_6::S_737 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_739;
            }
            C2Rust_Block_6::S_739 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_741;
            }
            C2Rust_Block_6::S_741 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_743;
            }
            C2Rust_Block_6::S_743 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_745;
            }
            C2Rust_Block_6::S_745 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_747;
            }
            C2Rust_Block_6::S_747 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_749;
            }
            C2Rust_Block_6::S_749 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_751;
            }
            C2Rust_Block_6::S_751 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_753;
            }
            C2Rust_Block_6::S_753 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_755;
            }
            C2Rust_Block_6::S_755 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_757;
            }
            C2Rust_Block_6::S_757 => {
                if _fa <= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1020;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_766;
                }
            }
            C2Rust_Block_6::S_766 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b590 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_768;
            }
            C2Rust_Block_6::S_768 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add(
                                (*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_770;
            }
            C2Rust_Block_6::S_770 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_772;
            }
            C2Rust_Block_6::S_772 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_774;
            }
            C2Rust_Block_6::S_774 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_776;
            }
            C2Rust_Block_6::S_776 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_778;
            }
            C2Rust_Block_6::S_778 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_987;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_787;
                }
            }
            C2Rust_Block_6::S_787 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_789;
            }
            C2Rust_Block_6::S_789 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_791;
            }
            C2Rust_Block_6::S_791 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_793;
            }
            C2Rust_Block_6::S_793 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_795;
            }
            C2Rust_Block_6::S_795 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_797;
            }
            C2Rust_Block_6::S_797 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_799;
            }
            C2Rust_Block_6::S_799 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_801;
            }
            C2Rust_Block_6::S_801 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_803;
            }
            C2Rust_Block_6::S_803 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi)
                            .wrapping_add((*__gamepkg_tls_g_ebx))
                            .wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_805;
            }
            C2Rust_Block_6::S_805 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_807;
            }
            C2Rust_Block_6::S_807 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_809;
            }
            C2Rust_Block_6::S_809 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_811;
            }
            C2Rust_Block_6::S_811 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_813;
            }
            C2Rust_Block_6::S_813 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add((*__gamepkg_tls_g_ebx))
                            .wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_815;
            }
            C2Rust_Block_6::S_815 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_817;
            }
            C2Rust_Block_6::S_817 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_819;
            }
            C2Rust_Block_6::S_819 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_821;
            }
            C2Rust_Block_6::S_821 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_edx));
                c2rust_current_block_6 = C2Rust_Block_6::S_823;
            }
            C2Rust_Block_6::S_823 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_825;
            }
            C2Rust_Block_6::S_825 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_827;
            }
            C2Rust_Block_6::S_827 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_829;
            }
            C2Rust_Block_6::S_829 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_831;
            }
            C2Rust_Block_6::S_831 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_833;
            }
            C2Rust_Block_6::S_833 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_835;
            }
            C2Rust_Block_6::S_835 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_837;
            }
            C2Rust_Block_6::S_837 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_841;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_875;
                }
            }
            C2Rust_Block_6::S_841 => {
                _d_1 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_1 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_843;
            }
            C2Rust_Block_6::S_843 => {
                _n_1 = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_845;
            }
            C2Rust_Block_6::S_845 => {
                if _d_1.offset(_n_1 as isize) <= _s_1
                    || _s_1.offset(_n_1 as isize) <= _d_1
                {
                    c2rust_current_block_6 = C2Rust_Block_6::S_847;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_851;
                }
            }
            C2Rust_Block_6::S_847 => {
                memcpy(
                    _d_1 as *mut ::core::ffi::c_void,
                    _s_1 as *const ::core::ffi::c_void,
                    _n_1 as size_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_868;
            }
            C2Rust_Block_6::S_851 => {
                _i_3 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_854;
            }
            C2Rust_Block_6::S_854 => {
                _i_3 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_855;
            }
            C2Rust_Block_6::S_855 => {
                if _i_3 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_6 = C2Rust_Block_6::S_856;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_868;
                }
            }
            C2Rust_Block_6::S_856 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i_3.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i_3.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_857;
            }
            C2Rust_Block_6::S_857 => {
                _i_3 = _i_3.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_855;
            }
            C2Rust_Block_6::S_868 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_870;
            }
            C2Rust_Block_6::S_870 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_896;
            }
            C2Rust_Block_6::S_875 => {
                _i_4 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_878;
            }
            C2Rust_Block_6::S_878 => {
                _i_4 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_879;
            }
            C2Rust_Block_6::S_879 => {
                if _i_4 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_6 = C2Rust_Block_6::S_880;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_888;
                }
            }
            C2Rust_Block_6::S_880 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_4.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_4.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_881;
            }
            C2Rust_Block_6::S_881 => {
                _i_4 = _i_4.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_879;
            }
            C2Rust_Block_6::S_888 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_890;
            }
            C2Rust_Block_6::S_890 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_6 = C2Rust_Block_6::S_896;
            }
            C2Rust_Block_6::S_896 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_898;
            }
            C2Rust_Block_6::S_898 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_6 = C2Rust_Block_6::S_900;
            }
            C2Rust_Block_6::S_900 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_902;
            }
            C2Rust_Block_6::S_902 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_904;
            }
            C2Rust_Block_6::S_904 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_906;
            }
            C2Rust_Block_6::S_906 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_908;
            }
            C2Rust_Block_6::S_908 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_912;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_946;
                }
            }
            C2Rust_Block_6::S_912 => {
                _d_2 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s_2 = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_914;
            }
            C2Rust_Block_6::S_914 => {
                _n_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_916;
            }
            C2Rust_Block_6::S_916 => {
                if _d_2.offset(_n_2 as isize) <= _s_2
                    || _s_2.offset(_n_2 as isize) <= _d_2
                {
                    c2rust_current_block_6 = C2Rust_Block_6::S_918;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_922;
                }
            }
            C2Rust_Block_6::S_918 => {
                memcpy(
                    _d_2 as *mut ::core::ffi::c_void,
                    _s_2 as *const ::core::ffi::c_void,
                    _n_2 as size_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_939;
            }
            C2Rust_Block_6::S_922 => {
                _i_5 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_925;
            }
            C2Rust_Block_6::S_925 => {
                _i_5 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_926;
            }
            C2Rust_Block_6::S_926 => {
                if _i_5 < _n_2 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_927;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_939;
                }
            }
            C2Rust_Block_6::S_927 => {
                *_d_2.offset(_i_5 as isize) = *_s_2.offset(_i_5 as isize);
                c2rust_current_block_6 = C2Rust_Block_6::S_928;
            }
            C2Rust_Block_6::S_928 => {
                _i_5 = _i_5.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_926;
            }
            C2Rust_Block_6::S_939 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_941;
            }
            C2Rust_Block_6::S_941 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_967;
            }
            C2Rust_Block_6::S_946 => {
                _i_6 = 0;
                c2rust_current_block_6 = C2Rust_Block_6::S_949;
            }
            C2Rust_Block_6::S_949 => {
                _i_6 = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_950;
            }
            C2Rust_Block_6::S_950 => {
                if _i_6 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_6 = C2Rust_Block_6::S_951;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_959;
                }
            }
            C2Rust_Block_6::S_951 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_sub(_i_6) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_sub(_i_6) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_952;
            }
            C2Rust_Block_6::S_952 => {
                _i_6 = _i_6.wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_950;
            }
            C2Rust_Block_6::S_959 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_961;
            }
            C2Rust_Block_6::S_961 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_967;
            }
            C2Rust_Block_6::S_967 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_969;
            }
            C2Rust_Block_6::S_969 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_971;
            }
            C2Rust_Block_6::S_971 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_973;
            }
            C2Rust_Block_6::S_973 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_975;
            }
            C2Rust_Block_6::S_975 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_977;
            }
            C2Rust_Block_6::S_977 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_979;
            }
            C2Rust_Block_6::S_979 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_981;
            }
            C2Rust_Block_6::S_981 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_987;
            }
            C2Rust_Block_6::S_987 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_989;
            }
            C2Rust_Block_6::S_989 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_991;
            }
            C2Rust_Block_6::S_991 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_993;
            }
            C2Rust_Block_6::S_993 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_995;
            }
            C2Rust_Block_6::S_995 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_997;
            }
            C2Rust_Block_6::S_997 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_999;
            }
            C2Rust_Block_6::S_999 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1001;
            }
            C2Rust_Block_6::S_1001 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1003;
            }
            C2Rust_Block_6::S_1003 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1005;
            }
            C2Rust_Block_6::S_1005 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1007;
            }
            C2Rust_Block_6::S_1007 => {
                if _fa < _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_766;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1020;
                }
            }
            C2Rust_Block_6::S_1020 => {
                _pv_7 = 0x20fcc6 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1022;
            }
            C2Rust_Block_6::S_1022 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1024;
            }
            C2Rust_Block_6::S_1024 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1034;
            }
            C2Rust_Block_6::S_1034 => {
                _pv_8 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1036;
            }
            C2Rust_Block_6::S_1036 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1038;
            }
            C2Rust_Block_6::S_1038 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1048;
            }
            C2Rust_Block_6::S_1048 => {
                _pv_9 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1050;
            }
            C2Rust_Block_6::S_1050 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1052;
            }
            C2Rust_Block_6::S_1052 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1062;
            }
            C2Rust_Block_6::S_1062 => {
                _pv_10 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1064;
            }
            C2Rust_Block_6::S_1064 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1066;
            }
            C2Rust_Block_6::S_1066 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1072;
            }
            C2Rust_Block_6::S_1072 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1074;
            }
            C2Rust_Block_6::S_1074 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1080;
            }
            C2Rust_Block_6::S_1080 => {
                _pv_11 = 0x2105c9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1082;
            }
            C2Rust_Block_6::S_1082 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1084;
            }
            C2Rust_Block_6::S_1084 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1090;
            }
            C2Rust_Block_6::S_1090 => {
                sub_002434C0();
                c2rust_current_block_6 = C2Rust_Block_6::S_1096;
            }
            C2Rust_Block_6::S_1096 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1098;
            }
            C2Rust_Block_6::S_1098 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1100;
            }
            C2Rust_Block_6::S_1100 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1102;
            }
            C2Rust_Block_6::S_1102 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1104;
            }
            C2Rust_Block_6::S_1104 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1106;
            }
            C2Rust_Block_6::S_1106 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1108;
            }
            C2Rust_Block_6::S_1108 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1110;
            }
            C2Rust_Block_6::S_1110 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1112;
            }
            C2Rust_Block_6::S_1112 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ebx));
                c2rust_current_block_6 = C2Rust_Block_6::S_1114;
            }
            C2Rust_Block_6::S_1114 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1116;
            }
            C2Rust_Block_6::S_1116 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1122;
            }
            C2Rust_Block_6::S_1122 => {
                _pv_12 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1124;
            }
            C2Rust_Block_6::S_1124 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1126;
            }
            C2Rust_Block_6::S_1126 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1136;
            }
            C2Rust_Block_6::S_1136 => {
                _pv_13 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1138;
            }
            C2Rust_Block_6::S_1138 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1140;
            }
            C2Rust_Block_6::S_1140 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1146;
            }
            C2Rust_Block_6::S_1146 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    >> 1 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_1148;
            }
            C2Rust_Block_6::S_1148 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1150;
            }
            C2Rust_Block_6::S_1150 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1156;
            }
            C2Rust_Block_6::S_1156 => {
                _pv_14 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1158;
            }
            C2Rust_Block_6::S_1158 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1160;
            }
            C2Rust_Block_6::S_1160 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1166;
            }
            C2Rust_Block_6::S_1166 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1168;
            }
            C2Rust_Block_6::S_1168 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1174;
            }
            C2Rust_Block_6::S_1174 => {
                _pv_15 = 0x2105df as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1176;
            }
            C2Rust_Block_6::S_1176 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1178;
            }
            C2Rust_Block_6::S_1178 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1184;
            }
            C2Rust_Block_6::S_1184 => {
                sub_002101BB();
                c2rust_current_block_6 = C2Rust_Block_6::S_1190;
            }
            C2Rust_Block_6::S_1190 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1192;
            }
            C2Rust_Block_6::S_1192 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1194;
            }
            C2Rust_Block_6::S_1194 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1196;
            }
            C2Rust_Block_6::S_1196 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1198;
            }
            C2Rust_Block_6::S_1198 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1200;
            }
            C2Rust_Block_6::S_1200 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1202;
            }
            C2Rust_Block_6::S_1202 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1204;
            }
            C2Rust_Block_6::S_1204 => {
                if _fa <= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1337;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1213;
                }
            }
            C2Rust_Block_6::S_1213 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1215;
            }
            C2Rust_Block_6::S_1215 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1217;
            }
            C2Rust_Block_6::S_1217 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1219;
            }
            C2Rust_Block_6::S_1219 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1221;
            }
            C2Rust_Block_6::S_1221 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1306;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1234;
                }
            }
            C2Rust_Block_6::S_1234 => {
                _pv_16 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1236;
            }
            C2Rust_Block_6::S_1236 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1238;
            }
            C2Rust_Block_6::S_1238 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1244;
            }
            C2Rust_Block_6::S_1244 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1246;
            }
            C2Rust_Block_6::S_1246 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1248;
            }
            C2Rust_Block_6::S_1248 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_esi));
                c2rust_current_block_6 = C2Rust_Block_6::S_1250;
            }
            C2Rust_Block_6::S_1250 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1252;
            }
            C2Rust_Block_6::S_1252 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1258;
            }
            C2Rust_Block_6::S_1258 => {
                _pv_17 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1260;
            }
            C2Rust_Block_6::S_1260 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1262;
            }
            C2Rust_Block_6::S_1262 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1272;
            }
            C2Rust_Block_6::S_1272 => {
                _pv_18 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1274;
            }
            C2Rust_Block_6::S_1274 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1276;
            }
            C2Rust_Block_6::S_1276 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1282;
            }
            C2Rust_Block_6::S_1282 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1284;
            }
            C2Rust_Block_6::S_1284 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1290;
            }
            C2Rust_Block_6::S_1290 => {
                _pv_19 = 0x2105fd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1292;
            }
            C2Rust_Block_6::S_1292 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1294;
            }
            C2Rust_Block_6::S_1294 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1300;
            }
            C2Rust_Block_6::S_1300 => {
                sub_002101BB();
                c2rust_current_block_6 = C2Rust_Block_6::S_1306;
            }
            C2Rust_Block_6::S_1306 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1308;
            }
            C2Rust_Block_6::S_1308 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1310;
            }
            C2Rust_Block_6::S_1310 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1312;
            }
            C2Rust_Block_6::S_1312 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1314;
            }
            C2Rust_Block_6::S_1314 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1316;
            }
            C2Rust_Block_6::S_1316 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1318;
            }
            C2Rust_Block_6::S_1318 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1320;
            }
            C2Rust_Block_6::S_1320 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1322;
            }
            C2Rust_Block_6::S_1322 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1324;
            }
            C2Rust_Block_6::S_1324 => {
                if _fa < _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1213;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1337;
                }
            }
            C2Rust_Block_6::S_1337 => {
                _pv_20 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1339;
            }
            C2Rust_Block_6::S_1339 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1341;
            }
            C2Rust_Block_6::S_1341 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1351;
            }
            C2Rust_Block_6::S_1351 => {
                _pv_21 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1353;
            }
            C2Rust_Block_6::S_1353 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1355;
            }
            C2Rust_Block_6::S_1355 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1365;
            }
            C2Rust_Block_6::S_1365 => {
                _pv_22 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1367;
            }
            C2Rust_Block_6::S_1367 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1369;
            }
            C2Rust_Block_6::S_1369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1375;
            }
            C2Rust_Block_6::S_1375 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1377;
            }
            C2Rust_Block_6::S_1377 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1383;
            }
            C2Rust_Block_6::S_1383 => {
                _pv_23 = 0x210614 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1385;
            }
            C2Rust_Block_6::S_1385 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1387;
            }
            C2Rust_Block_6::S_1387 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1393;
            }
            C2Rust_Block_6::S_1393 => {
                sub_0021026F();
                c2rust_current_block_6 = C2Rust_Block_6::S_1399;
            }
            C2Rust_Block_6::S_1399 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1405;
            }
            C2Rust_Block_6::S_1405 => {
                _pv_24 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1407;
            }
            C2Rust_Block_6::S_1407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1409;
            }
            C2Rust_Block_6::S_1409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1415;
            }
            C2Rust_Block_6::S_1415 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_1417;
            }
            C2Rust_Block_6::S_1417 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1419;
            }
            C2Rust_Block_6::S_1419 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1421;
            }
            C2Rust_Block_6::S_1421 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1427;
            }
            C2Rust_Block_6::S_1427 => {
                _pv_25 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1429;
            }
            C2Rust_Block_6::S_1429 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1431;
            }
            C2Rust_Block_6::S_1431 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1441;
            }
            C2Rust_Block_6::S_1441 => {
                _pv_26 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1443;
            }
            C2Rust_Block_6::S_1443 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1445;
            }
            C2Rust_Block_6::S_1445 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1451;
            }
            C2Rust_Block_6::S_1451 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1453;
            }
            C2Rust_Block_6::S_1453 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1459;
            }
            C2Rust_Block_6::S_1459 => {
                _pv_27 = 0x210625 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1461;
            }
            C2Rust_Block_6::S_1461 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1463;
            }
            C2Rust_Block_6::S_1463 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1469;
            }
            C2Rust_Block_6::S_1469 => {
                sub_0021026F();
                c2rust_current_block_6 = C2Rust_Block_6::S_1475;
            }
            C2Rust_Block_6::S_1475 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(2 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1477;
            }
            C2Rust_Block_6::S_1477 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1479;
            }
            C2Rust_Block_6::S_1479 => {
                (*__gamepkg_tls_g_eax) = 0x88 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1485;
            }
            C2Rust_Block_6::S_1485 => {
                _pv_28 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_1487;
            }
            C2Rust_Block_6::S_1487 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1489;
            }
            C2Rust_Block_6::S_1489 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1495;
            }
            C2Rust_Block_6::S_1495 => {
                (*__gamepkg_tls_g_esi) = 0x76b374 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1501;
            }
            C2Rust_Block_6::S_1501 => {
                _pv_29 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1503;
            }
            C2Rust_Block_6::S_1503 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1505;
            }
            C2Rust_Block_6::S_1505 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1511;
            }
            C2Rust_Block_6::S_1511 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b358 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1513;
            }
            C2Rust_Block_6::S_1513 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x46534358 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1515;
            }
            C2Rust_Block_6::S_1515 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b35c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1517;
            }
            C2Rust_Block_6::S_1517 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1519;
            }
            C2Rust_Block_6::S_1519 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1521;
            }
            C2Rust_Block_6::S_1521 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1523;
            }
            C2Rust_Block_6::S_1523 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1529;
            }
            C2Rust_Block_6::S_1529 => {
                _pv_30 = 0x210661 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1531;
            }
            C2Rust_Block_6::S_1531 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1533;
            }
            C2Rust_Block_6::S_1533 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1539;
            }
            C2Rust_Block_6::S_1539 => {
                sub_002102C1();
                c2rust_current_block_6 = C2Rust_Block_6::S_1545;
            }
            C2Rust_Block_6::S_1545 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1547;
            }
            C2Rust_Block_6::S_1547 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b378 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1549;
            }
            C2Rust_Block_6::S_1549 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax))
                    .wrapping_add(0x1f as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1551;
            }
            C2Rust_Block_6::S_1551 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffffe0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1553;
            }
            C2Rust_Block_6::S_1553 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1555;
            }
            C2Rust_Block_6::S_1555 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1557;
            }
            C2Rust_Block_6::S_1557 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1559;
            }
            C2Rust_Block_6::S_1559 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1565;
            }
            C2Rust_Block_6::S_1565 => {
                _pv_31 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_6 = C2Rust_Block_6::S_1567;
            }
            C2Rust_Block_6::S_1567 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1569;
            }
            C2Rust_Block_6::S_1569 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1575;
            }
            C2Rust_Block_6::S_1575 => {
                (*__gamepkg_tls_g_edi) = 0x76b390 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1581;
            }
            C2Rust_Block_6::S_1581 => {
                _pv_32 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1583;
            }
            C2Rust_Block_6::S_1583 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1585;
            }
            C2Rust_Block_6::S_1585 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1591;
            }
            C2Rust_Block_6::S_1591 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b394 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1593;
            }
            C2Rust_Block_6::S_1593 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1595;
            }
            C2Rust_Block_6::S_1595 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1601;
            }
            C2Rust_Block_6::S_1601 => {
                _pv_33 = 0x21068c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1603;
            }
            C2Rust_Block_6::S_1603 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1605;
            }
            C2Rust_Block_6::S_1605 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1611;
            }
            C2Rust_Block_6::S_1611 => {
                sub_002102C1();
                c2rust_current_block_6 = C2Rust_Block_6::S_1617;
            }
            C2Rust_Block_6::S_1617 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1619;
            }
            C2Rust_Block_6::S_1619 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1621;
            }
            C2Rust_Block_6::S_1621 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1627;
            }
            C2Rust_Block_6::S_1627 => {
                _pv_34 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1629;
            }
            C2Rust_Block_6::S_1629 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1631;
            }
            C2Rust_Block_6::S_1631 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1641;
            }
            C2Rust_Block_6::S_1641 => {
                _pv_35 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1643;
            }
            C2Rust_Block_6::S_1643 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1645;
            }
            C2Rust_Block_6::S_1645 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_35,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1651;
            }
            C2Rust_Block_6::S_1651 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1653;
            }
            C2Rust_Block_6::S_1653 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1655;
            }
            C2Rust_Block_6::S_1655 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1661;
            }
            C2Rust_Block_6::S_1661 => {
                _pv_36 = 0x210698 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1663;
            }
            C2Rust_Block_6::S_1663 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1665;
            }
            C2Rust_Block_6::S_1665 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_36,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1671;
            }
            C2Rust_Block_6::S_1671 => {
                sub_002102F5();
                c2rust_current_block_6 = C2Rust_Block_6::S_1677;
            }
            C2Rust_Block_6::S_1677 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1679;
            }
            C2Rust_Block_6::S_1679 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1681;
            }
            C2Rust_Block_6::S_1681 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1683;
            }
            C2Rust_Block_6::S_1683 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1685;
            }
            C2Rust_Block_6::S_1685 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1890;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1698;
                }
            }
            C2Rust_Block_6::S_1698 => {
                _pv_37 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1700;
            }
            C2Rust_Block_6::S_1700 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1702;
            }
            C2Rust_Block_6::S_1702 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_37,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1712;
            }
            C2Rust_Block_6::S_1712 => {
                _pv_38 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1714;
            }
            C2Rust_Block_6::S_1714 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1716;
            }
            C2Rust_Block_6::S_1716 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_38,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1722;
            }
            C2Rust_Block_6::S_1722 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1724;
            }
            C2Rust_Block_6::S_1724 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1730;
            }
            C2Rust_Block_6::S_1730 => {
                _pv_39 = 0x2106a5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1732;
            }
            C2Rust_Block_6::S_1732 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1734;
            }
            C2Rust_Block_6::S_1734 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_39,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1740;
            }
            C2Rust_Block_6::S_1740 => {
                sub_002102F5();
                c2rust_current_block_6 = C2Rust_Block_6::S_1746;
            }
            C2Rust_Block_6::S_1746 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1748;
            }
            C2Rust_Block_6::S_1748 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1750;
            }
            C2Rust_Block_6::S_1750 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1752;
            }
            C2Rust_Block_6::S_1752 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1754;
            }
            C2Rust_Block_6::S_1754 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1890;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1767;
                }
            }
            C2Rust_Block_6::S_1767 => {
                _pv_40 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_6 = C2Rust_Block_6::S_1769;
            }
            C2Rust_Block_6::S_1769 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1771;
            }
            C2Rust_Block_6::S_1771 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_40,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1781;
            }
            C2Rust_Block_6::S_1781 => {
                _pv_41 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_1783;
            }
            C2Rust_Block_6::S_1783 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1785;
            }
            C2Rust_Block_6::S_1785 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_41,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1791;
            }
            C2Rust_Block_6::S_1791 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1793;
            }
            C2Rust_Block_6::S_1793 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1799;
            }
            C2Rust_Block_6::S_1799 => {
                _pv_42 = 0x2106b0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1801;
            }
            C2Rust_Block_6::S_1801 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1803;
            }
            C2Rust_Block_6::S_1803 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_42,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1809;
            }
            C2Rust_Block_6::S_1809 => {
                sub_002102F5();
                c2rust_current_block_6 = C2Rust_Block_6::S_1815;
            }
            C2Rust_Block_6::S_1815 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1817;
            }
            C2Rust_Block_6::S_1817 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1819;
            }
            C2Rust_Block_6::S_1819 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1821;
            }
            C2Rust_Block_6::S_1821 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1823;
            }
            C2Rust_Block_6::S_1823 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1890;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_1832;
                }
            }
            C2Rust_Block_6::S_1832 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2018;
            }
            C2Rust_Block_6::S_1844 => {
                _pv_43 = 0xffffffff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1846;
            }
            C2Rust_Block_6::S_1846 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1848;
            }
            C2Rust_Block_6::S_1848 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_43,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1854;
            }
            C2Rust_Block_6::S_1854 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1856;
            }
            C2Rust_Block_6::S_1856 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1862;
            }
            C2Rust_Block_6::S_1862 => {
                _pv_44 = 0x2106c4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1864;
            }
            C2Rust_Block_6::S_1864 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1866;
            }
            C2Rust_Block_6::S_1866 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_44,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1872;
            }
            C2Rust_Block_6::S_1872 => {
                sub_001D1953();
                c2rust_current_block_6 = C2Rust_Block_6::S_1878;
            }
            C2Rust_Block_6::S_1878 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1880;
            }
            C2Rust_Block_6::S_1880 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1882;
            }
            C2Rust_Block_6::S_1882 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2096;
            }
            C2Rust_Block_6::S_1890 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1892;
            }
            C2Rust_Block_6::S_1892 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1894;
            }
            C2Rust_Block_6::S_1894 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1900;
            }
            C2Rust_Block_6::S_1900 => {
                _pv_45 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1902;
            }
            C2Rust_Block_6::S_1902 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1904;
            }
            C2Rust_Block_6::S_1904 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_45,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1914;
            }
            C2Rust_Block_6::S_1914 => {
                _pv_46 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1916;
            }
            C2Rust_Block_6::S_1916 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1918;
            }
            C2Rust_Block_6::S_1918 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_46,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1928;
            }
            C2Rust_Block_6::S_1928 => {
                _pv_47 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_1930;
            }
            C2Rust_Block_6::S_1930 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1932;
            }
            C2Rust_Block_6::S_1932 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_47,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1942;
            }
            C2Rust_Block_6::S_1942 => {
                _pv_48 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1944;
            }
            C2Rust_Block_6::S_1944 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1946;
            }
            C2Rust_Block_6::S_1946 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_48,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1952;
            }
            C2Rust_Block_6::S_1952 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1954;
            }
            C2Rust_Block_6::S_1954 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1960;
            }
            C2Rust_Block_6::S_1960 => {
                _pv_49 = 0x2106d8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_1962;
            }
            C2Rust_Block_6::S_1962 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1964;
            }
            C2Rust_Block_6::S_1964 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_49,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1970;
            }
            C2Rust_Block_6::S_1970 => {
                sub_001D120E();
                c2rust_current_block_6 = C2Rust_Block_6::S_1980;
            }
            C2Rust_Block_6::S_1980 => {
                _pv_50 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1982;
            }
            C2Rust_Block_6::S_1982 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_1984;
            }
            C2Rust_Block_6::S_1984 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_50,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_1990;
            }
            C2Rust_Block_6::S_1990 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1992;
            }
            C2Rust_Block_6::S_1992 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_1998;
            }
            C2Rust_Block_6::S_1998 => {
                _pv_51 = 0x2106e3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2000;
            }
            C2Rust_Block_6::S_2000 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2002;
            }
            C2Rust_Block_6::S_2002 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_51,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2008;
            }
            C2Rust_Block_6::S_2008 => {
                sub_001D118A();
                c2rust_current_block_6 = C2Rust_Block_6::S_2018;
            }
            C2Rust_Block_6::S_2018 => {
                _pv_52 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2020;
            }
            C2Rust_Block_6::S_2020 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2022;
            }
            C2Rust_Block_6::S_2022 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_52,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2028;
            }
            C2Rust_Block_6::S_2028 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_2030;
            }
            C2Rust_Block_6::S_2030 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_2036;
            }
            C2Rust_Block_6::S_2036 => {
                _pv_53 = 0x2106ee as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2038;
            }
            C2Rust_Block_6::S_2038 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2040;
            }
            C2Rust_Block_6::S_2040 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_53,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2046;
            }
            C2Rust_Block_6::S_2046 => {
                sub_001D19FD();
                c2rust_current_block_6 = C2Rust_Block_6::S_2052;
            }
            C2Rust_Block_6::S_2052 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2054;
            }
            C2Rust_Block_6::S_2054 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0xffffffff as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2056;
            }
            C2Rust_Block_6::S_2056 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x3c5d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2058;
            }
            C2Rust_Block_6::S_2058 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2060;
            }
            C2Rust_Block_6::S_2060 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76b374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2062;
            }
            C2Rust_Block_6::S_2062 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_2064;
            }
            C2Rust_Block_6::S_2064 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_2070;
            }
            C2Rust_Block_6::S_2070 => {
                _pv_54 = 0x210702 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2072;
            }
            C2Rust_Block_6::S_2072 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2074;
            }
            C2Rust_Block_6::S_2074 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_54,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2080;
            }
            C2Rust_Block_6::S_2080 => {
                sub_0020FA6B();
                c2rust_current_block_6 = C2Rust_Block_6::S_2086;
            }
            C2Rust_Block_6::S_2086 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2096;
            }
            C2Rust_Block_6::S_2096 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2098;
            }
            C2Rust_Block_6::S_2098 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2108;
            }
            C2Rust_Block_6::S_2108 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2110;
            }
            C2Rust_Block_6::S_2110 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2120;
            }
            C2Rust_Block_6::S_2120 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2122;
            }
            C2Rust_Block_6::S_2122 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2128;
            }
            C2Rust_Block_6::S_2128 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_2134;
            }
            C2Rust_Block_6::S_2134 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_2136;
            }
            C2Rust_Block_6::S_2136 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2142;
            }
            C2Rust_Block_6::S_2142 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_2144;
            }
            C2Rust_Block_6::S_2144 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0021070A() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0020FA6B();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210710() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x210715 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00215530();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t);
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x1780 as uint32_t);
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    loop {
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_eax))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa == _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x1790 as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x210737 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_002153B0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_174: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            <= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_174;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            3 as uint32_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    's_197: {
        if _fa != _fb {
            break 's_197;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            4 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17c0 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint8_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x2d737663 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        3 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17b0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17c0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint8_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002107B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    enum C2Rust_Block_9 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_78,
        S_80,
        S_82,
        S_88,
        S_101,
        S_103,
        S_105,
        S_115,
        S_117,
        S_119,
        S_129,
        S_131,
        S_133,
        S_139,
        S_141,
        S_143,
        S_149,
        S_151,
        S_153,
        S_159,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_217,
        S_227,
        S_229,
        S_231,
        S_237,
        S_243,
        S_245,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_281,
        S_283,
        S_285,
        S_287,
        S_295,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_322,
        S_324,
        S_326,
        S_336,
        S_338,
        S_340,
        S_350,
        S_352,
        S_354,
        S_364,
        S_366,
        S_368,
        S_374,
        S_380,
        S_382,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_407,
        S_409,
        S_411,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_436,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_461,
        S_463,
        S_471,
        S_473,
        S_475,
        S_477,
        S_479,
        S_481,
        S_490,
        S_492,
        S_500,
        S_506,
        S_508,
        S_510,
        S_516,
        S_522,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_547,
        S_549,
        S_551,
        S_561,
        S_563,
        S_565,
        S_575,
        S_577,
        S_579,
        S_589,
        S_591,
        S_593,
        S_599,
        S_605,
        S_607,
        S_609,
        S_611,
        S_613,
        S_615,
        S_617,
        S_619,
        S_621,
        S_623,
        S_625,
        S_638,
        S_640,
        S_642,
        S_648,
        S_654,
        S_656,
        S_658,
        S_668,
        S_670,
        S_672,
        S_682,
        S_684,
        S_686,
        S_692,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_734,
        S_736,
        S_738,
        S_740,
        S_742,
        S_744,
        S_746,
        S_748,
        S_750,
        S_759,
        S_761,
        S_771,
        S_773,
        S_783,
        S_785,
        S_795,
        S_797,
        S_803,
        S_805,
        S_807,
        S_809,
        S_811,
        S_813,
        S_815,
    }
    let mut c2rust_current_block_9: C2Rust_Block_9;
    c2rust_current_block_9 = C2Rust_Block_9::S_0;
    loop {
        match c2rust_current_block_9 {
            C2Rust_Block_9::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_9 = C2Rust_Block_9::S_2;
            }
            C2Rust_Block_9::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_4;
            }
            C2Rust_Block_9::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_18;
            }
            C2Rust_Block_9::S_18 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_20;
            }
            C2Rust_Block_9::S_20 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_22;
            }
            C2Rust_Block_9::S_22 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_24;
            }
            C2Rust_Block_9::S_24 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_26;
            }
            C2Rust_Block_9::S_26 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_32;
            }
            C2Rust_Block_9::S_32 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_9 = C2Rust_Block_9::S_34;
            }
            C2Rust_Block_9::S_34 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_36;
            }
            C2Rust_Block_9::S_36 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_46;
            }
            C2Rust_Block_9::S_46 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_9 = C2Rust_Block_9::S_48;
            }
            C2Rust_Block_9::S_48 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_50;
            }
            C2Rust_Block_9::S_50 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_56;
            }
            C2Rust_Block_9::S_56 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_58;
            }
            C2Rust_Block_9::S_58 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_60;
            }
            C2Rust_Block_9::S_60 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_62;
            }
            C2Rust_Block_9::S_62 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_64;
            }
            C2Rust_Block_9::S_64 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_66;
            }
            C2Rust_Block_9::S_66 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_68;
            }
            C2Rust_Block_9::S_68 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_70;
            }
            C2Rust_Block_9::S_70 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_72;
            }
            C2Rust_Block_9::S_72 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_78;
            }
            C2Rust_Block_9::S_78 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_9 = C2Rust_Block_9::S_80;
            }
            C2Rust_Block_9::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_82;
            }
            C2Rust_Block_9::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_88;
            }
            C2Rust_Block_9::S_88 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_295;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_101;
                }
            }
            C2Rust_Block_9::S_101 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_9 = C2Rust_Block_9::S_103;
            }
            C2Rust_Block_9::S_103 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_105;
            }
            C2Rust_Block_9::S_105 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_115;
            }
            C2Rust_Block_9::S_115 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_9 = C2Rust_Block_9::S_117;
            }
            C2Rust_Block_9::S_117 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_119;
            }
            C2Rust_Block_9::S_119 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_129;
            }
            C2Rust_Block_9::S_129 => {
                _pv_4 = 0x73746172 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_131;
            }
            C2Rust_Block_9::S_131 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_133;
            }
            C2Rust_Block_9::S_133 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_139;
            }
            C2Rust_Block_9::S_139 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_141;
            }
            C2Rust_Block_9::S_141 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_143;
            }
            C2Rust_Block_9::S_143 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_149;
            }
            C2Rust_Block_9::S_149 => {
                _pv_5 = 0x2107d5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_151;
            }
            C2Rust_Block_9::S_151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_153;
            }
            C2Rust_Block_9::S_153 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_159;
            }
            C2Rust_Block_9::S_159 => {
                sub_002155A0();
                c2rust_current_block_9 = C2Rust_Block_9::S_165;
            }
            C2Rust_Block_9::S_165 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_167;
            }
            C2Rust_Block_9::S_167 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_169;
            }
            C2Rust_Block_9::S_169 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_171;
            }
            C2Rust_Block_9::S_171 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_173;
            }
            C2Rust_Block_9::S_173 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_175;
            }
            C2Rust_Block_9::S_175 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_177;
            }
            C2Rust_Block_9::S_177 => {
                _fb = 0x2b697370 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_179;
            }
            C2Rust_Block_9::S_179 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_181;
            }
            C2Rust_Block_9::S_181 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_183;
            }
            C2Rust_Block_9::S_183 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_185;
            }
            C2Rust_Block_9::S_185 => {
                if _fa == _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_217;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_194;
                }
            }
            C2Rust_Block_9::S_194 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xff000000 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_196;
            }
            C2Rust_Block_9::S_196 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_198;
            }
            C2Rust_Block_9::S_198 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_200;
            }
            C2Rust_Block_9::S_200 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_202;
            }
            C2Rust_Block_9::S_202 => {
                _fb = 0x2d000000 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_204;
            }
            C2Rust_Block_9::S_204 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_206;
            }
            C2Rust_Block_9::S_206 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_208;
            }
            C2Rust_Block_9::S_208 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_227;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_217;
                }
            }
            C2Rust_Block_9::S_217 => {
                (*__gamepkg_tls_g_edi) = 1 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_227;
            }
            C2Rust_Block_9::S_227 => {
                _pv_6 = 0x2107fb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_229;
            }
            C2Rust_Block_9::S_229 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_231;
            }
            C2Rust_Block_9::S_231 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_237;
            }
            C2Rust_Block_9::S_237 => {
                sub_00243210();
                c2rust_current_block_9 = C2Rust_Block_9::S_243;
            }
            C2Rust_Block_9::S_243 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17bc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_245;
            }
            C2Rust_Block_9::S_245 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_247;
            }
            C2Rust_Block_9::S_247 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_249;
            }
            C2Rust_Block_9::S_249 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_9 = C2Rust_Block_9::S_251;
            }
            C2Rust_Block_9::S_251 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_253;
            }
            C2Rust_Block_9::S_253 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_255;
            }
            C2Rust_Block_9::S_255 => {
                if _fas < 0 as int32_t {
                    c2rust_current_block_9 = C2Rust_Block_9::S_281;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_264;
                }
            }
            C2Rust_Block_9::S_264 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_266;
            }
            C2Rust_Block_9::S_266 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_268;
            }
            C2Rust_Block_9::S_268 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_270;
            }
            C2Rust_Block_9::S_270 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_272;
            }
            C2Rust_Block_9::S_272 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_295;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_281;
                }
            }
            C2Rust_Block_9::S_281 => {
                (*__gamepkg_tls_g_edi) = 2 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_283;
            }
            C2Rust_Block_9::S_283 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_285;
            }
            C2Rust_Block_9::S_285 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_287;
            }
            C2Rust_Block_9::S_287 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_301;
            }
            C2Rust_Block_9::S_295 => {
                (*__gamepkg_tls_g_edi) = 2 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_301;
            }
            C2Rust_Block_9::S_301 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_303;
            }
            C2Rust_Block_9::S_303 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_305;
            }
            C2Rust_Block_9::S_305 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_307;
            }
            C2Rust_Block_9::S_307 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_309;
            }
            C2Rust_Block_9::S_309 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_522;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_322;
                }
            }
            C2Rust_Block_9::S_322 => {
                _pv_7 = 0x10 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_324;
            }
            C2Rust_Block_9::S_324 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_326;
            }
            C2Rust_Block_9::S_326 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_336;
            }
            C2Rust_Block_9::S_336 => {
                _pv_8 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_9 = C2Rust_Block_9::S_338;
            }
            C2Rust_Block_9::S_338 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_340;
            }
            C2Rust_Block_9::S_340 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_350;
            }
            C2Rust_Block_9::S_350 => {
                _pv_9 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_9 = C2Rust_Block_9::S_352;
            }
            C2Rust_Block_9::S_352 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_354;
            }
            C2Rust_Block_9::S_354 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_364;
            }
            C2Rust_Block_9::S_364 => {
                _pv_10 = 0x210839 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_366;
            }
            C2Rust_Block_9::S_366 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_368;
            }
            C2Rust_Block_9::S_368 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_374;
            }
            C2Rust_Block_9::S_374 => {
                sub_002152A0();
                c2rust_current_block_9 = C2Rust_Block_9::S_380;
            }
            C2Rust_Block_9::S_380 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_382;
            }
            C2Rust_Block_9::S_382 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_384;
            }
            C2Rust_Block_9::S_384 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_386;
            }
            C2Rust_Block_9::S_386 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_388;
            }
            C2Rust_Block_9::S_388 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_390;
            }
            C2Rust_Block_9::S_390 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_392;
            }
            C2Rust_Block_9::S_392 => {
                _fb = 0xfffffffd as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_394;
            }
            C2Rust_Block_9::S_394 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_396;
            }
            C2Rust_Block_9::S_396 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_398;
            }
            C2Rust_Block_9::S_398 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_419;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_407;
                }
            }
            C2Rust_Block_9::S_407 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_409;
            }
            C2Rust_Block_9::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    8 as uint32_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_411;
            }
            C2Rust_Block_9::S_411 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_522;
            }
            C2Rust_Block_9::S_419 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_421;
            }
            C2Rust_Block_9::S_421 => {
                _fb = 0xfffffffe as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_423;
            }
            C2Rust_Block_9::S_423 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_425;
            }
            C2Rust_Block_9::S_425 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_427;
            }
            C2Rust_Block_9::S_427 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_444;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_436;
                }
            }
            C2Rust_Block_9::S_436 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_522;
            }
            C2Rust_Block_9::S_444 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_446;
            }
            C2Rust_Block_9::S_446 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_448;
            }
            C2Rust_Block_9::S_448 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_450;
            }
            C2Rust_Block_9::S_450 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_452;
            }
            C2Rust_Block_9::S_452 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_471;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_461;
                }
            }
            C2Rust_Block_9::S_461 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_463;
            }
            C2Rust_Block_9::S_463 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_522;
            }
            C2Rust_Block_9::S_471 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_473;
            }
            C2Rust_Block_9::S_473 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17c0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_475;
            }
            C2Rust_Block_9::S_475 => {
                _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_477;
            }
            C2Rust_Block_9::S_477 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_479;
            }
            C2Rust_Block_9::S_479 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_481;
            }
            C2Rust_Block_9::S_481 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_500;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_490;
                }
            }
            C2Rust_Block_9::S_490 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_492;
            }
            C2Rust_Block_9::S_492 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_522;
            }
            C2Rust_Block_9::S_500 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_9 = C2Rust_Block_9::S_506;
            }
            C2Rust_Block_9::S_506 => {
                _pv_11 = 0x2108a8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_508;
            }
            C2Rust_Block_9::S_508 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_510;
            }
            C2Rust_Block_9::S_510 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_516;
            }
            C2Rust_Block_9::S_516 => {
                sub_00210710();
                c2rust_current_block_9 = C2Rust_Block_9::S_522;
            }
            C2Rust_Block_9::S_522 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_524;
            }
            C2Rust_Block_9::S_524 => {
                (*__gamepkg_tls_g_edi) = 3 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_526;
            }
            C2Rust_Block_9::S_526 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_528;
            }
            C2Rust_Block_9::S_528 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_530;
            }
            C2Rust_Block_9::S_530 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_532;
            }
            C2Rust_Block_9::S_532 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_534;
            }
            C2Rust_Block_9::S_534 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_771;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_547;
                }
            }
            C2Rust_Block_9::S_547 => {
                _pv_12 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_9 = C2Rust_Block_9::S_549;
            }
            C2Rust_Block_9::S_549 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_551;
            }
            C2Rust_Block_9::S_551 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_561;
            }
            C2Rust_Block_9::S_561 => {
                _pv_13 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_9 = C2Rust_Block_9::S_563;
            }
            C2Rust_Block_9::S_563 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_565;
            }
            C2Rust_Block_9::S_565 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_575;
            }
            C2Rust_Block_9::S_575 => {
                _pv_14 = 0x636f6e6e as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_577;
            }
            C2Rust_Block_9::S_577 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_579;
            }
            C2Rust_Block_9::S_579 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_589;
            }
            C2Rust_Block_9::S_589 => {
                _pv_15 = 0x2108c3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_591;
            }
            C2Rust_Block_9::S_591 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_593;
            }
            C2Rust_Block_9::S_593 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_599;
            }
            C2Rust_Block_9::S_599 => {
                sub_002155A0();
                c2rust_current_block_9 = C2Rust_Block_9::S_605;
            }
            C2Rust_Block_9::S_605 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_607;
            }
            C2Rust_Block_9::S_607 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_609;
            }
            C2Rust_Block_9::S_609 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_611;
            }
            C2Rust_Block_9::S_611 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_613;
            }
            C2Rust_Block_9::S_613 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_615;
            }
            C2Rust_Block_9::S_615 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_617;
            }
            C2Rust_Block_9::S_617 => {
                _fb = 0x2b6f6e6c as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_619;
            }
            C2Rust_Block_9::S_619 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_621;
            }
            C2Rust_Block_9::S_621 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_623;
            }
            C2Rust_Block_9::S_623 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_625;
            }
            C2Rust_Block_9::S_625 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_734;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_638;
                }
            }
            C2Rust_Block_9::S_638 => {
                _pv_16 = 0xc as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_640;
            }
            C2Rust_Block_9::S_640 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_642;
            }
            C2Rust_Block_9::S_642 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_648;
            }
            C2Rust_Block_9::S_648 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_654;
            }
            C2Rust_Block_9::S_654 => {
                _pv_17 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_9 = C2Rust_Block_9::S_656;
            }
            C2Rust_Block_9::S_656 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_658;
            }
            C2Rust_Block_9::S_658 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_668;
            }
            C2Rust_Block_9::S_668 => {
                _pv_18 = 0x78756964 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_670;
            }
            C2Rust_Block_9::S_670 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_672;
            }
            C2Rust_Block_9::S_672 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_682;
            }
            C2Rust_Block_9::S_682 => {
                _pv_19 = 0x2108e4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_684;
            }
            C2Rust_Block_9::S_684 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_686;
            }
            C2Rust_Block_9::S_686 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_692;
            }
            C2Rust_Block_9::S_692 => {
                sub_002155A0();
                c2rust_current_block_9 = C2Rust_Block_9::S_698;
            }
            C2Rust_Block_9::S_698 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_700;
            }
            C2Rust_Block_9::S_700 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 0x10 as ::core::ffi::c_int;
                c2rust_current_block_9 = C2Rust_Block_9::S_702;
            }
            C2Rust_Block_9::S_702 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_704;
            }
            C2Rust_Block_9::S_704 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_706;
            }
            C2Rust_Block_9::S_706 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_708;
            }
            C2Rust_Block_9::S_708 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_710;
            }
            C2Rust_Block_9::S_710 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_712;
            }
            C2Rust_Block_9::S_712 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_714;
            }
            C2Rust_Block_9::S_714 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_716;
            }
            C2Rust_Block_9::S_716 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint8_t
                        as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_718;
            }
            C2Rust_Block_9::S_718 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_720;
            }
            C2Rust_Block_9::S_720 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_722;
            }
            C2Rust_Block_9::S_722 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17c1 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_724;
            }
            C2Rust_Block_9::S_724 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    5 as uint32_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_726;
            }
            C2Rust_Block_9::S_726 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_728;
            }
            C2Rust_Block_9::S_728 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17c0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_734;
            }
            C2Rust_Block_9::S_734 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_736;
            }
            C2Rust_Block_9::S_736 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xff000000 as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_738;
            }
            C2Rust_Block_9::S_738 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_740;
            }
            C2Rust_Block_9::S_740 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_742;
            }
            C2Rust_Block_9::S_742 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_744;
            }
            C2Rust_Block_9::S_744 => {
                _fb = 0x2d000000 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_746;
            }
            C2Rust_Block_9::S_746 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_748;
            }
            C2Rust_Block_9::S_748 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_750;
            }
            C2Rust_Block_9::S_750 => {
                if _fa != _fb {
                    c2rust_current_block_9 = C2Rust_Block_9::S_771;
                } else {
                    c2rust_current_block_9 = C2Rust_Block_9::S_759;
                }
            }
            C2Rust_Block_9::S_759 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_761;
            }
            C2Rust_Block_9::S_761 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_771;
            }
            C2Rust_Block_9::S_771 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_773;
            }
            C2Rust_Block_9::S_773 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_783;
            }
            C2Rust_Block_9::S_783 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_785;
            }
            C2Rust_Block_9::S_785 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_795;
            }
            C2Rust_Block_9::S_795 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_9 = C2Rust_Block_9::S_797;
            }
            C2Rust_Block_9::S_797 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_803;
            }
            C2Rust_Block_9::S_803 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_805;
            }
            C2Rust_Block_9::S_805 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_807;
            }
            C2Rust_Block_9::S_807 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_809;
            }
            C2Rust_Block_9::S_809 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_811;
            }
            C2Rust_Block_9::S_811 => {
                _fas = _fa as int32_t;
                c2rust_current_block_9 = C2Rust_Block_9::S_813;
            }
            C2Rust_Block_9::S_813 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_9 = C2Rust_Block_9::S_815;
            }
            C2Rust_Block_9::S_815 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210940() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x17c4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x21094b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001B9070();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_265: {
        if _fa == _fb {
            break 's_265;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_ecx) = 0x5f1 as uint32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi);
        let mut _i: uint32_t = 0;
        let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
            -(4 as ::core::ffi::c_int as int32_t)
        } else {
            4 as ::core::ffi::c_int as int32_t
        };
        _i = 0 as uint32_t;
        while _i < (*__gamepkg_tls_g_ecx) {
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi)
                        .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            _i = _i.wrapping_add(1);
        }
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17a0 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x2107b0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        let mut _pv_5: uint32_t = 0x210990 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00215910();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_6: uint32_t = 0x210998 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_00243210();
        _fb = 0x3a98 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x3a98 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x17bc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002109B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x2107b0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x2109c0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00215960();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41cd30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41cd34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _pv_4: uint32_t = 0x2109dd as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001FEDC0();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002109F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi).wrapping_add(0x1700 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint8_t,
    );
    's_486: {
        if _fa != _fb {
            break 's_486;
        }
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_287: {
            's_119: {
                if _fa == _fb {
                    break 's_119;
                }
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_287;
                }
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x17b4 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x3b1338 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 0x80 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = 0x210a2d as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_00213630();
            let mut _pv_7: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = 0x3b1330 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = 0x80 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            let mut _pv_10: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            let mut _pv_11: uint32_t = 0x210a3e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_11,
            );
            sub_00213630();
            _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x20 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_486;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x17c1 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        let mut _pv_12: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_12,
        );
        let mut _pv_13: uint32_t = 0x36f808 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_13,
        );
        let mut _pv_14: uint32_t = 0x80 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_14,
        );
        let mut _pv_15: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_15,
        );
        let mut _pv_16: uint32_t = 0x210a5e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_16,
        );
        sub_00213630();
        _fb = 0x1780 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(0x1780 as uint32_t);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_17: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_17,
        );
        let mut _pv_18: uint32_t = 0x3b1324 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_18,
        );
        let mut _pv_19: uint32_t = 0x80 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_19,
        );
        let mut _pv_20: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_20,
        );
        let mut _pv_21: uint32_t = 0x210a75 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_21,
        );
        sub_00213970();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210A80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    enum C2Rust_Block_13 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_24,
        S_26,
        S_28,
        S_34,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_53,
        S_55,
        S_57,
        S_63,
        S_65,
        S_71,
        S_73,
        S_79,
        S_81,
        S_83,
        S_85,
        S_91,
        S_93,
        S_95,
        S_105,
        S_107,
        S_109,
        S_115,
        S_124,
        S_130,
        S_132,
        S_134,
        S_144,
        S_146,
        S_148,
        S_158,
        S_160,
        S_162,
        S_172,
        S_174,
        S_176,
        S_182,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_202,
        S_204,
        S_206,
        S_216,
        S_218,
        S_220,
        S_226,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_265,
        S_267,
        S_269,
        S_279,
        S_281,
        S_283,
        S_289,
        S_295,
        S_297,
        S_299,
        S_309,
        S_311,
        S_313,
        S_323,
        S_325,
        S_327,
        S_337,
        S_339,
        S_341,
        S_347,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_367,
        S_369,
        S_371,
        S_381,
        S_383,
        S_385,
        S_391,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_411,
        S_413,
        S_415,
        S_421,
        S_431,
        S_433,
        S_443,
        S_445,
        S_451,
        S_453,
        S_455,
        S_461,
        S_463,
        S_469,
        S_471,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_494,
        S_500,
        S_502,
        S_504,
        S_514,
        S_516,
        S_518,
        S_528,
        S_530,
        S_532,
        S_542,
        S_544,
        S_546,
        S_552,
        S_558,
        S_560,
        S_562,
        S_564,
        S_566,
        S_572,
        S_574,
        S_576,
        S_586,
        S_588,
        S_590,
        S_596,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_635,
        S_637,
        S_639,
        S_649,
        S_651,
        S_653,
        S_659,
        S_665,
        S_667,
        S_669,
        S_679,
        S_681,
        S_683,
        S_693,
        S_695,
        S_697,
        S_707,
        S_709,
        S_711,
        S_717,
        S_723,
        S_725,
        S_727,
        S_729,
        S_731,
        S_737,
        S_739,
        S_741,
        S_751,
        S_753,
        S_755,
        S_761,
        S_767,
        S_773,
        S_775,
        S_777,
        S_787,
        S_789,
        S_791,
        S_801,
        S_803,
        S_805,
        S_811,
        S_817,
        S_819,
        S_821,
        S_823,
        S_825,
        S_827,
        S_829,
        S_831,
        S_833,
        S_835,
        S_848,
        S_850,
        S_860,
        S_862,
        S_868,
        S_870,
        S_872,
        S_874,
        S_876,
        S_882,
        S_884,
        S_890,
        S_892,
        S_898,
        S_900,
        S_913,
        S_915,
        S_925,
        S_927,
        S_933,
        S_935,
        S_937,
        S_939,
        S_945,
        S_947,
        S_953,
        S_955,
        S_961,
        S_963,
        S_973,
        S_975,
        S_985,
        S_987,
        S_993,
        S_995,
        S_997,
        S_1003,
        S_1005,
        S_1011,
        S_1013,
    }
    let mut c2rust_current_block_13: C2Rust_Block_13;
    c2rust_current_block_13 = C2Rust_Block_13::S_0;
    loop {
        match c2rust_current_block_13 {
            C2Rust_Block_13::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_13 = C2Rust_Block_13::S_2;
            }
            C2Rust_Block_13::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_4;
            }
            C2Rust_Block_13::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_18;
            }
            C2Rust_Block_13::S_18 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_24;
            }
            C2Rust_Block_13::S_24 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_13 = C2Rust_Block_13::S_26;
            }
            C2Rust_Block_13::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_28;
            }
            C2Rust_Block_13::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_34;
            }
            C2Rust_Block_13::S_34 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_36;
            }
            C2Rust_Block_13::S_36 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_38;
            }
            C2Rust_Block_13::S_38 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_40;
            }
            C2Rust_Block_13::S_40 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_42;
            }
            C2Rust_Block_13::S_42 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_44;
            }
            C2Rust_Block_13::S_44 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_79;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_53;
                }
            }
            C2Rust_Block_13::S_53 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_55;
            }
            C2Rust_Block_13::S_55 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_57;
            }
            C2Rust_Block_13::S_57 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_63;
            }
            C2Rust_Block_13::S_63 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_65;
            }
            C2Rust_Block_13::S_65 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_71;
            }
            C2Rust_Block_13::S_71 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_73;
            }
            C2Rust_Block_13::S_73 => return,
            C2Rust_Block_13::S_79 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_81;
            }
            C2Rust_Block_13::S_81 => {
                _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_83;
            }
            C2Rust_Block_13::S_83 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_85;
            }
            C2Rust_Block_13::S_85 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_91;
            }
            C2Rust_Block_13::S_91 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_93;
            }
            C2Rust_Block_13::S_93 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_95;
            }
            C2Rust_Block_13::S_95 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_105;
            }
            C2Rust_Block_13::S_105 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_13 = C2Rust_Block_13::S_107;
            }
            C2Rust_Block_13::S_107 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_109;
            }
            C2Rust_Block_13::S_109 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_115;
            }
            C2Rust_Block_13::S_115 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_477;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_124;
                }
            }
            C2Rust_Block_13::S_124 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_130;
            }
            C2Rust_Block_13::S_130 => {
                _pv_2 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_132;
            }
            C2Rust_Block_13::S_132 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_134;
            }
            C2Rust_Block_13::S_134 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_144;
            }
            C2Rust_Block_13::S_144 => {
                _pv_3 = 0x3b131c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_146;
            }
            C2Rust_Block_13::S_146 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_148;
            }
            C2Rust_Block_13::S_148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_158;
            }
            C2Rust_Block_13::S_158 => {
                _pv_4 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_160;
            }
            C2Rust_Block_13::S_160 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_162;
            }
            C2Rust_Block_13::S_162 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_172;
            }
            C2Rust_Block_13::S_172 => {
                _pv_5 = 0x210aae as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_174;
            }
            C2Rust_Block_13::S_174 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_176;
            }
            C2Rust_Block_13::S_176 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_182;
            }
            C2Rust_Block_13::S_182 => {
                sub_002134B0();
                c2rust_current_block_13 = C2Rust_Block_13::S_188;
            }
            C2Rust_Block_13::S_188 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_190;
            }
            C2Rust_Block_13::S_190 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_192;
            }
            C2Rust_Block_13::S_192 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_194;
            }
            C2Rust_Block_13::S_194 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_196;
            }
            C2Rust_Block_13::S_196 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_202;
            }
            C2Rust_Block_13::S_202 => {
                _pv_6 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_204;
            }
            C2Rust_Block_13::S_204 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_206;
            }
            C2Rust_Block_13::S_206 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_216;
            }
            C2Rust_Block_13::S_216 => {
                _pv_7 = 0x210ab7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_218;
            }
            C2Rust_Block_13::S_218 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_220;
            }
            C2Rust_Block_13::S_220 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_226;
            }
            C2Rust_Block_13::S_226 => {
                sub_00213DA0();
                c2rust_current_block_13 = C2Rust_Block_13::S_232;
            }
            C2Rust_Block_13::S_232 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_234;
            }
            C2Rust_Block_13::S_234 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_236;
            }
            C2Rust_Block_13::S_236 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_238;
            }
            C2Rust_Block_13::S_238 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_240;
            }
            C2Rust_Block_13::S_240 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_242;
            }
            C2Rust_Block_13::S_242 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_244;
            }
            C2Rust_Block_13::S_244 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_246;
            }
            C2Rust_Block_13::S_246 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_248;
            }
            C2Rust_Block_13::S_248 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_250;
            }
            C2Rust_Block_13::S_250 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_252;
            }
            C2Rust_Block_13::S_252 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_973;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_265;
                }
            }
            C2Rust_Block_13::S_265 => {
                _pv_8 = 0x36f810 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_267;
            }
            C2Rust_Block_13::S_267 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_269;
            }
            C2Rust_Block_13::S_269 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_279;
            }
            C2Rust_Block_13::S_279 => {
                _pv_9 = 0x10 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_281;
            }
            C2Rust_Block_13::S_281 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_283;
            }
            C2Rust_Block_13::S_283 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_289;
            }
            C2Rust_Block_13::S_289 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x1790 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_295;
            }
            C2Rust_Block_13::S_295 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_297;
            }
            C2Rust_Block_13::S_297 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_299;
            }
            C2Rust_Block_13::S_299 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_309;
            }
            C2Rust_Block_13::S_309 => {
                _pv_11 = 0x3b1308 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_311;
            }
            C2Rust_Block_13::S_311 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_313;
            }
            C2Rust_Block_13::S_313 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_323;
            }
            C2Rust_Block_13::S_323 => {
                _pv_12 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_325;
            }
            C2Rust_Block_13::S_325 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_327;
            }
            C2Rust_Block_13::S_327 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_337;
            }
            C2Rust_Block_13::S_337 => {
                _pv_13 = 0x210add as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_339;
            }
            C2Rust_Block_13::S_339 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_341;
            }
            C2Rust_Block_13::S_341 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_347;
            }
            C2Rust_Block_13::S_347 => {
                sub_002134B0();
                c2rust_current_block_13 = C2Rust_Block_13::S_353;
            }
            C2Rust_Block_13::S_353 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_355;
            }
            C2Rust_Block_13::S_355 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_357;
            }
            C2Rust_Block_13::S_357 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_359;
            }
            C2Rust_Block_13::S_359 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_361;
            }
            C2Rust_Block_13::S_361 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_367;
            }
            C2Rust_Block_13::S_367 => {
                _pv_14 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_369;
            }
            C2Rust_Block_13::S_369 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_371;
            }
            C2Rust_Block_13::S_371 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_381;
            }
            C2Rust_Block_13::S_381 => {
                _pv_15 = 0x210ae6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_383;
            }
            C2Rust_Block_13::S_383 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_385;
            }
            C2Rust_Block_13::S_385 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_391;
            }
            C2Rust_Block_13::S_391 => {
                sub_00214040();
                c2rust_current_block_13 = C2Rust_Block_13::S_397;
            }
            C2Rust_Block_13::S_397 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_399;
            }
            C2Rust_Block_13::S_399 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_401;
            }
            C2Rust_Block_13::S_401 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_403;
            }
            C2Rust_Block_13::S_403 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_405;
            }
            C2Rust_Block_13::S_405 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_411;
            }
            C2Rust_Block_13::S_411 => {
                _pv_16 = 0x210aee as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_413;
            }
            C2Rust_Block_13::S_413 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_415;
            }
            C2Rust_Block_13::S_415 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_421;
            }
            C2Rust_Block_13::S_421 => {
                sub_00210710();
                c2rust_current_block_13 = C2Rust_Block_13::S_431;
            }
            C2Rust_Block_13::S_431 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_433;
            }
            C2Rust_Block_13::S_433 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_443;
            }
            C2Rust_Block_13::S_443 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_445;
            }
            C2Rust_Block_13::S_445 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_451;
            }
            C2Rust_Block_13::S_451 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_453;
            }
            C2Rust_Block_13::S_453 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_455;
            }
            C2Rust_Block_13::S_455 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_461;
            }
            C2Rust_Block_13::S_461 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_463;
            }
            C2Rust_Block_13::S_463 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_469;
            }
            C2Rust_Block_13::S_469 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_471;
            }
            C2Rust_Block_13::S_471 => return,
            C2Rust_Block_13::S_477 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_479;
            }
            C2Rust_Block_13::S_479 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_481;
            }
            C2Rust_Block_13::S_481 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_483;
            }
            C2Rust_Block_13::S_483 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_485;
            }
            C2Rust_Block_13::S_485 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_973;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_494;
                }
            }
            C2Rust_Block_13::S_494 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_500;
            }
            C2Rust_Block_13::S_500 => {
                _pv_17 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_502;
            }
            C2Rust_Block_13::S_502 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_504;
            }
            C2Rust_Block_13::S_504 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_514;
            }
            C2Rust_Block_13::S_514 => {
                _pv_18 = 0x3b131c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_516;
            }
            C2Rust_Block_13::S_516 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_518;
            }
            C2Rust_Block_13::S_518 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_528;
            }
            C2Rust_Block_13::S_528 => {
                _pv_19 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_530;
            }
            C2Rust_Block_13::S_530 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_532;
            }
            C2Rust_Block_13::S_532 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_542;
            }
            C2Rust_Block_13::S_542 => {
                _pv_20 = 0x210b0e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_544;
            }
            C2Rust_Block_13::S_544 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_546;
            }
            C2Rust_Block_13::S_546 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_552;
            }
            C2Rust_Block_13::S_552 => {
                sub_002134B0();
                c2rust_current_block_13 = C2Rust_Block_13::S_558;
            }
            C2Rust_Block_13::S_558 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_560;
            }
            C2Rust_Block_13::S_560 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_562;
            }
            C2Rust_Block_13::S_562 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_564;
            }
            C2Rust_Block_13::S_564 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_566;
            }
            C2Rust_Block_13::S_566 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_572;
            }
            C2Rust_Block_13::S_572 => {
                _pv_21 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_574;
            }
            C2Rust_Block_13::S_574 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_576;
            }
            C2Rust_Block_13::S_576 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_586;
            }
            C2Rust_Block_13::S_586 => {
                _pv_22 = 0x210b17 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_588;
            }
            C2Rust_Block_13::S_588 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_590;
            }
            C2Rust_Block_13::S_590 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_596;
            }
            C2Rust_Block_13::S_596 => {
                sub_00213DA0();
                c2rust_current_block_13 = C2Rust_Block_13::S_602;
            }
            C2Rust_Block_13::S_602 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_604;
            }
            C2Rust_Block_13::S_604 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_606;
            }
            C2Rust_Block_13::S_606 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_608;
            }
            C2Rust_Block_13::S_608 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_610;
            }
            C2Rust_Block_13::S_610 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_612;
            }
            C2Rust_Block_13::S_612 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_614;
            }
            C2Rust_Block_13::S_614 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_616;
            }
            C2Rust_Block_13::S_616 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_618;
            }
            C2Rust_Block_13::S_618 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_620;
            }
            C2Rust_Block_13::S_620 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_622;
            }
            C2Rust_Block_13::S_622 => {
                if _fa == _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_973;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_635;
                }
            }
            C2Rust_Block_13::S_635 => {
                _pv_23 = 0x3830e0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_637;
            }
            C2Rust_Block_13::S_637 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_639;
            }
            C2Rust_Block_13::S_639 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_649;
            }
            C2Rust_Block_13::S_649 => {
                _pv_24 = 0x3c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_651;
            }
            C2Rust_Block_13::S_651 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_653;
            }
            C2Rust_Block_13::S_653 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_659;
            }
            C2Rust_Block_13::S_659 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x44 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_665;
            }
            C2Rust_Block_13::S_665 => {
                _pv_25 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_13 = C2Rust_Block_13::S_667;
            }
            C2Rust_Block_13::S_667 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_669;
            }
            C2Rust_Block_13::S_669 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_679;
            }
            C2Rust_Block_13::S_679 => {
                _pv_26 = 0x3b12fc as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_681;
            }
            C2Rust_Block_13::S_681 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_683;
            }
            C2Rust_Block_13::S_683 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_693;
            }
            C2Rust_Block_13::S_693 => {
                _pv_27 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_13 = C2Rust_Block_13::S_695;
            }
            C2Rust_Block_13::S_695 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_697;
            }
            C2Rust_Block_13::S_697 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_707;
            }
            C2Rust_Block_13::S_707 => {
                _pv_28 = 0x210b36 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_709;
            }
            C2Rust_Block_13::S_709 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_711;
            }
            C2Rust_Block_13::S_711 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_717;
            }
            C2Rust_Block_13::S_717 => {
                sub_002134B0();
                c2rust_current_block_13 = C2Rust_Block_13::S_723;
            }
            C2Rust_Block_13::S_723 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_725;
            }
            C2Rust_Block_13::S_725 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_727;
            }
            C2Rust_Block_13::S_727 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_729;
            }
            C2Rust_Block_13::S_729 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_731;
            }
            C2Rust_Block_13::S_731 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_737;
            }
            C2Rust_Block_13::S_737 => {
                _pv_29 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_13 = C2Rust_Block_13::S_739;
            }
            C2Rust_Block_13::S_739 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_741;
            }
            C2Rust_Block_13::S_741 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_751;
            }
            C2Rust_Block_13::S_751 => {
                _pv_30 = 0x210b3f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_753;
            }
            C2Rust_Block_13::S_753 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_755;
            }
            C2Rust_Block_13::S_755 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_761;
            }
            C2Rust_Block_13::S_761 => {
                sub_00214040();
                c2rust_current_block_13 = C2Rust_Block_13::S_767;
            }
            C2Rust_Block_13::S_767 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x1790 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_773;
            }
            C2Rust_Block_13::S_773 => {
                _pv_31 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_13 = C2Rust_Block_13::S_775;
            }
            C2Rust_Block_13::S_775 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_777;
            }
            C2Rust_Block_13::S_777 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_787;
            }
            C2Rust_Block_13::S_787 => {
                _pv_32 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_13 = C2Rust_Block_13::S_789;
            }
            C2Rust_Block_13::S_789 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_791;
            }
            C2Rust_Block_13::S_791 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_801;
            }
            C2Rust_Block_13::S_801 => {
                _pv_33 = 0x210b4c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_803;
            }
            C2Rust_Block_13::S_803 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_805;
            }
            C2Rust_Block_13::S_805 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_811;
            }
            C2Rust_Block_13::S_811 => {
                sub_002153B0();
                c2rust_current_block_13 = C2Rust_Block_13::S_817;
            }
            C2Rust_Block_13::S_817 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_819;
            }
            C2Rust_Block_13::S_819 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_821;
            }
            C2Rust_Block_13::S_821 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_823;
            }
            C2Rust_Block_13::S_823 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_825;
            }
            C2Rust_Block_13::S_825 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_827;
            }
            C2Rust_Block_13::S_827 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_829;
            }
            C2Rust_Block_13::S_829 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_831;
            }
            C2Rust_Block_13::S_831 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_833;
            }
            C2Rust_Block_13::S_833 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_835;
            }
            C2Rust_Block_13::S_835 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    <= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_13 = C2Rust_Block_13::S_898;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_848;
                }
            }
            C2Rust_Block_13::S_848 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_850;
            }
            C2Rust_Block_13::S_850 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_860;
            }
            C2Rust_Block_13::S_860 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_862;
            }
            C2Rust_Block_13::S_862 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_868;
            }
            C2Rust_Block_13::S_868 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    2 as uint32_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_870;
            }
            C2Rust_Block_13::S_870 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17a4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_872;
            }
            C2Rust_Block_13::S_872 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_874;
            }
            C2Rust_Block_13::S_874 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_876;
            }
            C2Rust_Block_13::S_876 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_882;
            }
            C2Rust_Block_13::S_882 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_884;
            }
            C2Rust_Block_13::S_884 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_890;
            }
            C2Rust_Block_13::S_890 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_892;
            }
            C2Rust_Block_13::S_892 => return,
            C2Rust_Block_13::S_898 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17ac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_900;
            }
            C2Rust_Block_13::S_900 => {
                if _fa != _fb {
                    c2rust_current_block_13 = C2Rust_Block_13::S_961;
                } else {
                    c2rust_current_block_13 = C2Rust_Block_13::S_913;
                }
            }
            C2Rust_Block_13::S_913 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_915;
            }
            C2Rust_Block_13::S_915 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_925;
            }
            C2Rust_Block_13::S_925 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_927;
            }
            C2Rust_Block_13::S_927 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_933;
            }
            C2Rust_Block_13::S_933 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x2d70696e as uint32_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_935;
            }
            C2Rust_Block_13::S_935 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_937;
            }
            C2Rust_Block_13::S_937 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_939;
            }
            C2Rust_Block_13::S_939 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_945;
            }
            C2Rust_Block_13::S_945 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_947;
            }
            C2Rust_Block_13::S_947 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_953;
            }
            C2Rust_Block_13::S_953 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_955;
            }
            C2Rust_Block_13::S_955 => return,
            C2Rust_Block_13::S_961 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x2d737663 as uint32_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_963;
            }
            C2Rust_Block_13::S_963 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x17b0 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_973;
            }
            C2Rust_Block_13::S_973 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_975;
            }
            C2Rust_Block_13::S_975 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_985;
            }
            C2Rust_Block_13::S_985 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_987;
            }
            C2Rust_Block_13::S_987 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_993;
            }
            C2Rust_Block_13::S_993 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_995;
            }
            C2Rust_Block_13::S_995 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_997;
            }
            C2Rust_Block_13::S_997 => {
                _fas = _fa as int32_t;
                c2rust_current_block_13 = C2Rust_Block_13::S_1003;
            }
            C2Rust_Block_13::S_1003 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_13 = C2Rust_Block_13::S_1005;
            }
            C2Rust_Block_13::S_1005 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1011;
            }
            C2Rust_Block_13::S_1011 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_13 = C2Rust_Block_13::S_1013;
            }
            C2Rust_Block_13::S_1013 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210BB0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_65: {
        if _fa != _fb {
            break 's_65;
        }
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_139: {
            's_115: {
                if _fa == _fb {
                    break 's_115;
                }
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_139;
                }
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x17b0 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a0 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << 4 as ::core::ffi::c_int;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_esi));
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_270: {
            's_173: {
                if _fa == _fb {
                    break 's_173;
                }
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_270;
                }
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x17b8 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = 0x2d737663 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_248: {
                if _fa == _fb {
                    break 's_248;
                }
                loop {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    if _fa >= _fb {
                        break 's_248;
                    }
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x17b8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax)
                                .wrapping_mul(4 as uint32_t)
                                .wrapping_add(0x36f7e8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    if _fa == _fb {
                        break 's_248;
                    }
                }
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a0 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << 4 as ::core::ffi::c_int;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edx));
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x17ac as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x17c0 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint8_t,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210C40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
        .wrapping_sub(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a0 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ),
        );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
        >> (4 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210C60() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_49: {
        if _fa != _fb {
            break 's_49;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x17ac as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 4 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210C80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 6 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_68: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_62: {
            if _fa != _fb {
                break 's_62;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a4 as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                2 as uint32_t,
            );
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210CB0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x17a8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210CC0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    enum C2Rust_Block_19 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_72,
        S_74,
        S_76,
        S_86,
        S_88,
        S_90,
        S_96,
        S_105,
        S_107,
        S_115,
        S_117,
        S_123,
        S_125,
        S_127,
        S_129,
        S_131,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_151,
        S_153,
        S_156,
        S_157,
        S_158,
        S_159,
        S_166,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_191,
        S_193,
        S_199,
        S_201,
        S_203,
        S_205,
        S_207,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_233,
        S_235,
        S_237,
        S_239,
        S_241,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_284,
        S_292,
        S_300,
        S_306,
        S_308,
        S_314,
        S_316,
        S_318,
        S_324,
        S_330,
        S_332,
        S_338,
        S_340,
        S_342,
        S_352,
        S_354,
        S_356,
        S_362,
        S_364,
        S_366,
        S_372,
        S_374,
        S_376,
        S_382,
        S_392,
        S_394,
        S_404,
        S_406,
        S_412,
        S_418,
        S_420,
        S_426,
        S_428,
        S_438,
        S_440,
        S_442,
        S_448,
        S_450,
        S_456,
        S_458,
        S_460,
        S_466,
        S_476,
        S_478,
        S_488,
        S_490,
        S_496,
        S_502,
        S_504,
        S_510,
        S_512,
    }
    let mut c2rust_current_block_19: C2Rust_Block_19;
    c2rust_current_block_19 = C2Rust_Block_19::S_0;
    loop {
        match c2rust_current_block_19 {
            C2Rust_Block_19::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_2;
            }
            C2Rust_Block_19::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_19 = C2Rust_Block_19::S_4;
            }
            C2Rust_Block_19::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_19 = C2Rust_Block_19::S_6;
            }
            C2Rust_Block_19::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_8;
            }
            C2Rust_Block_19::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_26;
            }
            C2Rust_Block_19::S_26 => {
                _pv = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_28;
            }
            C2Rust_Block_19::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_30;
            }
            C2Rust_Block_19::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_36;
            }
            C2Rust_Block_19::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_19 = C2Rust_Block_19::S_38;
            }
            C2Rust_Block_19::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_40;
            }
            C2Rust_Block_19::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_42;
            }
            C2Rust_Block_19::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp) & 0xfffffff8 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_44;
            }
            C2Rust_Block_19::S_44 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_46;
            }
            C2Rust_Block_19::S_46 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_48;
            }
            C2Rust_Block_19::S_48 => {
                _fb = 0xc00 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_50;
            }
            C2Rust_Block_19::S_50 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_52;
            }
            C2Rust_Block_19::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc00 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_54;
            }
            C2Rust_Block_19::S_54 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_56;
            }
            C2Rust_Block_19::S_56 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_58;
            }
            C2Rust_Block_19::S_58 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_60;
            }
            C2Rust_Block_19::S_60 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_62;
            }
            C2Rust_Block_19::S_62 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_64;
            }
            C2Rust_Block_19::S_64 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_66;
            }
            C2Rust_Block_19::S_66 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_72;
            }
            C2Rust_Block_19::S_72 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_19 = C2Rust_Block_19::S_74;
            }
            C2Rust_Block_19::S_74 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_76;
            }
            C2Rust_Block_19::S_76 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_86;
            }
            C2Rust_Block_19::S_86 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_19 = C2Rust_Block_19::S_88;
            }
            C2Rust_Block_19::S_88 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_90;
            }
            C2Rust_Block_19::S_90 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_96;
            }
            C2Rust_Block_19::S_96 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_115;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_105;
                }
            }
            C2Rust_Block_19::S_105 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x17a8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_107;
            }
            C2Rust_Block_19::S_107 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x17b8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_123;
            }
            C2Rust_Block_19::S_115 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41cd30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_117;
            }
            C2Rust_Block_19::S_117 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41cd34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_123;
            }
            C2Rust_Block_19::S_123 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_125;
            }
            C2Rust_Block_19::S_125 => {
                _fb = 0x2d757064 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_127;
            }
            C2Rust_Block_19::S_127 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_129;
            }
            C2Rust_Block_19::S_129 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_131;
            }
            C2Rust_Block_19::S_131 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_438;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_140;
                }
            }
            C2Rust_Block_19::S_140 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_142;
            }
            C2Rust_Block_19::S_142 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_144;
            }
            C2Rust_Block_19::S_144 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_146;
            }
            C2Rust_Block_19::S_146 => {
                (*__gamepkg_tls_g_ecx) = 0x300 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_148;
            }
            C2Rust_Block_19::S_148 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_151;
            }
            C2Rust_Block_19::S_151 => {
                _i = 0;
                c2rust_current_block_19 = C2Rust_Block_19::S_153;
            }
            C2Rust_Block_19::S_153 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_19 = C2Rust_Block_19::S_156;
            }
            C2Rust_Block_19::S_156 => {
                _i = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_157;
            }
            C2Rust_Block_19::S_157 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_19 = C2Rust_Block_19::S_158;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_166;
                }
            }
            C2Rust_Block_19::S_158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_159;
            }
            C2Rust_Block_19::S_159 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_19 = C2Rust_Block_19::S_157;
            }
            C2Rust_Block_19::S_166 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_19 = C2Rust_Block_19::S_170;
            }
            C2Rust_Block_19::S_170 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_172;
            }
            C2Rust_Block_19::S_172 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_174;
            }
            C2Rust_Block_19::S_174 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_176;
            }
            C2Rust_Block_19::S_176 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_178;
            }
            C2Rust_Block_19::S_178 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_180;
            }
            C2Rust_Block_19::S_180 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_182;
            }
            C2Rust_Block_19::S_182 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_199;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_191;
                }
            }
            C2Rust_Block_19::S_191 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_193;
            }
            C2Rust_Block_19::S_193 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_199;
            }
            C2Rust_Block_19::S_199 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_201;
            }
            C2Rust_Block_19::S_201 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_203;
            }
            C2Rust_Block_19::S_203 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_205;
            }
            C2Rust_Block_19::S_205 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_207;
            }
            C2Rust_Block_19::S_207 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_300;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_216;
                }
            }
            C2Rust_Block_19::S_216 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_218;
            }
            C2Rust_Block_19::S_218 => {
                _fb = 0x2d737663 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_220;
            }
            C2Rust_Block_19::S_220 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_222;
            }
            C2Rust_Block_19::S_222 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_224;
            }
            C2Rust_Block_19::S_224 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_300;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_233;
                }
            }
            C2Rust_Block_19::S_233 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_235;
            }
            C2Rust_Block_19::S_235 => {
                _fb = 0x2d616374 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_237;
            }
            C2Rust_Block_19::S_237 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_239;
            }
            C2Rust_Block_19::S_239 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_241;
            }
            C2Rust_Block_19::S_241 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_292;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_250;
                }
            }
            C2Rust_Block_19::S_250 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_252;
            }
            C2Rust_Block_19::S_252 => {
                _fb = 0x2d696e76 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_254;
            }
            C2Rust_Block_19::S_254 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_256;
            }
            C2Rust_Block_19::S_256 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_258;
            }
            C2Rust_Block_19::S_258 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_292;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_267;
                }
            }
            C2Rust_Block_19::S_267 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_269;
            }
            C2Rust_Block_19::S_269 => {
                _fb = 0x2d6d7367 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_271;
            }
            C2Rust_Block_19::S_271 => {
                _fas = _fa as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_273;
            }
            C2Rust_Block_19::S_273 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_275;
            }
            C2Rust_Block_19::S_275 => {
                if _fa == _fb {
                    c2rust_current_block_19 = C2Rust_Block_19::S_292;
                } else {
                    c2rust_current_block_19 = C2Rust_Block_19::S_284;
                }
            }
            C2Rust_Block_19::S_284 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    7 as uint32_t,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_306;
            }
            C2Rust_Block_19::S_292 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    8 as uint32_t,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_330;
            }
            C2Rust_Block_19::S_300 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    6 as uint32_t,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_306;
            }
            C2Rust_Block_19::S_306 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_308;
            }
            C2Rust_Block_19::S_308 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_314;
            }
            C2Rust_Block_19::S_314 => {
                _pv_2 = 0x210d57 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_316;
            }
            C2Rust_Block_19::S_316 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_318;
            }
            C2Rust_Block_19::S_318 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_324;
            }
            C2Rust_Block_19::S_324 => {
                sub_0031B080();
                c2rust_current_block_19 = C2Rust_Block_19::S_330;
            }
            C2Rust_Block_19::S_330 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_332;
            }
            C2Rust_Block_19::S_332 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_338;
            }
            C2Rust_Block_19::S_338 => {
                _pv_3 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_19 = C2Rust_Block_19::S_340;
            }
            C2Rust_Block_19::S_340 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_342;
            }
            C2Rust_Block_19::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_352;
            }
            C2Rust_Block_19::S_352 => {
                _pv_4 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_354;
            }
            C2Rust_Block_19::S_354 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_356;
            }
            C2Rust_Block_19::S_356 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_362;
            }
            C2Rust_Block_19::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_364;
            }
            C2Rust_Block_19::S_364 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_366;
            }
            C2Rust_Block_19::S_366 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_372;
            }
            C2Rust_Block_19::S_372 => {
                _pv_5 = 0x210d6b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_374;
            }
            C2Rust_Block_19::S_374 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_376;
            }
            C2Rust_Block_19::S_376 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_382;
            }
            C2Rust_Block_19::S_382 => {
                sub_001CFF88();
                c2rust_current_block_19 = C2Rust_Block_19::S_392;
            }
            C2Rust_Block_19::S_392 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_394;
            }
            C2Rust_Block_19::S_394 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_404;
            }
            C2Rust_Block_19::S_404 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_406;
            }
            C2Rust_Block_19::S_406 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_412;
            }
            C2Rust_Block_19::S_412 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_418;
            }
            C2Rust_Block_19::S_418 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_420;
            }
            C2Rust_Block_19::S_420 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_426;
            }
            C2Rust_Block_19::S_426 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_428;
            }
            C2Rust_Block_19::S_428 => return,
            C2Rust_Block_19::S_438 => {
                _pv_6 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_440;
            }
            C2Rust_Block_19::S_440 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_442;
            }
            C2Rust_Block_19::S_442 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_448;
            }
            C2Rust_Block_19::S_448 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_450;
            }
            C2Rust_Block_19::S_450 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_456;
            }
            C2Rust_Block_19::S_456 => {
                _pv_7 = 0x210d78 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_19 = C2Rust_Block_19::S_458;
            }
            C2Rust_Block_19::S_458 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_460;
            }
            C2Rust_Block_19::S_460 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_466;
            }
            C2Rust_Block_19::S_466 => {
                sub_0031AAD1();
                c2rust_current_block_19 = C2Rust_Block_19::S_476;
            }
            C2Rust_Block_19::S_476 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_478;
            }
            C2Rust_Block_19::S_478 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_488;
            }
            C2Rust_Block_19::S_488 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_490;
            }
            C2Rust_Block_19::S_490 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_496;
            }
            C2Rust_Block_19::S_496 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_19 = C2Rust_Block_19::S_502;
            }
            C2Rust_Block_19::S_502 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_19 = C2Rust_Block_19::S_504;
            }
            C2Rust_Block_19::S_504 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_510;
            }
            C2Rust_Block_19::S_510 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_19 = C2Rust_Block_19::S_512;
            }
            C2Rust_Block_19::S_512 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210D80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 0x9c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x9c as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = 0x210d93 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0031ABF3();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_249: {
        if _fa != _fb {
            break 's_249;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xa4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_217: {
            if _fa == _fb {
                break 's_217;
            }
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xa8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa < _fb {
                break 's_217;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x3d as uint32_t);
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x210dbd as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_00243880();
            _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0xc as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fb = 0x9c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x9c as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_276: {
        if _fa != _fb {
            break 's_276;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fb = 0x9c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x9c as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210DE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x73656e64 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_37: {
        if _fa == _fb {
            break 's_37;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0x62726463 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_37;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0x61646475 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_81: {
            if _fa == _fb {
                break 's_81;
            }
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0x64656c75 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_108: {
                if _fa == _fb {
                    break 's_108;
                }
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_135: {
                    if _fa == _fb {
                        break 's_135;
                    }
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0x75736572 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_170: {
                        if _fa != _fb {
                            break 's_170;
                        }
                        (*__gamepkg_tls_g_eax) = 6 as uint32_t;
                        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                            .wrapping_add(4 as uint32_t);
                        return;
                    }
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0x65707374 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_197: {
                        if _fa != _fb {
                            break 's_197;
                        }
                        (*__gamepkg_tls_g_eax) = 8 as uint32_t;
                        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                            .wrapping_add(4 as uint32_t);
                        return;
                    }
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0x696e7674 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_224: {
                        if _fa != _fb {
                            break 's_224;
                        }
                        (*__gamepkg_tls_g_eax) = 9 as uint32_t;
                        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                            .wrapping_add(4 as uint32_t);
                        return;
                    }
                    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0x67696e76 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        & 0xffffff00 as uint32_t
                        | (if _fa != _fb {
                            1 as ::core::ffi::c_int
                        } else {
                            0 as ::core::ffi::c_int
                        }) as uint8_t as uint32_t;
                    _fb = 9 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        .wrapping_add(9 as uint32_t);
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    return;
                }
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_eax) = 3 as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = 2 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 7 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210E50() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_49: {
        if _fa != _fb {
            break 's_49;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0xffffffff as ::core::ffi::c_uint as uint32_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210E70() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    's_209: {
        if _fa == _fb {
            break 's_209;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _icall_target: uint32_t = (*__gamepkg_tls_g_ecx);
        let mut _pv_3: uint32_t = 0x210e8d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_195: {
            's_146: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_146;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_195;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_154: {
                if !_fn.is_none() {
                    break 's_154;
                }
                _fn = recomp_lookup(_va);
            }
            's_160: {
                if !_fn.is_none() {
                    break 's_160;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_166: {
                if _fn.is_some() {
                    break 's_166;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_195;
            }
            _fn.expect("non-null function pointer")();
        }
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210EA0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_413: {
        if _fa == _fb {
            break 's_413;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_413;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x210eba as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001B35F0();
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        's_371: {
            if _fas < 0 as int32_t {
                break 's_371;
            }
            loop {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                let mut _pv_5: uint32_t = 0x210ecf as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                sub_0021C190();
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_354: {
                    if _fa == _fb {
                        break 's_354;
                    }
                    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
                    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    let mut _pv_7: uint32_t = 0x210eda as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    let mut _va: uint32_t = _icall_target;
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                            as usize],
                        _va,
                    );
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_trace_idx,
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(&raw const g_icall_trace_idx)
                            .wrapping_add(1),
                    );
                    ::core::ptr::write_volatile(
                        &raw mut g_icall_count,
                        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                            .wrapping_add(1),
                    );
                    's_340: {
                        's_291: {
                            if _va >= 0xfe000000 as uint32_t
                                || g_xbox_code_hi == 0 as uint32_t
                                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                            {
                                break 's_291;
                            }
                            recomp_icall_not_code_log(_va);
                            (*__gamepkg_tls_g_esp) = _icall_esp;
                            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                            break 's_340;
                        }
                        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                        's_299: {
                            if !_fn.is_none() {
                                break 's_299;
                            }
                            _fn = recomp_lookup(_va);
                        }
                        's_305: {
                            if !_fn.is_none() {
                                break 's_305;
                            }
                            _fn = recomp_lookup_kernel(_va);
                        }
                        's_311: {
                            if _fn.is_some() {
                                break 's_311;
                            }
                            recomp_icall_fail_log(_va);
                            (*__gamepkg_tls_g_esp) = _icall_esp;
                            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                            break 's_340;
                        }
                        _fn.expect("non-null function pointer")();
                    }
                    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                }
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_sub(1);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                if _fas < 0 as int32_t {
                    break 's_371;
                }
            }
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_0021C030();
        return;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210F00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_375: {
        if _fa == _fb {
            break 's_375;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_375;
        }
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x28 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = 0x210f16 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_194: {
            's_133: {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    break 's_133;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_153: {
                    if !_fn.is_none() {
                        break 's_153;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_159: {
                    if !_fn.is_none() {
                        break 's_159;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_165: {
                    if _fn.is_some() {
                        break 's_165;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_194;
                }
                _fn.expect("non-null function pointer")();
                break 's_194;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_3: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x210f25 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_00243880();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0xc4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_359: {
            if _fa == _fb {
                break 's_359;
            }
            let mut _pv_7: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = 0x210f40 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            sub_0021C0C0();
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00210F50() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    enum C2Rust_Block_26 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_28,
        S_34,
        S_36,
        S_38,
        S_44,
        S_46,
        S_55,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_81,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_107,
        S_109,
        S_111,
        S_113,
        S_115,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_141,
        S_147,
        S_149,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_201,
        S_207,
        S_213,
        S_215,
        S_217,
        S_219,
        S_221,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_249,
        S_255,
        S_257,
        S_259,
        S_265,
        S_267,
        S_273,
        S_275,
        S_277,
        S_287,
        S_289,
        S_291,
        S_301,
        S_303,
        S_305,
        S_311,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_328,
        S_334,
        S_336,
        S_338,
        S_348,
        S_350,
        S_352,
        S_359,
        S_365,
        S_367,
        S_369,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_390,
        S_392,
        S_394,
        S_402,
        S_404,
        S_406,
        S_410,
        S_412,
        S_416,
        S_422,
        S_429,
        S_431,
        S_433,
        S_451,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_471,
        S_473,
        S_479,
        S_481,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_521,
        S_529,
        S_531,
        S_533,
        S_535,
        S_537,
        S_546,
        S_548,
        S_550,
        S_552,
        S_554,
        S_563,
        S_565,
        S_567,
        S_569,
        S_571,
    }
    let mut c2rust_current_block_26: C2Rust_Block_26;
    c2rust_current_block_26 = C2Rust_Block_26::S_0;
    loop {
        match c2rust_current_block_26 {
            C2Rust_Block_26::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_26 = C2Rust_Block_26::S_2;
            }
            C2Rust_Block_26::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_4;
            }
            C2Rust_Block_26::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_18;
            }
            C2Rust_Block_26::S_18 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_20;
            }
            C2Rust_Block_26::S_20 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_22;
            }
            C2Rust_Block_26::S_22 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_24;
            }
            C2Rust_Block_26::S_24 => {
                _fb = 0x67696e76 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_26;
            }
            C2Rust_Block_26::S_26 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_28;
            }
            C2Rust_Block_26::S_28 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_34;
            }
            C2Rust_Block_26::S_34 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_26 = C2Rust_Block_26::S_36;
            }
            C2Rust_Block_26::S_36 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_38;
            }
            C2Rust_Block_26::S_38 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_44;
            }
            C2Rust_Block_26::S_44 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_46;
            }
            C2Rust_Block_26::S_46 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    > if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_26 = C2Rust_Block_26::S_529;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_55;
                }
            }
            C2Rust_Block_26::S_55 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_504;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_64;
                }
            }
            C2Rust_Block_26::S_64 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_66;
            }
            C2Rust_Block_26::S_66 => {
                _fb = 0x64656c75 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_68;
            }
            C2Rust_Block_26::S_68 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_70;
            }
            C2Rust_Block_26::S_70 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_72;
            }
            C2Rust_Block_26::S_72 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    > if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_26 = C2Rust_Block_26::S_487;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_81;
                }
            }
            C2Rust_Block_26::S_81 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_504;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_90;
                }
            }
            C2Rust_Block_26::S_90 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_92;
            }
            C2Rust_Block_26::S_92 => {
                _fb = 0x61646475 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_94;
            }
            C2Rust_Block_26::S_94 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_96;
            }
            C2Rust_Block_26::S_96 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_98;
            }
            C2Rust_Block_26::S_98 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_504;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_107;
                }
            }
            C2Rust_Block_26::S_107 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_109;
            }
            C2Rust_Block_26::S_109 => {
                _fb = 0x62726463 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_111;
            }
            C2Rust_Block_26::S_111 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_113;
            }
            C2Rust_Block_26::S_113 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_115;
            }
            C2Rust_Block_26::S_115 => {
                if _fa != _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_213;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_124;
                }
            }
            C2Rust_Block_26::S_124 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_126;
            }
            C2Rust_Block_26::S_126 => {
                _fb = 0x66756c6c as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_128;
            }
            C2Rust_Block_26::S_128 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_130;
            }
            C2Rust_Block_26::S_130 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_132;
            }
            C2Rust_Block_26::S_132 => {
                if _fa != _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_147;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_141;
                }
            }
            C2Rust_Block_26::S_141 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xfffffffb as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_147;
            }
            C2Rust_Block_26::S_147 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xb4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_149;
            }
            C2Rust_Block_26::S_149 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_151;
            }
            C2Rust_Block_26::S_151 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_153;
            }
            C2Rust_Block_26::S_153 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_155;
            }
            C2Rust_Block_26::S_155 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_157;
            }
            C2Rust_Block_26::S_157 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_159;
            }
            C2Rust_Block_26::S_159 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_161;
            }
            C2Rust_Block_26::S_161 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_163;
            }
            C2Rust_Block_26::S_163 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (if _fa == _fb {
                        1 as ::core::ffi::c_int
                    } else {
                        0 as ::core::ffi::c_int
                    }) as uint8_t as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_165;
            }
            C2Rust_Block_26::S_165 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_167;
            }
            C2Rust_Block_26::S_167 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_169;
            }
            C2Rust_Block_26::S_169 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_171;
            }
            C2Rust_Block_26::S_171 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_173;
            }
            C2Rust_Block_26::S_173 => {
                if _fa != _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_213;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_182;
                }
            }
            C2Rust_Block_26::S_182 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_184;
            }
            C2Rust_Block_26::S_184 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_186;
            }
            C2Rust_Block_26::S_186 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_188;
            }
            C2Rust_Block_26::S_188 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_190;
            }
            C2Rust_Block_26::S_190 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_192;
            }
            C2Rust_Block_26::S_192 => {
                if _fa != _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_207;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_201;
                }
            }
            C2Rust_Block_26::S_201 => {
                (*__gamepkg_tls_g_eax) = 0xfffffc19 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_207;
            }
            C2Rust_Block_26::S_207 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_213;
            }
            C2Rust_Block_26::S_213 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_215;
            }
            C2Rust_Block_26::S_215 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_217;
            }
            C2Rust_Block_26::S_217 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_219;
            }
            C2Rust_Block_26::S_219 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_221;
            }
            C2Rust_Block_26::S_221 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_471;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_230;
                }
            }
            C2Rust_Block_26::S_230 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_232;
            }
            C2Rust_Block_26::S_232 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_234;
            }
            C2Rust_Block_26::S_234 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_236;
            }
            C2Rust_Block_26::S_236 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_238;
            }
            C2Rust_Block_26::S_238 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_240;
            }
            C2Rust_Block_26::S_240 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_471;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_249;
                }
            }
            C2Rust_Block_26::S_249 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_255;
            }
            C2Rust_Block_26::S_255 => {
                _pv_0 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_26 = C2Rust_Block_26::S_257;
            }
            C2Rust_Block_26::S_257 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_259;
            }
            C2Rust_Block_26::S_259 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_265;
            }
            C2Rust_Block_26::S_265 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_267;
            }
            C2Rust_Block_26::S_267 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_273;
            }
            C2Rust_Block_26::S_273 => {
                _pv_1 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_26 = C2Rust_Block_26::S_275;
            }
            C2Rust_Block_26::S_275 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_277;
            }
            C2Rust_Block_26::S_277 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_287;
            }
            C2Rust_Block_26::S_287 => {
                _pv_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_26 = C2Rust_Block_26::S_289;
            }
            C2Rust_Block_26::S_289 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_291;
            }
            C2Rust_Block_26::S_291 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_301;
            }
            C2Rust_Block_26::S_301 => {
                _pv_3 = 0x210fcb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_303;
            }
            C2Rust_Block_26::S_303 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_305;
            }
            C2Rust_Block_26::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_311;
            }
            C2Rust_Block_26::S_311 => {
                sub_00210DE0();
                c2rust_current_block_26 = C2Rust_Block_26::S_317;
            }
            C2Rust_Block_26::S_317 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_319;
            }
            C2Rust_Block_26::S_319 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_321;
            }
            C2Rust_Block_26::S_321 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_323;
            }
            C2Rust_Block_26::S_323 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_325;
            }
            C2Rust_Block_26::S_325 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_328;
            }
            C2Rust_Block_26::S_328 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_26 = C2Rust_Block_26::S_334;
            }
            C2Rust_Block_26::S_334 => {
                _pv_4 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_26 = C2Rust_Block_26::S_336;
            }
            C2Rust_Block_26::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_338;
            }
            C2Rust_Block_26::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_348;
            }
            C2Rust_Block_26::S_348 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_26 = C2Rust_Block_26::S_350;
            }
            C2Rust_Block_26::S_350 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_352;
            }
            C2Rust_Block_26::S_352 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_359;
            }
            C2Rust_Block_26::S_359 => {
                _icall_target = (*__gamepkg_tls_g_edx);
                c2rust_current_block_26 = C2Rust_Block_26::S_365;
            }
            C2Rust_Block_26::S_365 => {
                _pv_6 = 0x210fd2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_367;
            }
            C2Rust_Block_26::S_367 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_369;
            }
            C2Rust_Block_26::S_369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_379;
            }
            C2Rust_Block_26::S_379 => {
                _va = _icall_target;
                c2rust_current_block_26 = C2Rust_Block_26::S_381;
            }
            C2Rust_Block_26::S_381 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_383;
            }
            C2Rust_Block_26::S_383 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_385;
            }
            C2Rust_Block_26::S_385 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_387;
            }
            C2Rust_Block_26::S_387 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_26 = C2Rust_Block_26::S_390;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_402;
                }
            }
            C2Rust_Block_26::S_390 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_26 = C2Rust_Block_26::S_392;
            }
            C2Rust_Block_26::S_392 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_26 = C2Rust_Block_26::S_394;
            }
            C2Rust_Block_26::S_394 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_451;
            }
            C2Rust_Block_26::S_402 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_26 = C2Rust_Block_26::S_404;
            }
            C2Rust_Block_26::S_404 => {
                if _fn.is_none() {
                    c2rust_current_block_26 = C2Rust_Block_26::S_406;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_410;
                }
            }
            C2Rust_Block_26::S_406 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_26 = C2Rust_Block_26::S_410;
            }
            C2Rust_Block_26::S_410 => {
                if _fn.is_none() {
                    c2rust_current_block_26 = C2Rust_Block_26::S_412;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_416;
                }
            }
            C2Rust_Block_26::S_412 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_26 = C2Rust_Block_26::S_416;
            }
            C2Rust_Block_26::S_416 => {
                if _fn.is_some() {
                    c2rust_current_block_26 = C2Rust_Block_26::S_422;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_429;
                }
            }
            C2Rust_Block_26::S_422 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_26 = C2Rust_Block_26::S_451;
            }
            C2Rust_Block_26::S_429 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_26 = C2Rust_Block_26::S_431;
            }
            C2Rust_Block_26::S_431 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_26 = C2Rust_Block_26::S_433;
            }
            C2Rust_Block_26::S_433 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_451;
            }
            C2Rust_Block_26::S_451 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_453;
            }
            C2Rust_Block_26::S_453 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_455;
            }
            C2Rust_Block_26::S_455 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_457;
            }
            C2Rust_Block_26::S_457 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_459;
            }
            C2Rust_Block_26::S_459 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_461;
            }
            C2Rust_Block_26::S_461 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_471;
            }
            C2Rust_Block_26::S_471 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_473;
            }
            C2Rust_Block_26::S_473 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_479;
            }
            C2Rust_Block_26::S_479 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_26 = C2Rust_Block_26::S_481;
            }
            C2Rust_Block_26::S_481 => return,
            C2Rust_Block_26::S_487 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_489;
            }
            C2Rust_Block_26::S_489 => {
                _fb = 0x65707374 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_491;
            }
            C2Rust_Block_26::S_491 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_493;
            }
            C2Rust_Block_26::S_493 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_495;
            }
            C2Rust_Block_26::S_495 => {
                if _fa != _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_213;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_504;
                }
            }
            C2Rust_Block_26::S_504 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_506;
            }
            C2Rust_Block_26::S_506 => {
                _fb = 0x66756c6c as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_508;
            }
            C2Rust_Block_26::S_508 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_510;
            }
            C2Rust_Block_26::S_510 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_512;
            }
            C2Rust_Block_26::S_512 => {
                if _fa != _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_182;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_521;
                }
            }
            C2Rust_Block_26::S_521 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xfffffffb as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_26 = C2Rust_Block_26::S_182;
            }
            C2Rust_Block_26::S_529 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_531;
            }
            C2Rust_Block_26::S_531 => {
                _fb = 0x696e7674 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_533;
            }
            C2Rust_Block_26::S_533 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_535;
            }
            C2Rust_Block_26::S_535 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_537;
            }
            C2Rust_Block_26::S_537 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_504;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_546;
                }
            }
            C2Rust_Block_26::S_546 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_548;
            }
            C2Rust_Block_26::S_548 => {
                _fb = 0x73656e64 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_550;
            }
            C2Rust_Block_26::S_550 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_552;
            }
            C2Rust_Block_26::S_552 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_554;
            }
            C2Rust_Block_26::S_554 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_124;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_563;
                }
            }
            C2Rust_Block_26::S_563 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_565;
            }
            C2Rust_Block_26::S_565 => {
                _fb = 0x75736572 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_567;
            }
            C2Rust_Block_26::S_567 => {
                _fas = _fa as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_569;
            }
            C2Rust_Block_26::S_569 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_26 = C2Rust_Block_26::S_571;
            }
            C2Rust_Block_26::S_571 => {
                if _fa == _fb {
                    c2rust_current_block_26 = C2Rust_Block_26::S_504;
                } else {
                    c2rust_current_block_26 = C2Rust_Block_26::S_213;
                }
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211020() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_57: {
        if _fa == _fb {
            break 's_57;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ebx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_452: {
            if _fa != _fb {
                break 's_452;
            }
            let mut _pv_0: uint32_t = ebp;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x14 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t)
                        as usize,
                ),
            );
            let mut _pv_4: uint32_t = 0x211043 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_256: {
                's_195: {
                    if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                    {
                        break 's_195;
                    }
                    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                    's_215: {
                        if !_fn.is_none() {
                            break 's_215;
                        }
                        _fn = recomp_lookup(_va);
                    }
                    's_221: {
                        if !_fn.is_none() {
                            break 's_221;
                        }
                        _fn = recomp_lookup_kernel(_va);
                    }
                    's_227: {
                        if _fn.is_some() {
                            break 's_227;
                        }
                        recomp_icall_fail_log(_va);
                        (*__gamepkg_tls_g_esp) = _icall_esp;
                        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                        break 's_256;
                    }
                    _fn.expect("non-null function pointer")();
                    break 's_256;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            let mut _pv_8: uint32_t = 0x211061 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            sub_0021BFF0();
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
            let mut _pv_9: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            let mut _pv_10: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            let mut _pv_11: uint32_t = 0x21106b as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_11,
            );
            sub_0021C2F0();
            _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                .wrapping_add(0x18 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edi),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ebp,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ebx),
            );
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ebx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ebp = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        }
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211090() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    enum C2Rust_Block_28 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_40,
        S_42,
        S_44,
        S_50,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_84,
        S_86,
        S_88,
        S_94,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_129,
        S_131,
        S_133,
        S_135,
        S_137,
        S_139,
        S_141,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_202,
        S_204,
        S_210,
        S_212,
        S_214,
        S_224,
        S_226,
        S_228,
        S_238,
        S_240,
        S_242,
        S_248,
        S_254,
        S_256,
        S_258,
        S_268,
        S_270,
        S_272,
        S_282,
        S_284,
        S_286,
        S_292,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_344,
        S_346,
        S_352,
        S_354,
        S_356,
        S_366,
        S_368,
        S_370,
        S_380,
        S_382,
        S_384,
        S_390,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_416,
        S_418,
        S_420,
        S_430,
        S_432,
        S_434,
        S_444,
        S_446,
        S_448,
        S_454,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_474,
        S_476,
        S_486,
        S_488,
        S_494,
        S_496,
        S_502,
        S_512,
        S_514,
        S_520,
        S_522,
        S_524,
        S_530,
        S_532,
        S_538,
        S_540,
    }
    let mut c2rust_current_block_28: C2Rust_Block_28;
    c2rust_current_block_28 = C2Rust_Block_28::S_0;
    loop {
        match c2rust_current_block_28 {
            C2Rust_Block_28::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_28 = C2Rust_Block_28::S_2;
            }
            C2Rust_Block_28::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_4;
            }
            C2Rust_Block_28::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_22;
            }
            C2Rust_Block_28::S_22 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_28 = C2Rust_Block_28::S_24;
            }
            C2Rust_Block_28::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_26;
            }
            C2Rust_Block_28::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_32;
            }
            C2Rust_Block_28::S_32 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_34;
            }
            C2Rust_Block_28::S_34 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_40;
            }
            C2Rust_Block_28::S_40 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_28 = C2Rust_Block_28::S_42;
            }
            C2Rust_Block_28::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_44;
            }
            C2Rust_Block_28::S_44 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_50;
            }
            C2Rust_Block_28::S_50 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x118 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_56;
            }
            C2Rust_Block_28::S_56 => {
                _pv_1 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_58;
            }
            C2Rust_Block_28::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_60;
            }
            C2Rust_Block_28::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_70;
            }
            C2Rust_Block_28::S_70 => {
                _pv_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_28 = C2Rust_Block_28::S_72;
            }
            C2Rust_Block_28::S_72 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_74;
            }
            C2Rust_Block_28::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_84;
            }
            C2Rust_Block_28::S_84 => {
                _pv_3 = 0x2110a7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_86;
            }
            C2Rust_Block_28::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_88;
            }
            C2Rust_Block_28::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_94;
            }
            C2Rust_Block_28::S_94 => {
                sub_0021E1A0();
                c2rust_current_block_28 = C2Rust_Block_28::S_100;
            }
            C2Rust_Block_28::S_100 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_102;
            }
            C2Rust_Block_28::S_102 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_104;
            }
            C2Rust_Block_28::S_104 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_106;
            }
            C2Rust_Block_28::S_106 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_108;
            }
            C2Rust_Block_28::S_108 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_110;
            }
            C2Rust_Block_28::S_110 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_112;
            }
            C2Rust_Block_28::S_112 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_114;
            }
            C2Rust_Block_28::S_114 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_116;
            }
            C2Rust_Block_28::S_116 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_118;
            }
            C2Rust_Block_28::S_118 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_120;
            }
            C2Rust_Block_28::S_120 => {
                if _fa == _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_202;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_129;
                }
            }
            C2Rust_Block_28::S_129 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x108 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_131;
            }
            C2Rust_Block_28::S_131 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x210 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_133;
            }
            C2Rust_Block_28::S_133 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_135;
            }
            C2Rust_Block_28::S_135 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_137;
            }
            C2Rust_Block_28::S_137 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_139;
            }
            C2Rust_Block_28::S_139 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_141;
            }
            C2Rust_Block_28::S_141 => {
                if _fa == _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_416;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_150;
                }
            }
            C2Rust_Block_28::S_150 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0x100000 as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_152;
            }
            C2Rust_Block_28::S_152 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_154;
            }
            C2Rust_Block_28::S_154 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_156;
            }
            C2Rust_Block_28::S_156 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_158;
            }
            C2Rust_Block_28::S_158 => {
                if _fa == _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_202;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_167;
                }
            }
            C2Rust_Block_28::S_167 => {
                _fa = (*__gamepkg_tls_g_eax) & 0x204 as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_169;
            }
            C2Rust_Block_28::S_169 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_171;
            }
            C2Rust_Block_28::S_171 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_173;
            }
            C2Rust_Block_28::S_173 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_175;
            }
            C2Rust_Block_28::S_175 => {
                if _fa == _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_202;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_184;
                }
            }
            C2Rust_Block_28::S_184 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffefffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_186;
            }
            C2Rust_Block_28::S_186 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_188;
            }
            C2Rust_Block_28::S_188 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_190;
            }
            C2Rust_Block_28::S_190 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x210 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_192;
            }
            C2Rust_Block_28::S_192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xf8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0xf8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffefffff as uint32_t,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_194;
            }
            C2Rust_Block_28::S_194 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xf8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_196;
            }
            C2Rust_Block_28::S_196 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_202;
            }
            C2Rust_Block_28::S_202 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xac as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_204;
            }
            C2Rust_Block_28::S_204 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_210;
            }
            C2Rust_Block_28::S_210 => {
                _pv_4 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_28 = C2Rust_Block_28::S_212;
            }
            C2Rust_Block_28::S_212 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_214;
            }
            C2Rust_Block_28::S_214 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_224;
            }
            C2Rust_Block_28::S_224 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_28 = C2Rust_Block_28::S_226;
            }
            C2Rust_Block_28::S_226 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_228;
            }
            C2Rust_Block_28::S_228 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_238;
            }
            C2Rust_Block_28::S_238 => {
                _pv_6 = 0x210f50 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_240;
            }
            C2Rust_Block_28::S_240 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_242;
            }
            C2Rust_Block_28::S_242 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_248;
            }
            C2Rust_Block_28::S_248 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x124 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_254;
            }
            C2Rust_Block_28::S_254 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_256;
            }
            C2Rust_Block_28::S_256 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_258;
            }
            C2Rust_Block_28::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_268;
            }
            C2Rust_Block_28::S_268 => {
                _pv_8 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_28 = C2Rust_Block_28::S_270;
            }
            C2Rust_Block_28::S_270 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_272;
            }
            C2Rust_Block_28::S_272 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_282;
            }
            C2Rust_Block_28::S_282 => {
                _pv_9 = 0x211105 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_284;
            }
            C2Rust_Block_28::S_284 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_286;
            }
            C2Rust_Block_28::S_286 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_292;
            }
            C2Rust_Block_28::S_292 => {
                sub_0021EFA0();
                c2rust_current_block_28 = C2Rust_Block_28::S_298;
            }
            C2Rust_Block_28::S_298 => {
                _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_300;
            }
            C2Rust_Block_28::S_300 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_302;
            }
            C2Rust_Block_28::S_302 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_304;
            }
            C2Rust_Block_28::S_304 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_306;
            }
            C2Rust_Block_28::S_306 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_308;
            }
            C2Rust_Block_28::S_308 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_310;
            }
            C2Rust_Block_28::S_310 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_312;
            }
            C2Rust_Block_28::S_312 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_314;
            }
            C2Rust_Block_28::S_314 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_316;
            }
            C2Rust_Block_28::S_316 => {
                if _fa != _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_502;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_325;
                }
            }
            C2Rust_Block_28::S_325 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_327;
            }
            C2Rust_Block_28::S_327 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_329;
            }
            C2Rust_Block_28::S_329 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_331;
            }
            C2Rust_Block_28::S_331 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_333;
            }
            C2Rust_Block_28::S_333 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xffffffff as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_335;
            }
            C2Rust_Block_28::S_335 => {
                if _fa != _fb {
                    c2rust_current_block_28 = C2Rust_Block_28::S_512;
                } else {
                    c2rust_current_block_28 = C2Rust_Block_28::S_344;
                }
            }
            C2Rust_Block_28::S_344 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_346;
            }
            C2Rust_Block_28::S_346 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x118 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_352;
            }
            C2Rust_Block_28::S_352 => {
                _pv_10 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_28 = C2Rust_Block_28::S_354;
            }
            C2Rust_Block_28::S_354 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_356;
            }
            C2Rust_Block_28::S_356 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_366;
            }
            C2Rust_Block_28::S_366 => {
                _pv_11 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_368;
            }
            C2Rust_Block_28::S_368 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_370;
            }
            C2Rust_Block_28::S_370 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_380;
            }
            C2Rust_Block_28::S_380 => {
                _pv_12 = 0x211128 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_382;
            }
            C2Rust_Block_28::S_382 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_384;
            }
            C2Rust_Block_28::S_384 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_390;
            }
            C2Rust_Block_28::S_390 => {
                sub_0021E1A0();
                c2rust_current_block_28 = C2Rust_Block_28::S_396;
            }
            C2Rust_Block_28::S_396 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_398;
            }
            C2Rust_Block_28::S_398 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_400;
            }
            C2Rust_Block_28::S_400 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_402;
            }
            C2Rust_Block_28::S_402 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_404;
            }
            C2Rust_Block_28::S_404 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_406;
            }
            C2Rust_Block_28::S_406 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_28 = C2Rust_Block_28::S_416;
            }
            C2Rust_Block_28::S_416 => {
                _pv_13 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_28 = C2Rust_Block_28::S_418;
            }
            C2Rust_Block_28::S_418 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_420;
            }
            C2Rust_Block_28::S_420 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_430;
            }
            C2Rust_Block_28::S_430 => {
                _pv_14 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_28 = C2Rust_Block_28::S_432;
            }
            C2Rust_Block_28::S_432 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_434;
            }
            C2Rust_Block_28::S_434 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_444;
            }
            C2Rust_Block_28::S_444 => {
                _pv_15 = 0x211134 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_446;
            }
            C2Rust_Block_28::S_446 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_448;
            }
            C2Rust_Block_28::S_448 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_454;
            }
            C2Rust_Block_28::S_454 => {
                sub_00211020();
                c2rust_current_block_28 = C2Rust_Block_28::S_460;
            }
            C2Rust_Block_28::S_460 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_462;
            }
            C2Rust_Block_28::S_462 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_464;
            }
            C2Rust_Block_28::S_464 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_466;
            }
            C2Rust_Block_28::S_466 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_468;
            }
            C2Rust_Block_28::S_468 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_474;
            }
            C2Rust_Block_28::S_474 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_476;
            }
            C2Rust_Block_28::S_476 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_486;
            }
            C2Rust_Block_28::S_486 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_488;
            }
            C2Rust_Block_28::S_488 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_494;
            }
            C2Rust_Block_28::S_494 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_496;
            }
            C2Rust_Block_28::S_496 => return,
            C2Rust_Block_28::S_502 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_512;
            }
            C2Rust_Block_28::S_512 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_514;
            }
            C2Rust_Block_28::S_514 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_520;
            }
            C2Rust_Block_28::S_520 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_522;
            }
            C2Rust_Block_28::S_522 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_524;
            }
            C2Rust_Block_28::S_524 => {
                _fas = _fa as int32_t;
                c2rust_current_block_28 = C2Rust_Block_28::S_530;
            }
            C2Rust_Block_28::S_530 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_28 = C2Rust_Block_28::S_532;
            }
            C2Rust_Block_28::S_532 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_538;
            }
            C2Rust_Block_28::S_538 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_28 = C2Rust_Block_28::S_540;
            }
            C2Rust_Block_28::S_540 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211150() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    enum C2Rust_Block_29 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_52,
        S_58,
        S_60,
        S_62,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_93,
        S_95,
        S_97,
        S_99,
        S_101,
        S_103,
        S_116,
        S_118,
        S_120,
        S_130,
        S_132,
        S_134,
        S_144,
        S_146,
        S_148,
        S_154,
        S_156,
        S_158,
        S_164,
        S_166,
        S_168,
        S_174,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_213,
        S_219,
        S_221,
        S_223,
        S_233,
        S_235,
        S_237,
        S_247,
        S_249,
        S_251,
        S_257,
        S_263,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_345,
        S_347,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_395,
        S_401,
        S_403,
        S_409,
        S_415,
        S_417,
        S_427,
        S_429,
        S_435,
        S_437,
        S_443,
        S_445,
        S_455,
        S_457,
        S_463,
        S_465,
        S_471,
        S_473,
        S_475,
        S_481,
        S_483,
        S_493,
        S_495,
        S_505,
        S_507,
        S_513,
        S_515,
        S_521,
        S_523,
        S_533,
        S_535,
        S_541,
        S_543,
        S_549,
        S_555,
        S_557,
        S_567,
        S_569,
        S_579,
        S_581,
        S_587,
        S_589,
    }
    let mut c2rust_current_block_29: C2Rust_Block_29;
    c2rust_current_block_29 = C2Rust_Block_29::S_0;
    loop {
        match c2rust_current_block_29 {
            C2Rust_Block_29::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_2;
            }
            C2Rust_Block_29::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_29 = C2Rust_Block_29::S_4;
            }
            C2Rust_Block_29::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_29 = C2Rust_Block_29::S_6;
            }
            C2Rust_Block_29::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_8;
            }
            C2Rust_Block_29::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_18;
            }
            C2Rust_Block_29::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_29 = C2Rust_Block_29::S_28;
            }
            C2Rust_Block_29::S_28 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_29 = C2Rust_Block_29::S_30;
            }
            C2Rust_Block_29::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_32;
            }
            C2Rust_Block_29::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_42;
            }
            C2Rust_Block_29::S_42 => {
                _pv_0 = ebp;
                c2rust_current_block_29 = C2Rust_Block_29::S_44;
            }
            C2Rust_Block_29::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_46;
            }
            C2Rust_Block_29::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_52;
            }
            C2Rust_Block_29::S_52 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_58;
            }
            C2Rust_Block_29::S_58 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_29 = C2Rust_Block_29::S_60;
            }
            C2Rust_Block_29::S_60 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_62;
            }
            C2Rust_Block_29::S_62 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_68;
            }
            C2Rust_Block_29::S_68 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) | 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_70;
            }
            C2Rust_Block_29::S_70 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_72;
            }
            C2Rust_Block_29::S_72 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_74;
            }
            C2Rust_Block_29::S_74 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_76;
            }
            C2Rust_Block_29::S_76 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_78;
            }
            C2Rust_Block_29::S_78 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_80;
            }
            C2Rust_Block_29::S_80 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_82;
            }
            C2Rust_Block_29::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_84;
            }
            C2Rust_Block_29::S_84 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_549;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_93;
                }
            }
            C2Rust_Block_29::S_93 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_95;
            }
            C2Rust_Block_29::S_95 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_97;
            }
            C2Rust_Block_29::S_97 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_99;
            }
            C2Rust_Block_29::S_99 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_101;
            }
            C2Rust_Block_29::S_101 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_103;
            }
            C2Rust_Block_29::S_103 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_549;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_116;
                }
            }
            C2Rust_Block_29::S_116 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_29 = C2Rust_Block_29::S_118;
            }
            C2Rust_Block_29::S_118 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_120;
            }
            C2Rust_Block_29::S_120 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_130;
            }
            C2Rust_Block_29::S_130 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_29 = C2Rust_Block_29::S_132;
            }
            C2Rust_Block_29::S_132 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_134;
            }
            C2Rust_Block_29::S_134 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_144;
            }
            C2Rust_Block_29::S_144 => {
                _pv_4 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_146;
            }
            C2Rust_Block_29::S_146 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_148;
            }
            C2Rust_Block_29::S_148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_154;
            }
            C2Rust_Block_29::S_154 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_156;
            }
            C2Rust_Block_29::S_156 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_158;
            }
            C2Rust_Block_29::S_158 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_164;
            }
            C2Rust_Block_29::S_164 => {
                _pv_5 = 0x211173 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_166;
            }
            C2Rust_Block_29::S_166 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_168;
            }
            C2Rust_Block_29::S_168 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_174;
            }
            C2Rust_Block_29::S_174 => {
                sub_001B35F0();
                c2rust_current_block_29 = C2Rust_Block_29::S_180;
            }
            C2Rust_Block_29::S_180 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_182;
            }
            C2Rust_Block_29::S_182 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_184;
            }
            C2Rust_Block_29::S_184 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_186;
            }
            C2Rust_Block_29::S_186 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_188;
            }
            C2Rust_Block_29::S_188 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_190;
            }
            C2Rust_Block_29::S_190 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_192;
            }
            C2Rust_Block_29::S_192 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_194;
            }
            C2Rust_Block_29::S_194 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_196;
            }
            C2Rust_Block_29::S_196 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_198;
            }
            C2Rust_Block_29::S_198 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_200;
            }
            C2Rust_Block_29::S_200 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    <= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_29 = C2Rust_Block_29::S_471;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_213;
                }
            }
            C2Rust_Block_29::S_213 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_219;
            }
            C2Rust_Block_29::S_219 => {
                _pv_6 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_29 = C2Rust_Block_29::S_221;
            }
            C2Rust_Block_29::S_221 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_223;
            }
            C2Rust_Block_29::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_233;
            }
            C2Rust_Block_29::S_233 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_235;
            }
            C2Rust_Block_29::S_235 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_237;
            }
            C2Rust_Block_29::S_237 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_247;
            }
            C2Rust_Block_29::S_247 => {
                _pv_8 = 0x21118a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_249;
            }
            C2Rust_Block_29::S_249 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_251;
            }
            C2Rust_Block_29::S_251 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_257;
            }
            C2Rust_Block_29::S_257 => {
                sub_0021C240();
                c2rust_current_block_29 = C2Rust_Block_29::S_263;
            }
            C2Rust_Block_29::S_263 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_265;
            }
            C2Rust_Block_29::S_265 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_267;
            }
            C2Rust_Block_29::S_267 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_269;
            }
            C2Rust_Block_29::S_269 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_271;
            }
            C2Rust_Block_29::S_271 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_273;
            }
            C2Rust_Block_29::S_273 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_275;
            }
            C2Rust_Block_29::S_275 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_277;
            }
            C2Rust_Block_29::S_277 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_279;
            }
            C2Rust_Block_29::S_279 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_281;
            }
            C2Rust_Block_29::S_281 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_353;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_290;
                }
            }
            C2Rust_Block_29::S_290 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_292;
            }
            C2Rust_Block_29::S_292 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_294;
            }
            C2Rust_Block_29::S_294 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_296;
            }
            C2Rust_Block_29::S_296 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_298;
            }
            C2Rust_Block_29::S_298 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_300;
            }
            C2Rust_Block_29::S_300 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_326;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_309;
                }
            }
            C2Rust_Block_29::S_309 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_311;
            }
            C2Rust_Block_29::S_311 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_313;
            }
            C2Rust_Block_29::S_313 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_315;
            }
            C2Rust_Block_29::S_315 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_317;
            }
            C2Rust_Block_29::S_317 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_353;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_326;
                }
            }
            C2Rust_Block_29::S_326 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_328;
            }
            C2Rust_Block_29::S_328 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_330;
            }
            C2Rust_Block_29::S_330 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_332;
            }
            C2Rust_Block_29::S_332 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_334;
            }
            C2Rust_Block_29::S_334 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_336;
            }
            C2Rust_Block_29::S_336 => {
                if _fa >= _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_353;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_345;
                }
            }
            C2Rust_Block_29::S_345 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_347;
            }
            C2Rust_Block_29::S_347 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_353;
            }
            C2Rust_Block_29::S_353 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_29 = C2Rust_Block_29::S_355;
            }
            C2Rust_Block_29::S_355 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_357;
            }
            C2Rust_Block_29::S_357 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_359;
            }
            C2Rust_Block_29::S_359 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_361;
            }
            C2Rust_Block_29::S_361 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_363;
            }
            C2Rust_Block_29::S_363 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_365;
            }
            C2Rust_Block_29::S_365 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_367;
            }
            C2Rust_Block_29::S_367 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_369;
            }
            C2Rust_Block_29::S_369 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_29 = C2Rust_Block_29::S_213;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_378;
                }
            }
            C2Rust_Block_29::S_378 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_380;
            }
            C2Rust_Block_29::S_380 => {
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_382;
            }
            C2Rust_Block_29::S_382 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_384;
            }
            C2Rust_Block_29::S_384 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_386;
            }
            C2Rust_Block_29::S_386 => {
                if _fa >= _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_471;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_395;
                }
            }
            C2Rust_Block_29::S_395 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_401;
            }
            C2Rust_Block_29::S_401 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_403;
            }
            C2Rust_Block_29::S_403 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_409;
            }
            C2Rust_Block_29::S_409 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_29 = C2Rust_Block_29::S_415;
            }
            C2Rust_Block_29::S_415 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_417;
            }
            C2Rust_Block_29::S_417 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_427;
            }
            C2Rust_Block_29::S_427 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_429;
            }
            C2Rust_Block_29::S_429 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_435;
            }
            C2Rust_Block_29::S_435 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_437;
            }
            C2Rust_Block_29::S_437 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_443;
            }
            C2Rust_Block_29::S_443 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_445;
            }
            C2Rust_Block_29::S_445 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_455;
            }
            C2Rust_Block_29::S_455 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_457;
            }
            C2Rust_Block_29::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_463;
            }
            C2Rust_Block_29::S_463 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_465;
            }
            C2Rust_Block_29::S_465 => return,
            C2Rust_Block_29::S_471 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_473;
            }
            C2Rust_Block_29::S_473 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_475;
            }
            C2Rust_Block_29::S_475 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_481;
            }
            C2Rust_Block_29::S_481 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_483;
            }
            C2Rust_Block_29::S_483 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_493;
            }
            C2Rust_Block_29::S_493 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_495;
            }
            C2Rust_Block_29::S_495 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_505;
            }
            C2Rust_Block_29::S_505 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_507;
            }
            C2Rust_Block_29::S_507 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_513;
            }
            C2Rust_Block_29::S_513 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_515;
            }
            C2Rust_Block_29::S_515 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_521;
            }
            C2Rust_Block_29::S_521 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_523;
            }
            C2Rust_Block_29::S_523 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_533;
            }
            C2Rust_Block_29::S_533 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_535;
            }
            C2Rust_Block_29::S_535 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_541;
            }
            C2Rust_Block_29::S_541 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_543;
            }
            C2Rust_Block_29::S_543 => return,
            C2Rust_Block_29::S_549 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_29 = C2Rust_Block_29::S_555;
            }
            C2Rust_Block_29::S_555 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_557;
            }
            C2Rust_Block_29::S_557 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_567;
            }
            C2Rust_Block_29::S_567 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_569;
            }
            C2Rust_Block_29::S_569 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_579;
            }
            C2Rust_Block_29::S_579 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_581;
            }
            C2Rust_Block_29::S_581 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_587;
            }
            C2Rust_Block_29::S_587 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_589;
            }
            C2Rust_Block_29::S_589 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_002111F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_80: {
        if _fa == _fb {
            break 's_80;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_80;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x48 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_0021DDE0();
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211220() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_37: {
        if _fa == _fb {
            break 's_37;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x21124a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_0021DE00();
        _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0xfffffff8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211250() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_47: {
        if _fa != _fb {
            break 's_47;
        }
        (*__gamepkg_tls_g_eax) = 0xfffffffd as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211270() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0021E2D0();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211280() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_68: {
        if _fa == _fb {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_eax) = 0xfffffffb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002112B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_68: {
        if _fa == _fb {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_eax) = 0xfffffffb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002112E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_68: {
        if _fa == _fb {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_68;
        }
        (*__gamepkg_tls_g_eax) = 0xfffffffb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x5c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211310() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211320() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xf8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 9 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211340() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xf8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 0x12 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211360() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xf8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 0x13 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211380() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x85 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x85 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211390() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_61: {
        if _fa == _fb {
            break 's_61;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xf8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 2 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002113B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_49: {
        if _fa == _fb {
            break 's_49;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            int8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                int8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xf7 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as int32_t as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002113D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xf8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 0xd as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002113F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_197: {
        if _fa == _fb {
            break 's_197;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_197;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xb8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_197;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = 0x2a as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        _fb = 0x35 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x35 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x64 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x21141e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_002205E0();
        _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_5: uint32_t = 0x64 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    _fb = 0x35 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(0x35 as uint32_t);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x211434 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_00243880();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211440() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xf8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) >> 0x19 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211460() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xf0 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00211470() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x211482 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0021C240();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_107: {
        if _fa != _fb {
            break 's_107;
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_136: {
        if _fa == _fb {
            break 's_136;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) | 1 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002114A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_001B35F0();
}
