extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_cmp() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_cc() -> *mut uint16_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_00011000();
    fn sub_001D20AC();
    fn sub_002276E9();
    fn sub_002445E0();
    fn sub_00244750();
    fn sub_00244A20();
    fn sub_00244CA0();
    fn sub_0024DE67();
    fn sub_0024DFA1();
    fn sub_0024EFC3();
    fn sub_0024EFFB();
    fn sub_0024F023();
    fn sub_0024F094();
    fn sub_0024F0C9();
    fn sub_0024F0F5();
    fn sub_0024F109();
    fn sub_0024F15A();
    fn sub_0024F1A3();
    fn sub_0024F271();
    fn sub_0024F279();
    fn sub_0024F298();
    fn sub_0024F2D3();
    fn sub_00369C87();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn recomp_parity8(mut x: uint32_t) -> ::core::ffi::c_int {
    x = (x as ::core::ffi::c_uint & 0xff as ::core::ffi::c_uint) as uint32_t;
    x ^= x >> 4 as ::core::ffi::c_int;
    x ^= x >> 2 as ::core::ffi::c_int;
    x ^= x >> 1 as ::core::ffi::c_int;
    return (!x & 1 as uint32_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F30D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x374e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x24f322 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024F298();
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | (if _fa != _fb { 1 as ::core::ffi::c_int } else { 0 as ::core::ffi::c_int })
            as uint8_t as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F332() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_81: {
        if _fa != _fb {
            break 's_81;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x28 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (if _cf != 0 {
            0xffffffff as ::core::ffi::c_uint
        } else {
            0 as ::core::ffi::c_uint
        }) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
            .wrapping_add(3 as ::core::ffi::c_int as uint64_t)
            >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(3 as uint32_t);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x28 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F350() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_1: uint32_t = 6 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx);
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
        -(4 as ::core::ffi::c_int as int32_t)
    } else {
        4 as ::core::ffi::c_int as int32_t
    };
    _i = 0 as uint32_t;
    while _i < (*__gamepkg_tls_g_ecx) {
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(_i.wrapping_mul(_st as uint32_t))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        _i = _i.wrapping_add(1);
    }
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) << 7 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
        .wrapping_add(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ),
        );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x280 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F381() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_1: uint32_t = 6 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx);
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = if (*__gamepkg_tls_g_df) != 0 {
        -(4 as ::core::ffi::c_int as int32_t)
    } else {
        4 as ::core::ffi::c_int as int32_t
    };
    _i = 0 as uint32_t;
    while _i < (*__gamepkg_tls_g_ecx) {
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(_i.wrapping_mul(_st as uint32_t))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        _i = _i.wrapping_add(1);
    }
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) << 7 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
        .wrapping_add(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ),
        );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x280 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F3B2() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    let mut _icall_esp_2: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _icall_target_2: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _va_2: uint32_t = 0;
    let mut _fn_2: recomp_func_t = None;
    enum C2Rust_Block_5 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_55,
        S_61,
        S_63,
        S_65,
        S_75,
        S_77,
        S_79,
        S_85,
        S_87,
        S_93,
        S_95,
        S_97,
        S_103,
        S_106,
        S_112,
        S_114,
        S_116,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_137,
        S_139,
        S_141,
        S_149,
        S_151,
        S_153,
        S_157,
        S_159,
        S_163,
        S_169,
        S_176,
        S_178,
        S_180,
        S_202,
        S_204,
        S_206,
        S_212,
        S_218,
        S_220,
        S_222,
        S_228,
        S_230,
        S_232,
        S_238,
        S_240,
        S_242,
        S_248,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_281,
        S_283,
        S_286,
        S_292,
        S_294,
        S_296,
        S_306,
        S_308,
        S_310,
        S_320,
        S_322,
        S_324,
        S_334,
        S_336,
        S_338,
        S_348,
        S_350,
        S_352,
        S_359,
        S_365,
        S_367,
        S_369,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_390,
        S_392,
        S_394,
        S_402,
        S_404,
        S_406,
        S_410,
        S_412,
        S_416,
        S_422,
        S_429,
        S_431,
        S_433,
        S_455,
        S_457,
        S_459,
        S_465,
        S_471,
        S_473,
        S_475,
        S_481,
        S_483,
        S_489,
        S_491,
        S_493,
        S_499,
        S_505,
        S_507,
        S_509,
        S_512,
        S_518,
        S_520,
        S_522,
        S_532,
        S_534,
        S_536,
        S_546,
        S_548,
        S_550,
        S_557,
        S_563,
        S_565,
        S_567,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_588,
        S_590,
        S_592,
        S_600,
        S_602,
        S_604,
        S_608,
        S_610,
        S_614,
        S_620,
        S_627,
        S_629,
        S_631,
        S_649,
        S_652,
        S_658,
        S_660,
        S_662,
        S_669,
        S_675,
        S_677,
        S_679,
        S_689,
        S_691,
        S_693,
        S_695,
        S_697,
        S_700,
        S_702,
        S_704,
        S_712,
        S_714,
        S_716,
        S_720,
        S_722,
        S_726,
        S_732,
        S_739,
        S_741,
        S_743,
        S_765,
        S_767,
        S_777,
        S_779,
        S_785,
        S_791,
        S_793,
        S_799,
        S_801,
    }
    let mut c2rust_current_block_5: C2Rust_Block_5;
    c2rust_current_block_5 = C2Rust_Block_5::S_0;
    loop {
        match c2rust_current_block_5 {
            C2Rust_Block_5::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_2;
            }
            C2Rust_Block_5::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_5 = C2Rust_Block_5::S_4;
            }
            C2Rust_Block_5::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_6;
            }
            C2Rust_Block_5::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_8;
            }
            C2Rust_Block_5::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_26;
            }
            C2Rust_Block_5::S_26 => {
                _pv = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_28;
            }
            C2Rust_Block_5::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_30;
            }
            C2Rust_Block_5::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_36;
            }
            C2Rust_Block_5::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_5 = C2Rust_Block_5::S_38;
            }
            C2Rust_Block_5::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_40;
            }
            C2Rust_Block_5::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_42;
            }
            C2Rust_Block_5::S_42 => {
                _fb = 0x3c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_44;
            }
            C2Rust_Block_5::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_46;
            }
            C2Rust_Block_5::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x3c as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_48;
            }
            C2Rust_Block_5::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_50;
            }
            C2Rust_Block_5::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_52;
            }
            C2Rust_Block_5::S_52 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_55;
            }
            C2Rust_Block_5::S_55 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_5 = C2Rust_Block_5::S_61;
            }
            C2Rust_Block_5::S_61 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_63;
            }
            C2Rust_Block_5::S_63 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_65;
            }
            C2Rust_Block_5::S_65 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_75;
            }
            C2Rust_Block_5::S_75 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_77;
            }
            C2Rust_Block_5::S_77 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_79;
            }
            C2Rust_Block_5::S_79 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_85;
            }
            C2Rust_Block_5::S_85 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_87;
            }
            C2Rust_Block_5::S_87 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-60 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_93;
            }
            C2Rust_Block_5::S_93 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_95;
            }
            C2Rust_Block_5::S_95 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_97;
            }
            C2Rust_Block_5::S_97 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_103;
            }
            C2Rust_Block_5::S_103 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_5 = C2Rust_Block_5::S_106;
            }
            C2Rust_Block_5::S_106 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_112;
            }
            C2Rust_Block_5::S_112 => {
                _pv_3 = 0x24f3cd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_114;
            }
            C2Rust_Block_5::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_116;
            }
            C2Rust_Block_5::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_126;
            }
            C2Rust_Block_5::S_126 => {
                _va = _icall_target;
                c2rust_current_block_5 = C2Rust_Block_5::S_128;
            }
            C2Rust_Block_5::S_128 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_130;
            }
            C2Rust_Block_5::S_130 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_132;
            }
            C2Rust_Block_5::S_132 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_134;
            }
            C2Rust_Block_5::S_134 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_5 = C2Rust_Block_5::S_137;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_149;
                }
            }
            C2Rust_Block_5::S_137 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_5 = C2Rust_Block_5::S_139;
            }
            C2Rust_Block_5::S_139 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_5 = C2Rust_Block_5::S_141;
            }
            C2Rust_Block_5::S_141 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_202;
            }
            C2Rust_Block_5::S_149 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_5 = C2Rust_Block_5::S_151;
            }
            C2Rust_Block_5::S_151 => {
                if _fn.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_153;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_157;
                }
            }
            C2Rust_Block_5::S_153 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_5 = C2Rust_Block_5::S_157;
            }
            C2Rust_Block_5::S_157 => {
                if _fn.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_159;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_163;
                }
            }
            C2Rust_Block_5::S_159 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_5 = C2Rust_Block_5::S_163;
            }
            C2Rust_Block_5::S_163 => {
                if _fn.is_some() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_169;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_176;
                }
            }
            C2Rust_Block_5::S_169 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_5 = C2Rust_Block_5::S_202;
            }
            C2Rust_Block_5::S_176 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_5 = C2Rust_Block_5::S_178;
            }
            C2Rust_Block_5::S_178 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_5 = C2Rust_Block_5::S_180;
            }
            C2Rust_Block_5::S_180 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_202;
            }
            C2Rust_Block_5::S_202 => {
                _pv_4 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_204;
            }
            C2Rust_Block_5::S_204 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_206;
            }
            C2Rust_Block_5::S_206 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_212;
            }
            C2Rust_Block_5::S_212 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-28 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_218;
            }
            C2Rust_Block_5::S_218 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_220;
            }
            C2Rust_Block_5::S_220 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_222;
            }
            C2Rust_Block_5::S_222 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_228;
            }
            C2Rust_Block_5::S_228 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_230;
            }
            C2Rust_Block_5::S_230 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_232;
            }
            C2Rust_Block_5::S_232 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_238;
            }
            C2Rust_Block_5::S_238 => {
                _pv_6 = 0x24f3db as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_240;
            }
            C2Rust_Block_5::S_240 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_242;
            }
            C2Rust_Block_5::S_242 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_248;
            }
            C2Rust_Block_5::S_248 => {
                sub_0024F350();
                c2rust_current_block_5 = C2Rust_Block_5::S_254;
            }
            C2Rust_Block_5::S_254 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_256;
            }
            C2Rust_Block_5::S_256 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_258;
            }
            C2Rust_Block_5::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_260;
            }
            C2Rust_Block_5::S_260 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_262;
            }
            C2Rust_Block_5::S_262 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_264;
            }
            C2Rust_Block_5::S_264 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            )
                            .wrapping_add(0x28 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_266;
            }
            C2Rust_Block_5::S_266 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_268;
            }
            C2Rust_Block_5::S_268 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_270;
            }
            C2Rust_Block_5::S_270 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_272;
            }
            C2Rust_Block_5::S_272 => {
                if _fa == _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_455;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_281;
                }
            }
            C2Rust_Block_5::S_281 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_283;
            }
            C2Rust_Block_5::S_283 => {
                (*__gamepkg_tls_g_edx) = ebp
                    .wrapping_add(-4 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_286;
            }
            C2Rust_Block_5::S_286 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_5 = C2Rust_Block_5::S_292;
            }
            C2Rust_Block_5::S_292 => {
                _pv_7 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_5 = C2Rust_Block_5::S_294;
            }
            C2Rust_Block_5::S_294 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_296;
            }
            C2Rust_Block_5::S_296 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_306;
            }
            C2Rust_Block_5::S_306 => {
                _pv_8 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_308;
            }
            C2Rust_Block_5::S_308 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_310;
            }
            C2Rust_Block_5::S_310 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_320;
            }
            C2Rust_Block_5::S_320 => {
                _pv_9 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_322;
            }
            C2Rust_Block_5::S_322 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_324;
            }
            C2Rust_Block_5::S_324 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_334;
            }
            C2Rust_Block_5::S_334 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_336;
            }
            C2Rust_Block_5::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_338;
            }
            C2Rust_Block_5::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_348;
            }
            C2Rust_Block_5::S_348 => {
                _pv_11 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_350;
            }
            C2Rust_Block_5::S_350 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_352;
            }
            C2Rust_Block_5::S_352 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_359;
            }
            C2Rust_Block_5::S_359 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_365;
            }
            C2Rust_Block_5::S_365 => {
                _pv_12 = 0x24f3ff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_367;
            }
            C2Rust_Block_5::S_367 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_369;
            }
            C2Rust_Block_5::S_369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_379;
            }
            C2Rust_Block_5::S_379 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_5 = C2Rust_Block_5::S_381;
            }
            C2Rust_Block_5::S_381 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_383;
            }
            C2Rust_Block_5::S_383 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_385;
            }
            C2Rust_Block_5::S_385 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_387;
            }
            C2Rust_Block_5::S_387 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_5 = C2Rust_Block_5::S_390;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_402;
                }
            }
            C2Rust_Block_5::S_390 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_5 = C2Rust_Block_5::S_392;
            }
            C2Rust_Block_5::S_392 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_5 = C2Rust_Block_5::S_394;
            }
            C2Rust_Block_5::S_394 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_455;
            }
            C2Rust_Block_5::S_402 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_5 = C2Rust_Block_5::S_404;
            }
            C2Rust_Block_5::S_404 => {
                if _fn_0.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_406;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_410;
                }
            }
            C2Rust_Block_5::S_406 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_5 = C2Rust_Block_5::S_410;
            }
            C2Rust_Block_5::S_410 => {
                if _fn_0.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_412;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_416;
                }
            }
            C2Rust_Block_5::S_412 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_5 = C2Rust_Block_5::S_416;
            }
            C2Rust_Block_5::S_416 => {
                if _fn_0.is_some() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_422;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_429;
                }
            }
            C2Rust_Block_5::S_422 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_5 = C2Rust_Block_5::S_455;
            }
            C2Rust_Block_5::S_429 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_5 = C2Rust_Block_5::S_431;
            }
            C2Rust_Block_5::S_431 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_5 = C2Rust_Block_5::S_433;
            }
            C2Rust_Block_5::S_433 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_455;
            }
            C2Rust_Block_5::S_455 => {
                _pv_13 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_457;
            }
            C2Rust_Block_5::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_459;
            }
            C2Rust_Block_5::S_459 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_465;
            }
            C2Rust_Block_5::S_465 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_471;
            }
            C2Rust_Block_5::S_471 => {
                _pv_14 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_473;
            }
            C2Rust_Block_5::S_473 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_475;
            }
            C2Rust_Block_5::S_475 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_481;
            }
            C2Rust_Block_5::S_481 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_483;
            }
            C2Rust_Block_5::S_483 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_489;
            }
            C2Rust_Block_5::S_489 => {
                _pv_15 = 0x24f40d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_491;
            }
            C2Rust_Block_5::S_491 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_493;
            }
            C2Rust_Block_5::S_493 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_499;
            }
            C2Rust_Block_5::S_499 => {
                sub_0024F023();
                c2rust_current_block_5 = C2Rust_Block_5::S_505;
            }
            C2Rust_Block_5::S_505 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_507;
            }
            C2Rust_Block_5::S_507 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_509;
            }
            C2Rust_Block_5::S_509 => {
                (*__gamepkg_tls_g_ecx) = ebp
                    .wrapping_add(-28 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_512;
            }
            C2Rust_Block_5::S_512 => {
                _icall_esp_1 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_5 = C2Rust_Block_5::S_518;
            }
            C2Rust_Block_5::S_518 => {
                _pv_16 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_5 = C2Rust_Block_5::S_520;
            }
            C2Rust_Block_5::S_520 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_522;
            }
            C2Rust_Block_5::S_522 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_532;
            }
            C2Rust_Block_5::S_532 => {
                _pv_17 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_534;
            }
            C2Rust_Block_5::S_534 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_536;
            }
            C2Rust_Block_5::S_536 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_546;
            }
            C2Rust_Block_5::S_546 => {
                _pv_18 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_548;
            }
            C2Rust_Block_5::S_548 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_550;
            }
            C2Rust_Block_5::S_550 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_557;
            }
            C2Rust_Block_5::S_557 => {
                _icall_target_1 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_563;
            }
            C2Rust_Block_5::S_563 => {
                _pv_19 = 0x24f41c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_565;
            }
            C2Rust_Block_5::S_565 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_567;
            }
            C2Rust_Block_5::S_567 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_577;
            }
            C2Rust_Block_5::S_577 => {
                _va_1 = _icall_target_1;
                c2rust_current_block_5 = C2Rust_Block_5::S_579;
            }
            C2Rust_Block_5::S_579 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_1,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_581;
            }
            C2Rust_Block_5::S_581 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_583;
            }
            C2Rust_Block_5::S_583 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_585;
            }
            C2Rust_Block_5::S_585 => {
                if !(_va_1 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                {
                    c2rust_current_block_5 = C2Rust_Block_5::S_588;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_600;
                }
            }
            C2Rust_Block_5::S_588 => {
                recomp_icall_not_code_log(_va_1);
                c2rust_current_block_5 = C2Rust_Block_5::S_590;
            }
            C2Rust_Block_5::S_590 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_5 = C2Rust_Block_5::S_592;
            }
            C2Rust_Block_5::S_592 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_649;
            }
            C2Rust_Block_5::S_600 => {
                _fn_1 = recomp_lookup_manual(_va_1);
                c2rust_current_block_5 = C2Rust_Block_5::S_602;
            }
            C2Rust_Block_5::S_602 => {
                if _fn_1.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_604;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_608;
                }
            }
            C2Rust_Block_5::S_604 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block_5 = C2Rust_Block_5::S_608;
            }
            C2Rust_Block_5::S_608 => {
                if _fn_1.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_610;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_614;
                }
            }
            C2Rust_Block_5::S_610 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block_5 = C2Rust_Block_5::S_614;
            }
            C2Rust_Block_5::S_614 => {
                if _fn_1.is_some() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_620;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_627;
                }
            }
            C2Rust_Block_5::S_620 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block_5 = C2Rust_Block_5::S_649;
            }
            C2Rust_Block_5::S_627 => {
                recomp_icall_fail_log(_va_1);
                c2rust_current_block_5 = C2Rust_Block_5::S_629;
            }
            C2Rust_Block_5::S_629 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_5 = C2Rust_Block_5::S_631;
            }
            C2Rust_Block_5::S_631 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_649;
            }
            C2Rust_Block_5::S_649 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-60 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_652;
            }
            C2Rust_Block_5::S_652 => {
                _icall_esp_2 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_5 = C2Rust_Block_5::S_658;
            }
            C2Rust_Block_5::S_658 => {
                _pv_20 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_660;
            }
            C2Rust_Block_5::S_660 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_662;
            }
            C2Rust_Block_5::S_662 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_669;
            }
            C2Rust_Block_5::S_669 => {
                _icall_target_2 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b8cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_675;
            }
            C2Rust_Block_5::S_675 => {
                _pv_21 = 0x24f426 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_677;
            }
            C2Rust_Block_5::S_677 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_679;
            }
            C2Rust_Block_5::S_679 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_689;
            }
            C2Rust_Block_5::S_689 => {
                _va_2 = _icall_target_2;
                c2rust_current_block_5 = C2Rust_Block_5::S_691;
            }
            C2Rust_Block_5::S_691 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_2,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_693;
            }
            C2Rust_Block_5::S_693 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_695;
            }
            C2Rust_Block_5::S_695 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_697;
            }
            C2Rust_Block_5::S_697 => {
                if !(_va_2 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_2 >= g_xbox_code_lo && _va_2 < g_xbox_code_hi)
                {
                    c2rust_current_block_5 = C2Rust_Block_5::S_700;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_712;
                }
            }
            C2Rust_Block_5::S_700 => {
                recomp_icall_not_code_log(_va_2);
                c2rust_current_block_5 = C2Rust_Block_5::S_702;
            }
            C2Rust_Block_5::S_702 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_2;
                c2rust_current_block_5 = C2Rust_Block_5::S_704;
            }
            C2Rust_Block_5::S_704 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_765;
            }
            C2Rust_Block_5::S_712 => {
                _fn_2 = recomp_lookup_manual(_va_2);
                c2rust_current_block_5 = C2Rust_Block_5::S_714;
            }
            C2Rust_Block_5::S_714 => {
                if _fn_2.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_716;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_720;
                }
            }
            C2Rust_Block_5::S_716 => {
                _fn_2 = recomp_lookup(_va_2);
                c2rust_current_block_5 = C2Rust_Block_5::S_720;
            }
            C2Rust_Block_5::S_720 => {
                if _fn_2.is_none() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_722;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_726;
                }
            }
            C2Rust_Block_5::S_722 => {
                _fn_2 = recomp_lookup_kernel(_va_2);
                c2rust_current_block_5 = C2Rust_Block_5::S_726;
            }
            C2Rust_Block_5::S_726 => {
                if _fn_2.is_some() {
                    c2rust_current_block_5 = C2Rust_Block_5::S_732;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_739;
                }
            }
            C2Rust_Block_5::S_732 => {
                _fn_2.expect("non-null function pointer")();
                c2rust_current_block_5 = C2Rust_Block_5::S_765;
            }
            C2Rust_Block_5::S_739 => {
                recomp_icall_fail_log(_va_2);
                c2rust_current_block_5 = C2Rust_Block_5::S_741;
            }
            C2Rust_Block_5::S_741 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_2;
                c2rust_current_block_5 = C2Rust_Block_5::S_743;
            }
            C2Rust_Block_5::S_743 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_765;
            }
            C2Rust_Block_5::S_765 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_767;
            }
            C2Rust_Block_5::S_767 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_777;
            }
            C2Rust_Block_5::S_777 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_779;
            }
            C2Rust_Block_5::S_779 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_785;
            }
            C2Rust_Block_5::S_785 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_5 = C2Rust_Block_5::S_791;
            }
            C2Rust_Block_5::S_791 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_793;
            }
            C2Rust_Block_5::S_793 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_799;
            }
            C2Rust_Block_5::S_799 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_801;
            }
            C2Rust_Block_5::S_801 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F42C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _dividend_0: uint64_t = 0;
    let mut _dividend_1: uint64_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    enum C2Rust_Block_6 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_76,
        S_78,
        S_80,
        S_86,
        S_88,
        S_90,
        S_92,
        S_98,
        S_100,
        S_102,
        S_108,
        S_110,
        S_112,
        S_118,
        S_120,
        S_122,
        S_128,
        S_134,
        S_136,
        S_139,
        S_142,
        S_148,
        S_150,
        S_152,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_173,
        S_175,
        S_177,
        S_185,
        S_187,
        S_189,
        S_193,
        S_195,
        S_199,
        S_205,
        S_212,
        S_214,
        S_216,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_251,
        S_257,
        S_259,
        S_261,
        S_271,
        S_273,
        S_275,
        S_281,
        S_287,
        S_289,
        S_291,
        S_297,
        S_303,
        S_305,
        S_307,
        S_313,
        S_319,
        S_321,
        S_323,
        S_329,
        S_335,
        S_337,
        S_339,
        S_345,
        S_347,
        S_353,
        S_355,
        S_357,
        S_363,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_400,
        S_402,
        S_404,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_457,
        S_459,
        S_461,
        S_463,
        S_465,
        S_467,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_523,
        S_525,
        S_527,
        S_529,
        S_531,
        S_533,
        S_535,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_558,
        S_560,
        S_562,
        S_564,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_596,
        S_609,
        S_611,
        S_617,
        S_619,
        S_621,
        S_623,
        S_625,
        S_627,
        S_629,
        S_635,
        S_637,
        S_643,
        S_652,
        S_654,
        S_656,
        S_658,
        S_660,
        S_662,
        S_665,
        S_667,
        S_669,
        S_679,
        S_681,
        S_683,
        S_686,
        S_688,
        S_690,
        S_699,
        S_705,
        S_707,
        S_709,
        S_715,
        S_717,
        S_719,
        S_721,
        S_727,
        S_729,
        S_731,
        S_741,
        S_743,
        S_745,
        S_752,
        S_758,
        S_760,
        S_762,
        S_772,
        S_774,
        S_776,
        S_778,
        S_780,
        S_783,
        S_785,
        S_787,
        S_795,
        S_797,
        S_799,
        S_803,
        S_805,
        S_809,
        S_815,
        S_822,
        S_824,
        S_826,
        S_848,
        S_850,
        S_856,
        S_862,
        S_864,
        S_870,
        S_872,
    }
    let mut c2rust_current_block_6: C2Rust_Block_6;
    c2rust_current_block_6 = C2Rust_Block_6::S_0;
    loop {
        match c2rust_current_block_6 {
            C2Rust_Block_6::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2;
            }
            C2Rust_Block_6::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_6 = C2Rust_Block_6::S_4;
            }
            C2Rust_Block_6::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_6;
            }
            C2Rust_Block_6::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_8;
            }
            C2Rust_Block_6::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_26;
            }
            C2Rust_Block_6::S_26 => {
                _pv = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_28;
            }
            C2Rust_Block_6::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_30;
            }
            C2Rust_Block_6::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_36;
            }
            C2Rust_Block_6::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_6 = C2Rust_Block_6::S_38;
            }
            C2Rust_Block_6::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_40;
            }
            C2Rust_Block_6::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_42;
            }
            C2Rust_Block_6::S_42 => {
                _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_44;
            }
            C2Rust_Block_6::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_46;
            }
            C2Rust_Block_6::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x28 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_48;
            }
            C2Rust_Block_6::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_50;
            }
            C2Rust_Block_6::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_52;
            }
            C2Rust_Block_6::S_52 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_54;
            }
            C2Rust_Block_6::S_54 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_56;
            }
            C2Rust_Block_6::S_56 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_62;
            }
            C2Rust_Block_6::S_62 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_64;
            }
            C2Rust_Block_6::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_66;
            }
            C2Rust_Block_6::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_76;
            }
            C2Rust_Block_6::S_76 => {
                _pv_1 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_78;
            }
            C2Rust_Block_6::S_78 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_80;
            }
            C2Rust_Block_6::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_86;
            }
            C2Rust_Block_6::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_88;
            }
            C2Rust_Block_6::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_90;
            }
            C2Rust_Block_6::S_90 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_92;
            }
            C2Rust_Block_6::S_92 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-40 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_98;
            }
            C2Rust_Block_6::S_98 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_100;
            }
            C2Rust_Block_6::S_100 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_102;
            }
            C2Rust_Block_6::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_108;
            }
            C2Rust_Block_6::S_108 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_110;
            }
            C2Rust_Block_6::S_110 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_112;
            }
            C2Rust_Block_6::S_112 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_118;
            }
            C2Rust_Block_6::S_118 => {
                _pv_3 = 0x24f44c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_120;
            }
            C2Rust_Block_6::S_120 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_122;
            }
            C2Rust_Block_6::S_122 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_128;
            }
            C2Rust_Block_6::S_128 => {
                sub_0024F381();
                c2rust_current_block_6 = C2Rust_Block_6::S_134;
            }
            C2Rust_Block_6::S_134 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_136;
            }
            C2Rust_Block_6::S_136 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_139;
            }
            C2Rust_Block_6::S_139 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_6 = C2Rust_Block_6::S_142;
            }
            C2Rust_Block_6::S_142 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_148;
            }
            C2Rust_Block_6::S_148 => {
                _pv_4 = 0x24f454 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_150;
            }
            C2Rust_Block_6::S_150 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_152;
            }
            C2Rust_Block_6::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_162;
            }
            C2Rust_Block_6::S_162 => {
                _va = _icall_target;
                c2rust_current_block_6 = C2Rust_Block_6::S_164;
            }
            C2Rust_Block_6::S_164 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_166;
            }
            C2Rust_Block_6::S_166 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_168;
            }
            C2Rust_Block_6::S_168 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_170;
            }
            C2Rust_Block_6::S_170 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_6 = C2Rust_Block_6::S_173;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_185;
                }
            }
            C2Rust_Block_6::S_173 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_6 = C2Rust_Block_6::S_175;
            }
            C2Rust_Block_6::S_175 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_6 = C2Rust_Block_6::S_177;
            }
            C2Rust_Block_6::S_177 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_234;
            }
            C2Rust_Block_6::S_185 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_6 = C2Rust_Block_6::S_187;
            }
            C2Rust_Block_6::S_187 => {
                if _fn.is_none() {
                    c2rust_current_block_6 = C2Rust_Block_6::S_189;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_193;
                }
            }
            C2Rust_Block_6::S_189 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_6 = C2Rust_Block_6::S_193;
            }
            C2Rust_Block_6::S_193 => {
                if _fn.is_none() {
                    c2rust_current_block_6 = C2Rust_Block_6::S_195;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_199;
                }
            }
            C2Rust_Block_6::S_195 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_6 = C2Rust_Block_6::S_199;
            }
            C2Rust_Block_6::S_199 => {
                if _fn.is_some() {
                    c2rust_current_block_6 = C2Rust_Block_6::S_205;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_212;
                }
            }
            C2Rust_Block_6::S_205 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_6 = C2Rust_Block_6::S_234;
            }
            C2Rust_Block_6::S_212 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_6 = C2Rust_Block_6::S_214;
            }
            C2Rust_Block_6::S_214 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_6 = C2Rust_Block_6::S_216;
            }
            C2Rust_Block_6::S_216 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_234;
            }
            C2Rust_Block_6::S_234 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_236;
            }
            C2Rust_Block_6::S_236 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_238;
            }
            C2Rust_Block_6::S_238 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_240;
            }
            C2Rust_Block_6::S_240 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_242;
            }
            C2Rust_Block_6::S_242 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_848;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_251;
                }
            }
            C2Rust_Block_6::S_251 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_257;
            }
            C2Rust_Block_6::S_257 => {
                _pv_5 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_6 = C2Rust_Block_6::S_259;
            }
            C2Rust_Block_6::S_259 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_261;
            }
            C2Rust_Block_6::S_261 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_271;
            }
            C2Rust_Block_6::S_271 => {
                _pv_6 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_273;
            }
            C2Rust_Block_6::S_273 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_275;
            }
            C2Rust_Block_6::S_275 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_281;
            }
            C2Rust_Block_6::S_281 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-12 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_287;
            }
            C2Rust_Block_6::S_287 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_289;
            }
            C2Rust_Block_6::S_289 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_291;
            }
            C2Rust_Block_6::S_291 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_297;
            }
            C2Rust_Block_6::S_297 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-8 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_303;
            }
            C2Rust_Block_6::S_303 => {
                _pv_8 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_305;
            }
            C2Rust_Block_6::S_305 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_307;
            }
            C2Rust_Block_6::S_307 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_313;
            }
            C2Rust_Block_6::S_313 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-4 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_319;
            }
            C2Rust_Block_6::S_319 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_321;
            }
            C2Rust_Block_6::S_321 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_323;
            }
            C2Rust_Block_6::S_323 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_329;
            }
            C2Rust_Block_6::S_329 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_335;
            }
            C2Rust_Block_6::S_335 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_337;
            }
            C2Rust_Block_6::S_337 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_339;
            }
            C2Rust_Block_6::S_339 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_345;
            }
            C2Rust_Block_6::S_345 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_347;
            }
            C2Rust_Block_6::S_347 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_353;
            }
            C2Rust_Block_6::S_353 => {
                _pv_11 = 0x24f479 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_355;
            }
            C2Rust_Block_6::S_355 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_357;
            }
            C2Rust_Block_6::S_357 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_363;
            }
            C2Rust_Block_6::S_363 => {
                sub_0024DFA1();
                c2rust_current_block_6 = C2Rust_Block_6::S_369;
            }
            C2Rust_Block_6::S_369 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_371;
            }
            C2Rust_Block_6::S_371 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_373;
            }
            C2Rust_Block_6::S_373 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_375;
            }
            C2Rust_Block_6::S_375 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_377;
            }
            C2Rust_Block_6::S_377 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_379;
            }
            C2Rust_Block_6::S_379 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_381;
            }
            C2Rust_Block_6::S_381 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_383;
            }
            C2Rust_Block_6::S_383 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_385;
            }
            C2Rust_Block_6::S_385 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_387;
            }
            C2Rust_Block_6::S_387 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_389;
            }
            C2Rust_Block_6::S_389 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_391;
            }
            C2Rust_Block_6::S_391 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_393;
            }
            C2Rust_Block_6::S_393 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_395;
            }
            C2Rust_Block_6::S_395 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_397;
            }
            C2Rust_Block_6::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_400;
            }
            C2Rust_Block_6::S_400 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_402;
            }
            C2Rust_Block_6::S_402 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_404;
            }
            C2Rust_Block_6::S_404 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_408;
            }
            C2Rust_Block_6::S_408 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_410;
            }
            C2Rust_Block_6::S_410 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-40 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_412;
            }
            C2Rust_Block_6::S_412 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_414;
            }
            C2Rust_Block_6::S_414 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_416;
            }
            C2Rust_Block_6::S_416 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_418;
            }
            C2Rust_Block_6::S_418 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_420;
            }
            C2Rust_Block_6::S_420 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_422;
            }
            C2Rust_Block_6::S_422 => {
                (*__gamepkg_tls_g_ebx) = 0x140 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_424;
            }
            C2Rust_Block_6::S_424 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_426;
            }
            C2Rust_Block_6::S_426 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_428;
            }
            C2Rust_Block_6::S_428 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_430;
            }
            C2Rust_Block_6::S_430 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_432;
            }
            C2Rust_Block_6::S_432 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_sub((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_434;
            }
            C2Rust_Block_6::S_434 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_436;
            }
            C2Rust_Block_6::S_436 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_438;
            }
            C2Rust_Block_6::S_438 => {
                (*__gamepkg_tls_g_ecx) = 0x500 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_440;
            }
            C2Rust_Block_6::S_440 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_442;
            }
            C2Rust_Block_6::S_442 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_444;
            }
            C2Rust_Block_6::S_444 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_446;
            }
            C2Rust_Block_6::S_446 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_448;
            }
            C2Rust_Block_6::S_448 => {
                if _fa >= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_541;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_457;
                }
            }
            C2Rust_Block_6::S_457 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_459;
            }
            C2Rust_Block_6::S_459 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_461;
            }
            C2Rust_Block_6::S_461 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_463;
            }
            C2Rust_Block_6::S_463 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_6 = C2Rust_Block_6::S_465;
            }
            C2Rust_Block_6::S_465 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_467;
            }
            C2Rust_Block_6::S_467 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_523;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_476;
                }
            }
            C2Rust_Block_6::S_476 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(2 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_478;
            }
            C2Rust_Block_6::S_478 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_480;
            }
            C2Rust_Block_6::S_480 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_482;
            }
            C2Rust_Block_6::S_482 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_484;
            }
            C2Rust_Block_6::S_484 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_486;
            }
            C2Rust_Block_6::S_486 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_488;
            }
            C2Rust_Block_6::S_488 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_490;
            }
            C2Rust_Block_6::S_490 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_492;
            }
            C2Rust_Block_6::S_492 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_494;
            }
            C2Rust_Block_6::S_494 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_496;
            }
            C2Rust_Block_6::S_496 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_498;
            }
            C2Rust_Block_6::S_498 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_500;
            }
            C2Rust_Block_6::S_500 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_502;
            }
            C2Rust_Block_6::S_502 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_504;
            }
            C2Rust_Block_6::S_504 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_506;
            }
            C2Rust_Block_6::S_506 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_sub(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_508;
            }
            C2Rust_Block_6::S_508 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_510;
            }
            C2Rust_Block_6::S_510 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_512;
            }
            C2Rust_Block_6::S_512 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_514;
            }
            C2Rust_Block_6::S_514 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_476;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_523;
                }
            }
            C2Rust_Block_6::S_523 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_525;
            }
            C2Rust_Block_6::S_525 => {
                (*__gamepkg_tls_g_ebx) = 0x140 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_527;
            }
            C2Rust_Block_6::S_527 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_529;
            }
            C2Rust_Block_6::S_529 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_531;
            }
            C2Rust_Block_6::S_531 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_533;
            }
            C2Rust_Block_6::S_533 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_535;
            }
            C2Rust_Block_6::S_535 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_541;
            }
            C2Rust_Block_6::S_541 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_543;
            }
            C2Rust_Block_6::S_543 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_545;
            }
            C2Rust_Block_6::S_545 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_547;
            }
            C2Rust_Block_6::S_547 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_549;
            }
            C2Rust_Block_6::S_549 => {
                if _fa <= _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_609;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_558;
                }
            }
            C2Rust_Block_6::S_558 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(2 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_560;
            }
            C2Rust_Block_6::S_560 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_562;
            }
            C2Rust_Block_6::S_562 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_564;
            }
            C2Rust_Block_6::S_564 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_566;
            }
            C2Rust_Block_6::S_566 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_568;
            }
            C2Rust_Block_6::S_568 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_570;
            }
            C2Rust_Block_6::S_570 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_572;
            }
            C2Rust_Block_6::S_572 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_574;
            }
            C2Rust_Block_6::S_574 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_576;
            }
            C2Rust_Block_6::S_576 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_578;
            }
            C2Rust_Block_6::S_578 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_580;
            }
            C2Rust_Block_6::S_580 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_582;
            }
            C2Rust_Block_6::S_582 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_584;
            }
            C2Rust_Block_6::S_584 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_586;
            }
            C2Rust_Block_6::S_586 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_588;
            }
            C2Rust_Block_6::S_588 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_sub(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_590;
            }
            C2Rust_Block_6::S_590 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_592;
            }
            C2Rust_Block_6::S_592 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_594;
            }
            C2Rust_Block_6::S_594 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_596;
            }
            C2Rust_Block_6::S_596 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_558;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_609;
                }
            }
            C2Rust_Block_6::S_609 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_611;
            }
            C2Rust_Block_6::S_611 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_617;
            }
            C2Rust_Block_6::S_617 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_619;
            }
            C2Rust_Block_6::S_619 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_621;
            }
            C2Rust_Block_6::S_621 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_623;
            }
            C2Rust_Block_6::S_623 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_625;
            }
            C2Rust_Block_6::S_625 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_627;
            }
            C2Rust_Block_6::S_627 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_629;
            }
            C2Rust_Block_6::S_629 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_635;
            }
            C2Rust_Block_6::S_635 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_637;
            }
            C2Rust_Block_6::S_637 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_643;
            }
            C2Rust_Block_6::S_643 => {
                if _fa < _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_679;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_652;
                }
            }
            C2Rust_Block_6::S_652 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_654;
            }
            C2Rust_Block_6::S_654 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_656;
            }
            C2Rust_Block_6::S_656 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_658;
            }
            C2Rust_Block_6::S_658 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_6 = C2Rust_Block_6::S_660;
            }
            C2Rust_Block_6::S_660 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_662;
            }
            C2Rust_Block_6::S_662 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_665;
            }
            C2Rust_Block_6::S_665 => {
                _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_667;
            }
            C2Rust_Block_6::S_667 => {
                (*__gamepkg_tls_g_eax) = _dividend_0
                    .wrapping_div(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_669;
            }
            C2Rust_Block_6::S_669 => {
                (*__gamepkg_tls_g_edx) = _dividend_0
                    .wrapping_rem(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_699;
            }
            C2Rust_Block_6::S_679 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_681;
            }
            C2Rust_Block_6::S_681 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_683;
            }
            C2Rust_Block_6::S_683 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx))
                    .wrapping_add(-640 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_686;
            }
            C2Rust_Block_6::S_686 => {
                _dividend_1 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_688;
            }
            C2Rust_Block_6::S_688 => {
                (*__gamepkg_tls_g_eax) = _dividend_1
                    .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_690;
            }
            C2Rust_Block_6::S_690 => {
                (*__gamepkg_tls_g_edx) = _dividend_1
                    .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_699;
            }
            C2Rust_Block_6::S_699 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_6 = C2Rust_Block_6::S_705;
            }
            C2Rust_Block_6::S_705 => {
                _pv_12 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_707;
            }
            C2Rust_Block_6::S_707 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_709;
            }
            C2Rust_Block_6::S_709 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_715;
            }
            C2Rust_Block_6::S_715 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_717;
            }
            C2Rust_Block_6::S_717 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_719;
            }
            C2Rust_Block_6::S_719 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_721;
            }
            C2Rust_Block_6::S_721 => {
                (*__gamepkg_tls_g_ecx) = ebp
                    .wrapping_add(-40 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_727;
            }
            C2Rust_Block_6::S_727 => {
                _pv_13 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_6 = C2Rust_Block_6::S_729;
            }
            C2Rust_Block_6::S_729 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_731;
            }
            C2Rust_Block_6::S_731 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_741;
            }
            C2Rust_Block_6::S_741 => {
                _pv_14 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_743;
            }
            C2Rust_Block_6::S_743 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_745;
            }
            C2Rust_Block_6::S_745 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_752;
            }
            C2Rust_Block_6::S_752 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_758;
            }
            C2Rust_Block_6::S_758 => {
                _pv_15 = 0x24f512 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_760;
            }
            C2Rust_Block_6::S_760 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_762;
            }
            C2Rust_Block_6::S_762 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_772;
            }
            C2Rust_Block_6::S_772 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_6 = C2Rust_Block_6::S_774;
            }
            C2Rust_Block_6::S_774 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_776;
            }
            C2Rust_Block_6::S_776 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_778;
            }
            C2Rust_Block_6::S_778 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_780;
            }
            C2Rust_Block_6::S_780 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_6 = C2Rust_Block_6::S_783;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_795;
                }
            }
            C2Rust_Block_6::S_783 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_6 = C2Rust_Block_6::S_785;
            }
            C2Rust_Block_6::S_785 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_6 = C2Rust_Block_6::S_787;
            }
            C2Rust_Block_6::S_787 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_848;
            }
            C2Rust_Block_6::S_795 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_6 = C2Rust_Block_6::S_797;
            }
            C2Rust_Block_6::S_797 => {
                if _fn_0.is_none() {
                    c2rust_current_block_6 = C2Rust_Block_6::S_799;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_803;
                }
            }
            C2Rust_Block_6::S_799 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_6 = C2Rust_Block_6::S_803;
            }
            C2Rust_Block_6::S_803 => {
                if _fn_0.is_none() {
                    c2rust_current_block_6 = C2Rust_Block_6::S_805;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_809;
                }
            }
            C2Rust_Block_6::S_805 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_6 = C2Rust_Block_6::S_809;
            }
            C2Rust_Block_6::S_809 => {
                if _fn_0.is_some() {
                    c2rust_current_block_6 = C2Rust_Block_6::S_815;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_822;
                }
            }
            C2Rust_Block_6::S_815 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_6 = C2Rust_Block_6::S_848;
            }
            C2Rust_Block_6::S_822 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_6 = C2Rust_Block_6::S_824;
            }
            C2Rust_Block_6::S_824 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_6 = C2Rust_Block_6::S_826;
            }
            C2Rust_Block_6::S_826 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_848;
            }
            C2Rust_Block_6::S_848 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_850;
            }
            C2Rust_Block_6::S_850 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_856;
            }
            C2Rust_Block_6::S_856 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_6 = C2Rust_Block_6::S_862;
            }
            C2Rust_Block_6::S_862 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_864;
            }
            C2Rust_Block_6::S_864 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_870;
            }
            C2Rust_Block_6::S_870 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_872;
            }
            C2Rust_Block_6::S_872 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F517() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi);
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = 0x24f527 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_164: {
        's_103: {
            if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
            {
                break 's_103;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_123: {
                if !_fn.is_none() {
                    break 's_123;
                }
                _fn = recomp_lookup(_va);
            }
            's_129: {
                if !_fn.is_none() {
                    break 's_129;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_135: {
                if _fn.is_some() {
                    break 's_135;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_164;
            }
            _fn.expect("non-null function pointer")();
            break 's_164;
        }
        recomp_icall_not_code_log(_va);
        (*__gamepkg_tls_g_esp) = _icall_esp;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    }
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_269: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_269;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_259: {
            if _fa != _fb {
                break 's_259;
            }
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa != _fb {
                break 's_259;
            }
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
            let mut _pv_4: uint32_t = 0x24f541 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_0024F298();
            break 's_269;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edi),
        );
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F54E() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024F0F5();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F556() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0x24f561 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024F0C9();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_210: {
        if _fa == _fb {
            break 's_210;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = 0x24f56d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_0024F109();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        's_184: {
            's_178: {
                's_147: {
                    if _fa == _fb {
                        break 's_147;
                    }
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0x154 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    if _fa >= _fb {
                        break 's_184;
                    }
                    _fb = 0x14 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x14 as uint32_t);
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    break 's_178;
                }
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa <= _fb {
                    break 's_184;
                }
                _fb = 0xffffffec as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0xffffffec as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F595() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_5: uint32_t = 0x24f5a7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_0024F094();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx).wrapping_add(0x3c as uint32_t);
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
        .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t));
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
        .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(2 as uint32_t));
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(4 as ::core::ffi::c_int as int32_t)
            } else {
                4 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(2 as ::core::ffi::c_int as int32_t)
            } else {
                2 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
        .wrapping_add(
            (if (*__gamepkg_tls_g_df) != 0 {
                -(2 as ::core::ffi::c_int as int32_t)
            } else {
                2 as ::core::ffi::c_int as int32_t
            }) as uint32_t,
        );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _dividend: uint64_t = ((*__gamepkg_tls_g_edx) as uint64_t)
        << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
    (*__gamepkg_tls_g_eax) = _dividend
        .wrapping_div(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ebx).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint64_t,
        ) as uint32_t;
    (*__gamepkg_tls_g_edx) = _dividend
        .wrapping_rem(
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ebx).wrapping_add(0x38 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint64_t,
        ) as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    loop {
        let mut _cmp: uint32_t = (*__gamepkg_tls_g_eax);
        let mut _old: uint32_t = {
            let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let __gamepkg_atomic_expected = _cmp;
            let __gamepkg_atomic_replacement = (*__gamepkg_tls_g_edx);
            match ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
                .compare_exchange(
                    __gamepkg_atomic_expected,
                    __gamepkg_atomic_replacement,
                    ::core::sync::atomic::Ordering::SeqCst,
                    ::core::sync::atomic::Ordering::SeqCst,
                )
            {
                ::core::result::Result::Ok(value) => (value, true),
                ::core::result::Result::Err(value) => (value, false),
            }
        }
            .0;
        _fa = _old;
        _fb = _cmp;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_230: {
            if _old == _cmp {
                break 's_230;
            }
            (*__gamepkg_tls_g_eax) = _old;
        }
        if _fa == _fb {
            break;
        }
    }
    _fb = 0x40 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(0x40 as uint32_t);
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _old_0: uint32_t = {
        let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let __gamepkg_atomic_value = (*__gamepkg_tls_g_eax);
        ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
            .fetch_add(__gamepkg_atomic_value, ::core::sync::atomic::Ordering::SeqCst)
    };
    (*__gamepkg_tls_g_eax) = _old_0;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F5ED() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b8b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0x24f5fb as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_182: {
        's_121: {
            if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
            {
                break 's_121;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_141: {
                if !_fn.is_none() {
                    break 's_141;
                }
                _fn = recomp_lookup(_va);
            }
            's_147: {
                if !_fn.is_none() {
                    break 's_147;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_153: {
                if _fn.is_some() {
                    break 's_153;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_182;
            }
            _fn.expect("non-null function pointer")();
            break 's_182;
        }
        recomp_icall_not_code_log(_va);
        (*__gamepkg_tls_g_esp) = _icall_esp;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    }
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    loop {
        let mut _cmp: uint32_t = (*__gamepkg_tls_g_eax);
        let mut _old: uint32_t = {
            let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let __gamepkg_atomic_expected = _cmp;
            let __gamepkg_atomic_replacement = (*__gamepkg_tls_g_edx);
            match ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
                .compare_exchange(
                    __gamepkg_atomic_expected,
                    __gamepkg_atomic_replacement,
                    ::core::sync::atomic::Ordering::SeqCst,
                    ::core::sync::atomic::Ordering::SeqCst,
                )
            {
                ::core::result::Result::Ok(value) => (value, true),
                ::core::result::Result::Err(value) => (value, false),
            }
        }
            .0;
        _fa = _old;
        _fb = _cmp;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_219: {
            if _old == _cmp {
                break 's_219;
            }
            (*__gamepkg_tls_g_eax) = _old;
        }
        if _fa == _fb {
            break;
        }
    }
    _fb = 0x40 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_esi),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    loop {
        let mut _cmp_0: uint32_t = (*__gamepkg_tls_g_eax);
        let mut _old_0: uint32_t = {
            let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let __gamepkg_atomic_expected = _cmp_0;
            let __gamepkg_atomic_replacement = (*__gamepkg_tls_g_edx);
            match ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
                .compare_exchange(
                    __gamepkg_atomic_expected,
                    __gamepkg_atomic_replacement,
                    ::core::sync::atomic::Ordering::SeqCst,
                    ::core::sync::atomic::Ordering::SeqCst,
                )
            {
                ::core::result::Result::Ok(value) => (value, true),
                ::core::result::Result::Err(value) => (value, false),
            }
        }
            .0;
        _fa = _old_0;
        _fb = _cmp_0;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_271: {
            if _old_0 == _cmp_0 {
                break 's_271;
            }
            (*__gamepkg_tls_g_eax) = _old_0;
        }
        if _fa == _fb {
            break;
        }
    }
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as uint32_t;
    let mut _icall_esp_0: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _icall_target_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x36b8b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_4: uint32_t = 0x24f62f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _va_0: uint32_t = _icall_target_0;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va_0,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_382: {
        's_329: {
            if _va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi
            {
                break 's_329;
            }
            recomp_icall_not_code_log(_va_0);
            (*__gamepkg_tls_g_esp) = _icall_esp_0;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_382;
        }
        let mut _fn_0: recomp_func_t = recomp_lookup_manual(_va_0);
        's_337: {
            if !_fn_0.is_none() {
                break 's_337;
            }
            _fn_0 = recomp_lookup(_va_0);
        }
        's_343: {
            if !_fn_0.is_none() {
                break 's_343;
            }
            _fn_0 = recomp_lookup_kernel(_va_0);
        }
        's_349: {
            if _fn_0.is_some() {
                break 's_349;
            }
            recomp_icall_fail_log(_va_0);
            (*__gamepkg_tls_g_esp) = _icall_esp_0;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_382;
        }
        _fn_0.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F633() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_97: {
        if _fa >= _fb {
            break 's_97;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_377: {
        if _fa <= _fb {
            break 's_377;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_ebx));
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0xa as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            let mut _pv_7: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_8: uint32_t = 0x24f662 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_322: {
                's_273: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_273;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_322;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_281: {
                    if !_fn.is_none() {
                        break 's_281;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_287: {
                    if !_fn.is_none() {
                        break 's_287;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_293: {
                    if _fn.is_some() {
                        break 's_293;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_322;
                }
                _fn.expect("non-null function pointer")();
            }
            _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                .wrapping_add(0xa as uint32_t);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                    .wrapping_sub(1 as uint32_t),
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
            if _fa == 0 as uint32_t {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x24f673 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_0024F5ED();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F678() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ebx) = 0x24f200 as uint32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_4: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x24f68d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_00011000();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    let mut _pv_8: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_9: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t);
    let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x48 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    let mut _pv_11: uint32_t = 0x24f6c8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_00011000();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x7c as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x88 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x8c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x90 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F6F1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_1: uint32_t = 0x24f6fa as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024FC8C();
    let mut _pv_2: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x24f704 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_0024EFFB();
    (*__gamepkg_tls_g_edi) = 0x24f20d as uint32_t;
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t);
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 0x24f717 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_002276E9();
    let mut _pv_10: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    let mut _pv_12: uint32_t = 0x24f721 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_12,
    );
    sub_0024EFFB();
    let mut _pv_13: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_13,
    );
    let mut _pv_14: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_14,
    );
    let mut _pv_15: uint32_t = 0x24f72b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_15,
    );
    sub_0024EFFB();
    let mut _pv_16: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_16,
    );
    let mut _pv_17: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_17,
    );
    let mut _pv_18: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_18,
    );
    let mut _pv_19: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_19,
    );
    let mut _pv_20: uint32_t = 0x24f736 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_20,
    );
    sub_002276E9();
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F739() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_71: {
        if _fa != _fb {
            break 's_71;
        }
        let mut _pv: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = 0x24f74d as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_0024F3B2();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F750() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_71: {
        if _fa != _fb {
            break 's_71;
        }
        let mut _pv: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = 0x24f764 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_0024F42C();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F767() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    's_334: {
        's_312: {
            's_65: {
                if _fa == _fb {
                    break 's_65;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_171: {
                    if _fa != _fb {
                        break 's_171;
                    }
                    let mut _pv_1: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    let mut _pv_2: uint32_t = 0x500 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    let mut _pv_3: uint32_t = 0x24f78e as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    sub_0024EFC3();
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    if _fa != _fb {
                        break 's_171;
                    }
                    (*__gamepkg_tls_g_edi) = 0x8007000e as ::core::ffi::c_uint
                        as uint32_t;
                    break 's_312;
                }
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_4: uint32_t = 0x24f7a4 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                sub_0024F1A3();
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_312;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
                let mut _pv_5: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 1 as ::core::ffi::c_int;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                let mut _pv_7: uint32_t = 0x24f7ba as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                sub_0024EFC3();
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                's_295: {
                    if _fa != _fb {
                        break 's_295;
                    }
                    (*__gamepkg_tls_g_edi) = 0x8007000e as ::core::ffi::c_uint
                        as uint32_t;
                }
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_334;
                } else {
                    break 's_312;
                }
            }
            (*__gamepkg_tls_g_edi) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        let mut _pv_8: uint32_t = 0x24f7d1 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_0024F279();
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F7D6() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = 0x24f7de as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024F6F1();
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_119: {
        if _fa == _fb {
            break 's_119;
        }
        let mut _pv_1: uint32_t = 0x801b as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x24f7f0 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_0024EFFB();
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F7F6() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    let mut _pv_0: uint32_t = 0x24f805 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024F2D3();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F810() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_362: loop {
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_eax) = ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t);
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_ebp) = ebp;
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        let mut _pv_4: uint32_t = 0x24f833 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_0024F350();
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t);
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_8: uint32_t = 0x24f842 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_306: {
            's_257: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_257;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_306;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_265: {
                if !_fn.is_none() {
                    break 's_265;
                }
                _fn = recomp_lookup(_va);
            }
            's_271: {
                if !_fn.is_none() {
                    break 's_271;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_277: {
                if _fn.is_some() {
                    break 's_277;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_306;
            }
            _fn.expect("non-null function pointer")();
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_404: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                < if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_404;
            }
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa < _fb {
                continue 's_362;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            break 's_362;
        }
        (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
        break;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F859() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _st: int32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    enum C2Rust_Block_22 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_105,
        S_107,
        S_109,
        S_117,
        S_119,
        S_122,
        S_125,
        S_131,
        S_133,
        S_135,
        S_145,
        S_147,
        S_149,
        S_151,
        S_153,
        S_156,
        S_158,
        S_160,
        S_168,
        S_170,
        S_172,
        S_176,
        S_178,
        S_182,
        S_188,
        S_195,
        S_197,
        S_199,
        S_217,
        S_219,
        S_221,
        S_223,
        S_225,
        S_234,
        S_236,
        S_242,
        S_244,
        S_246,
        S_252,
        S_258,
        S_260,
        S_262,
        S_272,
        S_274,
        S_276,
        S_286,
        S_288,
        S_290,
        S_296,
        S_298,
        S_304,
        S_306,
        S_308,
        S_314,
        S_324,
        S_326,
        S_328,
        S_342,
        S_344,
        S_346,
        S_352,
        S_358,
        S_360,
        S_362,
        S_368,
        S_370,
        S_372,
        S_378,
        S_380,
        S_382,
        S_388,
        S_394,
        S_396,
        S_398,
        S_400,
        S_403,
        S_409,
        S_411,
        S_413,
        S_419,
        S_422,
        S_424,
        S_427,
        S_428,
        S_429,
        S_430,
        S_437,
        S_441,
        S_443,
        S_445,
        S_447,
        S_453,
        S_455,
        S_457,
        S_467,
        S_469,
        S_471,
        S_478,
        S_484,
        S_486,
        S_488,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_509,
        S_511,
        S_513,
        S_521,
        S_523,
        S_525,
        S_529,
        S_531,
        S_535,
        S_541,
        S_548,
        S_550,
        S_552,
        S_570,
        S_572,
        S_574,
        S_576,
        S_578,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_612,
        S_614,
        S_616,
        S_626,
        S_628,
        S_642,
        S_644,
        S_654,
        S_656,
        S_662,
        S_668,
        S_670,
        S_676,
        S_678,
        S_684,
    }
    let mut c2rust_current_block_22: C2Rust_Block_22;
    c2rust_current_block_22 = C2Rust_Block_22::S_0;
    loop {
        match c2rust_current_block_22 {
            C2Rust_Block_22::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_2;
            }
            C2Rust_Block_22::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_22 = C2Rust_Block_22::S_4;
            }
            C2Rust_Block_22::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_22 = C2Rust_Block_22::S_6;
            }
            C2Rust_Block_22::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_8;
            }
            C2Rust_Block_22::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_26;
            }
            C2Rust_Block_22::S_26 => {
                _pv = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_28;
            }
            C2Rust_Block_22::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_30;
            }
            C2Rust_Block_22::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_36;
            }
            C2Rust_Block_22::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_22 = C2Rust_Block_22::S_38;
            }
            C2Rust_Block_22::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_40;
            }
            C2Rust_Block_22::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_42;
            }
            C2Rust_Block_22::S_42 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_44;
            }
            C2Rust_Block_22::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_46;
            }
            C2Rust_Block_22::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x18 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_48;
            }
            C2Rust_Block_22::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_50;
            }
            C2Rust_Block_22::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_56;
            }
            C2Rust_Block_22::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_22 = C2Rust_Block_22::S_58;
            }
            C2Rust_Block_22::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_60;
            }
            C2Rust_Block_22::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_70;
            }
            C2Rust_Block_22::S_70 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_22 = C2Rust_Block_22::S_72;
            }
            C2Rust_Block_22::S_72 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_74;
            }
            C2Rust_Block_22::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_80;
            }
            C2Rust_Block_22::S_80 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_22 = C2Rust_Block_22::S_82;
            }
            C2Rust_Block_22::S_82 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_84;
            }
            C2Rust_Block_22::S_84 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_86;
            }
            C2Rust_Block_22::S_86 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_88;
            }
            C2Rust_Block_22::S_88 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_90;
            }
            C2Rust_Block_22::S_90 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_92;
            }
            C2Rust_Block_22::S_92 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_94;
            }
            C2Rust_Block_22::S_94 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_96;
            }
            C2Rust_Block_22::S_96 => {
                if _fa != _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_117;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_105;
                }
            }
            C2Rust_Block_22::S_105 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_107;
            }
            C2Rust_Block_22::S_107 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_109;
            }
            C2Rust_Block_22::S_109 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_642;
            }
            C2Rust_Block_22::S_117 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_119;
            }
            C2Rust_Block_22::S_119 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_122;
            }
            C2Rust_Block_22::S_122 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_22 = C2Rust_Block_22::S_125;
            }
            C2Rust_Block_22::S_125 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_131;
            }
            C2Rust_Block_22::S_131 => {
                _pv_2 = 0x24f876 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_133;
            }
            C2Rust_Block_22::S_133 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_135;
            }
            C2Rust_Block_22::S_135 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_145;
            }
            C2Rust_Block_22::S_145 => {
                _va = _icall_target;
                c2rust_current_block_22 = C2Rust_Block_22::S_147;
            }
            C2Rust_Block_22::S_147 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_149;
            }
            C2Rust_Block_22::S_149 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_151;
            }
            C2Rust_Block_22::S_151 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_153;
            }
            C2Rust_Block_22::S_153 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_22 = C2Rust_Block_22::S_156;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_168;
                }
            }
            C2Rust_Block_22::S_156 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_22 = C2Rust_Block_22::S_158;
            }
            C2Rust_Block_22::S_158 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_22 = C2Rust_Block_22::S_160;
            }
            C2Rust_Block_22::S_160 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_217;
            }
            C2Rust_Block_22::S_168 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_22 = C2Rust_Block_22::S_170;
            }
            C2Rust_Block_22::S_170 => {
                if _fn.is_none() {
                    c2rust_current_block_22 = C2Rust_Block_22::S_172;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_176;
                }
            }
            C2Rust_Block_22::S_172 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_22 = C2Rust_Block_22::S_176;
            }
            C2Rust_Block_22::S_176 => {
                if _fn.is_none() {
                    c2rust_current_block_22 = C2Rust_Block_22::S_178;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_182;
                }
            }
            C2Rust_Block_22::S_178 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_22 = C2Rust_Block_22::S_182;
            }
            C2Rust_Block_22::S_182 => {
                if _fn.is_some() {
                    c2rust_current_block_22 = C2Rust_Block_22::S_188;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_195;
                }
            }
            C2Rust_Block_22::S_188 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_22 = C2Rust_Block_22::S_217;
            }
            C2Rust_Block_22::S_195 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_22 = C2Rust_Block_22::S_197;
            }
            C2Rust_Block_22::S_197 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_22 = C2Rust_Block_22::S_199;
            }
            C2Rust_Block_22::S_199 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_217;
            }
            C2Rust_Block_22::S_217 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_219;
            }
            C2Rust_Block_22::S_219 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_221;
            }
            C2Rust_Block_22::S_221 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_223;
            }
            C2Rust_Block_22::S_223 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_225;
            }
            C2Rust_Block_22::S_225 => {
                if _fa == _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_324;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_234;
                }
            }
            C2Rust_Block_22::S_234 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_236;
            }
            C2Rust_Block_22::S_236 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x2c as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_242;
            }
            C2Rust_Block_22::S_242 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_22 = C2Rust_Block_22::S_244;
            }
            C2Rust_Block_22::S_244 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_246;
            }
            C2Rust_Block_22::S_246 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_252;
            }
            C2Rust_Block_22::S_252 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_258;
            }
            C2Rust_Block_22::S_258 => {
                _pv_4 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_22 = C2Rust_Block_22::S_260;
            }
            C2Rust_Block_22::S_260 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_262;
            }
            C2Rust_Block_22::S_262 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_272;
            }
            C2Rust_Block_22::S_272 => {
                _pv_5 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_22 = C2Rust_Block_22::S_274;
            }
            C2Rust_Block_22::S_274 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_276;
            }
            C2Rust_Block_22::S_276 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_286;
            }
            C2Rust_Block_22::S_286 => {
                _pv_6 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_22 = C2Rust_Block_22::S_288;
            }
            C2Rust_Block_22::S_288 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_290;
            }
            C2Rust_Block_22::S_290 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_296;
            }
            C2Rust_Block_22::S_296 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_298;
            }
            C2Rust_Block_22::S_298 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_304;
            }
            C2Rust_Block_22::S_304 => {
                _pv_7 = 0x24f88f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_306;
            }
            C2Rust_Block_22::S_306 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_308;
            }
            C2Rust_Block_22::S_308 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_314;
            }
            C2Rust_Block_22::S_314 => {
                sub_0024DFA1();
                c2rust_current_block_22 = C2Rust_Block_22::S_324;
            }
            C2Rust_Block_22::S_324 => {
                _pv_8 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_22 = C2Rust_Block_22::S_326;
            }
            C2Rust_Block_22::S_326 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_328;
            }
            C2Rust_Block_22::S_328 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_342;
            }
            C2Rust_Block_22::S_342 => {
                _pv_9 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_22 = C2Rust_Block_22::S_344;
            }
            C2Rust_Block_22::S_344 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_346;
            }
            C2Rust_Block_22::S_346 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_352;
            }
            C2Rust_Block_22::S_352 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-24 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_358;
            }
            C2Rust_Block_22::S_358 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_22 = C2Rust_Block_22::S_360;
            }
            C2Rust_Block_22::S_360 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_362;
            }
            C2Rust_Block_22::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_368;
            }
            C2Rust_Block_22::S_368 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_22 = C2Rust_Block_22::S_370;
            }
            C2Rust_Block_22::S_370 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_372;
            }
            C2Rust_Block_22::S_372 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_378;
            }
            C2Rust_Block_22::S_378 => {
                _pv_11 = 0x24f89c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_380;
            }
            C2Rust_Block_22::S_380 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_382;
            }
            C2Rust_Block_22::S_382 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_388;
            }
            C2Rust_Block_22::S_388 => {
                sub_0024F381();
                c2rust_current_block_22 = C2Rust_Block_22::S_394;
            }
            C2Rust_Block_22::S_394 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_396;
            }
            C2Rust_Block_22::S_396 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_398;
            }
            C2Rust_Block_22::S_398 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_400;
            }
            C2Rust_Block_22::S_400 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_403;
            }
            C2Rust_Block_22::S_403 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_22 = C2Rust_Block_22::S_409;
            }
            C2Rust_Block_22::S_409 => {
                _pv_12 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_411;
            }
            C2Rust_Block_22::S_411 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_413;
            }
            C2Rust_Block_22::S_413 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_419;
            }
            C2Rust_Block_22::S_419 => {
                (*__gamepkg_tls_g_ecx) = 0xa0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_422;
            }
            C2Rust_Block_22::S_422 => {
                _i = 0;
                c2rust_current_block_22 = C2Rust_Block_22::S_424;
            }
            C2Rust_Block_22::S_424 => {
                _st = if (*__gamepkg_tls_g_df) != 0 {
                    -(4 as ::core::ffi::c_int as int32_t)
                } else {
                    4 as ::core::ffi::c_int as int32_t
                };
                c2rust_current_block_22 = C2Rust_Block_22::S_427;
            }
            C2Rust_Block_22::S_427 => {
                _i = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_428;
            }
            C2Rust_Block_22::S_428 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_22 = C2Rust_Block_22::S_429;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_437;
                }
            }
            C2Rust_Block_22::S_429 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(_st as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_430;
            }
            C2Rust_Block_22::S_430 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_22 = C2Rust_Block_22::S_428;
            }
            C2Rust_Block_22::S_437 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(_st as uint32_t));
                c2rust_current_block_22 = C2Rust_Block_22::S_441;
            }
            C2Rust_Block_22::S_441 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_443;
            }
            C2Rust_Block_22::S_443 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_445;
            }
            C2Rust_Block_22::S_445 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_447;
            }
            C2Rust_Block_22::S_447 => {
                (*__gamepkg_tls_g_edx) = ebp
                    .wrapping_add(-24 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_453;
            }
            C2Rust_Block_22::S_453 => {
                _pv_13 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_22 = C2Rust_Block_22::S_455;
            }
            C2Rust_Block_22::S_455 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_457;
            }
            C2Rust_Block_22::S_457 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_467;
            }
            C2Rust_Block_22::S_467 => {
                _pv_14 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_22 = C2Rust_Block_22::S_469;
            }
            C2Rust_Block_22::S_469 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_471;
            }
            C2Rust_Block_22::S_471 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_478;
            }
            C2Rust_Block_22::S_478 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_484;
            }
            C2Rust_Block_22::S_484 => {
                _pv_15 = 0x24f8b7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_486;
            }
            C2Rust_Block_22::S_486 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_488;
            }
            C2Rust_Block_22::S_488 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_498;
            }
            C2Rust_Block_22::S_498 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_22 = C2Rust_Block_22::S_500;
            }
            C2Rust_Block_22::S_500 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_502;
            }
            C2Rust_Block_22::S_502 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_504;
            }
            C2Rust_Block_22::S_504 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_506;
            }
            C2Rust_Block_22::S_506 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_22 = C2Rust_Block_22::S_509;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_521;
                }
            }
            C2Rust_Block_22::S_509 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_22 = C2Rust_Block_22::S_511;
            }
            C2Rust_Block_22::S_511 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_22 = C2Rust_Block_22::S_513;
            }
            C2Rust_Block_22::S_513 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_570;
            }
            C2Rust_Block_22::S_521 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_22 = C2Rust_Block_22::S_523;
            }
            C2Rust_Block_22::S_523 => {
                if _fn_0.is_none() {
                    c2rust_current_block_22 = C2Rust_Block_22::S_525;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_529;
                }
            }
            C2Rust_Block_22::S_525 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_22 = C2Rust_Block_22::S_529;
            }
            C2Rust_Block_22::S_529 => {
                if _fn_0.is_none() {
                    c2rust_current_block_22 = C2Rust_Block_22::S_531;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_535;
                }
            }
            C2Rust_Block_22::S_531 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_22 = C2Rust_Block_22::S_535;
            }
            C2Rust_Block_22::S_535 => {
                if _fn_0.is_some() {
                    c2rust_current_block_22 = C2Rust_Block_22::S_541;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_548;
                }
            }
            C2Rust_Block_22::S_541 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_22 = C2Rust_Block_22::S_570;
            }
            C2Rust_Block_22::S_548 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_22 = C2Rust_Block_22::S_550;
            }
            C2Rust_Block_22::S_550 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_22 = C2Rust_Block_22::S_552;
            }
            C2Rust_Block_22::S_552 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_570;
            }
            C2Rust_Block_22::S_570 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_572;
            }
            C2Rust_Block_22::S_572 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_574;
            }
            C2Rust_Block_22::S_574 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_576;
            }
            C2Rust_Block_22::S_576 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_578;
            }
            C2Rust_Block_22::S_578 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_22 = C2Rust_Block_22::S_684;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_587;
                }
            }
            C2Rust_Block_22::S_587 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                c2rust_current_block_22 = C2Rust_Block_22::S_589;
            }
            C2Rust_Block_22::S_589 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_591;
            }
            C2Rust_Block_22::S_591 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_593;
            }
            C2Rust_Block_22::S_593 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_595;
            }
            C2Rust_Block_22::S_595 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_597;
            }
            C2Rust_Block_22::S_597 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_599;
            }
            C2Rust_Block_22::S_599 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_601;
            }
            C2Rust_Block_22::S_601 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_603;
            }
            C2Rust_Block_22::S_603 => {
                if _fa < _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_342;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_612;
                }
            }
            C2Rust_Block_22::S_612 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_614;
            }
            C2Rust_Block_22::S_614 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_616;
            }
            C2Rust_Block_22::S_616 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_626;
            }
            C2Rust_Block_22::S_626 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_628;
            }
            C2Rust_Block_22::S_628 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_642;
            }
            C2Rust_Block_22::S_642 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_644;
            }
            C2Rust_Block_22::S_644 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_654;
            }
            C2Rust_Block_22::S_654 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_656;
            }
            C2Rust_Block_22::S_656 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_662;
            }
            C2Rust_Block_22::S_662 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_668;
            }
            C2Rust_Block_22::S_668 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_670;
            }
            C2Rust_Block_22::S_670 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_676;
            }
            C2Rust_Block_22::S_676 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_678;
            }
            C2Rust_Block_22::S_678 => return,
            C2Rust_Block_22::S_684 => {
                (*__gamepkg_tls_g_eax) = 0x80004005 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_626;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F8CF() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = 0x24f8d7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024F2D3();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_121: {
        if _fa == _fb {
            break 's_121;
        }
        let mut _pv_1: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x24f8e5 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_0024F7D6();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    let mut _pv_3: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x24f8f3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_0024EFFB();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x24f901 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_0024EFFB();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F907() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    enum C2Rust_Block_24 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_56,
        S_58,
        S_60,
        S_66,
        S_72,
        S_74,
        S_76,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_111,
        S_113,
        S_115,
        S_121,
        S_131,
        S_133,
        S_135,
        S_145,
        S_147,
        S_149,
        S_159,
        S_161,
        S_163,
        S_169,
        S_175,
        S_177,
        S_179,
        S_189,
        S_191,
        S_193,
        S_203,
        S_205,
        S_207,
        S_217,
        S_219,
        S_221,
        S_231,
        S_233,
        S_235,
        S_241,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_283,
        S_289,
        S_291,
        S_293,
        S_303,
        S_305,
        S_307,
        S_317,
        S_319,
        S_321,
        S_331,
        S_333,
        S_335,
        S_345,
        S_347,
        S_349,
        S_359,
        S_361,
        S_363,
        S_373,
        S_375,
        S_377,
        S_387,
        S_389,
        S_391,
        S_397,
        S_403,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_439,
        S_445,
        S_447,
        S_449,
        S_455,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_497,
        S_503,
        S_505,
        S_507,
        S_513,
        S_519,
        S_521,
        S_523,
        S_525,
        S_527,
        S_529,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_550,
        S_559,
        S_565,
        S_567,
        S_569,
        S_575,
        S_581,
        S_587,
        S_589,
        S_599,
        S_601,
        S_611,
        S_613,
        S_623,
        S_625,
        S_631,
        S_633,
    }
    let mut c2rust_current_block_24: C2Rust_Block_24;
    c2rust_current_block_24 = C2Rust_Block_24::S_0;
    loop {
        match c2rust_current_block_24 {
            C2Rust_Block_24::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_2;
            }
            C2Rust_Block_24::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_24 = C2Rust_Block_24::S_4;
            }
            C2Rust_Block_24::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_24 = C2Rust_Block_24::S_6;
            }
            C2Rust_Block_24::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_8;
            }
            C2Rust_Block_24::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_18;
            }
            C2Rust_Block_24::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_24 = C2Rust_Block_24::S_28;
            }
            C2Rust_Block_24::S_28 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_24 = C2Rust_Block_24::S_30;
            }
            C2Rust_Block_24::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_32;
            }
            C2Rust_Block_24::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_42;
            }
            C2Rust_Block_24::S_42 => {
                _pv_0 = ebp;
                c2rust_current_block_24 = C2Rust_Block_24::S_44;
            }
            C2Rust_Block_24::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_46;
            }
            C2Rust_Block_24::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_56;
            }
            C2Rust_Block_24::S_56 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_24 = C2Rust_Block_24::S_58;
            }
            C2Rust_Block_24::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_60;
            }
            C2Rust_Block_24::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_66;
            }
            C2Rust_Block_24::S_66 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_24 = C2Rust_Block_24::S_72;
            }
            C2Rust_Block_24::S_72 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_24 = C2Rust_Block_24::S_74;
            }
            C2Rust_Block_24::S_74 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_76;
            }
            C2Rust_Block_24::S_76 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_82;
            }
            C2Rust_Block_24::S_82 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_84;
            }
            C2Rust_Block_24::S_84 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_86;
            }
            C2Rust_Block_24::S_86 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_88;
            }
            C2Rust_Block_24::S_88 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_90;
            }
            C2Rust_Block_24::S_90 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_92;
            }
            C2Rust_Block_24::S_92 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_94;
            }
            C2Rust_Block_24::S_94 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_96;
            }
            C2Rust_Block_24::S_96 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_98;
            }
            C2Rust_Block_24::S_98 => {
                if _fa == _fb {
                    c2rust_current_block_24 = C2Rust_Block_24::S_131;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_111;
                }
            }
            C2Rust_Block_24::S_111 => {
                _pv_3 = 0x24f91b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_113;
            }
            C2Rust_Block_24::S_113 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_115;
            }
            C2Rust_Block_24::S_115 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_121;
            }
            C2Rust_Block_24::S_121 => {
                sub_0024F7F6();
                c2rust_current_block_24 = C2Rust_Block_24::S_131;
            }
            C2Rust_Block_24::S_131 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_24 = C2Rust_Block_24::S_133;
            }
            C2Rust_Block_24::S_133 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_135;
            }
            C2Rust_Block_24::S_135 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_145;
            }
            C2Rust_Block_24::S_145 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_24 = C2Rust_Block_24::S_147;
            }
            C2Rust_Block_24::S_147 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_149;
            }
            C2Rust_Block_24::S_149 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_159;
            }
            C2Rust_Block_24::S_159 => {
                _pv_6 = 0x24f739 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_161;
            }
            C2Rust_Block_24::S_161 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_163;
            }
            C2Rust_Block_24::S_163 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_169;
            }
            C2Rust_Block_24::S_169 => {
                (*__gamepkg_tls_g_ebx) = 0x420678 as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_175;
            }
            C2Rust_Block_24::S_175 => {
                _pv_7 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_24 = C2Rust_Block_24::S_177;
            }
            C2Rust_Block_24::S_177 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_179;
            }
            C2Rust_Block_24::S_179 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_189;
            }
            C2Rust_Block_24::S_189 => {
                _pv_8 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_191;
            }
            C2Rust_Block_24::S_191 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_193;
            }
            C2Rust_Block_24::S_193 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_203;
            }
            C2Rust_Block_24::S_203 => {
                _pv_9 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_205;
            }
            C2Rust_Block_24::S_205 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_207;
            }
            C2Rust_Block_24::S_207 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_217;
            }
            C2Rust_Block_24::S_217 => {
                _pv_10 = 0x362c54 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_219;
            }
            C2Rust_Block_24::S_219 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_221;
            }
            C2Rust_Block_24::S_221 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_231;
            }
            C2Rust_Block_24::S_231 => {
                _pv_11 = 0x24f936 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_233;
            }
            C2Rust_Block_24::S_233 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_235;
            }
            C2Rust_Block_24::S_235 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_241;
            }
            C2Rust_Block_24::S_241 => {
                sub_00369C87();
                c2rust_current_block_24 = C2Rust_Block_24::S_247;
            }
            C2Rust_Block_24::S_247 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_24 = C2Rust_Block_24::S_249;
            }
            C2Rust_Block_24::S_249 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_251;
            }
            C2Rust_Block_24::S_251 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_253;
            }
            C2Rust_Block_24::S_253 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_255;
            }
            C2Rust_Block_24::S_255 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_257;
            }
            C2Rust_Block_24::S_257 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_24 = C2Rust_Block_24::S_559;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_266;
                }
            }
            C2Rust_Block_24::S_266 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x42068c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_268;
            }
            C2Rust_Block_24::S_268 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_270;
            }
            C2Rust_Block_24::S_270 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_272;
            }
            C2Rust_Block_24::S_272 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_274;
            }
            C2Rust_Block_24::S_274 => {
                if _fa == _fb {
                    c2rust_current_block_24 = C2Rust_Block_24::S_480;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_283;
                }
            }
            C2Rust_Block_24::S_283 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_289;
            }
            C2Rust_Block_24::S_289 => {
                _pv_12 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_24 = C2Rust_Block_24::S_291;
            }
            C2Rust_Block_24::S_291 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_293;
            }
            C2Rust_Block_24::S_293 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_303;
            }
            C2Rust_Block_24::S_303 => {
                _pv_13 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_24 = C2Rust_Block_24::S_305;
            }
            C2Rust_Block_24::S_305 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_307;
            }
            C2Rust_Block_24::S_307 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_317;
            }
            C2Rust_Block_24::S_317 => {
                _pv_14 = 0x24f750 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_319;
            }
            C2Rust_Block_24::S_319 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_321;
            }
            C2Rust_Block_24::S_321 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_331;
            }
            C2Rust_Block_24::S_331 => {
                _pv_15 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_24 = C2Rust_Block_24::S_333;
            }
            C2Rust_Block_24::S_333 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_335;
            }
            C2Rust_Block_24::S_335 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_345;
            }
            C2Rust_Block_24::S_345 => {
                _pv_16 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_347;
            }
            C2Rust_Block_24::S_347 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_349;
            }
            C2Rust_Block_24::S_349 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_359;
            }
            C2Rust_Block_24::S_359 => {
                _pv_17 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_361;
            }
            C2Rust_Block_24::S_361 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_363;
            }
            C2Rust_Block_24::S_363 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_373;
            }
            C2Rust_Block_24::S_373 => {
                _pv_18 = 0x362c60 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_375;
            }
            C2Rust_Block_24::S_375 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_377;
            }
            C2Rust_Block_24::S_377 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_387;
            }
            C2Rust_Block_24::S_387 => {
                _pv_19 = 0x24f95d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_389;
            }
            C2Rust_Block_24::S_389 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_391;
            }
            C2Rust_Block_24::S_391 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_397;
            }
            C2Rust_Block_24::S_397 => {
                sub_00369C87();
                c2rust_current_block_24 = C2Rust_Block_24::S_403;
            }
            C2Rust_Block_24::S_403 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_24 = C2Rust_Block_24::S_405;
            }
            C2Rust_Block_24::S_405 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_407;
            }
            C2Rust_Block_24::S_407 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_409;
            }
            C2Rust_Block_24::S_409 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_411;
            }
            C2Rust_Block_24::S_411 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_413;
            }
            C2Rust_Block_24::S_413 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_24 = C2Rust_Block_24::S_559;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_422;
                }
            }
            C2Rust_Block_24::S_422 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_424;
            }
            C2Rust_Block_24::S_424 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_426;
            }
            C2Rust_Block_24::S_426 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_428;
            }
            C2Rust_Block_24::S_428 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_430;
            }
            C2Rust_Block_24::S_430 => {
                if _fa == _fb {
                    c2rust_current_block_24 = C2Rust_Block_24::S_480;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_439;
                }
            }
            C2Rust_Block_24::S_439 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_24 = C2Rust_Block_24::S_445;
            }
            C2Rust_Block_24::S_445 => {
                _pv_20 = 0x24f96f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_447;
            }
            C2Rust_Block_24::S_447 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_449;
            }
            C2Rust_Block_24::S_449 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_455;
            }
            C2Rust_Block_24::S_455 => {
                sub_0024F859();
                c2rust_current_block_24 = C2Rust_Block_24::S_461;
            }
            C2Rust_Block_24::S_461 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_24 = C2Rust_Block_24::S_463;
            }
            C2Rust_Block_24::S_463 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_465;
            }
            C2Rust_Block_24::S_465 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_467;
            }
            C2Rust_Block_24::S_467 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_469;
            }
            C2Rust_Block_24::S_469 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_471;
            }
            C2Rust_Block_24::S_471 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_24 = C2Rust_Block_24::S_559;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_480;
                }
            }
            C2Rust_Block_24::S_480 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_482;
            }
            C2Rust_Block_24::S_482 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_484;
            }
            C2Rust_Block_24::S_484 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_486;
            }
            C2Rust_Block_24::S_486 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_488;
            }
            C2Rust_Block_24::S_488 => {
                if _fa == _fb {
                    c2rust_current_block_24 = C2Rust_Block_24::S_538;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_497;
                }
            }
            C2Rust_Block_24::S_497 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_24 = C2Rust_Block_24::S_503;
            }
            C2Rust_Block_24::S_503 => {
                _pv_21 = 0x24f981 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_505;
            }
            C2Rust_Block_24::S_505 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_507;
            }
            C2Rust_Block_24::S_507 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_513;
            }
            C2Rust_Block_24::S_513 => {
                sub_0024F810();
                c2rust_current_block_24 = C2Rust_Block_24::S_519;
            }
            C2Rust_Block_24::S_519 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_24 = C2Rust_Block_24::S_521;
            }
            C2Rust_Block_24::S_521 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_523;
            }
            C2Rust_Block_24::S_523 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_525;
            }
            C2Rust_Block_24::S_525 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_527;
            }
            C2Rust_Block_24::S_527 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_529;
            }
            C2Rust_Block_24::S_529 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_24 = C2Rust_Block_24::S_559;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_538;
                }
            }
            C2Rust_Block_24::S_538 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_540;
            }
            C2Rust_Block_24::S_540 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_542;
            }
            C2Rust_Block_24::S_542 => {
                _fas = _fa as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_544;
            }
            C2Rust_Block_24::S_544 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_546;
            }
            C2Rust_Block_24::S_546 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_548;
            }
            C2Rust_Block_24::S_548 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_550;
            }
            C2Rust_Block_24::S_550 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_24 = C2Rust_Block_24::S_581;
                } else {
                    c2rust_current_block_24 = C2Rust_Block_24::S_559;
                }
            }
            C2Rust_Block_24::S_559 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_24 = C2Rust_Block_24::S_565;
            }
            C2Rust_Block_24::S_565 => {
                _pv_22 = 0x24f998 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_24 = C2Rust_Block_24::S_567;
            }
            C2Rust_Block_24::S_567 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_569;
            }
            C2Rust_Block_24::S_569 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_575;
            }
            C2Rust_Block_24::S_575 => {
                sub_0024F7F6();
                c2rust_current_block_24 = C2Rust_Block_24::S_581;
            }
            C2Rust_Block_24::S_581 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_24 = C2Rust_Block_24::S_587;
            }
            C2Rust_Block_24::S_587 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_589;
            }
            C2Rust_Block_24::S_589 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_599;
            }
            C2Rust_Block_24::S_599 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_601;
            }
            C2Rust_Block_24::S_601 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_611;
            }
            C2Rust_Block_24::S_611 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_613;
            }
            C2Rust_Block_24::S_613 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_623;
            }
            C2Rust_Block_24::S_623 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_24 = C2Rust_Block_24::S_625;
            }
            C2Rust_Block_24::S_625 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_631;
            }
            C2Rust_Block_24::S_631 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_24 = C2Rust_Block_24::S_633;
            }
            C2Rust_Block_24::S_633 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024F99F() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _icall_esp_0: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_target_0: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _va_0: uint32_t = 0;
    let mut _fn_0: recomp_func_t = None;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _icall_esp_1: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _icall_target_1: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _va_1: uint32_t = 0;
    let mut _fn_1: recomp_func_t = None;
    enum C2Rust_Block_25 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_53,
        S_55,
        S_57,
        S_59,
        S_61,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_91,
        S_93,
        S_95,
        S_105,
        S_107,
        S_109,
        S_115,
        S_121,
        S_123,
        S_126,
        S_132,
        S_134,
        S_136,
        S_146,
        S_148,
        S_150,
        S_160,
        S_162,
        S_164,
        S_171,
        S_177,
        S_179,
        S_181,
        S_191,
        S_193,
        S_195,
        S_197,
        S_199,
        S_202,
        S_204,
        S_206,
        S_214,
        S_216,
        S_218,
        S_222,
        S_224,
        S_228,
        S_234,
        S_241,
        S_243,
        S_245,
        S_263,
        S_269,
        S_271,
        S_273,
        S_279,
        S_289,
        S_291,
        S_293,
        S_299,
        S_305,
        S_307,
        S_309,
        S_315,
        S_321,
        S_324,
        S_330,
        S_332,
        S_334,
        S_344,
        S_346,
        S_348,
        S_358,
        S_360,
        S_362,
        S_369,
        S_375,
        S_377,
        S_379,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_400,
        S_402,
        S_404,
        S_412,
        S_414,
        S_416,
        S_420,
        S_422,
        S_426,
        S_432,
        S_439,
        S_441,
        S_443,
        S_465,
        S_467,
        S_479,
        S_485,
        S_487,
        S_489,
        S_495,
        S_505,
        S_507,
        S_509,
        S_515,
        S_521,
        S_523,
        S_525,
        S_531,
        S_541,
        S_543,
        S_545,
        S_557,
        S_563,
        S_565,
        S_567,
        S_573,
        S_583,
        S_585,
        S_587,
        S_597,
        S_600,
        S_606,
        S_608,
        S_610,
        S_616,
        S_622,
        S_624,
        S_626,
        S_633,
        S_639,
        S_641,
        S_643,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_664,
        S_666,
        S_668,
        S_676,
        S_678,
        S_680,
        S_684,
        S_686,
        S_690,
        S_696,
        S_703,
        S_705,
        S_707,
        S_729,
        S_731,
        S_737,
        S_739,
    }
    let mut c2rust_current_block_25: C2Rust_Block_25;
    c2rust_current_block_25 = C2Rust_Block_25::S_0;
    loop {
        match c2rust_current_block_25 {
            C2Rust_Block_25::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_25 = C2Rust_Block_25::S_2;
            }
            C2Rust_Block_25::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_4;
            }
            C2Rust_Block_25::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_22;
            }
            C2Rust_Block_25::S_22 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_24;
            }
            C2Rust_Block_25::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_26;
            }
            C2Rust_Block_25::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_32;
            }
            C2Rust_Block_25::S_32 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_25 = C2Rust_Block_25::S_34;
            }
            C2Rust_Block_25::S_34 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_36;
            }
            C2Rust_Block_25::S_36 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_25 = C2Rust_Block_25::S_38;
            }
            C2Rust_Block_25::S_38 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_40;
            }
            C2Rust_Block_25::S_40 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_42;
            }
            C2Rust_Block_25::S_42 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_44;
            }
            C2Rust_Block_25::S_44 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_25 = C2Rust_Block_25::S_557;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_53;
                }
            }
            C2Rust_Block_25::S_53 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_25 = C2Rust_Block_25::S_55;
            }
            C2Rust_Block_25::S_55 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_57;
            }
            C2Rust_Block_25::S_57 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_59;
            }
            C2Rust_Block_25::S_59 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_61;
            }
            C2Rust_Block_25::S_61 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_25 = C2Rust_Block_25::S_479;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_70;
                }
            }
            C2Rust_Block_25::S_70 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_25 = C2Rust_Block_25::S_72;
            }
            C2Rust_Block_25::S_72 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_74;
            }
            C2Rust_Block_25::S_74 => {
                _fas = _fa as int32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_76;
            }
            C2Rust_Block_25::S_76 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_78;
            }
            C2Rust_Block_25::S_78 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_25 = C2Rust_Block_25::S_729;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_91;
                }
            }
            C2Rust_Block_25::S_91 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_25 = C2Rust_Block_25::S_93;
            }
            C2Rust_Block_25::S_93 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_95;
            }
            C2Rust_Block_25::S_95 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_105;
            }
            C2Rust_Block_25::S_105 => {
                _pv_1 = 0x24f9b4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_107;
            }
            C2Rust_Block_25::S_107 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_109;
            }
            C2Rust_Block_25::S_109 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_115;
            }
            C2Rust_Block_25::S_115 => {
                sub_0024F7F6();
                c2rust_current_block_25 = C2Rust_Block_25::S_121;
            }
            C2Rust_Block_25::S_121 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_123;
            }
            C2Rust_Block_25::S_123 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_126;
            }
            C2Rust_Block_25::S_126 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_132;
            }
            C2Rust_Block_25::S_132 => {
                _pv_2 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_134;
            }
            C2Rust_Block_25::S_134 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_136;
            }
            C2Rust_Block_25::S_136 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_146;
            }
            C2Rust_Block_25::S_146 => {
                _pv_3 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_148;
            }
            C2Rust_Block_25::S_148 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_150;
            }
            C2Rust_Block_25::S_150 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_160;
            }
            C2Rust_Block_25::S_160 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_25 = C2Rust_Block_25::S_162;
            }
            C2Rust_Block_25::S_162 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_164;
            }
            C2Rust_Block_25::S_164 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_171;
            }
            C2Rust_Block_25::S_171 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_177;
            }
            C2Rust_Block_25::S_177 => {
                _pv_5 = 0x24f9c2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_179;
            }
            C2Rust_Block_25::S_179 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_181;
            }
            C2Rust_Block_25::S_181 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_191;
            }
            C2Rust_Block_25::S_191 => {
                _va = _icall_target;
                c2rust_current_block_25 = C2Rust_Block_25::S_193;
            }
            C2Rust_Block_25::S_193 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_195;
            }
            C2Rust_Block_25::S_195 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_197;
            }
            C2Rust_Block_25::S_197 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_199;
            }
            C2Rust_Block_25::S_199 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_25 = C2Rust_Block_25::S_202;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_214;
                }
            }
            C2Rust_Block_25::S_202 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_204;
            }
            C2Rust_Block_25::S_204 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_25 = C2Rust_Block_25::S_206;
            }
            C2Rust_Block_25::S_206 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_263;
            }
            C2Rust_Block_25::S_214 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_216;
            }
            C2Rust_Block_25::S_216 => {
                if _fn.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_218;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_222;
                }
            }
            C2Rust_Block_25::S_218 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_222;
            }
            C2Rust_Block_25::S_222 => {
                if _fn.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_224;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_228;
                }
            }
            C2Rust_Block_25::S_224 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_228;
            }
            C2Rust_Block_25::S_228 => {
                if _fn.is_some() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_234;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_241;
                }
            }
            C2Rust_Block_25::S_234 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_25 = C2Rust_Block_25::S_263;
            }
            C2Rust_Block_25::S_241 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_25 = C2Rust_Block_25::S_243;
            }
            C2Rust_Block_25::S_243 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_25 = C2Rust_Block_25::S_245;
            }
            C2Rust_Block_25::S_245 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_263;
            }
            C2Rust_Block_25::S_263 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_269;
            }
            C2Rust_Block_25::S_269 => {
                _pv_6 = 0x24f9c9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_271;
            }
            C2Rust_Block_25::S_271 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_273;
            }
            C2Rust_Block_25::S_273 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_279;
            }
            C2Rust_Block_25::S_279 => {
                sub_0024F907();
                c2rust_current_block_25 = C2Rust_Block_25::S_289;
            }
            C2Rust_Block_25::S_289 => {
                _pv_7 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_291;
            }
            C2Rust_Block_25::S_291 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_293;
            }
            C2Rust_Block_25::S_293 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_299;
            }
            C2Rust_Block_25::S_299 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_305;
            }
            C2Rust_Block_25::S_305 => {
                _pv_8 = 0x24f9d3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_307;
            }
            C2Rust_Block_25::S_307 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_309;
            }
            C2Rust_Block_25::S_309 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_315;
            }
            C2Rust_Block_25::S_315 => {
                sub_0024F298();
                c2rust_current_block_25 = C2Rust_Block_25::S_321;
            }
            C2Rust_Block_25::S_321 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_324;
            }
            C2Rust_Block_25::S_324 => {
                _icall_esp_0 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_330;
            }
            C2Rust_Block_25::S_330 => {
                _pv_9 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_332;
            }
            C2Rust_Block_25::S_332 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_334;
            }
            C2Rust_Block_25::S_334 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_344;
            }
            C2Rust_Block_25::S_344 => {
                _pv_10 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_346;
            }
            C2Rust_Block_25::S_346 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_348;
            }
            C2Rust_Block_25::S_348 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_358;
            }
            C2Rust_Block_25::S_358 => {
                _pv_11 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_25 = C2Rust_Block_25::S_360;
            }
            C2Rust_Block_25::S_360 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_362;
            }
            C2Rust_Block_25::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_369;
            }
            C2Rust_Block_25::S_369 => {
                _icall_target_0 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_375;
            }
            C2Rust_Block_25::S_375 => {
                _pv_12 = 0x24f9dd as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_377;
            }
            C2Rust_Block_25::S_377 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_379;
            }
            C2Rust_Block_25::S_379 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_389;
            }
            C2Rust_Block_25::S_389 => {
                _va_0 = _icall_target_0;
                c2rust_current_block_25 = C2Rust_Block_25::S_391;
            }
            C2Rust_Block_25::S_391 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_393;
            }
            C2Rust_Block_25::S_393 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_395;
            }
            C2Rust_Block_25::S_395 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_397;
            }
            C2Rust_Block_25::S_397 => {
                if !(_va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi)
                {
                    c2rust_current_block_25 = C2Rust_Block_25::S_400;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_412;
                }
            }
            C2Rust_Block_25::S_400 => {
                recomp_icall_not_code_log(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_402;
            }
            C2Rust_Block_25::S_402 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_25 = C2Rust_Block_25::S_404;
            }
            C2Rust_Block_25::S_404 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_465;
            }
            C2Rust_Block_25::S_412 => {
                _fn_0 = recomp_lookup_manual(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_414;
            }
            C2Rust_Block_25::S_414 => {
                if _fn_0.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_416;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_420;
                }
            }
            C2Rust_Block_25::S_416 => {
                _fn_0 = recomp_lookup(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_420;
            }
            C2Rust_Block_25::S_420 => {
                if _fn_0.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_422;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_426;
                }
            }
            C2Rust_Block_25::S_422 => {
                _fn_0 = recomp_lookup_kernel(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_426;
            }
            C2Rust_Block_25::S_426 => {
                if _fn_0.is_some() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_432;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_439;
                }
            }
            C2Rust_Block_25::S_432 => {
                _fn_0.expect("non-null function pointer")();
                c2rust_current_block_25 = C2Rust_Block_25::S_465;
            }
            C2Rust_Block_25::S_439 => {
                recomp_icall_fail_log(_va_0);
                c2rust_current_block_25 = C2Rust_Block_25::S_441;
            }
            C2Rust_Block_25::S_441 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_0;
                c2rust_current_block_25 = C2Rust_Block_25::S_443;
            }
            C2Rust_Block_25::S_443 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_465;
            }
            C2Rust_Block_25::S_465 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_467;
            }
            C2Rust_Block_25::S_467 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_729;
            }
            C2Rust_Block_25::S_479 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_485;
            }
            C2Rust_Block_25::S_485 => {
                _pv_13 = 0x24f9e7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_487;
            }
            C2Rust_Block_25::S_487 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_489;
            }
            C2Rust_Block_25::S_489 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_495;
            }
            C2Rust_Block_25::S_495 => {
                sub_0024F907();
                c2rust_current_block_25 = C2Rust_Block_25::S_505;
            }
            C2Rust_Block_25::S_505 => {
                _pv_14 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_507;
            }
            C2Rust_Block_25::S_507 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_509;
            }
            C2Rust_Block_25::S_509 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_515;
            }
            C2Rust_Block_25::S_515 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_521;
            }
            C2Rust_Block_25::S_521 => {
                _pv_15 = 0x24f9f1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_523;
            }
            C2Rust_Block_25::S_523 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_525;
            }
            C2Rust_Block_25::S_525 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_531;
            }
            C2Rust_Block_25::S_531 => {
                sub_0024F298();
                c2rust_current_block_25 = C2Rust_Block_25::S_541;
            }
            C2Rust_Block_25::S_541 => {
                _pv_16 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_543;
            }
            C2Rust_Block_25::S_543 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_545;
            }
            C2Rust_Block_25::S_545 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_597;
            }
            C2Rust_Block_25::S_557 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_25 = C2Rust_Block_25::S_563;
            }
            C2Rust_Block_25::S_563 => {
                _pv_17 = 0x24f9fc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_565;
            }
            C2Rust_Block_25::S_565 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_567;
            }
            C2Rust_Block_25::S_567 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_573;
            }
            C2Rust_Block_25::S_573 => {
                sub_0024F7F6();
                c2rust_current_block_25 = C2Rust_Block_25::S_583;
            }
            C2Rust_Block_25::S_583 => {
                _pv_18 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_585;
            }
            C2Rust_Block_25::S_585 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_587;
            }
            C2Rust_Block_25::S_587 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_597;
            }
            C2Rust_Block_25::S_597 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_600;
            }
            C2Rust_Block_25::S_600 => {
                _icall_esp_1 = (*__gamepkg_tls_g_esp);
                c2rust_current_block_25 = C2Rust_Block_25::S_606;
            }
            C2Rust_Block_25::S_606 => {
                _pv_19 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_608;
            }
            C2Rust_Block_25::S_608 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_610;
            }
            C2Rust_Block_25::S_610 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_616;
            }
            C2Rust_Block_25::S_616 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_622;
            }
            C2Rust_Block_25::S_622 => {
                _pv_20 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_25 = C2Rust_Block_25::S_624;
            }
            C2Rust_Block_25::S_624 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_626;
            }
            C2Rust_Block_25::S_626 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_633;
            }
            C2Rust_Block_25::S_633 => {
                _icall_target_1 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_639;
            }
            C2Rust_Block_25::S_639 => {
                _pv_21 = 0x24fa0a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_641;
            }
            C2Rust_Block_25::S_641 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_643;
            }
            C2Rust_Block_25::S_643 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_653;
            }
            C2Rust_Block_25::S_653 => {
                _va_1 = _icall_target_1;
                c2rust_current_block_25 = C2Rust_Block_25::S_655;
            }
            C2Rust_Block_25::S_655 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_1,
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_657;
            }
            C2Rust_Block_25::S_657 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_659;
            }
            C2Rust_Block_25::S_659 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_661;
            }
            C2Rust_Block_25::S_661 => {
                if !(_va_1 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va_1 >= g_xbox_code_lo && _va_1 < g_xbox_code_hi)
                {
                    c2rust_current_block_25 = C2Rust_Block_25::S_664;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_676;
                }
            }
            C2Rust_Block_25::S_664 => {
                recomp_icall_not_code_log(_va_1);
                c2rust_current_block_25 = C2Rust_Block_25::S_666;
            }
            C2Rust_Block_25::S_666 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_25 = C2Rust_Block_25::S_668;
            }
            C2Rust_Block_25::S_668 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_729;
            }
            C2Rust_Block_25::S_676 => {
                _fn_1 = recomp_lookup_manual(_va_1);
                c2rust_current_block_25 = C2Rust_Block_25::S_678;
            }
            C2Rust_Block_25::S_678 => {
                if _fn_1.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_680;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_684;
                }
            }
            C2Rust_Block_25::S_680 => {
                _fn_1 = recomp_lookup(_va_1);
                c2rust_current_block_25 = C2Rust_Block_25::S_684;
            }
            C2Rust_Block_25::S_684 => {
                if _fn_1.is_none() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_686;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_690;
                }
            }
            C2Rust_Block_25::S_686 => {
                _fn_1 = recomp_lookup_kernel(_va_1);
                c2rust_current_block_25 = C2Rust_Block_25::S_690;
            }
            C2Rust_Block_25::S_690 => {
                if _fn_1.is_some() {
                    c2rust_current_block_25 = C2Rust_Block_25::S_696;
                } else {
                    c2rust_current_block_25 = C2Rust_Block_25::S_703;
                }
            }
            C2Rust_Block_25::S_696 => {
                _fn_1.expect("non-null function pointer")();
                c2rust_current_block_25 = C2Rust_Block_25::S_729;
            }
            C2Rust_Block_25::S_703 => {
                recomp_icall_fail_log(_va_1);
                c2rust_current_block_25 = C2Rust_Block_25::S_705;
            }
            C2Rust_Block_25::S_705 => {
                (*__gamepkg_tls_g_esp) = _icall_esp_1;
                c2rust_current_block_25 = C2Rust_Block_25::S_707;
            }
            C2Rust_Block_25::S_707 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_25 = C2Rust_Block_25::S_729;
            }
            C2Rust_Block_25::S_729 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_25 = C2Rust_Block_25::S_731;
            }
            C2Rust_Block_25::S_731 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_737;
            }
            C2Rust_Block_25::S_737 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_25 = C2Rust_Block_25::S_739;
            }
            C2Rust_Block_25::S_739 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FA0E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = 0x500 as uint32_t;
    's_482: {
        's_456: {
            's_298: {
                's_164: {
                    if _fa != _fb {
                        break 's_164;
                    }
                    let mut _pv_2: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    let mut _pv_4: uint32_t = 0x24fa26 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    sub_0024EFC3();
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    if _fa == _fb {
                        break 's_298;
                    }
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x374e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x374e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                }
                let mut _pv_5: uint32_t = 0x801b as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                let mut _pv_6: uint32_t = 0x94 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                let mut _pv_7: uint32_t = 0x24fa4c as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                sub_0024EFC3();
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_279: {
                    's_225: {
                        if _fa != _fb {
                            break 's_225;
                        }
                        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        break 's_279;
                    }
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    let mut _pv_8: uint32_t = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                    let mut _pv_9: uint32_t = 0x24fa60 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    sub_0024F678();
                }
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                if _fa == _fb {
                    break 's_298;
                }
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                let mut _pv_10: uint32_t = 0x24fa79 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                sub_0024F15A();
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_456;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_439: {
                    if _fa == _fb {
                        break 's_439;
                    }
                    let mut _pv_11: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    let mut _pv_12: uint32_t = (*__gamepkg_tls_g_edi);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    let mut _pv_13: uint32_t = 0x24fa92 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    sub_0024EFC3();
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    if _fa != _fb {
                        break 's_439;
                    }
                    (*__gamepkg_tls_g_ebx) = 0x8007000e as ::core::ffi::c_uint
                        as uint32_t;
                }
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_482;
                } else {
                    break 's_456;
                }
            }
            (*__gamepkg_tls_g_ebx) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
        let mut _pv_14: uint32_t = 0x24faa9 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_14,
        );
        sub_0024F8CF();
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FAAF() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_218: {
        if _fa == _fb {
            break 's_218;
        }
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        (*__gamepkg_tls_g_ecx) = 0x420690 as uint32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            let mut _cmp: uint32_t = (*__gamepkg_tls_g_eax);
            let mut _old: uint32_t = {
                let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let __gamepkg_atomic_expected = _cmp;
                let __gamepkg_atomic_replacement = (*__gamepkg_tls_g_edx);
                match ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
                    .compare_exchange(
                        __gamepkg_atomic_expected,
                        __gamepkg_atomic_replacement,
                        ::core::sync::atomic::Ordering::SeqCst,
                        ::core::sync::atomic::Ordering::SeqCst,
                    )
                {
                    ::core::result::Result::Ok(value) => (value, true),
                    ::core::result::Result::Err(value) => (value, false),
                }
            }
                .0;
            _fa = _old;
            _fb = _cmp;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_66: {
                if _old == _cmp {
                    break 's_66;
                }
                (*__gamepkg_tls_g_eax) = _old;
            }
            if _fa == _fb {
                break;
            }
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_218;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax)
            .wrapping_add(-24576 as ::core::ffi::c_int as uint32_t);
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x36b9d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = 0x24fadb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_169: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_169;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_218;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_177: {
            if !_fn.is_none() {
                break 's_177;
            }
            _fn = recomp_lookup(_va);
        }
        's_183: {
            if !_fn.is_none() {
                break 's_183;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_189: {
            if _fn.is_some() {
                break 's_189;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_218;
        }
        _fn.expect("non-null function pointer")();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FADC() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    's_400: {
        's_386: {
            if _fa != _fb {
                break 's_386;
            }
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = 0x6000 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x36b9dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_3: uint32_t = 0x24faf4 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_187: {
                's_126: {
                    if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                    {
                        break 's_126;
                    }
                    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                    's_146: {
                        if !_fn.is_none() {
                            break 's_146;
                        }
                        _fn = recomp_lookup(_va);
                    }
                    's_152: {
                        if !_fn.is_none() {
                            break 's_152;
                        }
                        _fn = recomp_lookup_kernel(_va);
                    }
                    's_158: {
                        if _fn.is_some() {
                            break 's_158;
                        }
                        recomp_icall_fail_log(_va);
                        (*__gamepkg_tls_g_esp) = _icall_esp;
                        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                        break 's_187;
                    }
                    _fn.expect("non-null function pointer")();
                    break 's_187;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
            's_208: {
                if _fa == _fb {
                    break 's_208;
                }
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                (*__gamepkg_tls_g_ecx) = 0x420690 as uint32_t;
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _cmp: uint32_t = (*__gamepkg_tls_g_eax);
                let mut _old: uint32_t = {
                    let __gamepkg_atomic_ptr = ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    let __gamepkg_atomic_expected = _cmp;
                    let __gamepkg_atomic_replacement = (*__gamepkg_tls_g_edx);
                    match ::core::sync::atomic::AtomicU32::from_ptr(__gamepkg_atomic_ptr)
                        .compare_exchange(
                            __gamepkg_atomic_expected,
                            __gamepkg_atomic_replacement,
                            ::core::sync::atomic::Ordering::SeqCst,
                            ::core::sync::atomic::Ordering::SeqCst,
                        )
                    {
                        ::core::result::Result::Ok(value) => (value, true),
                        ::core::result::Result::Err(value) => (value, false),
                    }
                }
                    .0;
                _fa = _old;
                _fb = _cmp;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_243: {
                    if _old == _cmp {
                        break 's_243;
                    }
                    (*__gamepkg_tls_g_eax) = _old;
                }
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_386;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(-24576 as ::core::ffi::c_int as uint32_t);
                let mut _icall_esp_0: uint32_t = (*__gamepkg_tls_g_esp);
                let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                let mut _icall_target_0: uint32_t = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x36b9d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_6: uint32_t = 0x24fb28 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                let mut _va_0: uint32_t = _icall_target_0;
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va_0,
                );
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                's_337: {
                    if _va_0 >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va_0 >= g_xbox_code_lo && _va_0 < g_xbox_code_hi
                    {
                        break 's_337;
                    }
                    recomp_icall_not_code_log(_va_0);
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_386;
                }
                let mut _fn_0: recomp_func_t = recomp_lookup_manual(_va_0);
                's_345: {
                    if !_fn_0.is_none() {
                        break 's_345;
                    }
                    _fn_0 = recomp_lookup(_va_0);
                }
                's_351: {
                    if !_fn_0.is_none() {
                        break 's_351;
                    }
                    _fn_0 = recomp_lookup_kernel(_va_0);
                }
                's_357: {
                    if _fn_0.is_some() {
                        break 's_357;
                    }
                    recomp_icall_fail_log(_va_0);
                    (*__gamepkg_tls_g_esp) = _icall_esp_0;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_386;
                }
                _fn_0.expect("non-null function pointer")();
                break 's_386;
            }
            (*__gamepkg_tls_g_eax) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
            break 's_400;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FB2D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FB36() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_149: {
        if _fa <= _fb {
            break 's_149;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
            (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_186: {
        if _fa != _fb {
            break 's_186;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                .wrapping_add(1 as uint32_t),
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    }
    let mut _pv_1: uint32_t = 0x24fb6a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024F859();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FB6E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_341: {
        if _fa <= _fb {
            break 's_341;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        's_150: {
            if _fa <= _fb {
                break 's_150;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            loop {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_150;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(4 as uint32_t);
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_150;
                }
            }
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_325: {
            if _fa >= _fb {
                break 's_325;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) << 2 as ::core::ffi::c_int;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
            let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_edi))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
            let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x34 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = 0x24fba9 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _va: uint32_t = _icall_target;
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                    uint32_t,
                >(&raw const g_icall_trace_idx)
                    & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                    as usize],
                _va,
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_trace_idx,
                ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                    .wrapping_add(1),
            );
            ::core::ptr::write_volatile(
                &raw mut g_icall_count,
                ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                    .wrapping_add(1),
            );
            's_291: {
                's_242: {
                    if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                        || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                    {
                        break 's_242;
                    }
                    recomp_icall_not_code_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_291;
                }
                let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
                's_250: {
                    if !_fn.is_none() {
                        break 's_250;
                    }
                    _fn = recomp_lookup(_va);
                }
                's_256: {
                    if !_fn.is_none() {
                        break 's_256;
                    }
                    _fn = recomp_lookup_kernel(_va);
                }
                's_262: {
                    if _fn.is_some() {
                        break 's_262;
                    }
                    recomp_icall_fail_log(_va);
                    (*__gamepkg_tls_g_esp) = _icall_esp;
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    break 's_291;
                }
                _fn.expect("non-null function pointer")();
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t))
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_edi))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ecx),
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            )
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t))
                        .wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                    .wrapping_sub(1 as uint32_t),
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FBC9() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_1: uint32_t = 0x22 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << 2 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x24fbe8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024EFC3();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_195: {
        's_135: {
            if _fa == _fb {
                break 's_135;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa <= _fb {
                break 's_195;
            }
            loop {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa >= _fb {
                    break 's_195;
                }
            }
        }
        (*__gamepkg_tls_g_edi) = 0x8007000e as ::core::ffi::c_uint as uint32_t;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC0E() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = 0x22 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x24fc1b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024EFFB();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC21() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x24fc2a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_0024FA0E();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC2D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_124: {
        if _fa <= _fb {
            break 's_124;
        }
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_1: uint32_t = 0x24fc43 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_0024F271();
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
            _fb = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break 's_124;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC4C() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x24fc55 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_0024F8CF();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC58() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x24fc68 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024DE67();
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) < (*__gamepkg_tls_g_ecx)) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub((*__gamepkg_tls_g_ecx));
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x80004005 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC79() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC8C() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FC8D() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_115: {
        if _fa == _fb {
            break 's_115;
        }
        let mut _pv_0: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x24fc9e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_0024EFFB();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FCA3() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x21 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    let mut _pv_2: uint32_t = 0x24fcb1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024EFC3();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_125: {
        if _fa == _fb {
            break 's_125;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FCC1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_eax) = ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t);
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_4: uint32_t = 0x24fcd2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_001D20AC();
    let mut _pv_5: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x3e8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x24fce4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_00244750();
    let mut _pv_10: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x94 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x90 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    let mut _pv_12: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_12,
    );
    let mut _pv_13: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_13,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_14: uint32_t = 0x24fcf7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_14,
    );
    sub_002445E0();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FCFA() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _pv_4: uint32_t = 0x24fd17 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_00244CA0();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x48 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FD1E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x420698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_76: {
        if _fa != _fb {
            break 's_76;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x42069c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_76;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x420698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x42069c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x4206a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x4206a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(16 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FD56() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _t: uint64_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _c: uint32_t = 0;
    let mut _t_0: uint64_t = 0;
    let mut _t_1: uint64_t = 0;
    let mut _t_2: uint64_t = 0;
    enum C2Rust_Block_44 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_48,
        S_50,
        S_52,
        S_62,
        S_64,
        S_66,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_90,
        S_92,
        S_94,
        S_100,
        S_106,
        S_108,
        S_110,
        S_116,
        S_122,
        S_124,
        S_126,
        S_132,
        S_138,
        S_140,
        S_142,
        S_148,
        S_151,
        S_153,
        S_155,
        S_159,
        S_161,
        S_167,
        S_169,
        S_171,
        S_181,
        S_183,
        S_185,
        S_195,
        S_197,
        S_199,
        S_205,
        S_207,
        S_213,
        S_215,
        S_217,
        S_223,
        S_229,
        S_231,
        S_233,
        S_236,
        S_238,
        S_241,
        S_243,
        S_245,
        S_255,
        S_259,
        S_261,
        S_263,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_284,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_327,
        S_329,
        S_331,
        S_335,
        S_337,
        S_339,
        S_341,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_362,
        S_364,
        S_366,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_387,
        S_389,
        S_391,
        S_395,
        S_397,
        S_403,
        S_409,
        S_411,
        S_417,
        S_423,
        S_425,
        S_435,
        S_437,
        S_443,
        S_449,
        S_451,
        S_457,
        S_459,
    }
    let mut c2rust_current_block_44: C2Rust_Block_44;
    c2rust_current_block_44 = C2Rust_Block_44::S_0;
    loop {
        match c2rust_current_block_44 {
            C2Rust_Block_44::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_2;
            }
            C2Rust_Block_44::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_44 = C2Rust_Block_44::S_4;
            }
            C2Rust_Block_44::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_6;
            }
            C2Rust_Block_44::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_8;
            }
            C2Rust_Block_44::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_18;
            }
            C2Rust_Block_44::S_18 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_28;
            }
            C2Rust_Block_44::S_28 => {
                _pv = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_30;
            }
            C2Rust_Block_44::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_32;
            }
            C2Rust_Block_44::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_38;
            }
            C2Rust_Block_44::S_38 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_44 = C2Rust_Block_44::S_40;
            }
            C2Rust_Block_44::S_40 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_42;
            }
            C2Rust_Block_44::S_42 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_48;
            }
            C2Rust_Block_44::S_48 => {
                _pv_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_44 = C2Rust_Block_44::S_50;
            }
            C2Rust_Block_44::S_50 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_52;
            }
            C2Rust_Block_44::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_62;
            }
            C2Rust_Block_44::S_62 => {
                _pv_1 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_44 = C2Rust_Block_44::S_64;
            }
            C2Rust_Block_44::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_66;
            }
            C2Rust_Block_44::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_72;
            }
            C2Rust_Block_44::S_72 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_74;
            }
            C2Rust_Block_44::S_74 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x420698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_76;
            }
            C2Rust_Block_44::S_76 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_78;
            }
            C2Rust_Block_44::S_78 => {
                _cf = ((*__gamepkg_tls_g_eax)
                    < ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x420698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_80;
            }
            C2Rust_Block_44::S_80 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (0x420698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_44 = C2Rust_Block_44::S_82;
            }
            C2Rust_Block_44::S_82 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_84;
            }
            C2Rust_Block_44::S_84 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_90;
            }
            C2Rust_Block_44::S_90 => {
                _pv_2 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_44 = C2Rust_Block_44::S_92;
            }
            C2Rust_Block_44::S_92 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_94;
            }
            C2Rust_Block_44::S_94 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_100;
            }
            C2Rust_Block_44::S_100 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_106;
            }
            C2Rust_Block_44::S_106 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_108;
            }
            C2Rust_Block_44::S_108 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_110;
            }
            C2Rust_Block_44::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_116;
            }
            C2Rust_Block_44::S_116 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x4206a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_122;
            }
            C2Rust_Block_44::S_122 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_124;
            }
            C2Rust_Block_44::S_124 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_126;
            }
            C2Rust_Block_44::S_126 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_132;
            }
            C2Rust_Block_44::S_132 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x4206a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_138;
            }
            C2Rust_Block_44::S_138 => {
                _pv_5 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_140;
            }
            C2Rust_Block_44::S_140 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_142;
            }
            C2Rust_Block_44::S_142 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_148;
            }
            C2Rust_Block_44::S_148 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_44 = C2Rust_Block_44::S_151;
            }
            C2Rust_Block_44::S_151 => {
                _t = ((*__gamepkg_tls_g_ecx) as uint64_t)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (0x42069c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    )
                    .wrapping_sub(_cf as uint64_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_153;
            }
            C2Rust_Block_44::S_153 => {
                _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_155;
            }
            C2Rust_Block_44::S_155 => {
                (*__gamepkg_tls_g_ecx) = _t as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_159;
            }
            C2Rust_Block_44::S_159 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_161;
            }
            C2Rust_Block_44::S_161 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_167;
            }
            C2Rust_Block_44::S_167 => {
                _pv_6 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_169;
            }
            C2Rust_Block_44::S_169 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_171;
            }
            C2Rust_Block_44::S_171 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_181;
            }
            C2Rust_Block_44::S_181 => {
                _pv_7 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_44 = C2Rust_Block_44::S_183;
            }
            C2Rust_Block_44::S_183 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_185;
            }
            C2Rust_Block_44::S_185 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_195;
            }
            C2Rust_Block_44::S_195 => {
                _pv_8 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_44 = C2Rust_Block_44::S_197;
            }
            C2Rust_Block_44::S_197 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_199;
            }
            C2Rust_Block_44::S_199 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_205;
            }
            C2Rust_Block_44::S_205 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_207;
            }
            C2Rust_Block_44::S_207 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_213;
            }
            C2Rust_Block_44::S_213 => {
                _pv_9 = 0x24fd87 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_215;
            }
            C2Rust_Block_44::S_215 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_217;
            }
            C2Rust_Block_44::S_217 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_223;
            }
            C2Rust_Block_44::S_223 => {
                sub_00244A20();
                c2rust_current_block_44 = C2Rust_Block_44::S_229;
            }
            C2Rust_Block_44::S_229 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_231;
            }
            C2Rust_Block_44::S_231 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_233;
            }
            C2Rust_Block_44::S_233 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_236;
            }
            C2Rust_Block_44::S_236 => {
                _c = 1 as ::core::ffi::c_int as uint32_t & 31 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_238;
            }
            C2Rust_Block_44::S_238 => {
                if _c != 0 && _c < 32 as uint32_t {
                    c2rust_current_block_44 = C2Rust_Block_44::S_241;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_255;
                }
            }
            C2Rust_Block_44::S_241 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) >> _c
                    | (*__gamepkg_tls_g_ecx) << (32 as uint32_t).wrapping_sub(_c);
                c2rust_current_block_44 = C2Rust_Block_44::S_243;
            }
            C2Rust_Block_44::S_243 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_245;
            }
            C2Rust_Block_44::S_245 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_255;
            }
            C2Rust_Block_44::S_255 => {
                _cf = ((*__gamepkg_tls_g_ecx)
                    >> 1 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_259;
            }
            C2Rust_Block_44::S_259 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    >> 1 as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_261;
            }
            C2Rust_Block_44::S_261 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_263;
            }
            C2Rust_Block_44::S_263 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_265;
            }
            C2Rust_Block_44::S_265 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_267;
            }
            C2Rust_Block_44::S_267 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_269;
            }
            C2Rust_Block_44::S_269 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_271;
            }
            C2Rust_Block_44::S_271 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_273;
            }
            C2Rust_Block_44::S_273 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_275;
            }
            C2Rust_Block_44::S_275 => {
                if _fa > _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_349;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_284;
                }
            }
            C2Rust_Block_44::S_284 => {
                if _fa < _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_312;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_293;
                }
            }
            C2Rust_Block_44::S_293 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_295;
            }
            C2Rust_Block_44::S_295 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_297;
            }
            C2Rust_Block_44::S_297 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_299;
            }
            C2Rust_Block_44::S_299 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_301;
            }
            C2Rust_Block_44::S_301 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_303;
            }
            C2Rust_Block_44::S_303 => {
                if _fa >= _fb {
                    c2rust_current_block_44 = C2Rust_Block_44::S_349;
                } else {
                    c2rust_current_block_44 = C2Rust_Block_44::S_312;
                }
            }
            C2Rust_Block_44::S_312 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_314;
            }
            C2Rust_Block_44::S_314 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_316;
            }
            C2Rust_Block_44::S_316 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_318;
            }
            C2Rust_Block_44::S_318 => {
                _cf = ((*__gamepkg_tls_g_ecx) < (*__gamepkg_tls_g_eax))
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_320;
            }
            C2Rust_Block_44::S_320 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_44 = C2Rust_Block_44::S_322;
            }
            C2Rust_Block_44::S_322 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_324;
            }
            C2Rust_Block_44::S_324 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_327;
            }
            C2Rust_Block_44::S_327 => {
                _t_0 = ((*__gamepkg_tls_g_ebx) as uint64_t)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    )
                    .wrapping_sub(_cf as uint64_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_329;
            }
            C2Rust_Block_44::S_329 => {
                _cf = (_t_0 >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_331;
            }
            C2Rust_Block_44::S_331 => {
                (*__gamepkg_tls_g_ebx) = _t_0 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_335;
            }
            C2Rust_Block_44::S_335 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_337;
            }
            C2Rust_Block_44::S_337 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_339;
            }
            C2Rust_Block_44::S_339 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_44 = C2Rust_Block_44::S_341;
            }
            C2Rust_Block_44::S_341 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_44 = C2Rust_Block_44::S_403;
            }
            C2Rust_Block_44::S_349 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_351;
            }
            C2Rust_Block_44::S_351 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_353;
            }
            C2Rust_Block_44::S_353 => {
                _cf = ((*__gamepkg_tls_g_edi) < (*__gamepkg_tls_g_eax))
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_355;
            }
            C2Rust_Block_44::S_355 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_44 = C2Rust_Block_44::S_357;
            }
            C2Rust_Block_44::S_357 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_359;
            }
            C2Rust_Block_44::S_359 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_362;
            }
            C2Rust_Block_44::S_362 => {
                _t_1 = ((*__gamepkg_tls_g_esi) as uint64_t)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    )
                    .wrapping_sub(_cf as uint64_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_364;
            }
            C2Rust_Block_44::S_364 => {
                _cf = (_t_1 >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_366;
            }
            C2Rust_Block_44::S_366 => {
                (*__gamepkg_tls_g_esi) = _t_1 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_370;
            }
            C2Rust_Block_44::S_370 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_372;
            }
            C2Rust_Block_44::S_372 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_374;
            }
            C2Rust_Block_44::S_374 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_376;
            }
            C2Rust_Block_44::S_376 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_378;
            }
            C2Rust_Block_44::S_378 => {
                _cf = (((*__gamepkg_tls_g_edi) as uint64_t)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_380;
            }
            C2Rust_Block_44::S_380 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_44 = C2Rust_Block_44::S_382;
            }
            C2Rust_Block_44::S_382 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_384;
            }
            C2Rust_Block_44::S_384 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_387;
            }
            C2Rust_Block_44::S_387 => {
                _t_2 = ((*__gamepkg_tls_g_esi) as uint64_t)
                    .wrapping_add((*__gamepkg_tls_g_ebx) as uint64_t)
                    .wrapping_add(_cf as uint64_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_389;
            }
            C2Rust_Block_44::S_389 => {
                _cf = (_t_2 >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_44 = C2Rust_Block_44::S_391;
            }
            C2Rust_Block_44::S_391 => {
                (*__gamepkg_tls_g_esi) = _t_2 as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_395;
            }
            C2Rust_Block_44::S_395 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_397;
            }
            C2Rust_Block_44::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_44 = C2Rust_Block_44::S_403;
            }
            C2Rust_Block_44::S_403 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_44 = C2Rust_Block_44::S_409;
            }
            C2Rust_Block_44::S_409 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_411;
            }
            C2Rust_Block_44::S_411 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_417;
            }
            C2Rust_Block_44::S_417 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_44 = C2Rust_Block_44::S_423;
            }
            C2Rust_Block_44::S_423 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_425;
            }
            C2Rust_Block_44::S_425 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_435;
            }
            C2Rust_Block_44::S_435 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_437;
            }
            C2Rust_Block_44::S_437 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_443;
            }
            C2Rust_Block_44::S_443 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_44 = C2Rust_Block_44::S_449;
            }
            C2Rust_Block_44::S_449 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_44 = C2Rust_Block_44::S_451;
            }
            C2Rust_Block_44::S_451 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_457;
            }
            C2Rust_Block_44::S_457 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_44 = C2Rust_Block_44::S_459;
            }
            C2Rust_Block_44::S_459 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FDC2() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
        & 2 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ecx);
    's_319: {
        's_71: {
            if _fa != _fb {
                break 's_71;
            }
            _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                & 0xff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_309: {
                if _fa == _fb {
                    break 's_309;
                }
                let mut _pv_10: uint32_t = 0x8025 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                let mut _pv_11: uint32_t = (*__gamepkg_tls_g_edi);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                let mut _pv_12: uint32_t = 0x24fe07 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                sub_0024EFFB();
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
            break 's_319;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x24fc8c as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi)
            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t);
        let mut _pv_3: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x18 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x24fde2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_002276E9();
        _fa = (((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
            as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_224: {
            if _fa == _fb {
                break 's_224;
            }
            let mut _pv_7: uint32_t = 0x8025 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = 0x24fdf2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            sub_0024EFFB();
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FE0E() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_49: {
        if _fa != _fb {
            break 's_49;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0x14 as uint32_t,
        );
    }
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_72: {
        if _fa != _fb {
            break 's_72;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0x50 as uint32_t,
        );
    }
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_95: {
        if _fa != _fb {
            break 's_95;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0x1f4 as uint32_t,
        );
    }
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_122: {
        if _fa != _fb {
            break 's_122;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0xf0 as uint32_t,
        );
    }
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_double,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_double,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
            != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t as uint32_t;
    _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as ::core::ffi::c_int & 0x44 as ::core::ffi::c_int) as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_195: {
        if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
            break 's_195;
        }
        let mut _fp_value_1: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            ::core::ffi::c_double,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                (0x3710f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        );
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
    }
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_218: {
        if _fa != _fb {
            break 's_218;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0xa as uint32_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FE6C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _t: uint64_t = 0;
    enum C2Rust_Block_47 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_20,
        S_26,
        S_28,
        S_30,
        S_40,
        S_42,
        S_44,
        S_54,
        S_56,
        S_58,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_88,
        S_90,
        S_92,
        S_102,
        S_104,
        S_106,
        S_116,
        S_118,
        S_120,
        S_130,
        S_132,
        S_134,
        S_144,
        S_146,
        S_148,
        S_154,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_259,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_339,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_358,
        S_360,
        S_362,
        S_364,
        S_370,
        S_372,
        S_374,
        S_384,
        S_386,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_455,
        S_457,
        S_459,
        S_461,
        S_467,
        S_469,
        S_471,
        S_473,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_497,
        S_499,
        S_501,
        S_503,
        S_505,
        S_507,
        S_509,
        S_512,
        S_514,
        S_516,
        S_520,
        S_522,
        S_524,
        S_526,
        S_532,
        S_534,
        S_536,
        S_538,
        S_548,
        S_550,
        S_560,
        S_562,
        S_568,
        S_574,
        S_576,
        S_582,
        S_584,
        S_590,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_609,
        S_611,
        S_613,
        S_615,
        S_617,
        S_619,
        S_628,
        S_630,
        S_632,
        S_634,
        S_640,
        S_642,
        S_644,
        S_646,
    }
    let mut c2rust_current_block_47: C2Rust_Block_47;
    c2rust_current_block_47 = C2Rust_Block_47::S_0;
    loop {
        match c2rust_current_block_47 {
            C2Rust_Block_47::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_2;
            }
            C2Rust_Block_47::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_4;
            }
            C2Rust_Block_47::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_14;
            }
            C2Rust_Block_47::S_14 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_20;
            }
            C2Rust_Block_47::S_20 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_26;
            }
            C2Rust_Block_47::S_26 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_47 = C2Rust_Block_47::S_28;
            }
            C2Rust_Block_47::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_30;
            }
            C2Rust_Block_47::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_40;
            }
            C2Rust_Block_47::S_40 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_47 = C2Rust_Block_47::S_42;
            }
            C2Rust_Block_47::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_44;
            }
            C2Rust_Block_47::S_44 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_54;
            }
            C2Rust_Block_47::S_54 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_47 = C2Rust_Block_47::S_56;
            }
            C2Rust_Block_47::S_56 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_58;
            }
            C2Rust_Block_47::S_58 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_64;
            }
            C2Rust_Block_47::S_64 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_66;
            }
            C2Rust_Block_47::S_66 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_68;
            }
            C2Rust_Block_47::S_68 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_70;
            }
            C2Rust_Block_47::S_70 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_72;
            }
            C2Rust_Block_47::S_72 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_74;
            }
            C2Rust_Block_47::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_76;
            }
            C2Rust_Block_47::S_76 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_78;
            }
            C2Rust_Block_47::S_78 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_80;
            }
            C2Rust_Block_47::S_80 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_82;
            }
            C2Rust_Block_47::S_82 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_88;
            }
            C2Rust_Block_47::S_88 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_47 = C2Rust_Block_47::S_90;
            }
            C2Rust_Block_47::S_90 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_92;
            }
            C2Rust_Block_47::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_102;
            }
            C2Rust_Block_47::S_102 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_47 = C2Rust_Block_47::S_104;
            }
            C2Rust_Block_47::S_104 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_106;
            }
            C2Rust_Block_47::S_106 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_116;
            }
            C2Rust_Block_47::S_116 => {
                _pv_4 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_118;
            }
            C2Rust_Block_47::S_118 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_120;
            }
            C2Rust_Block_47::S_120 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_130;
            }
            C2Rust_Block_47::S_130 => {
                _pv_5 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_132;
            }
            C2Rust_Block_47::S_132 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_134;
            }
            C2Rust_Block_47::S_134 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_144;
            }
            C2Rust_Block_47::S_144 => {
                _pv_6 = 0x24fe8e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_146;
            }
            C2Rust_Block_47::S_146 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_148;
            }
            C2Rust_Block_47::S_148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_154;
            }
            C2Rust_Block_47::S_154 => {
                sub_00244CA0();
                c2rust_current_block_47 = C2Rust_Block_47::S_160;
            }
            C2Rust_Block_47::S_160 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_162;
            }
            C2Rust_Block_47::S_162 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_164;
            }
            C2Rust_Block_47::S_164 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_166;
            }
            C2Rust_Block_47::S_166 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_47 = C2Rust_Block_47::S_168;
            }
            C2Rust_Block_47::S_168 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_170;
            }
            C2Rust_Block_47::S_170 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_172;
            }
            C2Rust_Block_47::S_172 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_174;
            }
            C2Rust_Block_47::S_174 => {
                (*__gamepkg_tls_g_ecx) = 0xfff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_176;
            }
            C2Rust_Block_47::S_176 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_178;
            }
            C2Rust_Block_47::S_178 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_180;
            }
            C2Rust_Block_47::S_180 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_182;
            }
            C2Rust_Block_47::S_182 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_184;
            }
            C2Rust_Block_47::S_184 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x1000 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_186;
            }
            C2Rust_Block_47::S_186 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_47 = C2Rust_Block_47::S_188;
            }
            C2Rust_Block_47::S_188 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_190;
            }
            C2Rust_Block_47::S_190 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_192;
            }
            C2Rust_Block_47::S_192 => {
                _cf = ((*__gamepkg_tls_g_edi) < (*__gamepkg_tls_g_edx))
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_194;
            }
            C2Rust_Block_47::S_194 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_47 = C2Rust_Block_47::S_196;
            }
            C2Rust_Block_47::S_196 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_198;
            }
            C2Rust_Block_47::S_198 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_200;
            }
            C2Rust_Block_47::S_200 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_202;
            }
            C2Rust_Block_47::S_202 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_204;
            }
            C2Rust_Block_47::S_204 => {
                _cf = (((*__gamepkg_tls_g_edx) as uint64_t)
                    .wrapping_add((*__gamepkg_tls_g_ebx) as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_206;
            }
            C2Rust_Block_47::S_206 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_ebx));
                c2rust_current_block_47 = C2Rust_Block_47::S_208;
            }
            C2Rust_Block_47::S_208 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_210;
            }
            C2Rust_Block_47::S_210 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_212;
            }
            C2Rust_Block_47::S_212 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_214;
            }
            C2Rust_Block_47::S_214 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_216;
            }
            C2Rust_Block_47::S_216 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) & (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_218;
            }
            C2Rust_Block_47::S_218 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_220;
            }
            C2Rust_Block_47::S_220 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_222;
            }
            C2Rust_Block_47::S_222 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_224;
            }
            C2Rust_Block_47::S_224 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_226;
            }
            C2Rust_Block_47::S_226 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_228;
            }
            C2Rust_Block_47::S_228 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_230;
            }
            C2Rust_Block_47::S_230 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_232;
            }
            C2Rust_Block_47::S_232 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_234;
            }
            C2Rust_Block_47::S_234 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_236;
            }
            C2Rust_Block_47::S_236 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_238;
            }
            C2Rust_Block_47::S_238 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_240;
            }
            C2Rust_Block_47::S_240 => {
                if _fa >= _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_320;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_249;
                }
            }
            C2Rust_Block_47::S_249 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_251;
            }
            C2Rust_Block_47::S_251 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_253;
            }
            C2Rust_Block_47::S_253 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_255;
            }
            C2Rust_Block_47::S_255 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_257;
            }
            C2Rust_Block_47::S_257 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_259;
            }
            C2Rust_Block_47::S_259 => {
                if _fa < _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_358;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_268;
                }
            }
            C2Rust_Block_47::S_268 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_270;
            }
            C2Rust_Block_47::S_270 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_272;
            }
            C2Rust_Block_47::S_272 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_274;
            }
            C2Rust_Block_47::S_274 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_276;
            }
            C2Rust_Block_47::S_276 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_278;
            }
            C2Rust_Block_47::S_278 => {
                if _fa > _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_358;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_287;
                }
            }
            C2Rust_Block_47::S_287 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_289;
            }
            C2Rust_Block_47::S_289 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_291;
            }
            C2Rust_Block_47::S_291 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_293;
            }
            C2Rust_Block_47::S_293 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_295;
            }
            C2Rust_Block_47::S_295 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_297;
            }
            C2Rust_Block_47::S_297 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_299;
            }
            C2Rust_Block_47::S_299 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_301;
            }
            C2Rust_Block_47::S_301 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_303;
            }
            C2Rust_Block_47::S_303 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_305;
            }
            C2Rust_Block_47::S_305 => {
                if _fa >= _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_467;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_640;
                }
            }
            C2Rust_Block_47::S_320 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_322;
            }
            C2Rust_Block_47::S_322 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_324;
            }
            C2Rust_Block_47::S_324 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_326;
            }
            C2Rust_Block_47::S_326 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_328;
            }
            C2Rust_Block_47::S_328 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_330;
            }
            C2Rust_Block_47::S_330 => {
                if _fa >= _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_398;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_339;
                }
            }
            C2Rust_Block_47::S_339 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_341;
            }
            C2Rust_Block_47::S_341 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_343;
            }
            C2Rust_Block_47::S_343 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_345;
            }
            C2Rust_Block_47::S_345 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_347;
            }
            C2Rust_Block_47::S_347 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_349;
            }
            C2Rust_Block_47::S_349 => {
                if _fa <= _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_398;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_358;
                }
            }
            C2Rust_Block_47::S_358 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_360;
            }
            C2Rust_Block_47::S_360 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_362;
            }
            C2Rust_Block_47::S_362 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_364;
            }
            C2Rust_Block_47::S_364 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_370;
            }
            C2Rust_Block_47::S_370 => {
                _pv_7 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_372;
            }
            C2Rust_Block_47::S_372 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_374;
            }
            C2Rust_Block_47::S_374 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_384;
            }
            C2Rust_Block_47::S_384 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_386;
            }
            C2Rust_Block_47::S_386 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_548;
            }
            C2Rust_Block_47::S_398 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_400;
            }
            C2Rust_Block_47::S_400 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_402;
            }
            C2Rust_Block_47::S_402 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_404;
            }
            C2Rust_Block_47::S_404 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_406;
            }
            C2Rust_Block_47::S_406 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_408;
            }
            C2Rust_Block_47::S_408 => {
                if _fa >= _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_590;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_417;
                }
            }
            C2Rust_Block_47::S_417 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_419;
            }
            C2Rust_Block_47::S_419 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_421;
            }
            C2Rust_Block_47::S_421 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_423;
            }
            C2Rust_Block_47::S_423 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_425;
            }
            C2Rust_Block_47::S_425 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_427;
            }
            C2Rust_Block_47::S_427 => {
                if _fa > _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_628;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_436;
                }
            }
            C2Rust_Block_47::S_436 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_438;
            }
            C2Rust_Block_47::S_438 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_440;
            }
            C2Rust_Block_47::S_440 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_442;
            }
            C2Rust_Block_47::S_442 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_444;
            }
            C2Rust_Block_47::S_444 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_446;
            }
            C2Rust_Block_47::S_446 => {
                if _fa > _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_628;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_455;
                }
            }
            C2Rust_Block_47::S_455 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_457;
            }
            C2Rust_Block_47::S_457 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_459;
            }
            C2Rust_Block_47::S_459 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_461;
            }
            C2Rust_Block_47::S_461 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_467;
            }
            C2Rust_Block_47::S_467 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_469;
            }
            C2Rust_Block_47::S_469 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_471;
            }
            C2Rust_Block_47::S_471 => {
                _cf = ((*__gamepkg_tls_g_ebx) < (*__gamepkg_tls_g_eax))
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_473;
            }
            C2Rust_Block_47::S_473 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_47 = C2Rust_Block_47::S_475;
            }
            C2Rust_Block_47::S_475 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_477;
            }
            C2Rust_Block_47::S_477 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_479;
            }
            C2Rust_Block_47::S_479 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_481;
            }
            C2Rust_Block_47::S_481 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_483;
            }
            C2Rust_Block_47::S_483 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & (*__gamepkg_tls_g_ecx);
                c2rust_current_block_47 = C2Rust_Block_47::S_485;
            }
            C2Rust_Block_47::S_485 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_487;
            }
            C2Rust_Block_47::S_487 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_489;
            }
            C2Rust_Block_47::S_489 => {
                (*__gamepkg_tls_g_ebx) = ((*__gamepkg_tls_g_ebx) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_491;
            }
            C2Rust_Block_47::S_491 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_493;
            }
            C2Rust_Block_47::S_493 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_495;
            }
            C2Rust_Block_47::S_495 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_497;
            }
            C2Rust_Block_47::S_497 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_499;
            }
            C2Rust_Block_47::S_499 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_501;
            }
            C2Rust_Block_47::S_501 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_503;
            }
            C2Rust_Block_47::S_503 => {
                _cf = (((*__gamepkg_tls_g_ebx) as uint64_t)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    ) >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_505;
            }
            C2Rust_Block_47::S_505 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x20 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_47 = C2Rust_Block_47::S_507;
            }
            C2Rust_Block_47::S_507 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_509;
            }
            C2Rust_Block_47::S_509 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_512;
            }
            C2Rust_Block_47::S_512 => {
                _t = ((*__gamepkg_tls_g_ecx) as uint64_t)
                    .wrapping_add(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x24 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint64_t,
                    )
                    .wrapping_add(_cf as uint64_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_514;
            }
            C2Rust_Block_47::S_514 => {
                _cf = (_t >> 32 as ::core::ffi::c_int & 1 as uint64_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_516;
            }
            C2Rust_Block_47::S_516 => {
                (*__gamepkg_tls_g_ecx) = _t as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_520;
            }
            C2Rust_Block_47::S_520 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_522;
            }
            C2Rust_Block_47::S_522 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_524;
            }
            C2Rust_Block_47::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_526;
            }
            C2Rust_Block_47::S_526 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_532;
            }
            C2Rust_Block_47::S_532 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_534;
            }
            C2Rust_Block_47::S_534 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_536;
            }
            C2Rust_Block_47::S_536 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xa4 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_538;
            }
            C2Rust_Block_47::S_538 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_548;
            }
            C2Rust_Block_47::S_548 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_550;
            }
            C2Rust_Block_47::S_550 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_560;
            }
            C2Rust_Block_47::S_560 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_562;
            }
            C2Rust_Block_47::S_562 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_568;
            }
            C2Rust_Block_47::S_568 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_47 = C2Rust_Block_47::S_574;
            }
            C2Rust_Block_47::S_574 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_47 = C2Rust_Block_47::S_576;
            }
            C2Rust_Block_47::S_576 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_582;
            }
            C2Rust_Block_47::S_582 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(12 as uint32_t);
                c2rust_current_block_47 = C2Rust_Block_47::S_584;
            }
            C2Rust_Block_47::S_584 => return,
            C2Rust_Block_47::S_590 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_592;
            }
            C2Rust_Block_47::S_592 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_594;
            }
            C2Rust_Block_47::S_594 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_596;
            }
            C2Rust_Block_47::S_596 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_598;
            }
            C2Rust_Block_47::S_598 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_600;
            }
            C2Rust_Block_47::S_600 => {
                if _fa > _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_455;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_609;
                }
            }
            C2Rust_Block_47::S_609 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_611;
            }
            C2Rust_Block_47::S_611 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_613;
            }
            C2Rust_Block_47::S_613 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_615;
            }
            C2Rust_Block_47::S_615 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_617;
            }
            C2Rust_Block_47::S_617 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_619;
            }
            C2Rust_Block_47::S_619 => {
                if _fa >= _fb {
                    c2rust_current_block_47 = C2Rust_Block_47::S_455;
                } else {
                    c2rust_current_block_47 = C2Rust_Block_47::S_628;
                }
            }
            C2Rust_Block_47::S_628 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_47 = C2Rust_Block_47::S_630;
            }
            C2Rust_Block_47::S_630 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_632;
            }
            C2Rust_Block_47::S_632 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_634;
            }
            C2Rust_Block_47::S_634 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_640;
            }
            C2Rust_Block_47::S_640 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(1);
                c2rust_current_block_47 = C2Rust_Block_47::S_642;
            }
            C2Rust_Block_47::S_642 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_644;
            }
            C2Rust_Block_47::S_644 => {
                _fas = _fa as int32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_646;
            }
            C2Rust_Block_47::S_646 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_47 = C2Rust_Block_47::S_532;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FF19() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    's_53: {
        if _fa == _fb {
            break 's_53;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_105: {
        if _fa == _fb {
            break 's_105;
        }
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_105;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0 as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FF43() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_201: {
        if _fa == _fb {
            break 's_201;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        's_189: loop {
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            if _fa < _fb {
                break;
            }
            's_108: {
                if _fa > _fb {
                    break 's_108;
                }
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa < _fb {
                    break 's_189;
                }
            }
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_142: {
                if _fa != _fb {
                    break 's_142;
                }
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_142;
                }
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                break 's_189;
            }
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break;
            }
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024FF7C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
            .wrapping_add(1 as uint32_t),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_388: {
        's_103: {
            if _fa == _fb {
                break 's_103;
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            's_364: {
                's_251: {
                    if _fa == _fb {
                        break 's_251;
                    }
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    's_234: loop {
                        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                        _fb = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        _fbs = _fb as int32_t;
                        if _fa > _fb {
                            break;
                        }
                        's_215: {
                            if _fa < _fb {
                                break 's_215;
                            }
                            _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                            _fb = ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) & 0xffffffff as uint32_t;
                            _fas = _fa as int32_t;
                            _fbs = _fb as int32_t;
                            if _fa >= _fb {
                                break 's_234;
                            }
                        }
                        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                        _fb = 0 as ::core::ffi::c_int as uint32_t
                            & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        _fbs = _fb as int32_t;
                        if _fa == _fb {
                            break;
                        }
                    }
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    if _fa == _fb {
                        break 's_251;
                    }
                    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                    _fb = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_299: {
                        if _fa != _fb {
                            break 's_299;
                        }
                        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                        _fb = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        _fbs = _fb as int32_t;
                        if _fa != _fb {
                            break 's_299;
                        }
                        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        );
                        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                        _fas = _fa as int32_t;
                        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                            as uint32_t;
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_ecx).wrapping_add(0x54 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            (*__gamepkg_tls_g_eax),
                        );
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            0x80004005 as ::core::ffi::c_uint as uint32_t,
                        );
                        break 's_364;
                    }
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    _fbs = _fb as int32_t;
                    's_326: {
                        if _fa == _fb {
                            break 's_326;
                        }
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            (*__gamepkg_tls_g_edx),
                        );
                        break 's_364;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    break 's_364;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            break 's_388;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
