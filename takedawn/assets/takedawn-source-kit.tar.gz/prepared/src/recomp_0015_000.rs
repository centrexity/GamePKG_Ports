extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_002948C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002948E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e278 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294900() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e270 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294920() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294940() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e29c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294960() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294980() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002949A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e304 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002949C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e27c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002949E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e29c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294A10() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e294 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294A40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e29c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e298 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294A60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294A80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x35bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e280 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294AA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294AC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e280 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e30c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294AE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e280 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294B00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294B20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294B40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294B60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e2b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e2e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294B80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294BA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294BC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e368 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294BE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e31c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294C00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294C20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e338 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294C40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294C60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e338 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294C80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294CA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294CC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e3c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294CE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294D00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e338 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294D20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e338 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e364 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294D40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e338 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e364 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e344 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294D60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e39c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294D80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e33c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294DA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e350 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294DC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294DE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x396eb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e394 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294E00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x398cc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e334 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294E20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e350 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294E40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e3b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e37c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294E60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e38c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294E80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294EA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294EC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e350 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e360 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294EE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e3b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00294F00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56e360 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56e3a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
