extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm3() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm1() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm2() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm6() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm5() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm4() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm7() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269840() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557620 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269860() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x55761c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55762c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269880() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557670 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002698A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x55762c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557660 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002698C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002698E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5575fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269900() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x55761c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55766c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269930() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557670 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557614 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269960() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x55761c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557618 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269980() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557670 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557678 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002699A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x35bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002699C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557628 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002699E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55768c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269A00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557670 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557650 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269A20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557650 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557628 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557648 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269A40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557678 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557638 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269A60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557624 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269A80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557638 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557668 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269AA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557808 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269AC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557814 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269AE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557804 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269B00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269B20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55780c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269B40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5576a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269B60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x55780c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55781c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269B80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x5576a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557818 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269BA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55782c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269BC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269BE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557828 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269C00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55769c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269C20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x5576a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557824 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269C40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x5576a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557800 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269C60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x5576a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557800 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5576a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269C80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557810 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269CA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5576a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00269CC0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let __gamepkg_tls_g_xmm3 = unsafe { gamepkg_tls_g_xmm3() };
    let __gamepkg_tls_g_xmm4 = unsafe { gamepkg_tls_g_xmm4() };
    let __gamepkg_tls_g_xmm5 = unsafe { gamepkg_tls_g_xmm5() };
    let __gamepkg_tls_g_xmm6 = unsafe { gamepkg_tls_g_xmm6() };
    let __gamepkg_tls_g_xmm7 = unsafe { gamepkg_tls_g_xmm7() };
    let mut ebp: uint32_t = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    enum C2Rust_Block_37 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_24,
        S_26,
        S_28,
        S_34,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_550,
        S_552,
        S_554,
        S_556,
        S_558,
        S_560,
        S_562,
        S_564,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_624,
        S_626,
        S_628,
        S_630,
        S_632,
        S_638,
        S_640,
        S_646,
        S_648,
    }
    let mut c2rust_current_block_37: C2Rust_Block_37;
    c2rust_current_block_37 = C2Rust_Block_37::S_0;
    loop {
        match c2rust_current_block_37 {
            C2Rust_Block_37::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_2;
            }
            C2Rust_Block_37::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_37 = C2Rust_Block_37::S_4;
            }
            C2Rust_Block_37::S_4 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_6;
            }
            C2Rust_Block_37::S_6 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_24;
            }
            C2Rust_Block_37::S_24 => {
                _pv = ebp;
                c2rust_current_block_37 = C2Rust_Block_37::S_26;
            }
            C2Rust_Block_37::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_28;
            }
            C2Rust_Block_37::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_34;
            }
            C2Rust_Block_37::S_34 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_37 = C2Rust_Block_37::S_36;
            }
            C2Rust_Block_37::S_36 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_37 = C2Rust_Block_37::S_38;
            }
            C2Rust_Block_37::S_38 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_37 = C2Rust_Block_37::S_40;
            }
            C2Rust_Block_37::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp) & 0xfffffff8 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_42;
            }
            C2Rust_Block_37::S_42 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_44;
            }
            C2Rust_Block_37::S_44 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_46;
            }
            C2Rust_Block_37::S_46 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_48;
            }
            C2Rust_Block_37::S_48 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_50;
            }
            C2Rust_Block_37::S_50 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x10 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_52;
            }
            C2Rust_Block_37::S_52 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_54;
            }
            C2Rust_Block_37::S_54 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_56;
            }
            C2Rust_Block_37::S_56 => {
                (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                c2rust_current_block_37 = C2Rust_Block_37::S_58;
            }
            C2Rust_Block_37::S_58 => {
                (*__gamepkg_tls_g_xmm4) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_60;
            }
            C2Rust_Block_37::S_60 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_62;
            }
            C2Rust_Block_37::S_62 => {
                (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b219c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_64;
            }
            C2Rust_Block_37::S_64 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b208c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_66;
            }
            C2Rust_Block_37::S_66 => {
                (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x35bee0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_68;
            }
            C2Rust_Block_37::S_68 => {
                (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1f54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_70;
            }
            C2Rust_Block_37::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_72;
            }
            C2Rust_Block_37::S_72 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_74;
            }
            C2Rust_Block_37::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_76;
            }
            C2Rust_Block_37::S_76 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2130 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_78;
            }
            C2Rust_Block_37::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_80;
            }
            C2Rust_Block_37::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_82;
            }
            C2Rust_Block_37::S_82 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_84;
            }
            C2Rust_Block_37::S_84 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_86;
            }
            C2Rust_Block_37::S_86 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_88;
            }
            C2Rust_Block_37::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm4).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_90;
            }
            C2Rust_Block_37::S_90 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_92;
            }
            C2Rust_Block_37::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_94;
            }
            C2Rust_Block_37::S_94 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1f88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_96;
            }
            C2Rust_Block_37::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_98;
            }
            C2Rust_Block_37::S_98 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm4).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_100;
            }
            C2Rust_Block_37::S_100 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_102;
            }
            C2Rust_Block_37::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_104;
            }
            C2Rust_Block_37::S_104 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_106;
            }
            C2Rust_Block_37::S_106 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_108;
            }
            C2Rust_Block_37::S_108 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_110;
            }
            C2Rust_Block_37::S_110 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_112;
            }
            C2Rust_Block_37::S_112 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_114;
            }
            C2Rust_Block_37::S_114 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_116;
            }
            C2Rust_Block_37::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_118;
            }
            C2Rust_Block_37::S_118 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_120;
            }
            C2Rust_Block_37::S_120 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_122;
            }
            C2Rust_Block_37::S_122 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_124;
            }
            C2Rust_Block_37::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_126;
            }
            C2Rust_Block_37::S_126 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_128;
            }
            C2Rust_Block_37::S_128 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_130;
            }
            C2Rust_Block_37::S_130 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_132;
            }
            C2Rust_Block_37::S_132 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_134;
            }
            C2Rust_Block_37::S_134 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2268 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_136;
            }
            C2Rust_Block_37::S_136 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_138;
            }
            C2Rust_Block_37::S_138 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_140;
            }
            C2Rust_Block_37::S_140 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm5).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_142;
            }
            C2Rust_Block_37::S_142 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_144;
            }
            C2Rust_Block_37::S_144 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_146;
            }
            C2Rust_Block_37::S_146 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_148;
            }
            C2Rust_Block_37::S_148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm5).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_150;
            }
            C2Rust_Block_37::S_150 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_152;
            }
            C2Rust_Block_37::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_154;
            }
            C2Rust_Block_37::S_154 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2264 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_156;
            }
            C2Rust_Block_37::S_156 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_158;
            }
            C2Rust_Block_37::S_158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_160;
            }
            C2Rust_Block_37::S_160 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_162;
            }
            C2Rust_Block_37::S_162 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_164;
            }
            C2Rust_Block_37::S_164 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_166;
            }
            C2Rust_Block_37::S_166 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_168;
            }
            C2Rust_Block_37::S_168 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_170;
            }
            C2Rust_Block_37::S_170 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2260 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_172;
            }
            C2Rust_Block_37::S_172 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_174;
            }
            C2Rust_Block_37::S_174 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_176;
            }
            C2Rust_Block_37::S_176 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_178;
            }
            C2Rust_Block_37::S_178 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b213c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_180;
            }
            C2Rust_Block_37::S_180 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_182;
            }
            C2Rust_Block_37::S_182 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_184;
            }
            C2Rust_Block_37::S_184 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_186;
            }
            C2Rust_Block_37::S_186 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_188;
            }
            C2Rust_Block_37::S_188 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_190;
            }
            C2Rust_Block_37::S_190 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_192;
            }
            C2Rust_Block_37::S_192 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x386600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_194;
            }
            C2Rust_Block_37::S_194 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_196;
            }
            C2Rust_Block_37::S_196 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_198;
            }
            C2Rust_Block_37::S_198 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm6).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_200;
            }
            C2Rust_Block_37::S_200 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_202;
            }
            C2Rust_Block_37::S_202 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_204;
            }
            C2Rust_Block_37::S_204 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_206;
            }
            C2Rust_Block_37::S_206 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b225c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_208;
            }
            C2Rust_Block_37::S_208 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_210;
            }
            C2Rust_Block_37::S_210 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_212;
            }
            C2Rust_Block_37::S_212 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_214;
            }
            C2Rust_Block_37::S_214 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5576fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_216;
            }
            C2Rust_Block_37::S_216 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_218;
            }
            C2Rust_Block_37::S_218 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_220;
            }
            C2Rust_Block_37::S_220 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_222;
            }
            C2Rust_Block_37::S_222 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1abc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_224;
            }
            C2Rust_Block_37::S_224 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557700 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_226;
            }
            C2Rust_Block_37::S_226 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_228;
            }
            C2Rust_Block_37::S_228 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_230;
            }
            C2Rust_Block_37::S_230 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3a3230 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_232;
            }
            C2Rust_Block_37::S_232 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557704 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_234;
            }
            C2Rust_Block_37::S_234 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_236;
            }
            C2Rust_Block_37::S_236 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557708 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_238;
            }
            C2Rust_Block_37::S_238 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55770c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_240;
            }
            C2Rust_Block_37::S_240 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm5).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_242;
            }
            C2Rust_Block_37::S_242 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_244;
            }
            C2Rust_Block_37::S_244 => {
                (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_246;
            }
            C2Rust_Block_37::S_246 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557710 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_248;
            }
            C2Rust_Block_37::S_248 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557714 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_250;
            }
            C2Rust_Block_37::S_250 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_252;
            }
            C2Rust_Block_37::S_252 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_254;
            }
            C2Rust_Block_37::S_254 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_256;
            }
            C2Rust_Block_37::S_256 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_258;
            }
            C2Rust_Block_37::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_260;
            }
            C2Rust_Block_37::S_260 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2258 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_262;
            }
            C2Rust_Block_37::S_262 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_264;
            }
            C2Rust_Block_37::S_264 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_266;
            }
            C2Rust_Block_37::S_266 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_268;
            }
            C2Rust_Block_37::S_268 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2254 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_270;
            }
            C2Rust_Block_37::S_270 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557718 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_272;
            }
            C2Rust_Block_37::S_272 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55771c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_274;
            }
            C2Rust_Block_37::S_274 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_276;
            }
            C2Rust_Block_37::S_276 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557720 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_278;
            }
            C2Rust_Block_37::S_278 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_280;
            }
            C2Rust_Block_37::S_280 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_282;
            }
            C2Rust_Block_37::S_282 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2250 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_284;
            }
            C2Rust_Block_37::S_284 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm5).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_286;
            }
            C2Rust_Block_37::S_286 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_288;
            }
            C2Rust_Block_37::S_288 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_290;
            }
            C2Rust_Block_37::S_290 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557724 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_292;
            }
            C2Rust_Block_37::S_292 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_294;
            }
            C2Rust_Block_37::S_294 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_296;
            }
            C2Rust_Block_37::S_296 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_298;
            }
            C2Rust_Block_37::S_298 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55772c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_300;
            }
            C2Rust_Block_37::S_300 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_302;
            }
            C2Rust_Block_37::S_302 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_304;
            }
            C2Rust_Block_37::S_304 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x386600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_306;
            }
            C2Rust_Block_37::S_306 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_308;
            }
            C2Rust_Block_37::S_308 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_310;
            }
            C2Rust_Block_37::S_310 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557734 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_312;
            }
            C2Rust_Block_37::S_312 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557738 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_314;
            }
            C2Rust_Block_37::S_314 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_316;
            }
            C2Rust_Block_37::S_316 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_318;
            }
            C2Rust_Block_37::S_318 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_320;
            }
            C2Rust_Block_37::S_320 => {
                (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b224c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_322;
            }
            C2Rust_Block_37::S_322 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm6).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_324;
            }
            C2Rust_Block_37::S_324 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_326;
            }
            C2Rust_Block_37::S_326 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_328;
            }
            C2Rust_Block_37::S_328 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_330;
            }
            C2Rust_Block_37::S_330 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2248 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_332;
            }
            C2Rust_Block_37::S_332 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55773c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_334;
            }
            C2Rust_Block_37::S_334 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm7).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_336;
            }
            C2Rust_Block_37::S_336 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_338;
            }
            C2Rust_Block_37::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm6).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_340;
            }
            C2Rust_Block_37::S_340 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557740 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_342;
            }
            C2Rust_Block_37::S_342 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_344;
            }
            C2Rust_Block_37::S_344 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557744 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_346;
            }
            C2Rust_Block_37::S_346 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_348;
            }
            C2Rust_Block_37::S_348 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_350;
            }
            C2Rust_Block_37::S_350 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_352;
            }
            C2Rust_Block_37::S_352 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2244 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_354;
            }
            C2Rust_Block_37::S_354 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557748 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_356;
            }
            C2Rust_Block_37::S_356 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_358;
            }
            C2Rust_Block_37::S_358 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55774c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_360;
            }
            C2Rust_Block_37::S_360 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_362;
            }
            C2Rust_Block_37::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_364;
            }
            C2Rust_Block_37::S_364 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_366;
            }
            C2Rust_Block_37::S_366 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_368;
            }
            C2Rust_Block_37::S_368 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_370;
            }
            C2Rust_Block_37::S_370 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2240 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_372;
            }
            C2Rust_Block_37::S_372 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557754 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_374;
            }
            C2Rust_Block_37::S_374 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557758 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_376;
            }
            C2Rust_Block_37::S_376 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55775c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_378;
            }
            C2Rust_Block_37::S_378 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm4).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_380;
            }
            C2Rust_Block_37::S_380 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_382;
            }
            C2Rust_Block_37::S_382 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_384;
            }
            C2Rust_Block_37::S_384 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_386;
            }
            C2Rust_Block_37::S_386 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_388;
            }
            C2Rust_Block_37::S_388 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b223c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_390;
            }
            C2Rust_Block_37::S_390 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_392;
            }
            C2Rust_Block_37::S_392 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2238 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_394;
            }
            C2Rust_Block_37::S_394 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557760 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_396;
            }
            C2Rust_Block_37::S_396 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_398;
            }
            C2Rust_Block_37::S_398 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557764 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_400;
            }
            C2Rust_Block_37::S_400 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_402;
            }
            C2Rust_Block_37::S_402 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_404;
            }
            C2Rust_Block_37::S_404 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_406;
            }
            C2Rust_Block_37::S_406 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_408;
            }
            C2Rust_Block_37::S_408 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2234 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_410;
            }
            C2Rust_Block_37::S_410 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55776c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_412;
            }
            C2Rust_Block_37::S_412 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_414;
            }
            C2Rust_Block_37::S_414 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_416;
            }
            C2Rust_Block_37::S_416 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2230 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_418;
            }
            C2Rust_Block_37::S_418 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557770 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_420;
            }
            C2Rust_Block_37::S_420 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557774 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_422;
            }
            C2Rust_Block_37::S_422 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_424;
            }
            C2Rust_Block_37::S_424 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_426;
            }
            C2Rust_Block_37::S_426 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b222c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_428;
            }
            C2Rust_Block_37::S_428 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557778 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_430;
            }
            C2Rust_Block_37::S_430 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55777c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_432;
            }
            C2Rust_Block_37::S_432 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm5).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_434;
            }
            C2Rust_Block_37::S_434 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_436;
            }
            C2Rust_Block_37::S_436 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557780 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_438;
            }
            C2Rust_Block_37::S_438 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_440;
            }
            C2Rust_Block_37::S_440 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_442;
            }
            C2Rust_Block_37::S_442 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_444;
            }
            C2Rust_Block_37::S_444 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_446;
            }
            C2Rust_Block_37::S_446 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557784 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_448;
            }
            C2Rust_Block_37::S_448 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_450;
            }
            C2Rust_Block_37::S_450 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_452;
            }
            C2Rust_Block_37::S_452 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557788 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_454;
            }
            C2Rust_Block_37::S_454 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55778c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_456;
            }
            C2Rust_Block_37::S_456 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm5).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_458;
            }
            C2Rust_Block_37::S_458 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_460;
            }
            C2Rust_Block_37::S_460 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_462;
            }
            C2Rust_Block_37::S_462 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_464;
            }
            C2Rust_Block_37::S_464 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_466;
            }
            C2Rust_Block_37::S_466 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_468;
            }
            C2Rust_Block_37::S_468 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_470;
            }
            C2Rust_Block_37::S_470 => {
                (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b2228 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_472;
            }
            C2Rust_Block_37::S_472 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557790 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_474;
            }
            C2Rust_Block_37::S_474 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_476;
            }
            C2Rust_Block_37::S_476 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557794 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_478;
            }
            C2Rust_Block_37::S_478 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x557798 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_480;
            }
            C2Rust_Block_37::S_480 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_482;
            }
            C2Rust_Block_37::S_482 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_484;
            }
            C2Rust_Block_37::S_484 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_486;
            }
            C2Rust_Block_37::S_486 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_488;
            }
            C2Rust_Block_37::S_488 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x55779c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_490;
            }
            C2Rust_Block_37::S_490 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_492;
            }
            C2Rust_Block_37::S_492 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_494;
            }
            C2Rust_Block_37::S_494 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_496;
            }
            C2Rust_Block_37::S_496 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_498;
            }
            C2Rust_Block_37::S_498 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_500;
            }
            C2Rust_Block_37::S_500 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_502;
            }
            C2Rust_Block_37::S_502 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_504;
            }
            C2Rust_Block_37::S_504 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_506;
            }
            C2Rust_Block_37::S_506 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_508;
            }
            C2Rust_Block_37::S_508 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_510;
            }
            C2Rust_Block_37::S_510 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_512;
            }
            C2Rust_Block_37::S_512 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_514;
            }
            C2Rust_Block_37::S_514 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3a7f38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_516;
            }
            C2Rust_Block_37::S_516 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_518;
            }
            C2Rust_Block_37::S_518 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_520;
            }
            C2Rust_Block_37::S_520 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_522;
            }
            C2Rust_Block_37::S_522 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_524;
            }
            C2Rust_Block_37::S_524 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_526;
            }
            C2Rust_Block_37::S_526 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_528;
            }
            C2Rust_Block_37::S_528 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_530;
            }
            C2Rust_Block_37::S_530 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_532;
            }
            C2Rust_Block_37::S_532 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_534;
            }
            C2Rust_Block_37::S_534 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_536;
            }
            C2Rust_Block_37::S_536 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_538;
            }
            C2Rust_Block_37::S_538 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_540;
            }
            C2Rust_Block_37::S_540 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_542;
            }
            C2Rust_Block_37::S_542 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_544;
            }
            C2Rust_Block_37::S_544 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_546;
            }
            C2Rust_Block_37::S_546 => {
                (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_548;
            }
            C2Rust_Block_37::S_548 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_550;
            }
            C2Rust_Block_37::S_550 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_552;
            }
            C2Rust_Block_37::S_552 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_554;
            }
            C2Rust_Block_37::S_554 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_556;
            }
            C2Rust_Block_37::S_556 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_558;
            }
            C2Rust_Block_37::S_558 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_560;
            }
            C2Rust_Block_37::S_560 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_562;
            }
            C2Rust_Block_37::S_562 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_564;
            }
            C2Rust_Block_37::S_564 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_566;
            }
            C2Rust_Block_37::S_566 => {
                (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                    ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b1900 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_568;
            }
            C2Rust_Block_37::S_568 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_570;
            }
            C2Rust_Block_37::S_570 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_572;
            }
            C2Rust_Block_37::S_572 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_574;
            }
            C2Rust_Block_37::S_574 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_576;
            }
            C2Rust_Block_37::S_576 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_578;
            }
            C2Rust_Block_37::S_578 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_580;
            }
            C2Rust_Block_37::S_580 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_582;
            }
            C2Rust_Block_37::S_582 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_584;
            }
            C2Rust_Block_37::S_584 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_586;
            }
            C2Rust_Block_37::S_586 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_588;
            }
            C2Rust_Block_37::S_588 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_590;
            }
            C2Rust_Block_37::S_590 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_592;
            }
            C2Rust_Block_37::S_592 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_594;
            }
            C2Rust_Block_37::S_594 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_596;
            }
            C2Rust_Block_37::S_596 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_598;
            }
            C2Rust_Block_37::S_598 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_600;
            }
            C2Rust_Block_37::S_600 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_602;
            }
            C2Rust_Block_37::S_602 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_604;
            }
            C2Rust_Block_37::S_604 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm3).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_606;
            }
            C2Rust_Block_37::S_606 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_608;
            }
            C2Rust_Block_37::S_608 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_610;
            }
            C2Rust_Block_37::S_610 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_612;
            }
            C2Rust_Block_37::S_612 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm1).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_614;
            }
            C2Rust_Block_37::S_614 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_616;
            }
            C2Rust_Block_37::S_616 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm0).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_618;
            }
            C2Rust_Block_37::S_618 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_620;
            }
            C2Rust_Block_37::S_620 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_xmm2).f[0usize],
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_622;
            }
            C2Rust_Block_37::S_622 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_624;
            }
            C2Rust_Block_37::S_624 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_626;
            }
            C2Rust_Block_37::S_626 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_628;
            }
            C2Rust_Block_37::S_628 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_630;
            }
            C2Rust_Block_37::S_630 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x5577fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_632;
            }
            C2Rust_Block_37::S_632 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_37 = C2Rust_Block_37::S_638;
            }
            C2Rust_Block_37::S_638 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_640;
            }
            C2Rust_Block_37::S_640 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_646;
            }
            C2Rust_Block_37::S_646 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_648;
            }
            C2Rust_Block_37::S_648 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A2F0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x559298 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A310() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A330() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x559288 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A350() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557830 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A370() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55929c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A390() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x557850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A3B0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x55929c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A3D0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A3F0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A410() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A430() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x5592d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A450() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x55783c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A470() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x5592e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0026A490() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x557850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x559284 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
