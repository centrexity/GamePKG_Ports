extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    fn gamepkg_tls_g_fp_cmp() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_cc() -> *mut uint16_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn xbox_ReadTimeStampCounter() -> uint64_t;
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001DEEB0();
    fn sub_001F5F30();
    fn sub_001F64C0();
    fn sub_001F79B0();
    fn sub_001F8520();
    fn sub_001F8550();
    fn sub_001F8970();
    fn sub_001F8B70();
    fn sub_001F8E20();
    fn sub_001F9F10();
    fn sub_001F9F40();
    fn sub_001FA470();
    fn sub_001FA7D0();
    fn sub_001FAFD0();
    fn sub_001FB140();
    fn sub_001FD330();
    fn sub_001FD480();
    fn sub_001FD5A0();
    fn sub_001FD620();
    fn sub_001FD6C0();
    fn sub_001FD770();
    fn sub_001FE900();
    fn sub_001FEA30();
    fn sub_001FEB70();
    fn sub_001FEBF0();
    fn sub_001FED80();
    fn sub_001FEDC0();
    fn sub_001FFF00();
    fn sub_00207DF0();
    fn sub_00244DF0();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn recomp_parity8(mut x: uint32_t) -> ::core::ffi::c_int {
    x = (x as ::core::ffi::c_uint & 0xff as ::core::ffi::c_uint) as uint32_t;
    x ^= x >> 4 as ::core::ffi::c_int;
    x ^= x >> 2 as ::core::ffi::c_int;
    x ^= x >> 1 as ::core::ffi::c_int;
    return (!x & 1 as uint32_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB5A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x8a as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    's_79: {
        's_57: {
            if _fa != _fb {
                break 's_57;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0xfb as ::core::ffi::c_int) as uint8_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            break 's_79;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int | 4 as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x8a as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_192: {
        if _fa == _fb {
            break 's_192;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0xa as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fb5d5 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001FBB40();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB5E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x8a as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 1 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB600() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1fb610 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FB140();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB620() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b170c as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b170c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    let mut _pv_1: uint32_t = 0x1fb633 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244DF0();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x8b as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_203: {
        if _fa == _fb {
            break 's_203;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1fb651 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_001FBB40();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB660() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        int8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            int8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x8b as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as int32_t as uint32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        int32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            int32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b1700 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b1700 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            as ::core::ffi::c_float,
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB680() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB690() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b16c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b16c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    let mut _pv_1: uint32_t = 0x1fb6a3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244DF0();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x86 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_203: {
        if _fa == _fb {
            break 's_203;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xd as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1fb6c1 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_001FBB40();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB6D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x86 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        int32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            int32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            as ::core::ffi::c_float,
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB6F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x68 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    's_147: {
        if _fa == _fb {
            break 's_147;
        }
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0xe as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fb70e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001FBB70();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB720() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    enum C2Rust_Block_14 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_36,
        S_38,
        S_40,
        S_50,
        S_52,
        S_54,
        S_64,
        S_66,
        S_68,
        S_78,
        S_80,
        S_82,
        S_88,
        S_98,
        S_100,
        S_102,
        S_108,
        S_114,
        S_116,
        S_118,
        S_124,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_171,
        S_173,
        S_175,
        S_185,
        S_187,
        S_189,
        S_195,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_217,
        S_219,
        S_221,
        S_229,
        S_235,
        S_237,
        S_239,
        S_241,
        S_247,
        S_249,
        S_251,
        S_257,
        S_270,
        S_272,
        S_274,
        S_280,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_327,
        S_329,
        S_331,
        S_341,
        S_343,
        S_345,
        S_351,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_387,
        S_393,
        S_395,
        S_397,
        S_399,
        S_405,
        S_407,
        S_409,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_436,
        S_438,
        S_440,
        S_446,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_493,
        S_495,
        S_497,
        S_507,
        S_509,
        S_511,
        S_517,
        S_523,
        S_525,
        S_527,
        S_529,
        S_531,
        S_533,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_563,
        S_565,
        S_567,
        S_569,
        S_571,
        S_579,
        S_581,
        S_583,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_605,
        S_607,
        S_619,
        S_621,
        S_623,
        S_629,
        S_635,
        S_637,
        S_639,
        S_641,
        S_643,
        S_645,
        S_647,
        S_649,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_663,
        S_676,
        S_678,
        S_680,
        S_690,
        S_692,
        S_694,
        S_700,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_730,
        S_732,
        S_734,
        S_736,
        S_738,
        S_740,
        S_742,
        S_744,
        S_746,
        S_748,
        S_750,
        S_752,
        S_760,
        S_762,
        S_764,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_776,
        S_778,
        S_780,
        S_782,
        S_784,
        S_786,
        S_798,
        S_800,
        S_802,
        S_808,
        S_814,
        S_816,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_828,
        S_830,
        S_832,
        S_834,
        S_836,
        S_838,
        S_840,
        S_842,
        S_855,
        S_857,
        S_859,
        S_869,
        S_871,
        S_873,
        S_879,
        S_885,
        S_887,
        S_889,
        S_891,
        S_893,
        S_895,
        S_897,
        S_899,
        S_901,
        S_903,
        S_905,
        S_913,
        S_919,
        S_921,
        S_923,
        S_925,
        S_931,
        S_933,
        S_935,
        S_941,
        S_954,
        S_956,
        S_958,
        S_964,
        S_970,
        S_972,
        S_974,
        S_976,
        S_978,
        S_980,
        S_982,
        S_984,
        S_986,
        S_988,
        S_990,
        S_992,
        S_994,
        S_996,
        S_998,
        S_1011,
        S_1013,
        S_1015,
        S_1025,
        S_1027,
        S_1029,
        S_1035,
        S_1041,
        S_1043,
        S_1045,
        S_1047,
        S_1049,
        S_1051,
        S_1053,
        S_1055,
        S_1057,
        S_1059,
        S_1061,
        S_1063,
        S_1065,
        S_1067,
        S_1069,
        S_1071,
        S_1073,
        S_1075,
        S_1077,
        S_1079,
        S_1087,
        S_1089,
        S_1091,
        S_1093,
        S_1095,
        S_1097,
        S_1099,
        S_1101,
        S_1103,
        S_1105,
        S_1117,
        S_1119,
        S_1121,
        S_1127,
        S_1133,
        S_1135,
        S_1137,
        S_1139,
        S_1141,
        S_1143,
        S_1145,
        S_1147,
        S_1149,
        S_1151,
        S_1153,
        S_1155,
        S_1157,
        S_1159,
        S_1161,
        S_1174,
        S_1176,
        S_1178,
        S_1188,
        S_1190,
        S_1192,
        S_1198,
        S_1204,
        S_1206,
        S_1208,
        S_1210,
        S_1212,
        S_1214,
        S_1216,
        S_1218,
        S_1220,
        S_1222,
        S_1224,
        S_1232,
        S_1238,
        S_1240,
        S_1242,
        S_1244,
        S_1246,
        S_1252,
        S_1254,
        S_1256,
        S_1258,
        S_1260,
        S_1262,
        S_1264,
        S_1266,
        S_1268,
        S_1270,
        S_1272,
        S_1274,
        S_1276,
        S_1282,
        S_1284,
        S_1290,
        S_1292,
    }
    let mut c2rust_current_block_14: C2Rust_Block_14;
    c2rust_current_block_14 = C2Rust_Block_14::S_0;
    loop {
        match c2rust_current_block_14 {
            C2Rust_Block_14::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_2;
            }
            C2Rust_Block_14::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_4;
            }
            C2Rust_Block_14::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_22;
            }
            C2Rust_Block_14::S_22 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_14 = C2Rust_Block_14::S_24;
            }
            C2Rust_Block_14::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_26;
            }
            C2Rust_Block_14::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_36;
            }
            C2Rust_Block_14::S_36 => {
                _pv_0 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_38;
            }
            C2Rust_Block_14::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_40;
            }
            C2Rust_Block_14::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_50;
            }
            C2Rust_Block_14::S_50 => {
                _pv_1 = 0x36dc8c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_52;
            }
            C2Rust_Block_14::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_54;
            }
            C2Rust_Block_14::S_54 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_64;
            }
            C2Rust_Block_14::S_64 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_14 = C2Rust_Block_14::S_66;
            }
            C2Rust_Block_14::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_68;
            }
            C2Rust_Block_14::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_78;
            }
            C2Rust_Block_14::S_78 => {
                _pv_3 = 0x1fb72e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_80;
            }
            C2Rust_Block_14::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_82;
            }
            C2Rust_Block_14::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_88;
            }
            C2Rust_Block_14::S_88 => {
                sub_001F8550();
                c2rust_current_block_14 = C2Rust_Block_14::S_98;
            }
            C2Rust_Block_14::S_98 => {
                _pv_4 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_100;
            }
            C2Rust_Block_14::S_100 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_102;
            }
            C2Rust_Block_14::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_108;
            }
            C2Rust_Block_14::S_108 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x64 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_114;
            }
            C2Rust_Block_14::S_114 => {
                _pv_5 = 0x1fb73c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_116;
            }
            C2Rust_Block_14::S_116 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_118;
            }
            C2Rust_Block_14::S_118 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_124;
            }
            C2Rust_Block_14::S_124 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_130;
            }
            C2Rust_Block_14::S_130 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_132;
            }
            C2Rust_Block_14::S_132 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_134;
            }
            C2Rust_Block_14::S_134 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_136;
            }
            C2Rust_Block_14::S_136 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_138;
            }
            C2Rust_Block_14::S_138 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_140;
            }
            C2Rust_Block_14::S_140 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_142;
            }
            C2Rust_Block_14::S_142 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_144;
            }
            C2Rust_Block_14::S_144 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_146;
            }
            C2Rust_Block_14::S_146 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_148;
            }
            C2Rust_Block_14::S_148 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_150;
            }
            C2Rust_Block_14::S_150 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_152;
            }
            C2Rust_Block_14::S_152 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_154;
            }
            C2Rust_Block_14::S_154 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_156;
            }
            C2Rust_Block_14::S_156 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_158;
            }
            C2Rust_Block_14::S_158 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_229;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_171;
                }
            }
            C2Rust_Block_14::S_171 => {
                _pv_6 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_173;
            }
            C2Rust_Block_14::S_173 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_175;
            }
            C2Rust_Block_14::S_175 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_185;
            }
            C2Rust_Block_14::S_185 => {
                _pv_7 = 0x1fb754 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_187;
            }
            C2Rust_Block_14::S_187 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_189;
            }
            C2Rust_Block_14::S_189 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_195;
            }
            C2Rust_Block_14::S_195 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_201;
            }
            C2Rust_Block_14::S_201 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_203;
            }
            C2Rust_Block_14::S_203 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_205;
            }
            C2Rust_Block_14::S_205 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_207;
            }
            C2Rust_Block_14::S_207 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_209;
            }
            C2Rust_Block_14::S_209 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_211;
            }
            C2Rust_Block_14::S_211 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_213;
            }
            C2Rust_Block_14::S_213 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_215;
            }
            C2Rust_Block_14::S_215 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_217;
            }
            C2Rust_Block_14::S_217 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_219;
            }
            C2Rust_Block_14::S_219 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_221;
            }
            C2Rust_Block_14::S_221 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_235;
            }
            C2Rust_Block_14::S_229 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_235;
            }
            C2Rust_Block_14::S_235 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_237;
            }
            C2Rust_Block_14::S_237 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_239;
            }
            C2Rust_Block_14::S_239 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_241;
            }
            C2Rust_Block_14::S_241 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_247;
            }
            C2Rust_Block_14::S_247 => {
                _pv_8 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_249;
            }
            C2Rust_Block_14::S_249 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_251;
            }
            C2Rust_Block_14::S_251 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_257;
            }
            C2Rust_Block_14::S_257 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_798;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_270;
                }
            }
            C2Rust_Block_14::S_270 => {
                _pv_9 = 0x1fb77c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_272;
            }
            C2Rust_Block_14::S_272 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_274;
            }
            C2Rust_Block_14::S_274 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_280;
            }
            C2Rust_Block_14::S_280 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_286;
            }
            C2Rust_Block_14::S_286 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_288;
            }
            C2Rust_Block_14::S_288 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_290;
            }
            C2Rust_Block_14::S_290 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_292;
            }
            C2Rust_Block_14::S_292 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_294;
            }
            C2Rust_Block_14::S_294 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_296;
            }
            C2Rust_Block_14::S_296 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_298;
            }
            C2Rust_Block_14::S_298 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_300;
            }
            C2Rust_Block_14::S_300 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_302;
            }
            C2Rust_Block_14::S_302 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_304;
            }
            C2Rust_Block_14::S_304 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_306;
            }
            C2Rust_Block_14::S_306 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_308;
            }
            C2Rust_Block_14::S_308 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_310;
            }
            C2Rust_Block_14::S_310 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_312;
            }
            C2Rust_Block_14::S_312 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_314;
            }
            C2Rust_Block_14::S_314 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_387;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_327;
                }
            }
            C2Rust_Block_14::S_327 => {
                _pv_10 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_329;
            }
            C2Rust_Block_14::S_329 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_331;
            }
            C2Rust_Block_14::S_331 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_341;
            }
            C2Rust_Block_14::S_341 => {
                _pv_11 = 0x1fb794 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_343;
            }
            C2Rust_Block_14::S_343 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_345;
            }
            C2Rust_Block_14::S_345 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_351;
            }
            C2Rust_Block_14::S_351 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_357;
            }
            C2Rust_Block_14::S_357 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_359;
            }
            C2Rust_Block_14::S_359 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_361;
            }
            C2Rust_Block_14::S_361 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_363;
            }
            C2Rust_Block_14::S_363 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_365;
            }
            C2Rust_Block_14::S_365 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_367;
            }
            C2Rust_Block_14::S_367 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_369;
            }
            C2Rust_Block_14::S_369 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_371;
            }
            C2Rust_Block_14::S_371 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_373;
            }
            C2Rust_Block_14::S_373 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_375;
            }
            C2Rust_Block_14::S_375 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_377;
            }
            C2Rust_Block_14::S_377 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_379;
            }
            C2Rust_Block_14::S_379 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_393;
            }
            C2Rust_Block_14::S_387 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_393;
            }
            C2Rust_Block_14::S_393 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_395;
            }
            C2Rust_Block_14::S_395 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_397;
            }
            C2Rust_Block_14::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_399;
            }
            C2Rust_Block_14::S_399 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
                    | (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(3 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t) << 8 as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_405;
            }
            C2Rust_Block_14::S_405 => {
                _pv_12 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_407;
            }
            C2Rust_Block_14::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_409;
            }
            C2Rust_Block_14::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_415;
            }
            C2Rust_Block_14::S_415 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_417;
            }
            C2Rust_Block_14::S_417 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_419;
            }
            C2Rust_Block_14::S_419 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_421;
            }
            C2Rust_Block_14::S_421 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_423;
            }
            C2Rust_Block_14::S_423 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_619;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_436;
                }
            }
            C2Rust_Block_14::S_436 => {
                _pv_13 = 0x1fb7c0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_438;
            }
            C2Rust_Block_14::S_438 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_440;
            }
            C2Rust_Block_14::S_440 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_446;
            }
            C2Rust_Block_14::S_446 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_452;
            }
            C2Rust_Block_14::S_452 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_454;
            }
            C2Rust_Block_14::S_454 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_456;
            }
            C2Rust_Block_14::S_456 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_458;
            }
            C2Rust_Block_14::S_458 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_460;
            }
            C2Rust_Block_14::S_460 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_462;
            }
            C2Rust_Block_14::S_462 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_464;
            }
            C2Rust_Block_14::S_464 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_466;
            }
            C2Rust_Block_14::S_466 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_468;
            }
            C2Rust_Block_14::S_468 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_470;
            }
            C2Rust_Block_14::S_470 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_472;
            }
            C2Rust_Block_14::S_472 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_474;
            }
            C2Rust_Block_14::S_474 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_476;
            }
            C2Rust_Block_14::S_476 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_478;
            }
            C2Rust_Block_14::S_478 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_480;
            }
            C2Rust_Block_14::S_480 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_579;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_493;
                }
            }
            C2Rust_Block_14::S_493 => {
                _pv_14 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_495;
            }
            C2Rust_Block_14::S_495 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_497;
            }
            C2Rust_Block_14::S_497 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_507;
            }
            C2Rust_Block_14::S_507 => {
                _pv_15 = 0x1fb7d8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_509;
            }
            C2Rust_Block_14::S_509 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_511;
            }
            C2Rust_Block_14::S_511 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_517;
            }
            C2Rust_Block_14::S_517 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_523;
            }
            C2Rust_Block_14::S_523 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_525;
            }
            C2Rust_Block_14::S_525 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_527;
            }
            C2Rust_Block_14::S_527 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_529;
            }
            C2Rust_Block_14::S_529 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_531;
            }
            C2Rust_Block_14::S_531 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_533;
            }
            C2Rust_Block_14::S_533 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_535;
            }
            C2Rust_Block_14::S_535 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_537;
            }
            C2Rust_Block_14::S_537 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_539;
            }
            C2Rust_Block_14::S_539 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_541;
            }
            C2Rust_Block_14::S_541 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_543;
            }
            C2Rust_Block_14::S_543 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_545;
            }
            C2Rust_Block_14::S_545 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x18 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_547;
            }
            C2Rust_Block_14::S_547 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_549;
            }
            C2Rust_Block_14::S_549 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_551;
            }
            C2Rust_Block_14::S_551 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_553;
            }
            C2Rust_Block_14::S_553 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_555;
            }
            C2Rust_Block_14::S_555 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_557;
            }
            C2Rust_Block_14::S_557 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_559;
            }
            C2Rust_Block_14::S_559 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_561;
            }
            C2Rust_Block_14::S_561 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_563;
            }
            C2Rust_Block_14::S_563 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_565;
            }
            C2Rust_Block_14::S_565 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_567;
            }
            C2Rust_Block_14::S_567 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_569;
            }
            C2Rust_Block_14::S_569 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_571;
            }
            C2Rust_Block_14::S_571 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_579 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_581;
            }
            C2Rust_Block_14::S_581 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x18 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_583;
            }
            C2Rust_Block_14::S_583 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_585;
            }
            C2Rust_Block_14::S_585 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_587;
            }
            C2Rust_Block_14::S_587 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_589;
            }
            C2Rust_Block_14::S_589 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_591;
            }
            C2Rust_Block_14::S_591 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_593;
            }
            C2Rust_Block_14::S_593 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_595;
            }
            C2Rust_Block_14::S_595 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_597;
            }
            C2Rust_Block_14::S_597 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_599;
            }
            C2Rust_Block_14::S_599 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_601;
            }
            C2Rust_Block_14::S_601 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_603;
            }
            C2Rust_Block_14::S_603 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_605;
            }
            C2Rust_Block_14::S_605 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_607;
            }
            C2Rust_Block_14::S_607 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_619 => {
                _pv_16 = 0x1fb81b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_621;
            }
            C2Rust_Block_14::S_621 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_623;
            }
            C2Rust_Block_14::S_623 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_629;
            }
            C2Rust_Block_14::S_629 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_635;
            }
            C2Rust_Block_14::S_635 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_637;
            }
            C2Rust_Block_14::S_637 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_639;
            }
            C2Rust_Block_14::S_639 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_641;
            }
            C2Rust_Block_14::S_641 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_643;
            }
            C2Rust_Block_14::S_643 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_645;
            }
            C2Rust_Block_14::S_645 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_647;
            }
            C2Rust_Block_14::S_647 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_649;
            }
            C2Rust_Block_14::S_649 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_651;
            }
            C2Rust_Block_14::S_651 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_653;
            }
            C2Rust_Block_14::S_653 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_655;
            }
            C2Rust_Block_14::S_655 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_657;
            }
            C2Rust_Block_14::S_657 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_659;
            }
            C2Rust_Block_14::S_659 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_661;
            }
            C2Rust_Block_14::S_661 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_663;
            }
            C2Rust_Block_14::S_663 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_760;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_676;
                }
            }
            C2Rust_Block_14::S_676 => {
                _pv_17 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_678;
            }
            C2Rust_Block_14::S_678 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_680;
            }
            C2Rust_Block_14::S_680 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_690;
            }
            C2Rust_Block_14::S_690 => {
                _pv_18 = 0x1fb833 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_692;
            }
            C2Rust_Block_14::S_692 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_694;
            }
            C2Rust_Block_14::S_694 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_700;
            }
            C2Rust_Block_14::S_700 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_706;
            }
            C2Rust_Block_14::S_706 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_708;
            }
            C2Rust_Block_14::S_708 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_710;
            }
            C2Rust_Block_14::S_710 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_712;
            }
            C2Rust_Block_14::S_712 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_714;
            }
            C2Rust_Block_14::S_714 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_716;
            }
            C2Rust_Block_14::S_716 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_718;
            }
            C2Rust_Block_14::S_718 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_720;
            }
            C2Rust_Block_14::S_720 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_722;
            }
            C2Rust_Block_14::S_722 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_724;
            }
            C2Rust_Block_14::S_724 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_726;
            }
            C2Rust_Block_14::S_726 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_728;
            }
            C2Rust_Block_14::S_728 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x10 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_730;
            }
            C2Rust_Block_14::S_730 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_732;
            }
            C2Rust_Block_14::S_732 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_734;
            }
            C2Rust_Block_14::S_734 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_736;
            }
            C2Rust_Block_14::S_736 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_14 = C2Rust_Block_14::S_738;
            }
            C2Rust_Block_14::S_738 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_740;
            }
            C2Rust_Block_14::S_740 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_742;
            }
            C2Rust_Block_14::S_742 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_744;
            }
            C2Rust_Block_14::S_744 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_746;
            }
            C2Rust_Block_14::S_746 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_748;
            }
            C2Rust_Block_14::S_748 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_750;
            }
            C2Rust_Block_14::S_750 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_752;
            }
            C2Rust_Block_14::S_752 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_760 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_762;
            }
            C2Rust_Block_14::S_762 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x10 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_764;
            }
            C2Rust_Block_14::S_764 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_766;
            }
            C2Rust_Block_14::S_766 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_768;
            }
            C2Rust_Block_14::S_768 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_770;
            }
            C2Rust_Block_14::S_770 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_14 = C2Rust_Block_14::S_772;
            }
            C2Rust_Block_14::S_772 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_774;
            }
            C2Rust_Block_14::S_774 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_776;
            }
            C2Rust_Block_14::S_776 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_778;
            }
            C2Rust_Block_14::S_778 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_780;
            }
            C2Rust_Block_14::S_780 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_782;
            }
            C2Rust_Block_14::S_782 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_784;
            }
            C2Rust_Block_14::S_784 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_786;
            }
            C2Rust_Block_14::S_786 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_798 => {
                _pv_19 = 0x1fb872 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_800;
            }
            C2Rust_Block_14::S_800 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_802;
            }
            C2Rust_Block_14::S_802 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_808;
            }
            C2Rust_Block_14::S_808 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_814;
            }
            C2Rust_Block_14::S_814 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_816;
            }
            C2Rust_Block_14::S_816 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_818;
            }
            C2Rust_Block_14::S_818 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_820;
            }
            C2Rust_Block_14::S_820 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_822;
            }
            C2Rust_Block_14::S_822 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_824;
            }
            C2Rust_Block_14::S_824 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_826;
            }
            C2Rust_Block_14::S_826 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_828;
            }
            C2Rust_Block_14::S_828 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_830;
            }
            C2Rust_Block_14::S_830 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_832;
            }
            C2Rust_Block_14::S_832 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_834;
            }
            C2Rust_Block_14::S_834 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_836;
            }
            C2Rust_Block_14::S_836 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_838;
            }
            C2Rust_Block_14::S_838 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_840;
            }
            C2Rust_Block_14::S_840 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_842;
            }
            C2Rust_Block_14::S_842 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_913;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_855;
                }
            }
            C2Rust_Block_14::S_855 => {
                _pv_20 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_857;
            }
            C2Rust_Block_14::S_857 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_859;
            }
            C2Rust_Block_14::S_859 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_869;
            }
            C2Rust_Block_14::S_869 => {
                _pv_21 = 0x1fb88a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_871;
            }
            C2Rust_Block_14::S_871 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_873;
            }
            C2Rust_Block_14::S_873 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_879;
            }
            C2Rust_Block_14::S_879 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_885;
            }
            C2Rust_Block_14::S_885 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_887;
            }
            C2Rust_Block_14::S_887 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_889;
            }
            C2Rust_Block_14::S_889 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_891;
            }
            C2Rust_Block_14::S_891 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_893;
            }
            C2Rust_Block_14::S_893 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_895;
            }
            C2Rust_Block_14::S_895 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_897;
            }
            C2Rust_Block_14::S_897 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_899;
            }
            C2Rust_Block_14::S_899 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_901;
            }
            C2Rust_Block_14::S_901 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_903;
            }
            C2Rust_Block_14::S_903 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_905;
            }
            C2Rust_Block_14::S_905 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_919;
            }
            C2Rust_Block_14::S_913 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_919;
            }
            C2Rust_Block_14::S_919 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0xff as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_921;
            }
            C2Rust_Block_14::S_921 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_923;
            }
            C2Rust_Block_14::S_923 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_925;
            }
            C2Rust_Block_14::S_925 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_931;
            }
            C2Rust_Block_14::S_931 => {
                _pv_22 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_933;
            }
            C2Rust_Block_14::S_933 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_935;
            }
            C2Rust_Block_14::S_935 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_941;
            }
            C2Rust_Block_14::S_941 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_1117;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_954;
                }
            }
            C2Rust_Block_14::S_954 => {
                _pv_23 = 0x1fb8ac as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_956;
            }
            C2Rust_Block_14::S_956 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_958;
            }
            C2Rust_Block_14::S_958 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_964;
            }
            C2Rust_Block_14::S_964 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_970;
            }
            C2Rust_Block_14::S_970 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_972;
            }
            C2Rust_Block_14::S_972 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_974;
            }
            C2Rust_Block_14::S_974 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_976;
            }
            C2Rust_Block_14::S_976 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_978;
            }
            C2Rust_Block_14::S_978 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_980;
            }
            C2Rust_Block_14::S_980 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_982;
            }
            C2Rust_Block_14::S_982 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_984;
            }
            C2Rust_Block_14::S_984 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_986;
            }
            C2Rust_Block_14::S_986 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_988;
            }
            C2Rust_Block_14::S_988 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_990;
            }
            C2Rust_Block_14::S_990 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_992;
            }
            C2Rust_Block_14::S_992 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_994;
            }
            C2Rust_Block_14::S_994 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_996;
            }
            C2Rust_Block_14::S_996 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_998;
            }
            C2Rust_Block_14::S_998 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_1087;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_1011;
                }
            }
            C2Rust_Block_14::S_1011 => {
                _pv_24 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1013;
            }
            C2Rust_Block_14::S_1013 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1015;
            }
            C2Rust_Block_14::S_1015 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1025;
            }
            C2Rust_Block_14::S_1025 => {
                _pv_25 = 0x1fb8c4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1027;
            }
            C2Rust_Block_14::S_1027 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1029;
            }
            C2Rust_Block_14::S_1029 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1035;
            }
            C2Rust_Block_14::S_1035 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_1041;
            }
            C2Rust_Block_14::S_1041 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1043;
            }
            C2Rust_Block_14::S_1043 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1045;
            }
            C2Rust_Block_14::S_1045 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1047;
            }
            C2Rust_Block_14::S_1047 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1049;
            }
            C2Rust_Block_14::S_1049 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1051;
            }
            C2Rust_Block_14::S_1051 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1053;
            }
            C2Rust_Block_14::S_1053 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_1055;
            }
            C2Rust_Block_14::S_1055 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_1057;
            }
            C2Rust_Block_14::S_1057 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1059;
            }
            C2Rust_Block_14::S_1059 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1061;
            }
            C2Rust_Block_14::S_1061 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1063;
            }
            C2Rust_Block_14::S_1063 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (8 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1065;
            }
            C2Rust_Block_14::S_1065 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1067;
            }
            C2Rust_Block_14::S_1067 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1069;
            }
            C2Rust_Block_14::S_1069 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1071;
            }
            C2Rust_Block_14::S_1071 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1073;
            }
            C2Rust_Block_14::S_1073 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1075;
            }
            C2Rust_Block_14::S_1075 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1077;
            }
            C2Rust_Block_14::S_1077 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1079;
            }
            C2Rust_Block_14::S_1079 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_1087 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1089;
            }
            C2Rust_Block_14::S_1089 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (8 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1091;
            }
            C2Rust_Block_14::S_1091 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1093;
            }
            C2Rust_Block_14::S_1093 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1095;
            }
            C2Rust_Block_14::S_1095 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1097;
            }
            C2Rust_Block_14::S_1097 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1099;
            }
            C2Rust_Block_14::S_1099 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1101;
            }
            C2Rust_Block_14::S_1101 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1103;
            }
            C2Rust_Block_14::S_1103 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1105;
            }
            C2Rust_Block_14::S_1105 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_1117 => {
                _pv_26 = 0x1fb8fb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1119;
            }
            C2Rust_Block_14::S_1119 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1121;
            }
            C2Rust_Block_14::S_1121 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1127;
            }
            C2Rust_Block_14::S_1127 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_1133;
            }
            C2Rust_Block_14::S_1133 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1135;
            }
            C2Rust_Block_14::S_1135 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1137;
            }
            C2Rust_Block_14::S_1137 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1139;
            }
            C2Rust_Block_14::S_1139 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1141;
            }
            C2Rust_Block_14::S_1141 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1143;
            }
            C2Rust_Block_14::S_1143 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1145;
            }
            C2Rust_Block_14::S_1145 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_1147;
            }
            C2Rust_Block_14::S_1147 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_1149;
            }
            C2Rust_Block_14::S_1149 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1151;
            }
            C2Rust_Block_14::S_1151 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1153;
            }
            C2Rust_Block_14::S_1153 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1155;
            }
            C2Rust_Block_14::S_1155 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1157;
            }
            C2Rust_Block_14::S_1157 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1159;
            }
            C2Rust_Block_14::S_1159 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1161;
            }
            C2Rust_Block_14::S_1161 => {
                if _fa == _fb {
                    c2rust_current_block_14 = C2Rust_Block_14::S_1232;
                } else {
                    c2rust_current_block_14 = C2Rust_Block_14::S_1174;
                }
            }
            C2Rust_Block_14::S_1174 => {
                _pv_27 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1176;
            }
            C2Rust_Block_14::S_1176 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1178;
            }
            C2Rust_Block_14::S_1178 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1188;
            }
            C2Rust_Block_14::S_1188 => {
                _pv_28 = 0x1fb913 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1190;
            }
            C2Rust_Block_14::S_1190 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1192;
            }
            C2Rust_Block_14::S_1192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1198;
            }
            C2Rust_Block_14::S_1198 => {
                sub_001FFF00();
                c2rust_current_block_14 = C2Rust_Block_14::S_1204;
            }
            C2Rust_Block_14::S_1204 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1206;
            }
            C2Rust_Block_14::S_1206 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1208;
            }
            C2Rust_Block_14::S_1208 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1210;
            }
            C2Rust_Block_14::S_1210 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1212;
            }
            C2Rust_Block_14::S_1212 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1214;
            }
            C2Rust_Block_14::S_1214 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1216;
            }
            C2Rust_Block_14::S_1216 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_1218;
            }
            C2Rust_Block_14::S_1218 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_1220;
            }
            C2Rust_Block_14::S_1220 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1222;
            }
            C2Rust_Block_14::S_1222 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1224;
            }
            C2Rust_Block_14::S_1224 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1238;
            }
            C2Rust_Block_14::S_1232 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1238;
            }
            C2Rust_Block_14::S_1238 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1240;
            }
            C2Rust_Block_14::S_1240 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_14 = C2Rust_Block_14::S_1242;
            }
            C2Rust_Block_14::S_1242 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1244;
            }
            C2Rust_Block_14::S_1244 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1246;
            }
            C2Rust_Block_14::S_1246 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1252;
            }
            C2Rust_Block_14::S_1252 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1254;
            }
            C2Rust_Block_14::S_1254 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 0x1c as ::core::ffi::c_int;
                c2rust_current_block_14 = C2Rust_Block_14::S_1256;
            }
            C2Rust_Block_14::S_1256 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1258;
            }
            C2Rust_Block_14::S_1258 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1260;
            }
            C2Rust_Block_14::S_1260 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) | (*__gamepkg_tls_g_eax);
                c2rust_current_block_14 = C2Rust_Block_14::S_1262;
            }
            C2Rust_Block_14::S_1262 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1264;
            }
            C2Rust_Block_14::S_1264 => {
                _fas = _fa as int32_t;
                c2rust_current_block_14 = C2Rust_Block_14::S_1266;
            }
            C2Rust_Block_14::S_1266 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1268;
            }
            C2Rust_Block_14::S_1268 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1fb000 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1270;
            }
            C2Rust_Block_14::S_1270 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1fb070 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1272;
            }
            C2Rust_Block_14::S_1272 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1fb0a0 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1274;
            }
            C2Rust_Block_14::S_1274 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1fb0f0 as uint32_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1276;
            }
            C2Rust_Block_14::S_1276 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    4 as uint16_t,
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1282;
            }
            C2Rust_Block_14::S_1282 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_14 = C2Rust_Block_14::S_1284;
            }
            C2Rust_Block_14::S_1284 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1290;
            }
            C2Rust_Block_14::S_1290 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_14 = C2Rust_Block_14::S_1292;
            }
            C2Rust_Block_14::S_1292 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB960() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x764134 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x30811 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x41b814 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x41b7a0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x41b7b8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x1fb982 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001F8E20();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_389: {
        if _fa == _fb {
            break 's_389;
        }
        let mut _pv_7: uint32_t = 0x1fb990 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        sub_001FB720();
        let mut _pv_8: uint32_t = 0x12 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x3c1750 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x11 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        let mut _pv_11: uint32_t = 0x3c15b8 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_11,
        );
        let mut _pv_12: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_12,
        );
        let mut _pv_13: uint32_t = 0x1fb9a4 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_13,
        );
        sub_001F8B70();
        _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_345: {
            if _fa == _fb {
                break 's_345;
            }
            let mut _pv_14: uint32_t = 0x1fb9b0 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_14,
            );
            sub_00207DF0();
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_345;
            }
            let mut _pv_17: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_17,
            );
            let mut _pv_18: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_18,
            );
            let mut _pv_19: uint32_t = 0x1fb9c8 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_19,
            );
            sub_001F8520();
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b81c as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                1 as uint32_t,
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        let mut _pv_15: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_15,
        );
        let mut _pv_16: uint32_t = 0x1fb9ba as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_16,
        );
        sub_001F8970();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FB9E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x4080c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41b828 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_eax) = 0x41b820 as uint32_t;
    let mut _pv_3: uint32_t = 0x40 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x18 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b824 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv_5: uint32_t = 0x1fba06 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001FEBF0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_163: {
        if _fa != _fb {
            break 's_163;
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b84c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBA20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    enum C2Rust_Block_17 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_42,
        S_48,
        S_50,
        S_52,
        S_62,
        S_64,
        S_66,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_103,
        S_109,
        S_111,
        S_113,
        S_115,
        S_117,
        S_119,
        S_121,
        S_130,
        S_132,
        S_134,
        S_136,
        S_142,
        S_144,
        S_150,
        S_156,
        S_158,
        S_168,
        S_170,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_217,
        S_219,
        S_221,
        S_231,
        S_233,
        S_235,
        S_241,
        S_247,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_259,
        S_261,
        S_263,
        S_265,
        S_274,
        S_276,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_329,
        S_335,
        S_337,
        S_339,
        S_341,
        S_343,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_369,
        S_371,
        S_377,
        S_379,
        S_381,
        S_391,
        S_393,
        S_395,
        S_405,
        S_407,
        S_409,
        S_419,
        S_421,
        S_423,
        S_429,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_449,
        S_451,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_482,
        S_484,
        S_486,
        S_496,
        S_498,
        S_500,
        S_510,
        S_512,
        S_514,
        S_520,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_544,
        S_546,
        S_552,
        S_558,
        S_560,
        S_570,
        S_572,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
    }
    let mut c2rust_current_block_17: C2Rust_Block_17;
    c2rust_current_block_17 = C2Rust_Block_17::S_0;
    loop {
        match c2rust_current_block_17 {
            C2Rust_Block_17::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_17 = C2Rust_Block_17::S_2;
            }
            C2Rust_Block_17::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_4;
            }
            C2Rust_Block_17::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_18;
            }
            C2Rust_Block_17::S_18 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_20;
            }
            C2Rust_Block_17::S_20 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_22;
            }
            C2Rust_Block_17::S_22 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x10 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_24;
            }
            C2Rust_Block_17::S_24 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_26;
            }
            C2Rust_Block_17::S_26 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_32;
            }
            C2Rust_Block_17::S_32 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_17 = C2Rust_Block_17::S_34;
            }
            C2Rust_Block_17::S_34 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_36;
            }
            C2Rust_Block_17::S_36 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_42;
            }
            C2Rust_Block_17::S_42 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_48;
            }
            C2Rust_Block_17::S_48 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_17 = C2Rust_Block_17::S_50;
            }
            C2Rust_Block_17::S_50 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_52;
            }
            C2Rust_Block_17::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_62;
            }
            C2Rust_Block_17::S_62 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_17 = C2Rust_Block_17::S_64;
            }
            C2Rust_Block_17::S_64 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_66;
            }
            C2Rust_Block_17::S_66 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_72;
            }
            C2Rust_Block_17::S_72 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_74;
            }
            C2Rust_Block_17::S_74 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_76;
            }
            C2Rust_Block_17::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_78;
            }
            C2Rust_Block_17::S_78 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_80;
            }
            C2Rust_Block_17::S_80 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_82;
            }
            C2Rust_Block_17::S_82 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_84;
            }
            C2Rust_Block_17::S_84 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_86;
            }
            C2Rust_Block_17::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_88;
            }
            C2Rust_Block_17::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_90;
            }
            C2Rust_Block_17::S_90 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_92;
            }
            C2Rust_Block_17::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_94;
            }
            C2Rust_Block_17::S_94 => {
                if _fa != _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_109;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_103;
                }
            }
            C2Rust_Block_17::S_103 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_109;
            }
            C2Rust_Block_17::S_109 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_111;
            }
            C2Rust_Block_17::S_111 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_113;
            }
            C2Rust_Block_17::S_113 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_115;
            }
            C2Rust_Block_17::S_115 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_117;
            }
            C2Rust_Block_17::S_117 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_119;
            }
            C2Rust_Block_17::S_119 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_121;
            }
            C2Rust_Block_17::S_121 => {
                if _fa <= _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_194;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_130;
                }
            }
            C2Rust_Block_17::S_130 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_17 = C2Rust_Block_17::S_132;
            }
            C2Rust_Block_17::S_132 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_134;
            }
            C2Rust_Block_17::S_134 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_136;
            }
            C2Rust_Block_17::S_136 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_142;
            }
            C2Rust_Block_17::S_142 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_144;
            }
            C2Rust_Block_17::S_144 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_150;
            }
            C2Rust_Block_17::S_150 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_156;
            }
            C2Rust_Block_17::S_156 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_158;
            }
            C2Rust_Block_17::S_158 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_168;
            }
            C2Rust_Block_17::S_168 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_170;
            }
            C2Rust_Block_17::S_170 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_176;
            }
            C2Rust_Block_17::S_176 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_178;
            }
            C2Rust_Block_17::S_178 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_180;
            }
            C2Rust_Block_17::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_182;
            }
            C2Rust_Block_17::S_182 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_184;
            }
            C2Rust_Block_17::S_184 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_186;
            }
            C2Rust_Block_17::S_186 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_188;
            }
            C2Rust_Block_17::S_188 => return,
            C2Rust_Block_17::S_194 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_196;
            }
            C2Rust_Block_17::S_196 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_198;
            }
            C2Rust_Block_17::S_198 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_200;
            }
            C2Rust_Block_17::S_200 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_202;
            }
            C2Rust_Block_17::S_202 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_204;
            }
            C2Rust_Block_17::S_204 => {
                if _fa == _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_282;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_217;
                }
            }
            C2Rust_Block_17::S_217 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_17 = C2Rust_Block_17::S_219;
            }
            C2Rust_Block_17::S_219 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_221;
            }
            C2Rust_Block_17::S_221 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_231;
            }
            C2Rust_Block_17::S_231 => {
                _pv_3 = 0x1fba67 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_233;
            }
            C2Rust_Block_17::S_233 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_235;
            }
            C2Rust_Block_17::S_235 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_241;
            }
            C2Rust_Block_17::S_241 => {
                sub_001FD330();
                c2rust_current_block_17 = C2Rust_Block_17::S_247;
            }
            C2Rust_Block_17::S_247 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_249;
            }
            C2Rust_Block_17::S_249 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_251;
            }
            C2Rust_Block_17::S_251 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_253;
            }
            C2Rust_Block_17::S_253 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_255;
            }
            C2Rust_Block_17::S_255 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_257;
            }
            C2Rust_Block_17::S_257 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_259;
            }
            C2Rust_Block_17::S_259 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_261;
            }
            C2Rust_Block_17::S_261 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_263;
            }
            C2Rust_Block_17::S_263 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_265;
            }
            C2Rust_Block_17::S_265 => {
                if _fa != _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_282;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_274;
                }
            }
            C2Rust_Block_17::S_274 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_276;
            }
            C2Rust_Block_17::S_276 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_282;
            }
            C2Rust_Block_17::S_282 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_284;
            }
            C2Rust_Block_17::S_284 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_286;
            }
            C2Rust_Block_17::S_286 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_288;
            }
            C2Rust_Block_17::S_288 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_290;
            }
            C2Rust_Block_17::S_290 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_292;
            }
            C2Rust_Block_17::S_292 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_294;
            }
            C2Rust_Block_17::S_294 => {
                if _fa == _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_329;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_303;
                }
            }
            C2Rust_Block_17::S_303 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_305;
            }
            C2Rust_Block_17::S_305 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_307;
            }
            C2Rust_Block_17::S_307 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_309;
            }
            C2Rust_Block_17::S_309 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_311;
            }
            C2Rust_Block_17::S_311 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_313;
            }
            C2Rust_Block_17::S_313 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_315;
            }
            C2Rust_Block_17::S_315 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_317;
            }
            C2Rust_Block_17::S_317 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edx));
                c2rust_current_block_17 = C2Rust_Block_17::S_319;
            }
            C2Rust_Block_17::S_319 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_321;
            }
            C2Rust_Block_17::S_321 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_335;
            }
            C2Rust_Block_17::S_329 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_335;
            }
            C2Rust_Block_17::S_335 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_eax) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_sub(1 as uint32_t),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_337;
            }
            C2Rust_Block_17::S_337 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_339;
            }
            C2Rust_Block_17::S_339 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_341;
            }
            C2Rust_Block_17::S_341 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_343;
            }
            C2Rust_Block_17::S_343 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_17 = C2Rust_Block_17::S_449;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_352;
                }
            }
            C2Rust_Block_17::S_352 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_354;
            }
            C2Rust_Block_17::S_354 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_356;
            }
            C2Rust_Block_17::S_356 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_358;
            }
            C2Rust_Block_17::S_358 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_360;
            }
            C2Rust_Block_17::S_360 => {
                if _fa != _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_449;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_369;
                }
            }
            C2Rust_Block_17::S_369 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_371;
            }
            C2Rust_Block_17::S_371 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_377;
            }
            C2Rust_Block_17::S_377 => {
                _pv_4 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_17 = C2Rust_Block_17::S_379;
            }
            C2Rust_Block_17::S_379 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_381;
            }
            C2Rust_Block_17::S_381 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_391;
            }
            C2Rust_Block_17::S_391 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_17 = C2Rust_Block_17::S_393;
            }
            C2Rust_Block_17::S_393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_395;
            }
            C2Rust_Block_17::S_395 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_405;
            }
            C2Rust_Block_17::S_405 => {
                _pv_6 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_17 = C2Rust_Block_17::S_407;
            }
            C2Rust_Block_17::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_409;
            }
            C2Rust_Block_17::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_419;
            }
            C2Rust_Block_17::S_419 => {
                _pv_7 = 0x1fbaa6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_421;
            }
            C2Rust_Block_17::S_421 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_423;
            }
            C2Rust_Block_17::S_423 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_429;
            }
            C2Rust_Block_17::S_429 => {
                sub_001F5F30();
                c2rust_current_block_17 = C2Rust_Block_17::S_435;
            }
            C2Rust_Block_17::S_435 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_437;
            }
            C2Rust_Block_17::S_437 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_439;
            }
            C2Rust_Block_17::S_439 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_441;
            }
            C2Rust_Block_17::S_441 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_443;
            }
            C2Rust_Block_17::S_443 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_449;
            }
            C2Rust_Block_17::S_449 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_451;
            }
            C2Rust_Block_17::S_451 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_453;
            }
            C2Rust_Block_17::S_453 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_455;
            }
            C2Rust_Block_17::S_455 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_457;
            }
            C2Rust_Block_17::S_457 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_459;
            }
            C2Rust_Block_17::S_459 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_461;
            }
            C2Rust_Block_17::S_461 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_463;
            }
            C2Rust_Block_17::S_463 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_465;
            }
            C2Rust_Block_17::S_465 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_467;
            }
            C2Rust_Block_17::S_467 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_469;
            }
            C2Rust_Block_17::S_469 => {
                if _fa != _fb {
                    c2rust_current_block_17 = C2Rust_Block_17::S_544;
                } else {
                    c2rust_current_block_17 = C2Rust_Block_17::S_482;
                }
            }
            C2Rust_Block_17::S_482 => {
                _pv_8 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_17 = C2Rust_Block_17::S_484;
            }
            C2Rust_Block_17::S_484 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_486;
            }
            C2Rust_Block_17::S_486 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_496;
            }
            C2Rust_Block_17::S_496 => {
                _pv_9 = 0x41b828 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_498;
            }
            C2Rust_Block_17::S_498 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_500;
            }
            C2Rust_Block_17::S_500 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_510;
            }
            C2Rust_Block_17::S_510 => {
                _pv_10 = 0x1fbacb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_512;
            }
            C2Rust_Block_17::S_512 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_514;
            }
            C2Rust_Block_17::S_514 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_520;
            }
            C2Rust_Block_17::S_520 => {
                sub_001FEA30();
                c2rust_current_block_17 = C2Rust_Block_17::S_526;
            }
            C2Rust_Block_17::S_526 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_528;
            }
            C2Rust_Block_17::S_528 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_530;
            }
            C2Rust_Block_17::S_530 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_532;
            }
            C2Rust_Block_17::S_532 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_534;
            }
            C2Rust_Block_17::S_534 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_544;
            }
            C2Rust_Block_17::S_544 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_546;
            }
            C2Rust_Block_17::S_546 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_552;
            }
            C2Rust_Block_17::S_552 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_558;
            }
            C2Rust_Block_17::S_558 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_560;
            }
            C2Rust_Block_17::S_560 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_570;
            }
            C2Rust_Block_17::S_570 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_17 = C2Rust_Block_17::S_572;
            }
            C2Rust_Block_17::S_572 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_578;
            }
            C2Rust_Block_17::S_578 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_580;
            }
            C2Rust_Block_17::S_580 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_582;
            }
            C2Rust_Block_17::S_582 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_584;
            }
            C2Rust_Block_17::S_584 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_586;
            }
            C2Rust_Block_17::S_586 => {
                _fas = _fa as int32_t;
                c2rust_current_block_17 = C2Rust_Block_17::S_588;
            }
            C2Rust_Block_17::S_588 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_17 = C2Rust_Block_17::S_590;
            }
            C2Rust_Block_17::S_590 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBAE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx)
        .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t));
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_4: uint32_t = 0x1fbb02 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_200: {
        's_151: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_151;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_200;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_159: {
            if !_fn.is_none() {
                break 's_159;
            }
            _fn = recomp_lookup(_va);
        }
        's_165: {
            if !_fn.is_none() {
                break 's_165;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_171: {
            if _fn.is_some() {
                break 's_171;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_200;
        }
        _fn.expect("non-null function pointer")();
    }
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBB10() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
        .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t));
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0x1fbb31 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_186: {
        's_137: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_137;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_186;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_145: {
            if !_fn.is_none() {
                break 's_145;
            }
            _fn = recomp_lookup(_va);
        }
        's_151: {
            if !_fn.is_none() {
                break 's_151;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_157: {
            if _fn.is_some() {
                break 's_157;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_186;
        }
        _fn.expect("non-null function pointer")();
    }
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBB40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_37: {
        if _fa == _fb {
            break 's_37;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x1fbb5e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001FBAE0();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBB70() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_55: {
        if _fa == _fb {
            break 's_55;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
        let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edx)
            .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t));
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = 0x1fbb9a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _va: uint32_t = _icall_target;
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                uint32_t,
            >(&raw const g_icall_trace_idx)
                & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
            _va,
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_trace_idx,
            ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                .wrapping_add(1),
        );
        ::core::ptr::write_volatile(
            &raw mut g_icall_count,
            ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                .wrapping_add(1),
        );
        's_249: {
            's_200: {
                if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
                {
                    break 's_200;
                }
                recomp_icall_not_code_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_249;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_208: {
                if !_fn.is_none() {
                    break 's_208;
                }
                _fn = recomp_lookup(_va);
            }
            's_214: {
                if !_fn.is_none() {
                    break 's_214;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_220: {
                if _fn.is_some() {
                    break 's_220;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_249;
            }
            _fn.expect("non-null function pointer")();
        }
        _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
            .wrapping_add(0xc as ::core::ffi::c_int as uint64_t)
            >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (if _cf != 0 {
            0xffffffff as ::core::ffi::c_uint
        } else {
            0 as ::core::ffi::c_uint
        }) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _cf = 0 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBBB0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1fbbc9 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001FBB10();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_153: {
        if _fa == _fb {
            break 's_153;
        }
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
            | (if _fa != _fb {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint8_t as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBBF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
        .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(8 as uint32_t));
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0x1fbc11 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_188: {
        's_127: {
            if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
            {
                break 's_127;
            }
            let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
            's_147: {
                if !_fn.is_none() {
                    break 's_147;
                }
                _fn = recomp_lookup(_va);
            }
            's_153: {
                if !_fn.is_none() {
                    break 's_153;
                }
                _fn = recomp_lookup_kernel(_va);
            }
            's_159: {
                if _fn.is_some() {
                    break 's_159;
                }
                recomp_icall_fail_log(_va);
                (*__gamepkg_tls_g_esp) = _icall_esp;
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                break 's_188;
            }
            _fn.expect("non-null function pointer")();
            break 's_188;
        }
        recomp_icall_not_code_log(_va);
        (*__gamepkg_tls_g_esp) = _icall_esp;
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(0xc as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_281: {
        if _fa == _fb {
            break 's_281;
        }
        _cf = 0 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_edx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        _cf = 0 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
            | (if _fa != _fb {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint8_t as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBC40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x41b820 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_132: {
        if _fa == _fb {
            break 's_132;
        }
        loop {
            _fb = 0xfffffff8 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add(0xfffffff8 as uint32_t);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv,
            );
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0x1fbc5b as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_001FBA20();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x41b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0x41b820 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_132;
            }
        }
    }
    let mut _pv_2: uint32_t = 0x41b828 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1fbc74 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001FEB70();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b84c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBC90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    enum C2Rust_Block_22 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_70,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_101,
        S_103,
        S_105,
        S_107,
        S_109,
        S_111,
        S_113,
        S_119,
        S_121,
        S_123,
        S_125,
        S_127,
        S_129,
        S_138,
        S_150,
        S_152,
        S_154,
        S_164,
        S_166,
        S_168,
        S_178,
        S_180,
        S_182,
        S_188,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_249,
        S_251,
        S_253,
        S_255,
        S_257,
        S_259,
        S_261,
        S_263,
        S_272,
        S_274,
        S_280,
        S_282,
        S_284,
        S_290,
        S_296,
        S_298,
        S_300,
        S_310,
        S_312,
        S_314,
        S_324,
        S_326,
        S_328,
        S_338,
        S_340,
        S_342,
        S_348,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_404,
        S_406,
        S_408,
        S_418,
        S_420,
        S_422,
        S_432,
        S_434,
        S_436,
        S_442,
        S_448,
        S_450,
        S_452,
        S_454,
        S_456,
        S_466,
        S_468,
        S_478,
        S_480,
        S_486,
        S_488,
        S_490,
        S_496,
        S_498,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_522,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_569,
        S_571,
        S_573,
        S_575,
        S_577,
        S_583,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_605,
        S_611,
        S_613,
        S_619,
        S_621,
        S_627,
        S_629,
        S_639,
        S_641,
        S_647,
        S_649,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
    }
    let mut c2rust_current_block_22: C2Rust_Block_22;
    c2rust_current_block_22 = C2Rust_Block_22::S_0;
    loop {
        match c2rust_current_block_22 {
            C2Rust_Block_22::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_2;
            }
            C2Rust_Block_22::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_22 = C2Rust_Block_22::S_4;
            }
            C2Rust_Block_22::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_22 = C2Rust_Block_22::S_6;
            }
            C2Rust_Block_22::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_8;
            }
            C2Rust_Block_22::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_18;
            }
            C2Rust_Block_22::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_22 = C2Rust_Block_22::S_24;
            }
            C2Rust_Block_22::S_24 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_26;
            }
            C2Rust_Block_22::S_26 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_28;
            }
            C2Rust_Block_22::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x18 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_30;
            }
            C2Rust_Block_22::S_30 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_32;
            }
            C2Rust_Block_22::S_32 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_38;
            }
            C2Rust_Block_22::S_38 => {
                _pv = ebp;
                c2rust_current_block_22 = C2Rust_Block_22::S_40;
            }
            C2Rust_Block_22::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_42;
            }
            C2Rust_Block_22::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_52;
            }
            C2Rust_Block_22::S_52 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_22 = C2Rust_Block_22::S_54;
            }
            C2Rust_Block_22::S_54 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_56;
            }
            C2Rust_Block_22::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_66;
            }
            C2Rust_Block_22::S_66 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_22 = C2Rust_Block_22::S_68;
            }
            C2Rust_Block_22::S_68 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_70;
            }
            C2Rust_Block_22::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_76;
            }
            C2Rust_Block_22::S_76 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_78;
            }
            C2Rust_Block_22::S_78 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_80;
            }
            C2Rust_Block_22::S_80 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_82;
            }
            C2Rust_Block_22::S_82 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_84;
            }
            C2Rust_Block_22::S_84 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_86;
            }
            C2Rust_Block_22::S_86 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_88;
            }
            C2Rust_Block_22::S_88 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_90;
            }
            C2Rust_Block_22::S_90 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_92;
            }
            C2Rust_Block_22::S_92 => {
                if _fa != _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_119;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_101;
                }
            }
            C2Rust_Block_22::S_101 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_103;
            }
            C2Rust_Block_22::S_103 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_105;
            }
            C2Rust_Block_22::S_105 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_107;
            }
            C2Rust_Block_22::S_107 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_109;
            }
            C2Rust_Block_22::S_109 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    2 as uint32_t,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_111;
            }
            C2Rust_Block_22::S_111 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_113;
            }
            C2Rust_Block_22::S_113 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_119;
            }
            C2Rust_Block_22::S_119 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_121;
            }
            C2Rust_Block_22::S_121 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_123;
            }
            C2Rust_Block_22::S_123 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_125;
            }
            C2Rust_Block_22::S_125 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_127;
            }
            C2Rust_Block_22::S_127 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_129;
            }
            C2Rust_Block_22::S_129 => {
                if _fa == _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_150;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_138;
                }
            }
            C2Rust_Block_22::S_138 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_212;
            }
            C2Rust_Block_22::S_150 => {
                _pv_2 = 0x3080c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_152;
            }
            C2Rust_Block_22::S_152 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_154;
            }
            C2Rust_Block_22::S_154 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_164;
            }
            C2Rust_Block_22::S_164 => {
                _pv_3 = 0x41b828 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_166;
            }
            C2Rust_Block_22::S_166 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_168;
            }
            C2Rust_Block_22::S_168 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_178;
            }
            C2Rust_Block_22::S_178 => {
                _pv_4 = 0x1fbcdf as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_180;
            }
            C2Rust_Block_22::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_182;
            }
            C2Rust_Block_22::S_182 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_188;
            }
            C2Rust_Block_22::S_188 => {
                sub_001FE900();
                c2rust_current_block_22 = C2Rust_Block_22::S_194;
            }
            C2Rust_Block_22::S_194 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_22 = C2Rust_Block_22::S_196;
            }
            C2Rust_Block_22::S_196 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_198;
            }
            C2Rust_Block_22::S_198 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_200;
            }
            C2Rust_Block_22::S_200 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_202;
            }
            C2Rust_Block_22::S_202 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_204;
            }
            C2Rust_Block_22::S_204 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_206;
            }
            C2Rust_Block_22::S_206 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_212;
            }
            C2Rust_Block_22::S_212 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_214;
            }
            C2Rust_Block_22::S_214 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_216;
            }
            C2Rust_Block_22::S_216 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 2 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_218;
            }
            C2Rust_Block_22::S_218 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_220;
            }
            C2Rust_Block_22::S_220 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_222;
            }
            C2Rust_Block_22::S_222 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_224;
            }
            C2Rust_Block_22::S_224 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_226;
            }
            C2Rust_Block_22::S_226 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_228;
            }
            C2Rust_Block_22::S_228 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_230;
            }
            C2Rust_Block_22::S_230 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_232;
            }
            C2Rust_Block_22::S_232 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_234;
            }
            C2Rust_Block_22::S_234 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_236;
            }
            C2Rust_Block_22::S_236 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_238;
            }
            C2Rust_Block_22::S_238 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_240;
            }
            C2Rust_Block_22::S_240 => {
                if _fa != _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_272;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_249;
                }
            }
            C2Rust_Block_22::S_249 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_251;
            }
            C2Rust_Block_22::S_251 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_253;
            }
            C2Rust_Block_22::S_253 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_255;
            }
            C2Rust_Block_22::S_255 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_257;
            }
            C2Rust_Block_22::S_257 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_259;
            }
            C2Rust_Block_22::S_259 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_261;
            }
            C2Rust_Block_22::S_261 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_263;
            }
            C2Rust_Block_22::S_263 => {
                if _fa == _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_522;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_272;
                }
            }
            C2Rust_Block_22::S_272 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_274;
            }
            C2Rust_Block_22::S_274 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_280;
            }
            C2Rust_Block_22::S_280 => {
                _pv_5 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_22 = C2Rust_Block_22::S_282;
            }
            C2Rust_Block_22::S_282 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_284;
            }
            C2Rust_Block_22::S_284 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_290;
            }
            C2Rust_Block_22::S_290 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_296;
            }
            C2Rust_Block_22::S_296 => {
                _pv_6 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_22 = C2Rust_Block_22::S_298;
            }
            C2Rust_Block_22::S_298 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_300;
            }
            C2Rust_Block_22::S_300 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_310;
            }
            C2Rust_Block_22::S_310 => {
                _pv_7 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_22 = C2Rust_Block_22::S_312;
            }
            C2Rust_Block_22::S_312 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_314;
            }
            C2Rust_Block_22::S_314 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_324;
            }
            C2Rust_Block_22::S_324 => {
                _pv_8 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_22 = C2Rust_Block_22::S_326;
            }
            C2Rust_Block_22::S_326 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_328;
            }
            C2Rust_Block_22::S_328 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_338;
            }
            C2Rust_Block_22::S_338 => {
                _pv_9 = 0x1fbd20 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_340;
            }
            C2Rust_Block_22::S_340 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_342;
            }
            C2Rust_Block_22::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_348;
            }
            C2Rust_Block_22::S_348 => {
                sub_001FD770();
                c2rust_current_block_22 = C2Rust_Block_22::S_354;
            }
            C2Rust_Block_22::S_354 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_356;
            }
            C2Rust_Block_22::S_356 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_358;
            }
            C2Rust_Block_22::S_358 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_360;
            }
            C2Rust_Block_22::S_360 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_362;
            }
            C2Rust_Block_22::S_362 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_364;
            }
            C2Rust_Block_22::S_364 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_366;
            }
            C2Rust_Block_22::S_366 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_368;
            }
            C2Rust_Block_22::S_368 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_370;
            }
            C2Rust_Block_22::S_370 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_372;
            }
            C2Rust_Block_22::S_372 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_374;
            }
            C2Rust_Block_22::S_374 => {
                if _fa != _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_522;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_383;
                }
            }
            C2Rust_Block_22::S_383 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_385;
            }
            C2Rust_Block_22::S_385 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_387;
            }
            C2Rust_Block_22::S_387 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_389;
            }
            C2Rust_Block_22::S_389 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_391;
            }
            C2Rust_Block_22::S_391 => {
                if _fa != _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_466;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_404;
                }
            }
            C2Rust_Block_22::S_404 => {
                _pv_10 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_22 = C2Rust_Block_22::S_406;
            }
            C2Rust_Block_22::S_406 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_408;
            }
            C2Rust_Block_22::S_408 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_418;
            }
            C2Rust_Block_22::S_418 => {
                _pv_11 = 0x41b828 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_420;
            }
            C2Rust_Block_22::S_420 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_422;
            }
            C2Rust_Block_22::S_422 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_432;
            }
            C2Rust_Block_22::S_432 => {
                _pv_12 = 0x1fbd3b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_434;
            }
            C2Rust_Block_22::S_434 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_436;
            }
            C2Rust_Block_22::S_436 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_442;
            }
            C2Rust_Block_22::S_442 => {
                sub_001FEA30();
                c2rust_current_block_22 = C2Rust_Block_22::S_448;
            }
            C2Rust_Block_22::S_448 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_450;
            }
            C2Rust_Block_22::S_450 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_452;
            }
            C2Rust_Block_22::S_452 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_454;
            }
            C2Rust_Block_22::S_454 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_456;
            }
            C2Rust_Block_22::S_456 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_466;
            }
            C2Rust_Block_22::S_466 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_468;
            }
            C2Rust_Block_22::S_468 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_478;
            }
            C2Rust_Block_22::S_478 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_480;
            }
            C2Rust_Block_22::S_480 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_486;
            }
            C2Rust_Block_22::S_486 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_488;
            }
            C2Rust_Block_22::S_488 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_490;
            }
            C2Rust_Block_22::S_490 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_496;
            }
            C2Rust_Block_22::S_496 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_498;
            }
            C2Rust_Block_22::S_498 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_504;
            }
            C2Rust_Block_22::S_504 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_506;
            }
            C2Rust_Block_22::S_506 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_508;
            }
            C2Rust_Block_22::S_508 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_510;
            }
            C2Rust_Block_22::S_510 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_512;
            }
            C2Rust_Block_22::S_512 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_514;
            }
            C2Rust_Block_22::S_514 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_516;
            }
            C2Rust_Block_22::S_516 => return,
            C2Rust_Block_22::S_522 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_524;
            }
            C2Rust_Block_22::S_524 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_526;
            }
            C2Rust_Block_22::S_526 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_528;
            }
            C2Rust_Block_22::S_528 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_530;
            }
            C2Rust_Block_22::S_530 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_532;
            }
            C2Rust_Block_22::S_532 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_534;
            }
            C2Rust_Block_22::S_534 => {
                if _fa == _fb {
                    c2rust_current_block_22 = C2Rust_Block_22::S_569;
                } else {
                    c2rust_current_block_22 = C2Rust_Block_22::S_543;
                }
            }
            C2Rust_Block_22::S_543 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_545;
            }
            C2Rust_Block_22::S_545 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_547;
            }
            C2Rust_Block_22::S_547 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xfffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_549;
            }
            C2Rust_Block_22::S_549 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_551;
            }
            C2Rust_Block_22::S_551 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_553;
            }
            C2Rust_Block_22::S_553 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_555;
            }
            C2Rust_Block_22::S_555 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_557;
            }
            C2Rust_Block_22::S_557 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_22 = C2Rust_Block_22::S_559;
            }
            C2Rust_Block_22::S_559 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_561;
            }
            C2Rust_Block_22::S_561 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_583;
            }
            C2Rust_Block_22::S_569 => {
                _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_571;
            }
            C2Rust_Block_22::S_571 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_573;
            }
            C2Rust_Block_22::S_573 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_575;
            }
            C2Rust_Block_22::S_575 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_577;
            }
            C2Rust_Block_22::S_577 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_583;
            }
            C2Rust_Block_22::S_583 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_eax) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_585;
            }
            C2Rust_Block_22::S_585 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_587;
            }
            C2Rust_Block_22::S_587 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_589;
            }
            C2Rust_Block_22::S_589 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_591;
            }
            C2Rust_Block_22::S_591 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_593;
            }
            C2Rust_Block_22::S_593 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_595;
            }
            C2Rust_Block_22::S_595 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_597;
            }
            C2Rust_Block_22::S_597 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_599;
            }
            C2Rust_Block_22::S_599 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_601;
            }
            C2Rust_Block_22::S_601 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x41b820 as uint32_t,
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_603;
            }
            C2Rust_Block_22::S_603 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_605;
            }
            C2Rust_Block_22::S_605 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_611;
            }
            C2Rust_Block_22::S_611 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_613;
            }
            C2Rust_Block_22::S_613 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_619;
            }
            C2Rust_Block_22::S_619 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_621;
            }
            C2Rust_Block_22::S_621 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_22 = C2Rust_Block_22::S_627;
            }
            C2Rust_Block_22::S_627 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_629;
            }
            C2Rust_Block_22::S_629 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_639;
            }
            C2Rust_Block_22::S_639 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_22 = C2Rust_Block_22::S_641;
            }
            C2Rust_Block_22::S_641 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_647;
            }
            C2Rust_Block_22::S_647 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_649;
            }
            C2Rust_Block_22::S_649 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_651;
            }
            C2Rust_Block_22::S_651 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_653;
            }
            C2Rust_Block_22::S_653 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_655;
            }
            C2Rust_Block_22::S_655 => {
                _fas = _fa as int32_t;
                c2rust_current_block_22 = C2Rust_Block_22::S_657;
            }
            C2Rust_Block_22::S_657 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_22 = C2Rust_Block_22::S_659;
            }
            C2Rust_Block_22::S_659 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBDA0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x41b858 as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b85c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = 0x41b850 as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b864 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _pv: uint32_t = 0x1fbdcd as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001FB960();
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBDE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = 0x1fbde5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_001FAFD0();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b864 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBDF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1fbdf7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001FC930();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    let mut _pv_2: uint32_t = 0x1fbdfe as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FC950();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b884 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub((*__gamepkg_tls_g_edx));
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_131: {
        if _fa >= _fb {
            break 's_131;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
    }
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        int32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            int32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    's_170: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_170;
        }
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
            as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
        {
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                + ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double
        } else {
            recomp_fp_round24(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    + ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double,
            )
        };
    }
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        int32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            int32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    's_209: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_209;
        }
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
            as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
        {
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                + ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double
        } else {
            recomp_fp_round24(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    + ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double,
            )
        };
    }
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] / (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
                / (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        )
    };
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            * ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b16cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b16cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double,
        )
    };
    let mut _pv_3: uint32_t = 0x1fbe3e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_00244DF0();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b884 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_esi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBE60() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FBE70() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    enum C2Rust_Block_29 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_70,
        S_80,
        S_82,
        S_84,
        S_94,
        S_96,
        S_98,
        S_108,
        S_110,
        S_112,
        S_118,
        S_128,
        S_130,
        S_132,
        S_138,
        S_144,
        S_146,
        S_148,
        S_154,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_226,
        S_228,
        S_230,
        S_240,
        S_242,
        S_244,
        S_254,
        S_256,
        S_258,
        S_264,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_305,
        S_307,
        S_309,
        S_311,
        S_317,
        S_319,
        S_321,
        S_327,
        S_329,
        S_331,
        S_337,
        S_339,
        S_341,
        S_351,
        S_353,
        S_355,
        S_361,
        S_363,
        S_365,
        S_367,
        S_373,
        S_375,
        S_377,
        S_383,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_422,
        S_424,
        S_426,
        S_436,
        S_438,
        S_440,
        S_446,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_466,
        S_468,
        S_478,
        S_480,
        S_490,
        S_492,
        S_498,
        S_500,
        S_502,
        S_508,
        S_510,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_528,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_550,
        S_552,
        S_554,
        S_556,
        S_565,
        S_571,
        S_573,
        S_575,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_587,
        S_593,
        S_595,
        S_597,
        S_607,
        S_609,
        S_611,
        S_621,
        S_623,
        S_625,
        S_635,
        S_637,
        S_639,
        S_645,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_663,
        S_665,
        S_667,
        S_669,
        S_671,
        S_673,
        S_682,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
        S_696,
        S_698,
        S_700,
        S_709,
        S_715,
        S_717,
        S_723,
        S_725,
        S_727,
        S_737,
        S_739,
        S_741,
        S_751,
        S_753,
        S_755,
        S_765,
        S_767,
        S_769,
        S_775,
        S_777,
        S_779,
        S_785,
        S_787,
        S_789,
        S_795,
        S_801,
        S_807,
        S_809,
        S_811,
        S_821,
        S_823,
        S_825,
        S_835,
        S_837,
        S_839,
        S_849,
        S_851,
        S_853,
        S_863,
        S_865,
        S_867,
        S_873,
        S_879,
        S_881,
        S_883,
        S_885,
        S_887,
        S_893,
        S_895,
        S_905,
        S_907,
        S_917,
        S_919,
        S_925,
        S_927,
        S_933,
        S_935,
        S_941,
        S_943,
        S_945,
        S_947,
        S_949,
        S_951,
        S_953,
        S_959,
        S_961,
        S_963,
        S_965,
        S_967,
        S_982,
        S_988,
        S_990,
        S_992,
        S_994,
        S_996,
        S_1002,
        S_1004,
        S_1006,
        S_1016,
        S_1018,
        S_1020,
        S_1030,
        S_1032,
        S_1034,
        S_1040,
        S_1046,
        S_1048,
        S_1050,
        S_1052,
        S_1054,
        S_1056,
        S_1058,
        S_1060,
        S_1062,
        S_1064,
        S_1073,
        S_1079,
        S_1081,
        S_1083,
        S_1093,
        S_1095,
        S_1097,
        S_1107,
        S_1109,
        S_1111,
        S_1117,
        S_1123,
        S_1125,
        S_1127,
        S_1129,
        S_1131,
        S_1133,
        S_1135,
        S_1137,
        S_1139,
        S_1141,
        S_1151,
        S_1153,
        S_1163,
        S_1165,
        S_1175,
        S_1177,
        S_1183,
        S_1185,
        S_1187,
        S_1193,
        S_1195,
        S_1201,
        S_1203,
        S_1205,
        S_1207,
        S_1209,
        S_1211,
        S_1213,
    }
    let mut c2rust_current_block_29: C2Rust_Block_29;
    c2rust_current_block_29 = C2Rust_Block_29::S_0;
    loop {
        match c2rust_current_block_29 {
            C2Rust_Block_29::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_2;
            }
            C2Rust_Block_29::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_29 = C2Rust_Block_29::S_4;
            }
            C2Rust_Block_29::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_29 = C2Rust_Block_29::S_6;
            }
            C2Rust_Block_29::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_8;
            }
            C2Rust_Block_29::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_18;
            }
            C2Rust_Block_29::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_29 = C2Rust_Block_29::S_24;
            }
            C2Rust_Block_29::S_24 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_26;
            }
            C2Rust_Block_29::S_26 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_28;
            }
            C2Rust_Block_29::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x20 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_30;
            }
            C2Rust_Block_29::S_30 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_32;
            }
            C2Rust_Block_29::S_32 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_38;
            }
            C2Rust_Block_29::S_38 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_29 = C2Rust_Block_29::S_40;
            }
            C2Rust_Block_29::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_42;
            }
            C2Rust_Block_29::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_52;
            }
            C2Rust_Block_29::S_52 => {
                _pv_0 = ebp;
                c2rust_current_block_29 = C2Rust_Block_29::S_54;
            }
            C2Rust_Block_29::S_54 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_56;
            }
            C2Rust_Block_29::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_66;
            }
            C2Rust_Block_29::S_66 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_29 = C2Rust_Block_29::S_68;
            }
            C2Rust_Block_29::S_68 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_70;
            }
            C2Rust_Block_29::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_80;
            }
            C2Rust_Block_29::S_80 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_29 = C2Rust_Block_29::S_82;
            }
            C2Rust_Block_29::S_82 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_84;
            }
            C2Rust_Block_29::S_84 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_94;
            }
            C2Rust_Block_29::S_94 => {
                _pv_3 = 0x36debc as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_96;
            }
            C2Rust_Block_29::S_96 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_98;
            }
            C2Rust_Block_29::S_98 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_108;
            }
            C2Rust_Block_29::S_108 => {
                _pv_4 = 0x1fbe81 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_110;
            }
            C2Rust_Block_29::S_110 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_112;
            }
            C2Rust_Block_29::S_112 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_118;
            }
            C2Rust_Block_29::S_118 => {
                sub_001FD6C0();
                c2rust_current_block_29 = C2Rust_Block_29::S_128;
            }
            C2Rust_Block_29::S_128 => {
                _pv_5 = 0x36dcac as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_130;
            }
            C2Rust_Block_29::S_130 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_132;
            }
            C2Rust_Block_29::S_132 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_138;
            }
            C2Rust_Block_29::S_138 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_144;
            }
            C2Rust_Block_29::S_144 => {
                _pv_6 = 0x1fbe8d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_146;
            }
            C2Rust_Block_29::S_146 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_148;
            }
            C2Rust_Block_29::S_148 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_154;
            }
            C2Rust_Block_29::S_154 => {
                sub_001FD6C0();
                c2rust_current_block_29 = C2Rust_Block_29::S_160;
            }
            C2Rust_Block_29::S_160 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_162;
            }
            C2Rust_Block_29::S_162 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x16 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_164;
            }
            C2Rust_Block_29::S_164 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_166;
            }
            C2Rust_Block_29::S_166 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_168;
            }
            C2Rust_Block_29::S_168 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_170;
            }
            C2Rust_Block_29::S_170 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_edx));
                c2rust_current_block_29 = C2Rust_Block_29::S_172;
            }
            C2Rust_Block_29::S_172 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_174;
            }
            C2Rust_Block_29::S_174 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_176;
            }
            C2Rust_Block_29::S_176 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_178;
            }
            C2Rust_Block_29::S_178 => {
                ebp = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_180;
            }
            C2Rust_Block_29::S_180 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x16 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_182;
            }
            C2Rust_Block_29::S_182 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_184;
            }
            C2Rust_Block_29::S_184 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_186;
            }
            C2Rust_Block_29::S_186 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(ebp);
                c2rust_current_block_29 = C2Rust_Block_29::S_188;
            }
            C2Rust_Block_29::S_188 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_190;
            }
            C2Rust_Block_29::S_190 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_192;
            }
            C2Rust_Block_29::S_192 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_mul(8 as uint32_t)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_194;
            }
            C2Rust_Block_29::S_194 => {
                ebp = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(2 as uint32_t))
                    .wrapping_add(3 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_196;
            }
            C2Rust_Block_29::S_196 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add(ebp.wrapping_mul(8 as uint32_t));
                c2rust_current_block_29 = C2Rust_Block_29::S_198;
            }
            C2Rust_Block_29::S_198 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_mul(8 as uint32_t)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_200;
            }
            C2Rust_Block_29::S_200 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi)
                    .wrapping_mul(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_202;
            }
            C2Rust_Block_29::S_202 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_204;
            }
            C2Rust_Block_29::S_204 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_206;
            }
            C2Rust_Block_29::S_206 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_ecx));
                c2rust_current_block_29 = C2Rust_Block_29::S_208;
            }
            C2Rust_Block_29::S_208 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_210;
            }
            C2Rust_Block_29::S_210 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_212;
            }
            C2Rust_Block_29::S_212 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_214;
            }
            C2Rust_Block_29::S_214 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_216;
            }
            C2Rust_Block_29::S_216 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_29 = C2Rust_Block_29::S_218;
            }
            C2Rust_Block_29::S_218 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_220;
            }
            C2Rust_Block_29::S_220 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_226;
            }
            C2Rust_Block_29::S_226 => {
                _pv_7 = 0x3080e as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_228;
            }
            C2Rust_Block_29::S_228 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_230;
            }
            C2Rust_Block_29::S_230 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_240;
            }
            C2Rust_Block_29::S_240 => {
                _pv_8 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_29 = C2Rust_Block_29::S_242;
            }
            C2Rust_Block_29::S_242 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_244;
            }
            C2Rust_Block_29::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_254;
            }
            C2Rust_Block_29::S_254 => {
                _pv_9 = 0x1fbed2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_256;
            }
            C2Rust_Block_29::S_256 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_258;
            }
            C2Rust_Block_29::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_264;
            }
            C2Rust_Block_29::S_264 => {
                sub_001FED80();
                c2rust_current_block_29 = C2Rust_Block_29::S_270;
            }
            C2Rust_Block_29::S_270 => {
                ebp = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_272;
            }
            C2Rust_Block_29::S_272 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_274;
            }
            C2Rust_Block_29::S_274 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_276;
            }
            C2Rust_Block_29::S_276 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_278;
            }
            C2Rust_Block_29::S_278 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_280;
            }
            C2Rust_Block_29::S_280 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_282;
            }
            C2Rust_Block_29::S_282 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_284;
            }
            C2Rust_Block_29::S_284 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_286;
            }
            C2Rust_Block_29::S_286 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_288;
            }
            C2Rust_Block_29::S_288 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_290;
            }
            C2Rust_Block_29::S_290 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_292;
            }
            C2Rust_Block_29::S_292 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_294;
            }
            C2Rust_Block_29::S_294 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_296;
            }
            C2Rust_Block_29::S_296 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_1151;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_305;
                }
            }
            C2Rust_Block_29::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_307;
            }
            C2Rust_Block_29::S_307 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_309;
            }
            C2Rust_Block_29::S_309 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_311;
            }
            C2Rust_Block_29::S_311 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x3c as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_317;
            }
            C2Rust_Block_29::S_317 => {
                _pv_10 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_29 = C2Rust_Block_29::S_319;
            }
            C2Rust_Block_29::S_319 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_321;
            }
            C2Rust_Block_29::S_321 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_327;
            }
            C2Rust_Block_29::S_327 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_329;
            }
            C2Rust_Block_29::S_329 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_331;
            }
            C2Rust_Block_29::S_331 => {
                (*__gamepkg_tls_g_ecx) = ebp.wrapping_add(0x18 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_337;
            }
            C2Rust_Block_29::S_337 => {
                _pv_11 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_29 = C2Rust_Block_29::S_339;
            }
            C2Rust_Block_29::S_339 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_341;
            }
            C2Rust_Block_29::S_341 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_351;
            }
            C2Rust_Block_29::S_351 => {
                _pv_12 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_353;
            }
            C2Rust_Block_29::S_353 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_355;
            }
            C2Rust_Block_29::S_355 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_361;
            }
            C2Rust_Block_29::S_361 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    2 as uint32_t,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_363;
            }
            C2Rust_Block_29::S_363 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1fbe60 as uint32_t,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_365;
            }
            C2Rust_Block_29::S_365 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_367;
            }
            C2Rust_Block_29::S_367 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_373;
            }
            C2Rust_Block_29::S_373 => {
                _pv_13 = 0x1fbf1c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_375;
            }
            C2Rust_Block_29::S_375 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_377;
            }
            C2Rust_Block_29::S_377 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_383;
            }
            C2Rust_Block_29::S_383 => {
                sub_001FBC90();
                c2rust_current_block_29 = C2Rust_Block_29::S_389;
            }
            C2Rust_Block_29::S_389 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_391;
            }
            C2Rust_Block_29::S_391 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_393;
            }
            C2Rust_Block_29::S_393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_395;
            }
            C2Rust_Block_29::S_395 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_397;
            }
            C2Rust_Block_29::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_399;
            }
            C2Rust_Block_29::S_399 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_401;
            }
            C2Rust_Block_29::S_401 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_403;
            }
            C2Rust_Block_29::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_405;
            }
            C2Rust_Block_29::S_405 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_407;
            }
            C2Rust_Block_29::S_407 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_409;
            }
            C2Rust_Block_29::S_409 => {
                if _fa != _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_534;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_422;
                }
            }
            C2Rust_Block_29::S_422 => {
                _pv_14 = ebp;
                c2rust_current_block_29 = C2Rust_Block_29::S_424;
            }
            C2Rust_Block_29::S_424 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_426;
            }
            C2Rust_Block_29::S_426 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_436;
            }
            C2Rust_Block_29::S_436 => {
                _pv_15 = 0x1fbf2e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_438;
            }
            C2Rust_Block_29::S_438 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_440;
            }
            C2Rust_Block_29::S_440 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_446;
            }
            C2Rust_Block_29::S_446 => {
                sub_001FEDC0();
                c2rust_current_block_29 = C2Rust_Block_29::S_452;
            }
            C2Rust_Block_29::S_452 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_454;
            }
            C2Rust_Block_29::S_454 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_456;
            }
            C2Rust_Block_29::S_456 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_458;
            }
            C2Rust_Block_29::S_458 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_460;
            }
            C2Rust_Block_29::S_460 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_466;
            }
            C2Rust_Block_29::S_466 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_468;
            }
            C2Rust_Block_29::S_468 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_478;
            }
            C2Rust_Block_29::S_478 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_480;
            }
            C2Rust_Block_29::S_480 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_490;
            }
            C2Rust_Block_29::S_490 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_492;
            }
            C2Rust_Block_29::S_492 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_498;
            }
            C2Rust_Block_29::S_498 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_500;
            }
            C2Rust_Block_29::S_500 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_502;
            }
            C2Rust_Block_29::S_502 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_508;
            }
            C2Rust_Block_29::S_508 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_510;
            }
            C2Rust_Block_29::S_510 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_516;
            }
            C2Rust_Block_29::S_516 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_518;
            }
            C2Rust_Block_29::S_518 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_520;
            }
            C2Rust_Block_29::S_520 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_522;
            }
            C2Rust_Block_29::S_522 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_524;
            }
            C2Rust_Block_29::S_524 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_526;
            }
            C2Rust_Block_29::S_526 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_528;
            }
            C2Rust_Block_29::S_528 => return,
            C2Rust_Block_29::S_534 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_536;
            }
            C2Rust_Block_29::S_536 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_29 = C2Rust_Block_29::S_538;
            }
            C2Rust_Block_29::S_538 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_540;
            }
            C2Rust_Block_29::S_540 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_542;
            }
            C2Rust_Block_29::S_542 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_544;
            }
            C2Rust_Block_29::S_544 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_546;
            }
            C2Rust_Block_29::S_546 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_548;
            }
            C2Rust_Block_29::S_548 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_550;
            }
            C2Rust_Block_29::S_550 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_552;
            }
            C2Rust_Block_29::S_552 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b860 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_554;
            }
            C2Rust_Block_29::S_554 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_edi).wrapping_mul(4 as uint32_t));
                c2rust_current_block_29 = C2Rust_Block_29::S_556;
            }
            C2Rust_Block_29::S_556 => {
                if _fa <= _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_715;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_565;
                }
            }
            C2Rust_Block_29::S_565 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_571;
            }
            C2Rust_Block_29::S_571 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_573;
            }
            C2Rust_Block_29::S_573 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_575;
            }
            C2Rust_Block_29::S_575 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_577;
            }
            C2Rust_Block_29::S_577 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_579;
            }
            C2Rust_Block_29::S_579 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_581;
            }
            C2Rust_Block_29::S_581 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_583;
            }
            C2Rust_Block_29::S_583 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_585;
            }
            C2Rust_Block_29::S_585 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_587;
            }
            C2Rust_Block_29::S_587 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_593;
            }
            C2Rust_Block_29::S_593 => {
                _pv_16 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_29 = C2Rust_Block_29::S_595;
            }
            C2Rust_Block_29::S_595 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_597;
            }
            C2Rust_Block_29::S_597 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_607;
            }
            C2Rust_Block_29::S_607 => {
                _pv_17 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_29 = C2Rust_Block_29::S_609;
            }
            C2Rust_Block_29::S_609 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_611;
            }
            C2Rust_Block_29::S_611 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_621;
            }
            C2Rust_Block_29::S_621 => {
                _pv_18 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_29 = C2Rust_Block_29::S_623;
            }
            C2Rust_Block_29::S_623 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_625;
            }
            C2Rust_Block_29::S_625 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_635;
            }
            C2Rust_Block_29::S_635 => {
                _pv_19 = 0x1fbf6f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_637;
            }
            C2Rust_Block_29::S_637 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_639;
            }
            C2Rust_Block_29::S_639 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_645;
            }
            C2Rust_Block_29::S_645 => {
                sub_001FBC90();
                c2rust_current_block_29 = C2Rust_Block_29::S_651;
            }
            C2Rust_Block_29::S_651 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b860 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_653;
            }
            C2Rust_Block_29::S_653 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_655;
            }
            C2Rust_Block_29::S_655 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_657;
            }
            C2Rust_Block_29::S_657 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_659;
            }
            C2Rust_Block_29::S_659 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_661;
            }
            C2Rust_Block_29::S_661 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_663;
            }
            C2Rust_Block_29::S_663 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_665;
            }
            C2Rust_Block_29::S_665 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_667;
            }
            C2Rust_Block_29::S_667 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_669;
            }
            C2Rust_Block_29::S_669 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_671;
            }
            C2Rust_Block_29::S_671 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_673;
            }
            C2Rust_Block_29::S_673 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_959;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_682;
                }
            }
            C2Rust_Block_29::S_682 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_684;
            }
            C2Rust_Block_29::S_684 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_29 = C2Rust_Block_29::S_686;
            }
            C2Rust_Block_29::S_686 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_688;
            }
            C2Rust_Block_29::S_688 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_690;
            }
            C2Rust_Block_29::S_690 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_692;
            }
            C2Rust_Block_29::S_692 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_694;
            }
            C2Rust_Block_29::S_694 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_696;
            }
            C2Rust_Block_29::S_696 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_698;
            }
            C2Rust_Block_29::S_698 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_700;
            }
            C2Rust_Block_29::S_700 => {
                if _fa < _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_571;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_709;
                }
            }
            C2Rust_Block_29::S_709 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_715;
            }
            C2Rust_Block_29::S_715 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_717;
            }
            C2Rust_Block_29::S_717 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_723;
            }
            C2Rust_Block_29::S_723 => {
                _pv_20 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_29 = C2Rust_Block_29::S_725;
            }
            C2Rust_Block_29::S_725 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_727;
            }
            C2Rust_Block_29::S_727 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_737;
            }
            C2Rust_Block_29::S_737 => {
                _pv_21 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_739;
            }
            C2Rust_Block_29::S_739 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_741;
            }
            C2Rust_Block_29::S_741 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_751;
            }
            C2Rust_Block_29::S_751 => {
                _pv_22 = 5 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_753;
            }
            C2Rust_Block_29::S_753 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_755;
            }
            C2Rust_Block_29::S_755 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_765;
            }
            C2Rust_Block_29::S_765 => {
                _pv_23 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_767;
            }
            C2Rust_Block_29::S_767 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_769;
            }
            C2Rust_Block_29::S_769 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_775;
            }
            C2Rust_Block_29::S_775 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b868 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_777;
            }
            C2Rust_Block_29::S_777 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b874 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_779;
            }
            C2Rust_Block_29::S_779 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_785;
            }
            C2Rust_Block_29::S_785 => {
                _pv_24 = 0x1fbfb4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_787;
            }
            C2Rust_Block_29::S_787 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_789;
            }
            C2Rust_Block_29::S_789 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_795;
            }
            C2Rust_Block_29::S_795 => {
                sub_001FBB70();
                c2rust_current_block_29 = C2Rust_Block_29::S_801;
            }
            C2Rust_Block_29::S_801 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_807;
            }
            C2Rust_Block_29::S_807 => {
                _pv_25 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_809;
            }
            C2Rust_Block_29::S_809 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_811;
            }
            C2Rust_Block_29::S_811 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_821;
            }
            C2Rust_Block_29::S_821 => {
                _pv_26 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_823;
            }
            C2Rust_Block_29::S_823 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_825;
            }
            C2Rust_Block_29::S_825 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_835;
            }
            C2Rust_Block_29::S_835 => {
                _pv_27 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_837;
            }
            C2Rust_Block_29::S_837 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_839;
            }
            C2Rust_Block_29::S_839 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_849;
            }
            C2Rust_Block_29::S_849 => {
                _pv_28 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_851;
            }
            C2Rust_Block_29::S_851 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_853;
            }
            C2Rust_Block_29::S_853 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_863;
            }
            C2Rust_Block_29::S_863 => {
                _pv_29 = 0x1fbfc5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_865;
            }
            C2Rust_Block_29::S_865 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_867;
            }
            C2Rust_Block_29::S_867 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_873;
            }
            C2Rust_Block_29::S_873 => {
                sub_001FBBF0();
                c2rust_current_block_29 = C2Rust_Block_29::S_879;
            }
            C2Rust_Block_29::S_879 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_881;
            }
            C2Rust_Block_29::S_881 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_883;
            }
            C2Rust_Block_29::S_883 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_885;
            }
            C2Rust_Block_29::S_885 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_887;
            }
            C2Rust_Block_29::S_887 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_893;
            }
            C2Rust_Block_29::S_893 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_895;
            }
            C2Rust_Block_29::S_895 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_905;
            }
            C2Rust_Block_29::S_905 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_907;
            }
            C2Rust_Block_29::S_907 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_917;
            }
            C2Rust_Block_29::S_917 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_919;
            }
            C2Rust_Block_29::S_919 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_925;
            }
            C2Rust_Block_29::S_925 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_927;
            }
            C2Rust_Block_29::S_927 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_933;
            }
            C2Rust_Block_29::S_933 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_935;
            }
            C2Rust_Block_29::S_935 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_941;
            }
            C2Rust_Block_29::S_941 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_943;
            }
            C2Rust_Block_29::S_943 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_945;
            }
            C2Rust_Block_29::S_945 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_947;
            }
            C2Rust_Block_29::S_947 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_949;
            }
            C2Rust_Block_29::S_949 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_951;
            }
            C2Rust_Block_29::S_951 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_953;
            }
            C2Rust_Block_29::S_953 => return,
            C2Rust_Block_29::S_959 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_961;
            }
            C2Rust_Block_29::S_961 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_963;
            }
            C2Rust_Block_29::S_963 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_965;
            }
            C2Rust_Block_29::S_965 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_967;
            }
            C2Rust_Block_29::S_967 => {
                if _fa == _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_1073;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_988;
                }
            }
            C2Rust_Block_29::S_982 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b860 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_988;
            }
            C2Rust_Block_29::S_988 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t),
                            )
                            .wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_990;
            }
            C2Rust_Block_29::S_990 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_sub(1);
                c2rust_current_block_29 = C2Rust_Block_29::S_992;
            }
            C2Rust_Block_29::S_992 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_994;
            }
            C2Rust_Block_29::S_994 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_996;
            }
            C2Rust_Block_29::S_996 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1002;
            }
            C2Rust_Block_29::S_1002 => {
                _pv_30 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1004;
            }
            C2Rust_Block_29::S_1004 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1006;
            }
            C2Rust_Block_29::S_1006 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1016;
            }
            C2Rust_Block_29::S_1016 => {
                _pv_31 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_29 = C2Rust_Block_29::S_1018;
            }
            C2Rust_Block_29::S_1018 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1020;
            }
            C2Rust_Block_29::S_1020 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1030;
            }
            C2Rust_Block_29::S_1030 => {
                _pv_32 = 0x1fbff3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1032;
            }
            C2Rust_Block_29::S_1032 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1034;
            }
            C2Rust_Block_29::S_1034 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1040;
            }
            C2Rust_Block_29::S_1040 => {
                sub_001FBA20();
                c2rust_current_block_29 = C2Rust_Block_29::S_1046;
            }
            C2Rust_Block_29::S_1046 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1048;
            }
            C2Rust_Block_29::S_1048 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1050;
            }
            C2Rust_Block_29::S_1050 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1052;
            }
            C2Rust_Block_29::S_1052 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1054;
            }
            C2Rust_Block_29::S_1054 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1056;
            }
            C2Rust_Block_29::S_1056 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1058;
            }
            C2Rust_Block_29::S_1058 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1060;
            }
            C2Rust_Block_29::S_1060 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1062;
            }
            C2Rust_Block_29::S_1062 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1064;
            }
            C2Rust_Block_29::S_1064 => {
                if _fa != _fb {
                    c2rust_current_block_29 = C2Rust_Block_29::S_982;
                } else {
                    c2rust_current_block_29 = C2Rust_Block_29::S_1073;
                }
            }
            C2Rust_Block_29::S_1073 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1079;
            }
            C2Rust_Block_29::S_1079 => {
                _pv_33 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1081;
            }
            C2Rust_Block_29::S_1081 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1083;
            }
            C2Rust_Block_29::S_1083 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1093;
            }
            C2Rust_Block_29::S_1093 => {
                _pv_34 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_29 = C2Rust_Block_29::S_1095;
            }
            C2Rust_Block_29::S_1095 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1097;
            }
            C2Rust_Block_29::S_1097 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1107;
            }
            C2Rust_Block_29::S_1107 => {
                _pv_35 = 0x1fc008 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1109;
            }
            C2Rust_Block_29::S_1109 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1111;
            }
            C2Rust_Block_29::S_1111 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_35,
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1117;
            }
            C2Rust_Block_29::S_1117 => {
                sub_001FBA20();
                c2rust_current_block_29 = C2Rust_Block_29::S_1123;
            }
            C2Rust_Block_29::S_1123 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1125;
            }
            C2Rust_Block_29::S_1125 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1127;
            }
            C2Rust_Block_29::S_1127 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1129;
            }
            C2Rust_Block_29::S_1129 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1131;
            }
            C2Rust_Block_29::S_1131 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1133;
            }
            C2Rust_Block_29::S_1133 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1135;
            }
            C2Rust_Block_29::S_1135 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1137;
            }
            C2Rust_Block_29::S_1137 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1139;
            }
            C2Rust_Block_29::S_1139 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b874 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1141;
            }
            C2Rust_Block_29::S_1141 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1151;
            }
            C2Rust_Block_29::S_1151 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1153;
            }
            C2Rust_Block_29::S_1153 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1163;
            }
            C2Rust_Block_29::S_1163 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1165;
            }
            C2Rust_Block_29::S_1165 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1175;
            }
            C2Rust_Block_29::S_1175 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1177;
            }
            C2Rust_Block_29::S_1177 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1183;
            }
            C2Rust_Block_29::S_1183 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1185;
            }
            C2Rust_Block_29::S_1185 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1187;
            }
            C2Rust_Block_29::S_1187 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1193;
            }
            C2Rust_Block_29::S_1193 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_29 = C2Rust_Block_29::S_1195;
            }
            C2Rust_Block_29::S_1195 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1201;
            }
            C2Rust_Block_29::S_1201 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1203;
            }
            C2Rust_Block_29::S_1203 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1205;
            }
            C2Rust_Block_29::S_1205 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1207;
            }
            C2Rust_Block_29::S_1207 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1209;
            }
            C2Rust_Block_29::S_1209 => {
                _fas = _fa as int32_t;
                c2rust_current_block_29 = C2Rust_Block_29::S_1211;
            }
            C2Rust_Block_29::S_1211 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_29 = C2Rust_Block_29::S_1213;
            }
            C2Rust_Block_29::S_1213 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC030() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x28 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x41b858 as uint32_t,
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x62 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x62 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0xfe as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x62 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC070() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    enum C2Rust_Block_31 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_35,
        S_37,
        S_39,
        S_41,
        S_43,
        S_49,
        S_51,
        S_53,
        S_59,
        S_61,
        S_63,
        S_65,
        S_67,
        S_69,
        S_71,
        S_84,
        S_86,
        S_88,
        S_98,
        S_100,
        S_102,
        S_112,
        S_114,
        S_116,
        S_126,
        S_128,
        S_130,
        S_140,
        S_142,
        S_144,
        S_150,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_174,
        S_187,
        S_189,
        S_191,
        S_201,
        S_203,
        S_205,
        S_215,
        S_217,
        S_219,
        S_229,
        S_231,
        S_233,
        S_243,
        S_245,
        S_247,
        S_253,
        S_259,
        S_261,
        S_263,
        S_265,
        S_267,
        S_277,
        S_279,
        S_281,
        S_291,
        S_293,
        S_295,
        S_305,
        S_307,
        S_309,
        S_319,
        S_321,
        S_323,
        S_333,
        S_335,
        S_337,
        S_343,
        S_353,
        S_355,
        S_357,
        S_367,
        S_369,
        S_371,
        S_381,
        S_383,
        S_385,
        S_395,
        S_397,
        S_399,
        S_409,
        S_411,
        S_413,
        S_419,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_473,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_487,
        S_489,
        S_491,
        S_493,
        S_495,
        S_497,
        S_503,
        S_505,
        S_515,
        S_517,
    }
    let mut c2rust_current_block_31: C2Rust_Block_31;
    c2rust_current_block_31 = C2Rust_Block_31::S_0;
    loop {
        match c2rust_current_block_31 {
            C2Rust_Block_31::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_2;
            }
            C2Rust_Block_31::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_4;
            }
            C2Rust_Block_31::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_18;
            }
            C2Rust_Block_31::S_18 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_20;
            }
            C2Rust_Block_31::S_20 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_22;
            }
            C2Rust_Block_31::S_22 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_24;
            }
            C2Rust_Block_31::S_24 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_26;
            }
            C2Rust_Block_31::S_26 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_515;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_35;
                }
            }
            C2Rust_Block_31::S_35 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_37;
            }
            C2Rust_Block_31::S_37 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_39;
            }
            C2Rust_Block_31::S_39 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_41;
            }
            C2Rust_Block_31::S_41 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_43;
            }
            C2Rust_Block_31::S_43 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_49;
            }
            C2Rust_Block_31::S_49 => {
                _pv = (*__gamepkg_tls_g_edi);
                c2rust_current_block_31 = C2Rust_Block_31::S_51;
            }
            C2Rust_Block_31::S_51 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_53;
            }
            C2Rust_Block_31::S_53 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_59;
            }
            C2Rust_Block_31::S_59 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_61;
            }
            C2Rust_Block_31::S_61 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_63;
            }
            C2Rust_Block_31::S_63 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_65;
            }
            C2Rust_Block_31::S_65 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_67;
            }
            C2Rust_Block_31::S_67 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_69;
            }
            C2Rust_Block_31::S_69 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_71;
            }
            C2Rust_Block_31::S_71 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_441;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_84;
                }
            }
            C2Rust_Block_31::S_84 => {
                _pv_0 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_86;
            }
            C2Rust_Block_31::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_88;
            }
            C2Rust_Block_31::S_88 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_98;
            }
            C2Rust_Block_31::S_98 => {
                _pv_1 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_100;
            }
            C2Rust_Block_31::S_100 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_102;
            }
            C2Rust_Block_31::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_112;
            }
            C2Rust_Block_31::S_112 => {
                _pv_2 = 8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_114;
            }
            C2Rust_Block_31::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_116;
            }
            C2Rust_Block_31::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_126;
            }
            C2Rust_Block_31::S_126 => {
                _pv_3 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_31 = C2Rust_Block_31::S_128;
            }
            C2Rust_Block_31::S_128 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_130;
            }
            C2Rust_Block_31::S_130 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_140;
            }
            C2Rust_Block_31::S_140 => {
                _pv_4 = 0x1fc09d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_142;
            }
            C2Rust_Block_31::S_142 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_144;
            }
            C2Rust_Block_31::S_144 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_150;
            }
            C2Rust_Block_31::S_150 => {
                sub_001FBBB0();
                c2rust_current_block_31 = C2Rust_Block_31::S_156;
            }
            C2Rust_Block_31::S_156 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_158;
            }
            C2Rust_Block_31::S_158 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_160;
            }
            C2Rust_Block_31::S_160 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_162;
            }
            C2Rust_Block_31::S_162 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_164;
            }
            C2Rust_Block_31::S_164 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_166;
            }
            C2Rust_Block_31::S_166 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_168;
            }
            C2Rust_Block_31::S_168 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_170;
            }
            C2Rust_Block_31::S_170 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_172;
            }
            C2Rust_Block_31::S_172 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_174;
            }
            C2Rust_Block_31::S_174 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_277;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_187;
                }
            }
            C2Rust_Block_31::S_187 => {
                _pv_5 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_189;
            }
            C2Rust_Block_31::S_189 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_191;
            }
            C2Rust_Block_31::S_191 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_201;
            }
            C2Rust_Block_31::S_201 => {
                _pv_6 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_203;
            }
            C2Rust_Block_31::S_203 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_205;
            }
            C2Rust_Block_31::S_205 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_215;
            }
            C2Rust_Block_31::S_215 => {
                _pv_7 = 8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_217;
            }
            C2Rust_Block_31::S_217 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_219;
            }
            C2Rust_Block_31::S_219 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_229;
            }
            C2Rust_Block_31::S_229 => {
                _pv_8 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_31 = C2Rust_Block_31::S_231;
            }
            C2Rust_Block_31::S_231 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_233;
            }
            C2Rust_Block_31::S_233 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_243;
            }
            C2Rust_Block_31::S_243 => {
                _pv_9 = 0x1fc0b0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_245;
            }
            C2Rust_Block_31::S_245 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_247;
            }
            C2Rust_Block_31::S_247 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_253;
            }
            C2Rust_Block_31::S_253 => {
                sub_001FBB40();
                c2rust_current_block_31 = C2Rust_Block_31::S_259;
            }
            C2Rust_Block_31::S_259 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_261;
            }
            C2Rust_Block_31::S_261 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_263;
            }
            C2Rust_Block_31::S_263 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_265;
            }
            C2Rust_Block_31::S_265 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_267;
            }
            C2Rust_Block_31::S_267 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_277;
            }
            C2Rust_Block_31::S_277 => {
                _pv_10 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_279;
            }
            C2Rust_Block_31::S_279 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_281;
            }
            C2Rust_Block_31::S_281 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_291;
            }
            C2Rust_Block_31::S_291 => {
                _pv_11 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_293;
            }
            C2Rust_Block_31::S_293 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_295;
            }
            C2Rust_Block_31::S_295 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_305;
            }
            C2Rust_Block_31::S_305 => {
                _pv_12 = 0xb as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_307;
            }
            C2Rust_Block_31::S_307 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_309;
            }
            C2Rust_Block_31::S_309 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_319;
            }
            C2Rust_Block_31::S_319 => {
                _pv_13 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_31 = C2Rust_Block_31::S_321;
            }
            C2Rust_Block_31::S_321 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_323;
            }
            C2Rust_Block_31::S_323 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_333;
            }
            C2Rust_Block_31::S_333 => {
                _pv_14 = 0x1fc0bf as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_335;
            }
            C2Rust_Block_31::S_335 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_337;
            }
            C2Rust_Block_31::S_337 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_343;
            }
            C2Rust_Block_31::S_343 => {
                sub_001FBB70();
                c2rust_current_block_31 = C2Rust_Block_31::S_353;
            }
            C2Rust_Block_31::S_353 => {
                _pv_15 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_355;
            }
            C2Rust_Block_31::S_355 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_357;
            }
            C2Rust_Block_31::S_357 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_367;
            }
            C2Rust_Block_31::S_367 => {
                _pv_16 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_369;
            }
            C2Rust_Block_31::S_369 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_371;
            }
            C2Rust_Block_31::S_371 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_381;
            }
            C2Rust_Block_31::S_381 => {
                _pv_17 = 0xe as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_383;
            }
            C2Rust_Block_31::S_383 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_385;
            }
            C2Rust_Block_31::S_385 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_395;
            }
            C2Rust_Block_31::S_395 => {
                _pv_18 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_31 = C2Rust_Block_31::S_397;
            }
            C2Rust_Block_31::S_397 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_399;
            }
            C2Rust_Block_31::S_399 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_409;
            }
            C2Rust_Block_31::S_409 => {
                _pv_19 = 0x1fc0cb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_411;
            }
            C2Rust_Block_31::S_411 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_413;
            }
            C2Rust_Block_31::S_413 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_419;
            }
            C2Rust_Block_31::S_419 => {
                sub_001FBB70();
                c2rust_current_block_31 = C2Rust_Block_31::S_425;
            }
            C2Rust_Block_31::S_425 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_427;
            }
            C2Rust_Block_31::S_427 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_429;
            }
            C2Rust_Block_31::S_429 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_431;
            }
            C2Rust_Block_31::S_431 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_433;
            }
            C2Rust_Block_31::S_433 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_435;
            }
            C2Rust_Block_31::S_435 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_441;
            }
            C2Rust_Block_31::S_441 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_443;
            }
            C2Rust_Block_31::S_443 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_445;
            }
            C2Rust_Block_31::S_445 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_447;
            }
            C2Rust_Block_31::S_447 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x41b858 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_449;
            }
            C2Rust_Block_31::S_449 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_451;
            }
            C2Rust_Block_31::S_451 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_453;
            }
            C2Rust_Block_31::S_453 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b878 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_455;
            }
            C2Rust_Block_31::S_455 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_457;
            }
            C2Rust_Block_31::S_457 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x61 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_459;
            }
            C2Rust_Block_31::S_459 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_461;
            }
            C2Rust_Block_31::S_461 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_463;
            }
            C2Rust_Block_31::S_463 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_31 = C2Rust_Block_31::S_465;
            }
            C2Rust_Block_31::S_465 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_467;
            }
            C2Rust_Block_31::S_467 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_469;
            }
            C2Rust_Block_31::S_469 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_471;
            }
            C2Rust_Block_31::S_471 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_473;
            }
            C2Rust_Block_31::S_473 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_475;
            }
            C2Rust_Block_31::S_475 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_477;
            }
            C2Rust_Block_31::S_477 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_479;
            }
            C2Rust_Block_31::S_479 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_481;
            }
            C2Rust_Block_31::S_481 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_483;
            }
            C2Rust_Block_31::S_483 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int & 0xfc as ::core::ffi::c_int) as uint8_t
                        as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_485;
            }
            C2Rust_Block_31::S_485 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_487;
            }
            C2Rust_Block_31::S_487 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_489;
            }
            C2Rust_Block_31::S_489 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b878 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_491;
            }
            C2Rust_Block_31::S_491 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_493;
            }
            C2Rust_Block_31::S_493 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_495;
            }
            C2Rust_Block_31::S_495 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_497;
            }
            C2Rust_Block_31::S_497 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x61 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_503;
            }
            C2Rust_Block_31::S_503 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_505;
            }
            C2Rust_Block_31::S_505 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_515;
            }
            C2Rust_Block_31::S_515 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_517;
            }
            C2Rust_Block_31::S_517 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC130() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _t: ::core::ffi::c_double = 0.;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _t_0: ::core::ffi::c_double = 0.;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _fp_value_3: ::core::ffi::c_double = 0.;
    let mut _fp_value_4: ::core::ffi::c_double = 0.;
    let mut _fp_value_5: ::core::ffi::c_double = 0.;
    let mut _fp_value_6: ::core::ffi::c_double = 0.;
    let mut _fp_value_7: ::core::ffi::c_double = 0.;
    let mut _t_1: ::core::ffi::c_double = 0.;
    let mut _fp_value_8: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_32 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_42,
        S_44,
        S_46,
        S_52,
        S_54,
        S_56,
        S_65,
        S_67,
        S_69,
        S_71,
        S_73,
        S_75,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_110,
        S_112,
        S_114,
        S_120,
        S_122,
        S_124,
        S_130,
        S_132,
        S_134,
        S_140,
        S_142,
        S_144,
        S_150,
        S_152,
        S_154,
        S_160,
        S_162,
        S_164,
        S_166,
        S_172,
        S_174,
        S_176,
        S_182,
        S_188,
        S_190,
        S_192,
        S_202,
        S_204,
        S_206,
        S_216,
        S_218,
        S_220,
        S_226,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_278,
        S_280,
        S_282,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_315,
        S_317,
        S_319,
        S_325,
        S_327,
        S_329,
        S_335,
        S_337,
        S_343,
        S_345,
        S_347,
        S_353,
        S_356,
        S_358,
        S_360,
        S_364,
        S_366,
        S_368,
        S_374,
        S_376,
        S_378,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_395,
        S_397,
        S_399,
        S_407,
        S_409,
        S_411,
        S_417,
        S_423,
        S_429,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_452,
        S_454,
        S_456,
        S_462,
        S_464,
        S_466,
        S_476,
        S_478,
        S_480,
        S_486,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_517,
        S_519,
        S_521,
        S_537,
        S_539,
        S_541,
        S_553,
        S_555,
        S_561,
        S_563,
        S_565,
        S_571,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_594,
        S_602,
        S_604,
        S_610,
        S_612,
        S_614,
        S_620,
        S_622,
        S_624,
        S_631,
        S_637,
        S_639,
        S_641,
        S_649,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_663,
        S_665,
        S_667,
        S_676,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
        S_696,
        S_698,
        S_707,
        S_715,
        S_717,
        S_719,
        S_721,
        S_723,
        S_729,
        S_731,
        S_737,
        S_746,
        S_748,
        S_750,
        S_752,
        S_754,
        S_756,
        S_758,
        S_760,
        S_762,
        S_764,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_780,
        S_782,
        S_788,
        S_790,
        S_792,
        S_794,
        S_796,
        S_798,
        S_800,
        S_806,
        S_808,
        S_810,
        S_812,
        S_814,
        S_816,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_828,
        S_837,
        S_843,
        S_845,
        S_847,
        S_849,
        S_851,
        S_860,
        S_862,
        S_864,
        S_866,
        S_868,
        S_870,
        S_885,
        S_887,
        S_889,
        S_891,
        S_893,
        S_902,
        S_904,
        S_906,
        S_908,
        S_910,
        S_912,
        S_914,
        S_916,
        S_918,
        S_924,
        S_926,
        S_932,
        S_934,
        S_936,
        S_938,
        S_940,
        S_942,
        S_944,
        S_950,
        S_952,
        S_954,
        S_956,
        S_958,
        S_960,
        S_966,
        S_968,
        S_970,
        S_976,
        S_978,
        S_984,
        S_986,
        S_988,
        S_990,
        S_992,
        S_994,
        S_996,
    }
    let mut c2rust_current_block_32: C2Rust_Block_32;
    c2rust_current_block_32 = C2Rust_Block_32::S_0;
    loop {
        match c2rust_current_block_32 {
            C2Rust_Block_32::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_2;
            }
            C2Rust_Block_32::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_4;
            }
            C2Rust_Block_32::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_18;
            }
            C2Rust_Block_32::S_18 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x5d as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_20;
            }
            C2Rust_Block_32::S_20 => {
                _fb = 0x48 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_22;
            }
            C2Rust_Block_32::S_22 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_24;
            }
            C2Rust_Block_32::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x48 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_26;
            }
            C2Rust_Block_32::S_26 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_28;
            }
            C2Rust_Block_32::S_28 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_30;
            }
            C2Rust_Block_32::S_30 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_32;
            }
            C2Rust_Block_32::S_32 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_34;
            }
            C2Rust_Block_32::S_34 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_36;
            }
            C2Rust_Block_32::S_36 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_42;
            }
            C2Rust_Block_32::S_42 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_32 = C2Rust_Block_32::S_44;
            }
            C2Rust_Block_32::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_46;
            }
            C2Rust_Block_32::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_52;
            }
            C2Rust_Block_32::S_52 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_54;
            }
            C2Rust_Block_32::S_54 => {
                (*__gamepkg_tls_g_ebx) = 1 as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_56;
            }
            C2Rust_Block_32::S_56 => {
                if _fa <= _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_435;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_65;
                }
            }
            C2Rust_Block_32::S_65 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_67;
            }
            C2Rust_Block_32::S_67 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_69;
            }
            C2Rust_Block_32::S_69 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_71;
            }
            C2Rust_Block_32::S_71 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_73;
            }
            C2Rust_Block_32::S_73 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_75;
            }
            C2Rust_Block_32::S_75 => {
                if _fa == _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_537;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_84;
                }
            }
            C2Rust_Block_32::S_84 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_86;
            }
            C2Rust_Block_32::S_86 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_88;
            }
            C2Rust_Block_32::S_88 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_90;
            }
            C2Rust_Block_32::S_90 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_92;
            }
            C2Rust_Block_32::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_94;
            }
            C2Rust_Block_32::S_94 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_96;
            }
            C2Rust_Block_32::S_96 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_98;
            }
            C2Rust_Block_32::S_98 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_100;
            }
            C2Rust_Block_32::S_100 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_102;
            }
            C2Rust_Block_32::S_102 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_104;
            }
            C2Rust_Block_32::S_104 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_110;
            }
            C2Rust_Block_32::S_110 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_32 = C2Rust_Block_32::S_112;
            }
            C2Rust_Block_32::S_112 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_114;
            }
            C2Rust_Block_32::S_114 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_120;
            }
            C2Rust_Block_32::S_120 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_122;
            }
            C2Rust_Block_32::S_122 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_124;
            }
            C2Rust_Block_32::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_130;
            }
            C2Rust_Block_32::S_130 => {
                _pv_1 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_132;
            }
            C2Rust_Block_32::S_132 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_134;
            }
            C2Rust_Block_32::S_134 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_140;
            }
            C2Rust_Block_32::S_140 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_142;
            }
            C2Rust_Block_32::S_142 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_144;
            }
            C2Rust_Block_32::S_144 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_150;
            }
            C2Rust_Block_32::S_150 => {
                _pv_2 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_32 = C2Rust_Block_32::S_152;
            }
            C2Rust_Block_32::S_152 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_154;
            }
            C2Rust_Block_32::S_154 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_160;
            }
            C2Rust_Block_32::S_160 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_162;
            }
            C2Rust_Block_32::S_162 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_164;
            }
            C2Rust_Block_32::S_164 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x2c as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_166;
            }
            C2Rust_Block_32::S_166 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_172;
            }
            C2Rust_Block_32::S_172 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_32 = C2Rust_Block_32::S_174;
            }
            C2Rust_Block_32::S_174 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_176;
            }
            C2Rust_Block_32::S_176 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_182;
            }
            C2Rust_Block_32::S_182 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(-4000 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_188;
            }
            C2Rust_Block_32::S_188 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_32 = C2Rust_Block_32::S_190;
            }
            C2Rust_Block_32::S_190 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_192;
            }
            C2Rust_Block_32::S_192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_202;
            }
            C2Rust_Block_32::S_202 => {
                _pv_5 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_32 = C2Rust_Block_32::S_204;
            }
            C2Rust_Block_32::S_204 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_206;
            }
            C2Rust_Block_32::S_206 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_216;
            }
            C2Rust_Block_32::S_216 => {
                _pv_6 = 0x1fc1b1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_218;
            }
            C2Rust_Block_32::S_218 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_220;
            }
            C2Rust_Block_32::S_220 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_226;
            }
            C2Rust_Block_32::S_226 => {
                sub_001F79B0();
                c2rust_current_block_32 = C2Rust_Block_32::S_232;
            }
            C2Rust_Block_32::S_232 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_234;
            }
            C2Rust_Block_32::S_234 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_236;
            }
            C2Rust_Block_32::S_236 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_238;
            }
            C2Rust_Block_32::S_238 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_240;
            }
            C2Rust_Block_32::S_240 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_242;
            }
            C2Rust_Block_32::S_242 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_244;
            }
            C2Rust_Block_32::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_246;
            }
            C2Rust_Block_32::S_246 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_248;
            }
            C2Rust_Block_32::S_248 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_250;
            }
            C2Rust_Block_32::S_250 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x2c as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_252;
            }
            C2Rust_Block_32::S_252 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_254;
            }
            C2Rust_Block_32::S_254 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_256;
            }
            C2Rust_Block_32::S_256 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_258;
            }
            C2Rust_Block_32::S_258 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5d as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_260;
            }
            C2Rust_Block_32::S_260 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_262;
            }
            C2Rust_Block_32::S_262 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_264;
            }
            C2Rust_Block_32::S_264 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_266;
            }
            C2Rust_Block_32::S_266 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_268;
            }
            C2Rust_Block_32::S_268 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_270;
            }
            C2Rust_Block_32::S_270 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_272;
            }
            C2Rust_Block_32::S_272 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_278;
            }
            C2Rust_Block_32::S_278 => {
                _fp_value = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_280;
            }
            C2Rust_Block_32::S_280 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_282;
            }
            C2Rust_Block_32::S_282 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_32 = C2Rust_Block_32::S_288;
            }
            C2Rust_Block_32::S_288 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_290;
            }
            C2Rust_Block_32::S_290 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_292;
            }
            C2Rust_Block_32::S_292 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b16e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b16e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b16e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_294;
            }
            C2Rust_Block_32::S_294 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_296;
            }
            C2Rust_Block_32::S_296 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_298;
            }
            C2Rust_Block_32::S_298 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_300;
            }
            C2Rust_Block_32::S_300 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_302;
            }
            C2Rust_Block_32::S_302 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_304;
            }
            C2Rust_Block_32::S_304 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_306;
            }
            C2Rust_Block_32::S_306 => {
                if _fa != _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_429;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_315;
                }
            }
            C2Rust_Block_32::S_315 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5f as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_317;
            }
            C2Rust_Block_32::S_317 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_319;
            }
            C2Rust_Block_32::S_319 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_325;
            }
            C2Rust_Block_32::S_325 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_327;
            }
            C2Rust_Block_32::S_327 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_329;
            }
            C2Rust_Block_32::S_329 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_32 = C2Rust_Block_32::S_335;
            }
            C2Rust_Block_32::S_335 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_337;
            }
            C2Rust_Block_32::S_337 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_343;
            }
            C2Rust_Block_32::S_343 => {
                _fp_value_1 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_345;
            }
            C2Rust_Block_32::S_345 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_347;
            }
            C2Rust_Block_32::S_347 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_32 = C2Rust_Block_32::S_353;
            }
            C2Rust_Block_32::S_353 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        - (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            - (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                                & 7 as ::core::ffi::c_uint) as usize],
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_356;
            }
            C2Rust_Block_32::S_356 => {
                _t = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_32 = C2Rust_Block_32::S_358;
            }
            C2Rust_Block_32::S_358 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                    + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize];
                c2rust_current_block_32 = C2Rust_Block_32::S_360;
            }
            C2Rust_Block_32::S_360 => {
                (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                    + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize] = _t;
                c2rust_current_block_32 = C2Rust_Block_32::S_364;
            }
            C2Rust_Block_32::S_364 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_366;
            }
            C2Rust_Block_32::S_366 => {
                (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                    + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                        + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize]
                        * (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                            + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int)
                            as usize]
                            * (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                                as usize],
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_368;
            }
            C2Rust_Block_32::S_368 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_374;
            }
            C2Rust_Block_32::S_374 => {
                _fp_value_2 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_376;
            }
            C2Rust_Block_32::S_376 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_378;
            }
            C2Rust_Block_32::S_378 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                c2rust_current_block_32 = C2Rust_Block_32::S_384;
            }
            C2Rust_Block_32::S_384 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_386;
            }
            C2Rust_Block_32::S_386 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                                & 7 as ::core::ffi::c_uint) as usize],
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_388;
            }
            C2Rust_Block_32::S_388 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_390;
            }
            C2Rust_Block_32::S_390 => {
                (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                    + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                        + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int) as usize]
                        + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[((*__gamepkg_tls_g_fp_top)
                            + 2 as ::core::ffi::c_int & 7 as ::core::ffi::c_int)
                            as usize]
                            + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                                as usize],
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_392;
            }
            C2Rust_Block_32::S_392 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_395;
            }
            C2Rust_Block_32::S_395 => {
                _t_0 = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_32 = C2Rust_Block_32::S_397;
            }
            C2Rust_Block_32::S_397 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize];
                c2rust_current_block_32 = C2Rust_Block_32::S_399;
            }
            C2Rust_Block_32::S_399 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = _t_0;
                c2rust_current_block_32 = C2Rust_Block_32::S_407;
            }
            C2Rust_Block_32::S_407 => {
                _pv_7 = 0x1fc24c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_409;
            }
            C2Rust_Block_32::S_409 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_411;
            }
            C2Rust_Block_32::S_411 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_417;
            }
            C2Rust_Block_32::S_417 => {
                sub_00244DF0();
                c2rust_current_block_32 = C2Rust_Block_32::S_423;
            }
            C2Rust_Block_32::S_423 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_429;
            }
            C2Rust_Block_32::S_429 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_435;
            }
            C2Rust_Block_32::S_435 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int
                    & ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_437;
            }
            C2Rust_Block_32::S_437 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_439;
            }
            C2Rust_Block_32::S_439 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_441;
            }
            C2Rust_Block_32::S_441 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_443;
            }
            C2Rust_Block_32::S_443 => {
                if _fa == _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_806;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_452;
                }
            }
            C2Rust_Block_32::S_452 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_454;
            }
            C2Rust_Block_32::S_454 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_456;
            }
            C2Rust_Block_32::S_456 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_32 = C2Rust_Block_32::S_462;
            }
            C2Rust_Block_32::S_462 => {
                _pv_8 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_32 = C2Rust_Block_32::S_464;
            }
            C2Rust_Block_32::S_464 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_466;
            }
            C2Rust_Block_32::S_466 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_476;
            }
            C2Rust_Block_32::S_476 => {
                _fp_value_3 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_478;
            }
            C2Rust_Block_32::S_478 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_480;
            }
            C2Rust_Block_32::S_480 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
                c2rust_current_block_32 = C2Rust_Block_32::S_486;
            }
            C2Rust_Block_32::S_486 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_492;
            }
            C2Rust_Block_32::S_492 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_494;
            }
            C2Rust_Block_32::S_494 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_496;
            }
            C2Rust_Block_32::S_496 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_498;
            }
            C2Rust_Block_32::S_498 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_500;
            }
            C2Rust_Block_32::S_500 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_502;
            }
            C2Rust_Block_32::S_502 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_504;
            }
            C2Rust_Block_32::S_504 => {
                if _fa != _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_553;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_517;
                }
            }
            C2Rust_Block_32::S_517 => {
                _fp_value_4 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_519;
            }
            C2Rust_Block_32::S_519 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_521;
            }
            C2Rust_Block_32::S_521 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_4;
                c2rust_current_block_32 = C2Rust_Block_32::S_577;
            }
            C2Rust_Block_32::S_537 => {
                _fp_value_5 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_539;
            }
            C2Rust_Block_32::S_539 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_541;
            }
            C2Rust_Block_32::S_541 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_5;
                c2rust_current_block_32 = C2Rust_Block_32::S_315;
            }
            C2Rust_Block_32::S_553 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_555;
            }
            C2Rust_Block_32::S_555 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_561;
            }
            C2Rust_Block_32::S_561 => {
                _fp_value_6 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_563;
            }
            C2Rust_Block_32::S_563 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_565;
            }
            C2Rust_Block_32::S_565 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_6;
                c2rust_current_block_32 = C2Rust_Block_32::S_571;
            }
            C2Rust_Block_32::S_571 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_577;
            }
            C2Rust_Block_32::S_577 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_579;
            }
            C2Rust_Block_32::S_579 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_581;
            }
            C2Rust_Block_32::S_581 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_583;
            }
            C2Rust_Block_32::S_583 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_585;
            }
            C2Rust_Block_32::S_585 => {
                if _fa != _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_602;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_594;
                }
            }
            C2Rust_Block_32::S_594 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xbf800000 as ::core::ffi::c_uint as uint32_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_631;
            }
            C2Rust_Block_32::S_602 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_604;
            }
            C2Rust_Block_32::S_604 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_610;
            }
            C2Rust_Block_32::S_610 => {
                _fp_value_7 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_32 = C2Rust_Block_32::S_612;
            }
            C2Rust_Block_32::S_612 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_614;
            }
            C2Rust_Block_32::S_614 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_7;
                c2rust_current_block_32 = C2Rust_Block_32::S_620;
            }
            C2Rust_Block_32::S_620 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_622;
            }
            C2Rust_Block_32::S_622 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        as ::core::ffi::c_float,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_624;
            }
            C2Rust_Block_32::S_624 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_631;
            }
            C2Rust_Block_32::S_631 => {
                _t_1 = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize];
                c2rust_current_block_32 = C2Rust_Block_32::S_637;
            }
            C2Rust_Block_32::S_637 => {
                _fp_value_8 = _t_1;
                c2rust_current_block_32 = C2Rust_Block_32::S_639;
            }
            C2Rust_Block_32::S_639 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_641;
            }
            C2Rust_Block_32::S_641 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_8;
                c2rust_current_block_32 = C2Rust_Block_32::S_649;
            }
            C2Rust_Block_32::S_649 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_651;
            }
            C2Rust_Block_32::S_651 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_653;
            }
            C2Rust_Block_32::S_653 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_655;
            }
            C2Rust_Block_32::S_655 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_657;
            }
            C2Rust_Block_32::S_657 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_659;
            }
            C2Rust_Block_32::S_659 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_661;
            }
            C2Rust_Block_32::S_661 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_663;
            }
            C2Rust_Block_32::S_663 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_665;
            }
            C2Rust_Block_32::S_665 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_667;
            }
            C2Rust_Block_32::S_667 => {
                if _fa != _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_684;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_676;
                }
            }
            C2Rust_Block_32::S_676 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
                c2rust_current_block_32 = C2Rust_Block_32::S_492;
            }
            C2Rust_Block_32::S_684 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_32 = C2Rust_Block_32::S_686;
            }
            C2Rust_Block_32::S_686 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_688;
            }
            C2Rust_Block_32::S_688 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_690;
            }
            C2Rust_Block_32::S_690 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 5 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_692;
            }
            C2Rust_Block_32::S_692 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_694;
            }
            C2Rust_Block_32::S_694 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_696;
            }
            C2Rust_Block_32::S_696 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_698;
            }
            C2Rust_Block_32::S_698 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_32 = C2Rust_Block_32::S_715;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_707;
                }
            }
            C2Rust_Block_32::S_707 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_32 = C2Rust_Block_32::S_492;
            }
            C2Rust_Block_32::S_715 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_717;
            }
            C2Rust_Block_32::S_717 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_719;
            }
            C2Rust_Block_32::S_719 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_721;
            }
            C2Rust_Block_32::S_721 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_723;
            }
            C2Rust_Block_32::S_723 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_32 = C2Rust_Block_32::S_729;
            }
            C2Rust_Block_32::S_729 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_731;
            }
            C2Rust_Block_32::S_731 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_737;
            }
            C2Rust_Block_32::S_737 => {
                if _fa == _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_966;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_746;
                }
            }
            C2Rust_Block_32::S_746 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_748;
            }
            C2Rust_Block_32::S_748 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_750;
            }
            C2Rust_Block_32::S_750 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_752;
            }
            C2Rust_Block_32::S_752 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_754;
            }
            C2Rust_Block_32::S_754 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_756;
            }
            C2Rust_Block_32::S_756 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_758;
            }
            C2Rust_Block_32::S_758 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_760;
            }
            C2Rust_Block_32::S_760 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_762;
            }
            C2Rust_Block_32::S_762 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_764;
            }
            C2Rust_Block_32::S_764 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_766;
            }
            C2Rust_Block_32::S_766 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_768;
            }
            C2Rust_Block_32::S_768 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_770;
            }
            C2Rust_Block_32::S_770 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_772;
            }
            C2Rust_Block_32::S_772 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_774;
            }
            C2Rust_Block_32::S_774 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_780;
            }
            C2Rust_Block_32::S_780 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_782;
            }
            C2Rust_Block_32::S_782 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_788;
            }
            C2Rust_Block_32::S_788 => {
                _fb = 0x48 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_790;
            }
            C2Rust_Block_32::S_790 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_792;
            }
            C2Rust_Block_32::S_792 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x48 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_794;
            }
            C2Rust_Block_32::S_794 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_796;
            }
            C2Rust_Block_32::S_796 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_798;
            }
            C2Rust_Block_32::S_798 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_800;
            }
            C2Rust_Block_32::S_800 => return,
            C2Rust_Block_32::S_806 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_808;
            }
            C2Rust_Block_32::S_808 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_810;
            }
            C2Rust_Block_32::S_810 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_812;
            }
            C2Rust_Block_32::S_812 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_814;
            }
            C2Rust_Block_32::S_814 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_816;
            }
            C2Rust_Block_32::S_816 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_818;
            }
            C2Rust_Block_32::S_818 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_820;
            }
            C2Rust_Block_32::S_820 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_822;
            }
            C2Rust_Block_32::S_822 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_824;
            }
            C2Rust_Block_32::S_824 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_826;
            }
            C2Rust_Block_32::S_826 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_828;
            }
            C2Rust_Block_32::S_828 => {
                if _fa == _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_902;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_837;
                }
            }
            C2Rust_Block_32::S_837 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_843;
            }
            C2Rust_Block_32::S_843 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_845;
            }
            C2Rust_Block_32::S_845 => {
                _fb = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x60 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_847;
            }
            C2Rust_Block_32::S_847 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_849;
            }
            C2Rust_Block_32::S_849 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_851;
            }
            C2Rust_Block_32::S_851 => {
                if _fa < _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_885;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_860;
                }
            }
            C2Rust_Block_32::S_860 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_862;
            }
            C2Rust_Block_32::S_862 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_864;
            }
            C2Rust_Block_32::S_864 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_866;
            }
            C2Rust_Block_32::S_866 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_868;
            }
            C2Rust_Block_32::S_868 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_870;
            }
            C2Rust_Block_32::S_870 => {
                if _fa != _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_843;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_902;
                }
            }
            C2Rust_Block_32::S_885 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_887;
            }
            C2Rust_Block_32::S_887 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_889;
            }
            C2Rust_Block_32::S_889 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_891;
            }
            C2Rust_Block_32::S_891 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_893;
            }
            C2Rust_Block_32::S_893 => {
                if _fa != _fb {
                    c2rust_current_block_32 = C2Rust_Block_32::S_950;
                } else {
                    c2rust_current_block_32 = C2Rust_Block_32::S_902;
                }
            }
            C2Rust_Block_32::S_902 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_904;
            }
            C2Rust_Block_32::S_904 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_906;
            }
            C2Rust_Block_32::S_906 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x41b850 as uint32_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_908;
            }
            C2Rust_Block_32::S_908 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_910;
            }
            C2Rust_Block_32::S_910 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_912;
            }
            C2Rust_Block_32::S_912 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_914;
            }
            C2Rust_Block_32::S_914 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_916;
            }
            C2Rust_Block_32::S_916 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_918;
            }
            C2Rust_Block_32::S_918 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_924;
            }
            C2Rust_Block_32::S_924 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_926;
            }
            C2Rust_Block_32::S_926 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_932;
            }
            C2Rust_Block_32::S_932 => {
                _fb = 0x48 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_934;
            }
            C2Rust_Block_32::S_934 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_936;
            }
            C2Rust_Block_32::S_936 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x48 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_938;
            }
            C2Rust_Block_32::S_938 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_940;
            }
            C2Rust_Block_32::S_940 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_942;
            }
            C2Rust_Block_32::S_942 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_944;
            }
            C2Rust_Block_32::S_944 => return,
            C2Rust_Block_32::S_950 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_952;
            }
            C2Rust_Block_32::S_952 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_954;
            }
            C2Rust_Block_32::S_954 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_956;
            }
            C2Rust_Block_32::S_956 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_958;
            }
            C2Rust_Block_32::S_958 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_960;
            }
            C2Rust_Block_32::S_960 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_966;
            }
            C2Rust_Block_32::S_966 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t,
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_968;
            }
            C2Rust_Block_32::S_968 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_970;
            }
            C2Rust_Block_32::S_970 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_976;
            }
            C2Rust_Block_32::S_976 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_32 = C2Rust_Block_32::S_978;
            }
            C2Rust_Block_32::S_978 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_984;
            }
            C2Rust_Block_32::S_984 => {
                _fb = 0x48 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_986;
            }
            C2Rust_Block_32::S_986 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_988;
            }
            C2Rust_Block_32::S_988 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x48 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_990;
            }
            C2Rust_Block_32::S_990 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_992;
            }
            C2Rust_Block_32::S_992 => {
                _fas = _fa as int32_t;
                c2rust_current_block_32 = C2Rust_Block_32::S_994;
            }
            C2Rust_Block_32::S_994 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_32 = C2Rust_Block_32::S_996;
            }
            C2Rust_Block_32::S_996 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC3A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    let mut _pv_36: uint32_t = 0;
    let mut _pv_37: uint32_t = 0;
    let mut _pv_38: uint32_t = 0;
    let mut _pv_39: uint32_t = 0;
    let mut _pv_40: uint32_t = 0;
    let mut _pv_41: uint32_t = 0;
    let mut _pv_42: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _pv_43: uint32_t = 0;
    let mut _pv_44: uint32_t = 0;
    let mut _pv_45: uint32_t = 0;
    let mut _pv_46: uint32_t = 0;
    let mut _pv_47: uint32_t = 0;
    let mut _pv_48: uint32_t = 0;
    let mut _pv_49: uint32_t = 0;
    let mut _pv_50: uint32_t = 0;
    let mut _pv_51: uint32_t = 0;
    let mut _pv_52: uint32_t = 0;
    let mut _pv_53: uint32_t = 0;
    let mut _pv_54: uint32_t = 0;
    let mut _pv_55: uint32_t = 0;
    let mut _pv_56: uint32_t = 0;
    let mut _pv_57: uint32_t = 0;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _pv_58: uint32_t = 0;
    let mut _pv_59: uint32_t = 0;
    let mut _pv_60: uint32_t = 0;
    let mut _pv_61: uint32_t = 0;
    let mut _pv_62: uint32_t = 0;
    let mut _pv_63: uint32_t = 0;
    let mut _pv_64: uint32_t = 0;
    let mut _pv_65: uint32_t = 0;
    let mut _pv_66: uint32_t = 0;
    let mut _pv_67: uint32_t = 0;
    let mut _pv_68: uint32_t = 0;
    let mut _pv_69: uint32_t = 0;
    let mut _pv_70: uint32_t = 0;
    let mut _pv_71: uint32_t = 0;
    let mut _pv_72: uint32_t = 0;
    let mut _pv_73: uint32_t = 0;
    let mut _pv_74: uint32_t = 0;
    let mut _pv_75: uint32_t = 0;
    let mut _pv_76: uint32_t = 0;
    let mut _pv_77: uint32_t = 0;
    let mut _pv_78: uint32_t = 0;
    let mut _pv_79: uint32_t = 0;
    let mut _pv_80: uint32_t = 0;
    let mut _pv_81: uint32_t = 0;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _pv_82: uint32_t = 0;
    let mut _pv_83: uint32_t = 0;
    let mut _pv_84: uint32_t = 0;
    let mut _pv_85: uint32_t = 0;
    let mut _pv_86: uint32_t = 0;
    let mut _pv_87: uint32_t = 0;
    let mut _pv_88: uint32_t = 0;
    let mut _pv_89: uint32_t = 0;
    let mut _pv_90: uint32_t = 0;
    let mut _pv_91: uint32_t = 0;
    let mut _pv_92: uint32_t = 0;
    let mut _pv_93: uint32_t = 0;
    let mut _pv_94: uint32_t = 0;
    let mut _pv_95: uint32_t = 0;
    enum C2Rust_Block_33 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_40,
        S_42,
        S_44,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_62,
        S_64,
        S_77,
        S_79,
        S_81,
        S_87,
        S_89,
        S_91,
        S_93,
        S_95,
        S_97,
        S_99,
        S_112,
        S_114,
        S_116,
        S_128,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_190,
        S_192,
        S_194,
        S_200,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_229,
        S_231,
        S_233,
        S_235,
        S_237,
        S_246,
        S_248,
        S_260,
        S_262,
        S_264,
        S_274,
        S_276,
        S_278,
        S_288,
        S_290,
        S_292,
        S_302,
        S_304,
        S_306,
        S_316,
        S_318,
        S_320,
        S_326,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_352,
        S_354,
        S_356,
        S_366,
        S_368,
        S_370,
        S_380,
        S_382,
        S_384,
        S_394,
        S_396,
        S_398,
        S_408,
        S_410,
        S_412,
        S_418,
        S_428,
        S_430,
        S_432,
        S_442,
        S_444,
        S_446,
        S_456,
        S_458,
        S_460,
        S_470,
        S_472,
        S_474,
        S_484,
        S_486,
        S_488,
        S_494,
        S_500,
        S_506,
        S_508,
        S_510,
        S_520,
        S_522,
        S_524,
        S_534,
        S_536,
        S_538,
        S_548,
        S_550,
        S_552,
        S_562,
        S_564,
        S_566,
        S_572,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
        S_608,
        S_617,
        S_619,
        S_621,
        S_623,
        S_625,
        S_634,
        S_636,
        S_642,
        S_644,
        S_646,
        S_652,
        S_654,
        S_656,
        S_658,
        S_660,
        S_666,
        S_668,
        S_670,
        S_680,
        S_682,
        S_684,
        S_690,
        S_696,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_730,
        S_736,
        S_738,
        S_740,
        S_746,
        S_755,
        S_761,
        S_763,
        S_769,
        S_771,
        S_773,
        S_779,
        S_785,
        S_787,
        S_789,
        S_791,
        S_793,
        S_795,
        S_797,
        S_799,
        S_801,
        S_803,
        S_805,
        S_807,
        S_809,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_835,
        S_841,
        S_843,
        S_845,
        S_847,
        S_849,
        S_851,
        S_853,
        S_855,
        S_857,
        S_859,
        S_868,
        S_870,
        S_872,
        S_884,
        S_886,
        S_888,
        S_894,
        S_900,
        S_906,
        S_908,
        S_916,
        S_918,
        S_920,
        S_922,
        S_924,
        S_933,
        S_939,
        S_941,
        S_943,
        S_953,
        S_955,
        S_957,
        S_967,
        S_969,
        S_971,
        S_981,
        S_983,
        S_985,
        S_995,
        S_997,
        S_999,
        S_1005,
        S_1011,
        S_1013,
        S_1015,
        S_1017,
        S_1019,
        S_1021,
        S_1023,
        S_1025,
        S_1027,
        S_1029,
        S_1031,
        S_1033,
        S_1042,
        S_1048,
        S_1050,
        S_1052,
        S_1062,
        S_1064,
        S_1066,
        S_1076,
        S_1078,
        S_1080,
        S_1090,
        S_1092,
        S_1094,
        S_1104,
        S_1106,
        S_1108,
        S_1114,
        S_1120,
        S_1126,
        S_1128,
        S_1130,
        S_1140,
        S_1142,
        S_1144,
        S_1154,
        S_1156,
        S_1158,
        S_1168,
        S_1170,
        S_1172,
        S_1182,
        S_1184,
        S_1186,
        S_1192,
        S_1198,
        S_1200,
        S_1202,
        S_1204,
        S_1206,
        S_1208,
        S_1210,
        S_1216,
        S_1218,
        S_1220,
        S_1226,
        S_1228,
        S_1230,
        S_1236,
        S_1238,
        S_1240,
        S_1250,
        S_1252,
        S_1254,
        S_1264,
        S_1266,
        S_1268,
        S_1278,
        S_1280,
        S_1282,
        S_1288,
        S_1294,
        S_1296,
        S_1298,
        S_1300,
        S_1302,
        S_1304,
        S_1306,
        S_1308,
        S_1310,
        S_1312,
        S_1318,
        S_1320,
        S_1322,
        S_1332,
        S_1334,
        S_1336,
        S_1346,
        S_1348,
        S_1350,
        S_1360,
        S_1362,
        S_1364,
        S_1374,
        S_1376,
        S_1378,
        S_1384,
        S_1390,
        S_1392,
        S_1394,
        S_1396,
        S_1398,
        S_1400,
        S_1402,
        S_1404,
        S_1406,
        S_1408,
        S_1410,
        S_1419,
        S_1425,
        S_1427,
        S_1429,
        S_1439,
        S_1441,
        S_1443,
        S_1453,
        S_1455,
        S_1457,
        S_1467,
        S_1469,
        S_1471,
        S_1481,
        S_1483,
        S_1485,
        S_1491,
        S_1497,
        S_1499,
        S_1501,
        S_1503,
        S_1505,
        S_1511,
        S_1513,
        S_1519,
        S_1521,
        S_1523,
        S_1533,
        S_1535,
        S_1537,
        S_1543,
        S_1545,
        S_1551,
        S_1553,
        S_1555,
        S_1565,
        S_1567,
        S_1569,
        S_1579,
        S_1581,
        S_1583,
        S_1593,
        S_1595,
        S_1597,
        S_1603,
        S_1609,
        S_1615,
        S_1617,
        S_1619,
        S_1629,
        S_1631,
        S_1633,
        S_1643,
        S_1645,
        S_1647,
        S_1657,
        S_1659,
        S_1661,
        S_1671,
        S_1673,
        S_1675,
        S_1681,
        S_1687,
        S_1693,
        S_1695,
        S_1697,
        S_1707,
        S_1709,
        S_1711,
        S_1721,
        S_1723,
        S_1725,
        S_1735,
        S_1737,
        S_1739,
        S_1749,
        S_1751,
        S_1753,
        S_1759,
        S_1765,
        S_1771,
        S_1773,
        S_1775,
        S_1785,
        S_1787,
        S_1789,
        S_1799,
        S_1801,
        S_1803,
        S_1813,
        S_1815,
        S_1817,
        S_1827,
        S_1829,
        S_1831,
        S_1837,
        S_1843,
        S_1845,
        S_1847,
        S_1849,
        S_1851,
        S_1853,
        S_1859,
        S_1861,
        S_1863,
        S_1873,
        S_1875,
        S_1877,
        S_1887,
        S_1889,
        S_1891,
        S_1901,
        S_1903,
        S_1905,
        S_1915,
        S_1917,
        S_1919,
        S_1925,
        S_1931,
        S_1933,
        S_1935,
        S_1937,
        S_1939,
        S_1941,
        S_1943,
        S_1949,
        S_1951,
        S_1953,
        S_1959,
        S_1961,
        S_1963,
        S_1969,
        S_1971,
        S_1973,
        S_1983,
        S_1985,
        S_1987,
        S_1997,
        S_1999,
        S_2001,
        S_2011,
        S_2013,
        S_2015,
        S_2021,
        S_2031,
        S_2033,
        S_2035,
        S_2045,
        S_2047,
        S_2049,
        S_2059,
        S_2061,
        S_2063,
        S_2073,
        S_2075,
        S_2077,
        S_2087,
        S_2089,
        S_2091,
        S_2097,
        S_2103,
        S_2109,
        S_2111,
        S_2113,
        S_2123,
        S_2125,
        S_2127,
        S_2137,
        S_2139,
        S_2141,
        S_2151,
        S_2153,
        S_2155,
        S_2165,
        S_2167,
        S_2169,
        S_2175,
        S_2181,
        S_2183,
        S_2185,
        S_2187,
        S_2189,
        S_2195,
        S_2197,
        S_2199,
        S_2201,
        S_2203,
        S_2205,
        S_2207,
        S_2209,
        S_2211,
        S_2213,
        S_2215,
        S_2217,
        S_2219,
        S_2221,
        S_2234,
        S_2236,
        S_2250,
        S_2252,
        S_2266,
        S_2268,
        S_2274,
        S_2276,
        S_2278,
        S_2280,
        S_2282,
        S_2284,
        S_2286,
    }
    let mut c2rust_current_block_33: C2Rust_Block_33;
    c2rust_current_block_33 = C2Rust_Block_33::S_0;
    loop {
        match c2rust_current_block_33 {
            C2Rust_Block_33::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2;
            }
            C2Rust_Block_33::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_33 = C2Rust_Block_33::S_4;
            }
            C2Rust_Block_33::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_6;
            }
            C2Rust_Block_33::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_8;
            }
            C2Rust_Block_33::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_18;
            }
            C2Rust_Block_33::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_33 = C2Rust_Block_33::S_24;
            }
            C2Rust_Block_33::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_26;
            }
            C2Rust_Block_33::S_26 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_28;
            }
            C2Rust_Block_33::S_28 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_30;
            }
            C2Rust_Block_33::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0xc as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_32;
            }
            C2Rust_Block_33::S_32 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_34;
            }
            C2Rust_Block_33::S_34 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_40;
            }
            C2Rust_Block_33::S_40 => {
                _pv = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_42;
            }
            C2Rust_Block_33::S_42 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_44;
            }
            C2Rust_Block_33::S_44 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_50;
            }
            C2Rust_Block_33::S_50 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_52;
            }
            C2Rust_Block_33::S_52 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_54;
            }
            C2Rust_Block_33::S_54 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_56;
            }
            C2Rust_Block_33::S_56 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_58;
            }
            C2Rust_Block_33::S_58 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_60;
            }
            C2Rust_Block_33::S_60 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_62;
            }
            C2Rust_Block_33::S_62 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_64;
            }
            C2Rust_Block_33::S_64 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2266;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_77;
                }
            }
            C2Rust_Block_33::S_77 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_33 = C2Rust_Block_33::S_79;
            }
            C2Rust_Block_33::S_79 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_81;
            }
            C2Rust_Block_33::S_81 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_87;
            }
            C2Rust_Block_33::S_87 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_89;
            }
            C2Rust_Block_33::S_89 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_91;
            }
            C2Rust_Block_33::S_91 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_93;
            }
            C2Rust_Block_33::S_93 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_95;
            }
            C2Rust_Block_33::S_95 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_97;
            }
            C2Rust_Block_33::S_97 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_99;
            }
            C2Rust_Block_33::S_99 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2250;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_112;
                }
            }
            C2Rust_Block_33::S_112 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_114;
            }
            C2Rust_Block_33::S_114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_116;
            }
            C2Rust_Block_33::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_128;
            }
            C2Rust_Block_33::S_128 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_130;
            }
            C2Rust_Block_33::S_130 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_132;
            }
            C2Rust_Block_33::S_132 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b874 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_134;
            }
            C2Rust_Block_33::S_134 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_136;
            }
            C2Rust_Block_33::S_136 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_138;
            }
            C2Rust_Block_33::S_138 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_140;
            }
            C2Rust_Block_33::S_140 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_142;
            }
            C2Rust_Block_33::S_142 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_144;
            }
            C2Rust_Block_33::S_144 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_33 = C2Rust_Block_33::S_146;
            }
            C2Rust_Block_33::S_146 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_148;
            }
            C2Rust_Block_33::S_148 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_150;
            }
            C2Rust_Block_33::S_150 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_152;
            }
            C2Rust_Block_33::S_152 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_154;
            }
            C2Rust_Block_33::S_154 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_156;
            }
            C2Rust_Block_33::S_156 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_158;
            }
            C2Rust_Block_33::S_158 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_33 = C2Rust_Block_33::S_916;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_167;
                }
            }
            C2Rust_Block_33::S_167 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_169;
            }
            C2Rust_Block_33::S_169 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x10 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_171;
            }
            C2Rust_Block_33::S_171 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_173;
            }
            C2Rust_Block_33::S_173 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_175;
            }
            C2Rust_Block_33::S_175 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_177;
            }
            C2Rust_Block_33::S_177 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_212;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_190;
                }
            }
            C2Rust_Block_33::S_190 => {
                _pv_2 = 0x1fc3ff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_192;
            }
            C2Rust_Block_33::S_192 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_194;
            }
            C2Rust_Block_33::S_194 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_200;
            }
            C2Rust_Block_33::S_200 => {
                sub_001FC070();
                c2rust_current_block_33 = C2Rust_Block_33::S_598;
            }
            C2Rust_Block_33::S_212 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_214;
            }
            C2Rust_Block_33::S_214 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_216;
            }
            C2Rust_Block_33::S_216 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_218;
            }
            C2Rust_Block_33::S_218 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_220;
            }
            C2Rust_Block_33::S_220 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_598;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_229;
                }
            }
            C2Rust_Block_33::S_229 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_231;
            }
            C2Rust_Block_33::S_231 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_233;
            }
            C2Rust_Block_33::S_233 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_235;
            }
            C2Rust_Block_33::S_235 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_237;
            }
            C2Rust_Block_33::S_237 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_260;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_246;
                }
            }
            C2Rust_Block_33::S_246 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_248;
            }
            C2Rust_Block_33::S_248 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_352;
            }
            C2Rust_Block_33::S_260 => {
                _pv_3 = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_262;
            }
            C2Rust_Block_33::S_262 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_264;
            }
            C2Rust_Block_33::S_264 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_274;
            }
            C2Rust_Block_33::S_274 => {
                _pv_4 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_276;
            }
            C2Rust_Block_33::S_276 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_278;
            }
            C2Rust_Block_33::S_278 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_288;
            }
            C2Rust_Block_33::S_288 => {
                _pv_5 = 9 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_290;
            }
            C2Rust_Block_33::S_290 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_292;
            }
            C2Rust_Block_33::S_292 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_302;
            }
            C2Rust_Block_33::S_302 => {
                _pv_6 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_304;
            }
            C2Rust_Block_33::S_304 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_306;
            }
            C2Rust_Block_33::S_306 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_316;
            }
            C2Rust_Block_33::S_316 => {
                _pv_7 = 0x1fc41c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_318;
            }
            C2Rust_Block_33::S_318 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_320;
            }
            C2Rust_Block_33::S_320 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_326;
            }
            C2Rust_Block_33::S_326 => {
                sub_001FBBB0();
                c2rust_current_block_33 = C2Rust_Block_33::S_332;
            }
            C2Rust_Block_33::S_332 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_334;
            }
            C2Rust_Block_33::S_334 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_336;
            }
            C2Rust_Block_33::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_338;
            }
            C2Rust_Block_33::S_338 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_340;
            }
            C2Rust_Block_33::S_340 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_342;
            }
            C2Rust_Block_33::S_342 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_352;
            }
            C2Rust_Block_33::S_352 => {
                _pv_8 = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_354;
            }
            C2Rust_Block_33::S_354 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_356;
            }
            C2Rust_Block_33::S_356 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_366;
            }
            C2Rust_Block_33::S_366 => {
                _pv_9 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_368;
            }
            C2Rust_Block_33::S_368 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_370;
            }
            C2Rust_Block_33::S_370 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_380;
            }
            C2Rust_Block_33::S_380 => {
                _pv_10 = 8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_382;
            }
            C2Rust_Block_33::S_382 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_384;
            }
            C2Rust_Block_33::S_384 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_394;
            }
            C2Rust_Block_33::S_394 => {
                _pv_11 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_396;
            }
            C2Rust_Block_33::S_396 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_398;
            }
            C2Rust_Block_33::S_398 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_408;
            }
            C2Rust_Block_33::S_408 => {
                _pv_12 = 0x1fc42d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_410;
            }
            C2Rust_Block_33::S_410 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_412;
            }
            C2Rust_Block_33::S_412 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_418;
            }
            C2Rust_Block_33::S_418 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_428;
            }
            C2Rust_Block_33::S_428 => {
                _pv_13 = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_430;
            }
            C2Rust_Block_33::S_430 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_432;
            }
            C2Rust_Block_33::S_432 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_442;
            }
            C2Rust_Block_33::S_442 => {
                _pv_14 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_444;
            }
            C2Rust_Block_33::S_444 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_446;
            }
            C2Rust_Block_33::S_446 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_456;
            }
            C2Rust_Block_33::S_456 => {
                _pv_15 = 0xb as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_458;
            }
            C2Rust_Block_33::S_458 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_460;
            }
            C2Rust_Block_33::S_460 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_470;
            }
            C2Rust_Block_33::S_470 => {
                _pv_16 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_472;
            }
            C2Rust_Block_33::S_472 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_474;
            }
            C2Rust_Block_33::S_474 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_484;
            }
            C2Rust_Block_33::S_484 => {
                _pv_17 = 0x1fc438 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_486;
            }
            C2Rust_Block_33::S_486 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_488;
            }
            C2Rust_Block_33::S_488 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_494;
            }
            C2Rust_Block_33::S_494 => {
                sub_001FBB70();
                c2rust_current_block_33 = C2Rust_Block_33::S_500;
            }
            C2Rust_Block_33::S_500 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_506;
            }
            C2Rust_Block_33::S_506 => {
                _pv_18 = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_508;
            }
            C2Rust_Block_33::S_508 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_510;
            }
            C2Rust_Block_33::S_510 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_520;
            }
            C2Rust_Block_33::S_520 => {
                _pv_19 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_522;
            }
            C2Rust_Block_33::S_522 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_524;
            }
            C2Rust_Block_33::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_534;
            }
            C2Rust_Block_33::S_534 => {
                _pv_20 = 0xe as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_536;
            }
            C2Rust_Block_33::S_536 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_538;
            }
            C2Rust_Block_33::S_538 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_548;
            }
            C2Rust_Block_33::S_548 => {
                _pv_21 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_550;
            }
            C2Rust_Block_33::S_550 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_552;
            }
            C2Rust_Block_33::S_552 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_562;
            }
            C2Rust_Block_33::S_562 => {
                _pv_22 = 0x1fc446 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_564;
            }
            C2Rust_Block_33::S_564 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_566;
            }
            C2Rust_Block_33::S_566 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_572;
            }
            C2Rust_Block_33::S_572 => {
                sub_001FBB70();
                c2rust_current_block_33 = C2Rust_Block_33::S_578;
            }
            C2Rust_Block_33::S_578 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_580;
            }
            C2Rust_Block_33::S_580 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_582;
            }
            C2Rust_Block_33::S_582 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_584;
            }
            C2Rust_Block_33::S_584 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_586;
            }
            C2Rust_Block_33::S_586 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_588;
            }
            C2Rust_Block_33::S_588 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_590;
            }
            C2Rust_Block_33::S_590 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_592;
            }
            C2Rust_Block_33::S_592 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_598;
            }
            C2Rust_Block_33::S_598 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_600;
            }
            C2Rust_Block_33::S_600 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_602;
            }
            C2Rust_Block_33::S_602 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_604;
            }
            C2Rust_Block_33::S_604 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_606;
            }
            C2Rust_Block_33::S_606 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_608;
            }
            C2Rust_Block_33::S_608 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2195;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_617;
                }
            }
            C2Rust_Block_33::S_617 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_619;
            }
            C2Rust_Block_33::S_619 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_621;
            }
            C2Rust_Block_33::S_621 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_623;
            }
            C2Rust_Block_33::S_623 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_625;
            }
            C2Rust_Block_33::S_625 => {
                if _fa != _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2195;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_634;
                }
            }
            C2Rust_Block_33::S_634 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_636;
            }
            C2Rust_Block_33::S_636 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_642;
            }
            C2Rust_Block_33::S_642 => {
                _pv_23 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_33 = C2Rust_Block_33::S_644;
            }
            C2Rust_Block_33::S_644 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_646;
            }
            C2Rust_Block_33::S_646 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_652;
            }
            C2Rust_Block_33::S_652 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_654;
            }
            C2Rust_Block_33::S_654 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_656;
            }
            C2Rust_Block_33::S_656 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_658;
            }
            C2Rust_Block_33::S_658 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_660;
            }
            C2Rust_Block_33::S_660 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_666;
            }
            C2Rust_Block_33::S_666 => {
                _pv_24 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_668;
            }
            C2Rust_Block_33::S_668 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_670;
            }
            C2Rust_Block_33::S_670 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_680;
            }
            C2Rust_Block_33::S_680 => {
                _pv_25 = 0x1fc478 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_682;
            }
            C2Rust_Block_33::S_682 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_684;
            }
            C2Rust_Block_33::S_684 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_690;
            }
            C2Rust_Block_33::S_690 => {
                sub_001FA7D0();
                c2rust_current_block_33 = C2Rust_Block_33::S_696;
            }
            C2Rust_Block_33::S_696 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_698;
            }
            C2Rust_Block_33::S_698 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_700;
            }
            C2Rust_Block_33::S_700 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_702;
            }
            C2Rust_Block_33::S_702 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_704;
            }
            C2Rust_Block_33::S_704 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_706;
            }
            C2Rust_Block_33::S_706 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edx));
                c2rust_current_block_33 = C2Rust_Block_33::S_708;
            }
            C2Rust_Block_33::S_708 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_710;
            }
            C2Rust_Block_33::S_710 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_712;
            }
            C2Rust_Block_33::S_712 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_714;
            }
            C2Rust_Block_33::S_714 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_716;
            }
            C2Rust_Block_33::S_716 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_718;
            }
            C2Rust_Block_33::S_718 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_720;
            }
            C2Rust_Block_33::S_720 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_722;
            }
            C2Rust_Block_33::S_722 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_724;
            }
            C2Rust_Block_33::S_724 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_726;
            }
            C2Rust_Block_33::S_726 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_728;
            }
            C2Rust_Block_33::S_728 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_730;
            }
            C2Rust_Block_33::S_730 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_736;
            }
            C2Rust_Block_33::S_736 => {
                _fp_value = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_33 = C2Rust_Block_33::S_738;
            }
            C2Rust_Block_33::S_738 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_740;
            }
            C2Rust_Block_33::S_740 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_33 = C2Rust_Block_33::S_746;
            }
            C2Rust_Block_33::S_746 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_33 = C2Rust_Block_33::S_761;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_755;
                }
            }
            C2Rust_Block_33::S_755 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_761;
            }
            C2Rust_Block_33::S_761 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t)
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_763;
            }
            C2Rust_Block_33::S_763 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_769;
            }
            C2Rust_Block_33::S_769 => {
                _pv_26 = 0x1fc4a7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_771;
            }
            C2Rust_Block_33::S_771 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_773;
            }
            C2Rust_Block_33::S_773 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_779;
            }
            C2Rust_Block_33::S_779 => {
                sub_00244DF0();
                c2rust_current_block_33 = C2Rust_Block_33::S_785;
            }
            C2Rust_Block_33::S_785 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_787;
            }
            C2Rust_Block_33::S_787 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_789;
            }
            C2Rust_Block_33::S_789 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_791;
            }
            C2Rust_Block_33::S_791 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_33 = C2Rust_Block_33::S_793;
            }
            C2Rust_Block_33::S_793 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_795;
            }
            C2Rust_Block_33::S_795 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_797;
            }
            C2Rust_Block_33::S_797 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_33 = C2Rust_Block_33::S_799;
            }
            C2Rust_Block_33::S_799 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_801;
            }
            C2Rust_Block_33::S_801 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_803;
            }
            C2Rust_Block_33::S_803 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_805;
            }
            C2Rust_Block_33::S_805 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_807;
            }
            C2Rust_Block_33::S_807 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_809;
            }
            C2Rust_Block_33::S_809 => {
                if _fa < _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_906;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_818;
                }
            }
            C2Rust_Block_33::S_818 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_820;
            }
            C2Rust_Block_33::S_820 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_822;
            }
            C2Rust_Block_33::S_822 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_824;
            }
            C2Rust_Block_33::S_824 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_826;
            }
            C2Rust_Block_33::S_826 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_884;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_835;
                }
            }
            C2Rust_Block_33::S_835 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_33 = C2Rust_Block_33::S_841;
            }
            C2Rust_Block_33::S_841 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_843;
            }
            C2Rust_Block_33::S_843 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_845;
            }
            C2Rust_Block_33::S_845 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub((*__gamepkg_tls_g_edi));
                c2rust_current_block_33 = C2Rust_Block_33::S_847;
            }
            C2Rust_Block_33::S_847 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_849;
            }
            C2Rust_Block_33::S_849 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_851;
            }
            C2Rust_Block_33::S_851 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_853;
            }
            C2Rust_Block_33::S_853 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_855;
            }
            C2Rust_Block_33::S_855 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_857;
            }
            C2Rust_Block_33::S_857 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_859;
            }
            C2Rust_Block_33::S_859 => {
                if _fa >= _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_841;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_868;
                }
            }
            C2Rust_Block_33::S_868 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_870;
            }
            C2Rust_Block_33::S_870 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_872;
            }
            C2Rust_Block_33::S_872 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2195;
            }
            C2Rust_Block_33::S_884 => {
                _pv_27 = 0x1fc4dc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_886;
            }
            C2Rust_Block_33::S_886 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_888;
            }
            C2Rust_Block_33::S_888 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_894;
            }
            C2Rust_Block_33::S_894 => {
                sub_001FC070();
                c2rust_current_block_33 = C2Rust_Block_33::S_900;
            }
            C2Rust_Block_33::S_900 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_906;
            }
            C2Rust_Block_33::S_906 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_908;
            }
            C2Rust_Block_33::S_908 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2195;
            }
            C2Rust_Block_33::S_916 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_918;
            }
            C2Rust_Block_33::S_918 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_920;
            }
            C2Rust_Block_33::S_920 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_922;
            }
            C2Rust_Block_33::S_922 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_924;
            }
            C2Rust_Block_33::S_924 => {
                if _fa != _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2195;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_933;
                }
            }
            C2Rust_Block_33::S_933 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41b86c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_939;
            }
            C2Rust_Block_33::S_939 => {
                _pv_28 = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_941;
            }
            C2Rust_Block_33::S_941 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_943;
            }
            C2Rust_Block_33::S_943 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_953;
            }
            C2Rust_Block_33::S_953 => {
                _pv_29 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_955;
            }
            C2Rust_Block_33::S_955 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_957;
            }
            C2Rust_Block_33::S_957 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_967;
            }
            C2Rust_Block_33::S_967 => {
                _pv_30 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_969;
            }
            C2Rust_Block_33::S_969 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_971;
            }
            C2Rust_Block_33::S_971 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_981;
            }
            C2Rust_Block_33::S_981 => {
                _pv_31 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_33 = C2Rust_Block_33::S_983;
            }
            C2Rust_Block_33::S_983 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_985;
            }
            C2Rust_Block_33::S_985 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_995;
            }
            C2Rust_Block_33::S_995 => {
                _pv_32 = 0x1fc506 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_997;
            }
            C2Rust_Block_33::S_997 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_999;
            }
            C2Rust_Block_33::S_999 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1005;
            }
            C2Rust_Block_33::S_1005 => {
                sub_001FBBF0();
                c2rust_current_block_33 = C2Rust_Block_33::S_1011;
            }
            C2Rust_Block_33::S_1011 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_1013;
            }
            C2Rust_Block_33::S_1013 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1015;
            }
            C2Rust_Block_33::S_1015 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1017;
            }
            C2Rust_Block_33::S_1017 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1019;
            }
            C2Rust_Block_33::S_1019 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1021;
            }
            C2Rust_Block_33::S_1021 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1023;
            }
            C2Rust_Block_33::S_1023 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1025;
            }
            C2Rust_Block_33::S_1025 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1027;
            }
            C2Rust_Block_33::S_1027 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1029;
            }
            C2Rust_Block_33::S_1029 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1031;
            }
            C2Rust_Block_33::S_1031 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1033;
            }
            C2Rust_Block_33::S_1033 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2195;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_1042;
                }
            }
            C2Rust_Block_33::S_1042 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1048;
            }
            C2Rust_Block_33::S_1048 => {
                _pv_33 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_1050;
            }
            C2Rust_Block_33::S_1050 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1052;
            }
            C2Rust_Block_33::S_1052 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1062;
            }
            C2Rust_Block_33::S_1062 => {
                _pv_34 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1064;
            }
            C2Rust_Block_33::S_1064 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1066;
            }
            C2Rust_Block_33::S_1066 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1076;
            }
            C2Rust_Block_33::S_1076 => {
                _pv_35 = 0xb as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1078;
            }
            C2Rust_Block_33::S_1078 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1080;
            }
            C2Rust_Block_33::S_1080 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_35,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1090;
            }
            C2Rust_Block_33::S_1090 => {
                _pv_36 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1092;
            }
            C2Rust_Block_33::S_1092 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1094;
            }
            C2Rust_Block_33::S_1094 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_36,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1104;
            }
            C2Rust_Block_33::S_1104 => {
                _pv_37 = 0x1fc524 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1106;
            }
            C2Rust_Block_33::S_1106 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1108;
            }
            C2Rust_Block_33::S_1108 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_37,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1114;
            }
            C2Rust_Block_33::S_1114 => {
                sub_001FBB70();
                c2rust_current_block_33 = C2Rust_Block_33::S_1120;
            }
            C2Rust_Block_33::S_1120 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1126;
            }
            C2Rust_Block_33::S_1126 => {
                _pv_38 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_33 = C2Rust_Block_33::S_1128;
            }
            C2Rust_Block_33::S_1128 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1130;
            }
            C2Rust_Block_33::S_1130 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_38,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1140;
            }
            C2Rust_Block_33::S_1140 => {
                _pv_39 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1142;
            }
            C2Rust_Block_33::S_1142 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1144;
            }
            C2Rust_Block_33::S_1144 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_39,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1154;
            }
            C2Rust_Block_33::S_1154 => {
                _pv_40 = 6 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1156;
            }
            C2Rust_Block_33::S_1156 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1158;
            }
            C2Rust_Block_33::S_1158 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_40,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1168;
            }
            C2Rust_Block_33::S_1168 => {
                _pv_41 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1170;
            }
            C2Rust_Block_33::S_1170 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1172;
            }
            C2Rust_Block_33::S_1172 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_41,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1182;
            }
            C2Rust_Block_33::S_1182 => {
                _pv_42 = 0x1fc532 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1184;
            }
            C2Rust_Block_33::S_1184 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1186;
            }
            C2Rust_Block_33::S_1186 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_42,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1192;
            }
            C2Rust_Block_33::S_1192 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1198;
            }
            C2Rust_Block_33::S_1198 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5d as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1200;
            }
            C2Rust_Block_33::S_1200 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1202;
            }
            C2Rust_Block_33::S_1202 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1204;
            }
            C2Rust_Block_33::S_1204 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1206;
            }
            C2Rust_Block_33::S_1206 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1208;
            }
            C2Rust_Block_33::S_1208 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1210;
            }
            C2Rust_Block_33::S_1210 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1216;
            }
            C2Rust_Block_33::S_1216 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_33 = C2Rust_Block_33::S_1218;
            }
            C2Rust_Block_33::S_1218 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1220;
            }
            C2Rust_Block_33::S_1220 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_33 = C2Rust_Block_33::S_1226;
            }
            C2Rust_Block_33::S_1226 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_1228;
            }
            C2Rust_Block_33::S_1228 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        as ::core::ffi::c_float,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1230;
            }
            C2Rust_Block_33::S_1230 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1236;
            }
            C2Rust_Block_33::S_1236 => {
                _pv_43 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1238;
            }
            C2Rust_Block_33::S_1238 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1240;
            }
            C2Rust_Block_33::S_1240 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_43,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1250;
            }
            C2Rust_Block_33::S_1250 => {
                _pv_44 = 7 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1252;
            }
            C2Rust_Block_33::S_1252 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1254;
            }
            C2Rust_Block_33::S_1254 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_44,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1264;
            }
            C2Rust_Block_33::S_1264 => {
                _pv_45 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1266;
            }
            C2Rust_Block_33::S_1266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1268;
            }
            C2Rust_Block_33::S_1268 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_45,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1278;
            }
            C2Rust_Block_33::S_1278 => {
                _pv_46 = 0x1fc554 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1280;
            }
            C2Rust_Block_33::S_1280 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1282;
            }
            C2Rust_Block_33::S_1282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_46,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1288;
            }
            C2Rust_Block_33::S_1288 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1294;
            }
            C2Rust_Block_33::S_1294 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1296;
            }
            C2Rust_Block_33::S_1296 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1298;
            }
            C2Rust_Block_33::S_1298 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1300;
            }
            C2Rust_Block_33::S_1300 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1302;
            }
            C2Rust_Block_33::S_1302 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 2 as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1304;
            }
            C2Rust_Block_33::S_1304 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1306;
            }
            C2Rust_Block_33::S_1306 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1308;
            }
            C2Rust_Block_33::S_1308 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 1 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1310;
            }
            C2Rust_Block_33::S_1310 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1312;
            }
            C2Rust_Block_33::S_1312 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1318;
            }
            C2Rust_Block_33::S_1318 => {
                _pv_47 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_1320;
            }
            C2Rust_Block_33::S_1320 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1322;
            }
            C2Rust_Block_33::S_1322 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_47,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1332;
            }
            C2Rust_Block_33::S_1332 => {
                _pv_48 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1334;
            }
            C2Rust_Block_33::S_1334 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1336;
            }
            C2Rust_Block_33::S_1336 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_48,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1346;
            }
            C2Rust_Block_33::S_1346 => {
                _pv_49 = 0xa as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1348;
            }
            C2Rust_Block_33::S_1348 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1350;
            }
            C2Rust_Block_33::S_1350 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_49,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1360;
            }
            C2Rust_Block_33::S_1360 => {
                _pv_50 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1362;
            }
            C2Rust_Block_33::S_1362 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1364;
            }
            C2Rust_Block_33::S_1364 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_50,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1374;
            }
            C2Rust_Block_33::S_1374 => {
                _pv_51 = 0x1fc56a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1376;
            }
            C2Rust_Block_33::S_1376 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1378;
            }
            C2Rust_Block_33::S_1378 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_51,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1384;
            }
            C2Rust_Block_33::S_1384 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1390;
            }
            C2Rust_Block_33::S_1390 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1392;
            }
            C2Rust_Block_33::S_1392 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1394;
            }
            C2Rust_Block_33::S_1394 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1396;
            }
            C2Rust_Block_33::S_1396 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1398;
            }
            C2Rust_Block_33::S_1398 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1400;
            }
            C2Rust_Block_33::S_1400 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1402;
            }
            C2Rust_Block_33::S_1402 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 8 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1404;
            }
            C2Rust_Block_33::S_1404 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1406;
            }
            C2Rust_Block_33::S_1406 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1408;
            }
            C2Rust_Block_33::S_1408 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1410;
            }
            C2Rust_Block_33::S_1410 => {
                if _fa != _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_1511;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_1419;
                }
            }
            C2Rust_Block_33::S_1419 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1425;
            }
            C2Rust_Block_33::S_1425 => {
                _pv_52 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_33 = C2Rust_Block_33::S_1427;
            }
            C2Rust_Block_33::S_1427 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1429;
            }
            C2Rust_Block_33::S_1429 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_52,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1439;
            }
            C2Rust_Block_33::S_1439 => {
                _pv_53 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1441;
            }
            C2Rust_Block_33::S_1441 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1443;
            }
            C2Rust_Block_33::S_1443 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_53,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1453;
            }
            C2Rust_Block_33::S_1453 => {
                _pv_54 = 9 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1455;
            }
            C2Rust_Block_33::S_1455 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1457;
            }
            C2Rust_Block_33::S_1457 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_54,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1467;
            }
            C2Rust_Block_33::S_1467 => {
                _pv_55 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1469;
            }
            C2Rust_Block_33::S_1469 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1471;
            }
            C2Rust_Block_33::S_1471 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_55,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1481;
            }
            C2Rust_Block_33::S_1481 => {
                _pv_56 = 0x1fc582 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1483;
            }
            C2Rust_Block_33::S_1483 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1485;
            }
            C2Rust_Block_33::S_1485 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_56,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1491;
            }
            C2Rust_Block_33::S_1491 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1497;
            }
            C2Rust_Block_33::S_1497 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1499;
            }
            C2Rust_Block_33::S_1499 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1501;
            }
            C2Rust_Block_33::S_1501 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1503;
            }
            C2Rust_Block_33::S_1503 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1505;
            }
            C2Rust_Block_33::S_1505 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1511;
            }
            C2Rust_Block_33::S_1511 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x63 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1513;
            }
            C2Rust_Block_33::S_1513 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1519;
            }
            C2Rust_Block_33::S_1519 => {
                _pv_57 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_33 = C2Rust_Block_33::S_1521;
            }
            C2Rust_Block_33::S_1521 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1523;
            }
            C2Rust_Block_33::S_1523 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_57,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1533;
            }
            C2Rust_Block_33::S_1533 => {
                _fp_value_1 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_33 = C2Rust_Block_33::S_1535;
            }
            C2Rust_Block_33::S_1535 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1537;
            }
            C2Rust_Block_33::S_1537 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_33 = C2Rust_Block_33::S_1543;
            }
            C2Rust_Block_33::S_1543 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        as ::core::ffi::c_float,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1545;
            }
            C2Rust_Block_33::S_1545 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1551;
            }
            C2Rust_Block_33::S_1551 => {
                _pv_58 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1553;
            }
            C2Rust_Block_33::S_1553 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1555;
            }
            C2Rust_Block_33::S_1555 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_58,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1565;
            }
            C2Rust_Block_33::S_1565 => {
                _pv_59 = 0xc as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1567;
            }
            C2Rust_Block_33::S_1567 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1569;
            }
            C2Rust_Block_33::S_1569 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_59,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1579;
            }
            C2Rust_Block_33::S_1579 => {
                _pv_60 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1581;
            }
            C2Rust_Block_33::S_1581 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1583;
            }
            C2Rust_Block_33::S_1583 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_60,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1593;
            }
            C2Rust_Block_33::S_1593 => {
                _pv_61 = 0x1fc59f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1595;
            }
            C2Rust_Block_33::S_1595 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1597;
            }
            C2Rust_Block_33::S_1597 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_61,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1603;
            }
            C2Rust_Block_33::S_1603 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1609;
            }
            C2Rust_Block_33::S_1609 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1615;
            }
            C2Rust_Block_33::S_1615 => {
                _pv_62 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_1617;
            }
            C2Rust_Block_33::S_1617 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1619;
            }
            C2Rust_Block_33::S_1619 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_62,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1629;
            }
            C2Rust_Block_33::S_1629 => {
                _pv_63 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1631;
            }
            C2Rust_Block_33::S_1631 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1633;
            }
            C2Rust_Block_33::S_1633 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_63,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1643;
            }
            C2Rust_Block_33::S_1643 => {
                _pv_64 = ebp;
                c2rust_current_block_33 = C2Rust_Block_33::S_1645;
            }
            C2Rust_Block_33::S_1645 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1647;
            }
            C2Rust_Block_33::S_1647 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_64,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1657;
            }
            C2Rust_Block_33::S_1657 => {
                _pv_65 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1659;
            }
            C2Rust_Block_33::S_1659 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1661;
            }
            C2Rust_Block_33::S_1661 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_65,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1671;
            }
            C2Rust_Block_33::S_1671 => {
                _pv_66 = 0x1fc5ac as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1673;
            }
            C2Rust_Block_33::S_1673 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1675;
            }
            C2Rust_Block_33::S_1675 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_66,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1681;
            }
            C2Rust_Block_33::S_1681 => {
                sub_001FBAE0();
                c2rust_current_block_33 = C2Rust_Block_33::S_1687;
            }
            C2Rust_Block_33::S_1687 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1693;
            }
            C2Rust_Block_33::S_1693 => {
                _pv_67 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_33 = C2Rust_Block_33::S_1695;
            }
            C2Rust_Block_33::S_1695 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1697;
            }
            C2Rust_Block_33::S_1697 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_67,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1707;
            }
            C2Rust_Block_33::S_1707 => {
                _pv_68 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1709;
            }
            C2Rust_Block_33::S_1709 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1711;
            }
            C2Rust_Block_33::S_1711 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_68,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1721;
            }
            C2Rust_Block_33::S_1721 => {
                _pv_69 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1723;
            }
            C2Rust_Block_33::S_1723 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1725;
            }
            C2Rust_Block_33::S_1725 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_69,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1735;
            }
            C2Rust_Block_33::S_1735 => {
                _pv_70 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1737;
            }
            C2Rust_Block_33::S_1737 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1739;
            }
            C2Rust_Block_33::S_1739 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_70,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1749;
            }
            C2Rust_Block_33::S_1749 => {
                _pv_71 = 0x1fc5ba as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1751;
            }
            C2Rust_Block_33::S_1751 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1753;
            }
            C2Rust_Block_33::S_1753 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_71,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1759;
            }
            C2Rust_Block_33::S_1759 => {
                sub_001FBAE0();
                c2rust_current_block_33 = C2Rust_Block_33::S_1765;
            }
            C2Rust_Block_33::S_1765 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1771;
            }
            C2Rust_Block_33::S_1771 => {
                _pv_72 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_33 = C2Rust_Block_33::S_1773;
            }
            C2Rust_Block_33::S_1773 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1775;
            }
            C2Rust_Block_33::S_1775 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_72,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1785;
            }
            C2Rust_Block_33::S_1785 => {
                _pv_73 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1787;
            }
            C2Rust_Block_33::S_1787 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1789;
            }
            C2Rust_Block_33::S_1789 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_73,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1799;
            }
            C2Rust_Block_33::S_1799 => {
                _pv_74 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1801;
            }
            C2Rust_Block_33::S_1801 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1803;
            }
            C2Rust_Block_33::S_1803 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_74,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1813;
            }
            C2Rust_Block_33::S_1813 => {
                _pv_75 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1815;
            }
            C2Rust_Block_33::S_1815 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1817;
            }
            C2Rust_Block_33::S_1817 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_75,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1827;
            }
            C2Rust_Block_33::S_1827 => {
                _pv_76 = 0x1fc5c8 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1829;
            }
            C2Rust_Block_33::S_1829 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1831;
            }
            C2Rust_Block_33::S_1831 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_76,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1837;
            }
            C2Rust_Block_33::S_1837 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1843;
            }
            C2Rust_Block_33::S_1843 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1845;
            }
            C2Rust_Block_33::S_1845 => {
                _fb = 0x40 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1847;
            }
            C2Rust_Block_33::S_1847 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1849;
            }
            C2Rust_Block_33::S_1849 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x40 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1851;
            }
            C2Rust_Block_33::S_1851 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1853;
            }
            C2Rust_Block_33::S_1853 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1859;
            }
            C2Rust_Block_33::S_1859 => {
                _pv_77 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_1861;
            }
            C2Rust_Block_33::S_1861 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1863;
            }
            C2Rust_Block_33::S_1863 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_77,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1873;
            }
            C2Rust_Block_33::S_1873 => {
                _pv_78 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1875;
            }
            C2Rust_Block_33::S_1875 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1877;
            }
            C2Rust_Block_33::S_1877 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_78,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1887;
            }
            C2Rust_Block_33::S_1887 => {
                _pv_79 = 5 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1889;
            }
            C2Rust_Block_33::S_1889 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1891;
            }
            C2Rust_Block_33::S_1891 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_79,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1901;
            }
            C2Rust_Block_33::S_1901 => {
                _pv_80 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1903;
            }
            C2Rust_Block_33::S_1903 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1905;
            }
            C2Rust_Block_33::S_1905 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_80,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1915;
            }
            C2Rust_Block_33::S_1915 => {
                _pv_81 = 0x1fc5d9 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1917;
            }
            C2Rust_Block_33::S_1917 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1919;
            }
            C2Rust_Block_33::S_1919 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_81,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1925;
            }
            C2Rust_Block_33::S_1925 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_1931;
            }
            C2Rust_Block_33::S_1931 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x5e as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1933;
            }
            C2Rust_Block_33::S_1933 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1935;
            }
            C2Rust_Block_33::S_1935 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1937;
            }
            C2Rust_Block_33::S_1937 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1939;
            }
            C2Rust_Block_33::S_1939 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1941;
            }
            C2Rust_Block_33::S_1941 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1943;
            }
            C2Rust_Block_33::S_1943 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1949;
            }
            C2Rust_Block_33::S_1949 => {
                _fp_value_2 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_33 = C2Rust_Block_33::S_1951;
            }
            C2Rust_Block_33::S_1951 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1953;
            }
            C2Rust_Block_33::S_1953 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                c2rust_current_block_33 = C2Rust_Block_33::S_1959;
            }
            C2Rust_Block_33::S_1959 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_1961;
            }
            C2Rust_Block_33::S_1961 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        as ::core::ffi::c_float,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1963;
            }
            C2Rust_Block_33::S_1963 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_1969;
            }
            C2Rust_Block_33::S_1969 => {
                _pv_82 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1971;
            }
            C2Rust_Block_33::S_1971 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1973;
            }
            C2Rust_Block_33::S_1973 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_82,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1983;
            }
            C2Rust_Block_33::S_1983 => {
                _pv_83 = 0xd as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_1985;
            }
            C2Rust_Block_33::S_1985 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_1987;
            }
            C2Rust_Block_33::S_1987 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_83,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_1997;
            }
            C2Rust_Block_33::S_1997 => {
                _pv_84 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_1999;
            }
            C2Rust_Block_33::S_1999 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2001;
            }
            C2Rust_Block_33::S_2001 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_84,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2011;
            }
            C2Rust_Block_33::S_2011 => {
                _pv_85 = 0x1fc5fb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2013;
            }
            C2Rust_Block_33::S_2013 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2015;
            }
            C2Rust_Block_33::S_2015 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_85,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2021;
            }
            C2Rust_Block_33::S_2021 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_2031;
            }
            C2Rust_Block_33::S_2031 => {
                _pv_86 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2033;
            }
            C2Rust_Block_33::S_2033 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2035;
            }
            C2Rust_Block_33::S_2035 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_86,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2045;
            }
            C2Rust_Block_33::S_2045 => {
                _pv_87 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2047;
            }
            C2Rust_Block_33::S_2047 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2049;
            }
            C2Rust_Block_33::S_2049 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_87,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2059;
            }
            C2Rust_Block_33::S_2059 => {
                _pv_88 = 8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2061;
            }
            C2Rust_Block_33::S_2061 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2063;
            }
            C2Rust_Block_33::S_2063 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_88,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2073;
            }
            C2Rust_Block_33::S_2073 => {
                _pv_89 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_2075;
            }
            C2Rust_Block_33::S_2075 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2077;
            }
            C2Rust_Block_33::S_2077 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_89,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2087;
            }
            C2Rust_Block_33::S_2087 => {
                _pv_90 = 0x1fc607 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2089;
            }
            C2Rust_Block_33::S_2089 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2091;
            }
            C2Rust_Block_33::S_2091 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_90,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2097;
            }
            C2Rust_Block_33::S_2097 => {
                sub_001FBB40();
                c2rust_current_block_33 = C2Rust_Block_33::S_2103;
            }
            C2Rust_Block_33::S_2103 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2109;
            }
            C2Rust_Block_33::S_2109 => {
                _pv_91 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_33 = C2Rust_Block_33::S_2111;
            }
            C2Rust_Block_33::S_2111 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2113;
            }
            C2Rust_Block_33::S_2113 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_91,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2123;
            }
            C2Rust_Block_33::S_2123 => {
                _pv_92 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2125;
            }
            C2Rust_Block_33::S_2125 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2127;
            }
            C2Rust_Block_33::S_2127 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_92,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2137;
            }
            C2Rust_Block_33::S_2137 => {
                _pv_93 = 0xe as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2139;
            }
            C2Rust_Block_33::S_2139 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2141;
            }
            C2Rust_Block_33::S_2141 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_93,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2151;
            }
            C2Rust_Block_33::S_2151 => {
                _pv_94 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_33 = C2Rust_Block_33::S_2153;
            }
            C2Rust_Block_33::S_2153 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2155;
            }
            C2Rust_Block_33::S_2155 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_94,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2165;
            }
            C2Rust_Block_33::S_2165 => {
                _pv_95 = 0x1fc615 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2167;
            }
            C2Rust_Block_33::S_2167 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2169;
            }
            C2Rust_Block_33::S_2169 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_95,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2175;
            }
            C2Rust_Block_33::S_2175 => {
                sub_001FBB70();
                c2rust_current_block_33 = C2Rust_Block_33::S_2181;
            }
            C2Rust_Block_33::S_2181 => {
                _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2183;
            }
            C2Rust_Block_33::S_2183 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2185;
            }
            C2Rust_Block_33::S_2185 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2187;
            }
            C2Rust_Block_33::S_2187 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2189;
            }
            C2Rust_Block_33::S_2189 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2195;
            }
            C2Rust_Block_33::S_2195 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x61 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2197;
            }
            C2Rust_Block_33::S_2197 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2199;
            }
            C2Rust_Block_33::S_2199 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2201;
            }
            C2Rust_Block_33::S_2201 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2203;
            }
            C2Rust_Block_33::S_2203 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2205;
            }
            C2Rust_Block_33::S_2205 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add((*__gamepkg_tls_g_eax));
                c2rust_current_block_33 = C2Rust_Block_33::S_2207;
            }
            C2Rust_Block_33::S_2207 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2209;
            }
            C2Rust_Block_33::S_2209 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2211;
            }
            C2Rust_Block_33::S_2211 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2213;
            }
            C2Rust_Block_33::S_2213 => {
                _fb = 0x41b850 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2215;
            }
            C2Rust_Block_33::S_2215 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2217;
            }
            C2Rust_Block_33::S_2217 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2219;
            }
            C2Rust_Block_33::S_2219 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2221;
            }
            C2Rust_Block_33::S_2221 => {
                if _fa != _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_128;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_2234;
                }
            }
            C2Rust_Block_33::S_2234 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2236;
            }
            C2Rust_Block_33::S_2236 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2250;
            }
            C2Rust_Block_33::S_2250 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2252;
            }
            C2Rust_Block_33::S_2252 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2266;
            }
            C2Rust_Block_33::S_2266 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_2268;
            }
            C2Rust_Block_33::S_2268 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2274;
            }
            C2Rust_Block_33::S_2274 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2276;
            }
            C2Rust_Block_33::S_2276 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2278;
            }
            C2Rust_Block_33::S_2278 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2280;
            }
            C2Rust_Block_33::S_2280 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2282;
            }
            C2Rust_Block_33::S_2282 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_2284;
            }
            C2Rust_Block_33::S_2284 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_2286;
            }
            C2Rust_Block_33::S_2286 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC640() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_75: {
        if _fa == _fb {
            break 's_75;
        }
        let mut _pv_0: uint32_t = 0x1fc64e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_001FC070();
    }
    let mut _pv_1: uint32_t = 0x1fc653 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001FC130();
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b878 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            | 2 as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x61 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x48 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b87c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b878 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC690() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(0 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_194: {
        if _fa == 0 as uint32_t {
            break 's_194;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        's_152: {
            if _fa == 0 as uint32_t {
                break 's_152;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
            's_136: {
                if _fa != 0 as uint32_t {
                    break 's_136;
                }
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x62 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if _fa == _fb {
                    break 's_136;
                }
                let mut _pv_0: uint32_t = 0x1fc6af as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                sub_001FC130();
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = 0x1fc6ba as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        sub_001FC070();
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_001FC640();
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC6D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _pv: uint32_t = 0x41b888 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc6da as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001F9F40();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(4 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (if _cf != 0 {
        0xffffffff as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC6F0() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0x30807 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    let mut _pv_2: uint32_t = 0x1fc70a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FED80();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    's_119: {
        if _fa == _fb {
            break 's_119;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ebx).wrapping_add(0x30 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_277: {
            if _fa != _fb {
                break 's_277;
            }
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ebx)
                .wrapping_add(0x10 as uint32_t);
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx)
                .wrapping_add(0x2c as uint32_t);
            (*__gamepkg_tls_g_ecx) = 7 as uint32_t;
            's_247: {
                's_226: {
                    if (*__gamepkg_tls_g_df) != 0 {
                        break 's_226;
                    }
                    let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    );
                    let mut _n: uint32_t = (*__gamepkg_tls_g_ecx)
                        .wrapping_mul(4 as uint32_t);
                    's_219: {
                        's_198: {
                            if _d.offset(_n as isize) <= _s
                                || _s.offset(_n as isize) <= _d
                            {
                                break 's_198;
                            }
                            let mut _i: uint32_t = 0;
                            _i = 0 as uint32_t;
                            loop {
                                if _i >= (*__gamepkg_tls_g_ecx) {
                                    break 's_219;
                                }
                                ::core::ptr::write_volatile(
                                    ::core::ptr::with_exposed_provenance_mut::<
                                        uint32_t,
                                    >(
                                        ((*__gamepkg_tls_g_edi)
                                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                    ),
                                    ::core::ptr::read_volatile::<
                                        uint32_t,
                                    >(
                                        ::core::ptr::with_exposed_provenance_mut::<
                                            uint32_t,
                                        >(
                                            ((*__gamepkg_tls_g_esi)
                                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                        ),
                                    ),
                                );
                                _i = _i.wrapping_add(1);
                            }
                        }
                        memcpy(
                            _d as *mut ::core::ffi::c_void,
                            _s as *const ::core::ffi::c_void,
                            _n as size_t,
                        );
                    }
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_add(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    break 's_247;
                }
                let mut _i_0: uint32_t = 0;
                _i_0 = 0 as uint32_t;
                while _i_0 < (*__gamepkg_tls_g_ecx) {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    _i_0 = _i_0.wrapping_add(1);
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            }
            (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC740() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_57: {
        if _fa == _fb {
            break 's_57;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_001FEDC0();
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC760() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi).wrapping_add((*__gamepkg_tls_g_edx));
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_131: {
        's_76: {
            if (*__gamepkg_tls_g_df) == 0 {
                break 's_76;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            break 's_131;
        }
        let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _n: uint32_t = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
        's_103: {
            's_82: {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    break 's_82;
                }
                let mut _i: uint32_t = 0;
                _i = 0 as uint32_t;
                loop {
                    if _i >= (*__gamepkg_tls_g_ecx) {
                        break 's_103;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    _i = _i.wrapping_add(1);
                }
            }
            memcpy(
                _d as *mut ::core::ffi::c_void,
                _s as *const ::core::ffi::c_void,
                _n as size_t,
            );
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_200: {
        's_179: {
            if (*__gamepkg_tls_g_df) != 0 {
                break 's_179;
            }
            let mut _d_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let mut _s_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let mut _n_0: uint32_t = (*__gamepkg_tls_g_ecx);
            's_172: {
                's_151: {
                    if _d_0.offset(_n_0 as isize) <= _s_0
                        || _s_0.offset(_n_0 as isize) <= _d_0
                    {
                        break 's_151;
                    }
                    let mut _i_1: uint32_t = 0;
                    _i_1 = 0 as uint32_t;
                    loop {
                        if _i_1 >= _n_0 {
                            break 's_172;
                        }
                        *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                        _i_1 = _i_1.wrapping_add(1);
                    }
                }
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add((*__gamepkg_tls_g_ecx));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add((*__gamepkg_tls_g_ecx));
            break 's_200;
        }
        let mut _i_2: uint32_t = 0;
        _i_2 = 0 as uint32_t;
        while _i_2 < (*__gamepkg_tls_g_ecx) {
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            _i_2 = _i_2.wrapping_add(1);
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC790() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add((*__gamepkg_tls_g_edx));
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ecx);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) >> 2 as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_133: {
        's_78: {
            if (*__gamepkg_tls_g_df) == 0 {
                break 's_78;
            }
            let mut _i_0: uint32_t = 0;
            _i_0 = 0 as uint32_t;
            while _i_0 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_0 = _i_0.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            break 's_133;
        }
        let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        );
        let mut _n: uint32_t = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
        's_105: {
            's_84: {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    break 's_84;
                }
                let mut _i: uint32_t = 0;
                _i = 0 as uint32_t;
                loop {
                    if _i >= (*__gamepkg_tls_g_ecx) {
                        break 's_105;
                    }
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esi)
                                    .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    _i = _i.wrapping_add(1);
                }
            }
            memcpy(
                _d as *mut ::core::ffi::c_void,
                _s as *const ::core::ffi::c_void,
                _n as size_t,
            );
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 3 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_202: {
        's_181: {
            if (*__gamepkg_tls_g_df) != 0 {
                break 's_181;
            }
            let mut _d_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let mut _s_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            );
            let mut _n_0: uint32_t = (*__gamepkg_tls_g_ecx);
            's_174: {
                's_153: {
                    if _d_0.offset(_n_0 as isize) <= _s_0
                        || _s_0.offset(_n_0 as isize) <= _d_0
                    {
                        break 's_153;
                    }
                    let mut _i_1: uint32_t = 0;
                    _i_1 = 0 as uint32_t;
                    loop {
                        if _i_1 >= _n_0 {
                            break 's_174;
                        }
                        *_d_0.offset(_i_1 as isize) = *_s_0.offset(_i_1 as isize);
                        _i_1 = _i_1.wrapping_add(1);
                    }
                }
                memcpy(
                    _d_0 as *mut ::core::ffi::c_void,
                    _s_0 as *const ::core::ffi::c_void,
                    _n_0 as size_t,
                );
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_add((*__gamepkg_tls_g_ecx));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_add((*__gamepkg_tls_g_ecx));
            break 's_202;
        }
        let mut _i_2: uint32_t = 0;
        _i_2 = 0 as uint32_t;
        while _i_2 < (*__gamepkg_tls_g_ecx) {
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_sub(_i_2) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_sub(_i_2) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            _i_2 = _i_2.wrapping_add(1);
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
            .wrapping_sub((*__gamepkg_tls_g_ecx));
    }
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC7C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41b888 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1fc7cd as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FA470();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_133: {
        if _fa != _fb {
            break 's_133;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_3: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x36dc9c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x1fc7e5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_001F9F10();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1fc6f0 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1fc740 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1fc760 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x1fc790 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC810() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41b8e4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc81a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD5A0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_79: {
        if _fa == _fb {
            break 's_79;
        }
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x36dcac as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x41b8e4 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fc833 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001F64C0();
        let mut _pv_5: uint32_t = 0x10 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x3c1a30 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 0xf as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3c1900 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x41b8e4 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x1fc84b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001FD480();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0x41b8e4 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC860() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41b8e4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc86a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD620();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC870() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41b90c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc87a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD5A0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_79: {
        if _fa == _fb {
            break 's_79;
        }
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x36dd7c as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x41b90c as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fc893 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001F64C0();
        let mut _pv_5: uint32_t = 0xa as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x3c1c28 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 9 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3c1b70 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x41b90c as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x1fc8ab as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001FD480();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0x41b90c as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC8C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41b90c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc8ca as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD620();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC8D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41b934 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc8da as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD5A0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_79: {
        if _fa == _fb {
            break 's_79;
        }
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x36debc as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x41b934 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1fc8f3 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001F64C0();
        let mut _pv_5: uint32_t = 5 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x3c1d68 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 6 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3c1cf0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x41b934 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0x1fc90b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001FD480();
        _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = 0x41b934 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC920() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x41b934 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x1fc92a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_001FD620();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC930() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _tsc: uint64_t = xbox_ReadTimeStampCounter();
    (*__gamepkg_tls_g_eax) = _tsc as uint32_t;
    (*__gamepkg_tls_g_edx) = (_tsc >> 32 as ::core::ffi::c_int) as uint32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC950() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = 0x2bb5c755 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC960() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _tsc: uint64_t = xbox_ReadTimeStampCounter();
    (*__gamepkg_tls_g_eax) = _tsc as uint32_t;
    (*__gamepkg_tls_g_edx) = (_tsc >> 32 as ::core::ffi::c_int) as uint32_t;
    (*__gamepkg_tls_g_ebx) = 0x41b960 as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC980() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _tsc: uint64_t = xbox_ReadTimeStampCounter();
    (*__gamepkg_tls_g_eax) = _tsc as uint32_t;
    (*__gamepkg_tls_g_edx) = (_tsc >> 32 as ::core::ffi::c_int) as uint32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC9A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x48 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        3 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x5c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        4 as uint32_t,
    );
    let mut _pv_1: uint32_t = 0x1fc9ce as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001DEEB0();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) >> 0xb as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _icall_esp: uint32_t = (*__gamepkg_tls_g_esp);
    let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi) << 0xb as ::core::ffi::c_int;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _icall_target: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_5: uint32_t = 0x1fc9e0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _va: uint32_t = _icall_target;
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace[(::core::ptr::read_volatile::<
            uint32_t,
        >(&raw const g_icall_trace_idx)
            & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t) as usize],
        _va,
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_trace_idx,
        ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
            .wrapping_add(1),
    );
    ::core::ptr::write_volatile(
        &raw mut g_icall_count,
        ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count).wrapping_add(1),
    );
    's_236: {
        's_187: {
            if _va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                || _va >= g_xbox_code_lo && _va < g_xbox_code_hi
            {
                break 's_187;
            }
            recomp_icall_not_code_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_236;
        }
        let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
        's_195: {
            if !_fn.is_none() {
                break 's_195;
            }
            _fn = recomp_lookup(_va);
        }
        's_201: {
            if !_fn.is_none() {
                break 's_201;
            }
            _fn = recomp_lookup_kernel(_va);
        }
        's_207: {
            if _fn.is_some() {
                break 's_207;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = _icall_esp;
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_236;
        }
        _fn.expect("non-null function pointer")();
    }
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FC9F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
