extern "C" {
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn exp2(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn ceil(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn floor(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn fmod(
        __x: ::core::ffi::c_double,
        __y: ::core::ffi::c_double,
    ) -> ::core::ffi::c_double;
    fn copysign(
        __x: ::core::ffi::c_double,
        __y: ::core::ffi::c_double,
    ) -> ::core::ffi::c_double;
    fn trunc(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    fn gamepkg_tls_g_fp_cmp() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_cc() -> *mut uint16_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001D10B4();
    fn sub_001D120E();
    fn sub_001D192B();
    fn sub_002440A5();
    fn sub_0024419D();
    fn sub_00244784();
    fn sub_002447BF();
    fn sub_00244D08();
    fn sub_002453B1();
    fn sub_00245A3D();
    fn sub_00247577();
    fn sub_00248347();
    fn sub_002485FC();
    fn sub_002486AE();
    fn sub_0024A46A();
    fn sub_0024A480();
    fn sub_0024B189();
    fn sub_0024BC71();
    fn sub_0024BDDD();
    fn sub_0024BE1E();
    fn sub_0024BEBE();
    fn sub_0024C05C();
    fn sub_00249AB6();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
#[inline]
unsafe extern "C" fn recomp_fxam(mut value: ::core::ffi::c_double) -> uint16_t {
    return (if value.is_sign_negative() as ::core::ffi::c_int != 0 {
        0x200 as ::core::ffi::c_uint
    } else {
        0 as ::core::ffi::c_uint
    }
        | if value.is_nan() as i32 != 0 {
            0x100 as ::core::ffi::c_uint
        } else if if value.is_infinite() {
            if value.is_sign_positive() { 1 } else { -1 }
        } else {
            0
        } != 0
        {
            0x500 as ::core::ffi::c_uint
        } else if value == 0.0f64 {
            0x4000 as ::core::ffi::c_uint
        } else {
            0x400 as ::core::ffi::c_uint
        }) as uint16_t;
}
#[inline]
unsafe extern "C" fn recomp_frndint(
    mut value: ::core::ffi::c_double,
    mut control: uint16_t,
) -> ::core::ffi::c_double {
    let mut rounded: ::core::ffi::c_double = 0.;
    's_4: {
        if value.is_finite() as i32 == 0 {
            break 's_4;
        }
        's_45: {
            'c_11463: {
                'c_11461: {
                    'c_11459: {
                        match control as ::core::ffi::c_int >> 10 as ::core::ffi::c_int
                            & 3 as ::core::ffi::c_int
                        {
                            1 => {
                                break 'c_11459;
                            }
                            2 => {
                                break 'c_11461;
                            }
                            3 => {
                                break 'c_11463;
                            }
                            _ => {}
                        }
                        let mut lo: ::core::ffi::c_double = floor(value);
                        let mut fraction: ::core::ffi::c_double = value - lo;
                        rounded = lo;
                        if !(fraction > 0.5f64
                            || fraction == 0.5f64 && fmod(lo, 2.0f64) != 0.0f64)
                        {
                            break 's_45;
                        }
                        rounded = lo + 1.0f64;
                        break 's_45;
                    }
                    rounded = floor(value);
                    break 's_45;
                }
                rounded = ceil(value);
                break 's_45;
            }
            rounded = trunc(value);
        }
        return if rounded == 0.0f64 { copysign(0.0f64, value) } else { rounded };
    }
    return value;
}
#[inline]
unsafe extern "C" fn ROL8(mut val: uint8_t, mut n: ::core::ffi::c_int) -> uint8_t {
    n = (n & 31 as ::core::ffi::c_int) % 8 as ::core::ffi::c_int;
    return (if n != 0 {
        ((val as ::core::ffi::c_int) << n
            | val as ::core::ffi::c_int >> 8 as ::core::ffi::c_int - n) as uint8_t
            as ::core::ffi::c_int
    } else {
        val as ::core::ffi::c_int
    }) as uint8_t;
}
#[inline]
unsafe extern "C" fn recomp_parity8(mut x: uint32_t) -> ::core::ffi::c_int {
    x = (x as ::core::ffi::c_uint & 0xff as ::core::ffi::c_uint) as uint32_t;
    x ^= x >> 4 as ::core::ffi::c_int;
    x ^= x >> 2 as ::core::ffi::c_int;
    x ^= x >> 1 as ::core::ffi::c_int;
    return (!x & 1 as uint32_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249538() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xfffffd30 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xfffffd30 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_control_word),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6a88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_85: {
        if _fa != _fb {
            break 's_85;
        }
        let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = _t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                (ebp.wrapping_add(-134 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        );
        let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = _t_0;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                (ebp.wrapping_add(-126 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        );
    }
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x249558 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00249A17();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int | 3 as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_2: uint32_t = 0x249564 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00249602();
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249576() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xfffffd30 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xfffffd30 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_control_word),
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x3c6a88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_85: {
        if _fa != _fb {
            break 's_85;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                (ebp.wrapping_add(-134 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        );
    }
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x249595 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_002499B0();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int | 1 as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0xfd as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_2: uint32_t = 0x2495a8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00249602();
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002495B3() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xfffffd30 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xfffffd30 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x2495c8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024977C();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_6: uint32_t = 0x2495d6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_0024977C();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_control_word),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int | 2 as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-143 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint8_t,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_7: uint32_t = 0x2495f3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_00249A17();
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_8: uint32_t = 0x2495f8 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_002495FB();
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002495FB() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0xfe as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00249602();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249602() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _t: ::core::ffi::c_double = 0.;
    let mut _t_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _t_1: ::core::ffi::c_double = 0.;
    let mut _t_2: ::core::ffi::c_double = 0.;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _fp_value_3: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_6 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_41,
        S_43,
        S_45,
        S_47,
        S_49,
        S_51,
        S_60,
        S_62,
        S_64,
        S_66,
        S_68,
        S_77,
        S_79,
        S_81,
        S_83,
        S_85,
        S_94,
        S_96,
        S_98,
        S_100,
        S_109,
        S_111,
        S_119,
        S_121,
        S_123,
        S_125,
        S_127,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_153,
        S_161,
        S_163,
        S_165,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_217,
        S_219,
        S_221,
        S_223,
        S_225,
        S_227,
        S_229,
        S_231,
        S_233,
        S_248,
        S_254,
        S_256,
        S_258,
        S_265,
        S_267,
        S_269,
        S_273,
        S_275,
        S_277,
        S_280,
        S_286,
        S_288,
        S_290,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_319,
        S_327,
        S_333,
        S_335,
        S_337,
        S_344,
        S_346,
        S_348,
        S_352,
        S_354,
        S_356,
        S_359,
        S_365,
        S_367,
        S_369,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_398,
        S_408,
        S_410,
        S_412,
        S_422,
        S_424,
        S_426,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_461,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_473,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_487,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_516,
        S_518,
        S_520,
        S_522,
        S_528,
        S_530,
        S_532,
        S_542,
        S_544,
        S_546,
        S_552,
        S_554,
        S_556,
        S_562,
        S_564,
        S_566,
        S_576,
        S_578,
        S_580,
        S_586,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_606,
        S_608,
        S_618,
        S_620,
        S_630,
        S_632,
        S_634,
    }
    let mut c2rust_current_block_6: C2Rust_Block_6;
    c2rust_current_block_6 = C2Rust_Block_6::S_0;
    loop {
        match c2rust_current_block_6 {
            C2Rust_Block_6::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_2;
            }
            C2Rust_Block_6::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_6 = C2Rust_Block_6::S_4;
            }
            C2Rust_Block_6::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_6;
            }
            C2Rust_Block_6::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_8;
            }
            C2Rust_Block_6::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_18;
            }
            C2Rust_Block_6::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_6 = C2Rust_Block_6::S_24;
            }
            C2Rust_Block_6::S_24 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41d2a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_26;
            }
            C2Rust_Block_6::S_26 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_28;
            }
            C2Rust_Block_6::S_28 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_30;
            }
            C2Rust_Block_6::S_30 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_32;
            }
            C2Rust_Block_6::S_32 => {
                if _fa != _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_161;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_41;
                }
            }
            C2Rust_Block_6::S_41 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(-720 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_43;
            }
            C2Rust_Block_6::S_43 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(-144 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_45;
            }
            C2Rust_Block_6::S_45 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_47;
            }
            C2Rust_Block_6::S_47 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_49;
            }
            C2Rust_Block_6::S_49 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_51;
            }
            C2Rust_Block_6::S_51 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_119;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_60;
                }
            }
            C2Rust_Block_6::S_60 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_62;
            }
            C2Rust_Block_6::S_62 => {
                _fb = 0xff as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_64;
            }
            C2Rust_Block_6::S_64 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_66;
            }
            C2Rust_Block_6::S_66 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_68;
            }
            C2Rust_Block_6::S_68 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_217;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_77;
                }
            }
            C2Rust_Block_6::S_77 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_79;
            }
            C2Rust_Block_6::S_79 => {
                _fb = 0xfe as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_81;
            }
            C2Rust_Block_6::S_81 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_83;
            }
            C2Rust_Block_6::S_83 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_85;
            }
            C2Rust_Block_6::S_85 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_171;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_94;
                }
            }
            C2Rust_Block_6::S_94 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int) as uint8_t as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_96;
            }
            C2Rust_Block_6::S_96 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_98;
            }
            C2Rust_Block_6::S_98 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_100;
            }
            C2Rust_Block_6::S_100 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_161;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_109;
                }
            }
            C2Rust_Block_6::S_109 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t)
                    as uint8_t as int8_t as int32_t as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_111;
            }
            C2Rust_Block_6::S_111 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-142 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_408;
            }
            C2Rust_Block_6::S_119 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_121;
            }
            C2Rust_Block_6::S_121 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_123;
            }
            C2Rust_Block_6::S_123 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_125;
            }
            C2Rust_Block_6::S_125 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_127;
            }
            C2Rust_Block_6::S_127 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_161;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_136;
                }
            }
            C2Rust_Block_6::S_136 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_138;
            }
            C2Rust_Block_6::S_138 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_140;
            }
            C2Rust_Block_6::S_140 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_142;
            }
            C2Rust_Block_6::S_142 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_144;
            }
            C2Rust_Block_6::S_144 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_161;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_153;
                }
            }
            C2Rust_Block_6::S_153 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-142 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    8 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_408;
            }
            C2Rust_Block_6::S_161 => {
                (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_163;
            }
            C2Rust_Block_6::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_165;
            }
            C2Rust_Block_6::S_165 => return,
            C2Rust_Block_6::S_171 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (ebp.wrapping_add(-714 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_173;
            }
            C2Rust_Block_6::S_173 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as ::core::ffi::c_int & 0x7ff0 as ::core::ffi::c_int) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_175;
            }
            C2Rust_Block_6::S_175 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_177;
            }
            C2Rust_Block_6::S_177 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_179;
            }
            C2Rust_Block_6::S_179 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as ::core::ffi::c_int
                        | ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                            as ::core::ffi::c_int) as uint16_t as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_181;
            }
            C2Rust_Block_6::S_181 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_183;
            }
            C2Rust_Block_6::S_183 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_185;
            }
            C2Rust_Block_6::S_185 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_6 = C2Rust_Block_6::S_248;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_194;
                }
            }
            C2Rust_Block_6::S_194 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_196;
            }
            C2Rust_Block_6::S_196 => {
                _fb = 0x7ff0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_198;
            }
            C2Rust_Block_6::S_198 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_200;
            }
            C2Rust_Block_6::S_200 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_202;
            }
            C2Rust_Block_6::S_202 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_327;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_119;
                }
            }
            C2Rust_Block_6::S_217 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            (ebp.wrapping_add(-714 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_219;
            }
            C2Rust_Block_6::S_219 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as ::core::ffi::c_int & 0x7ff0 as ::core::ffi::c_int) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_221;
            }
            C2Rust_Block_6::S_221 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_223;
            }
            C2Rust_Block_6::S_223 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_225;
            }
            C2Rust_Block_6::S_225 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_227;
            }
            C2Rust_Block_6::S_227 => {
                _fb = 0x7ff0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_229;
            }
            C2Rust_Block_6::S_229 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_231;
            }
            C2Rust_Block_6::S_231 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_233;
            }
            C2Rust_Block_6::S_233 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_327;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_119;
                }
            }
            C2Rust_Block_6::S_248 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-142 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    4 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_254;
            }
            C2Rust_Block_6::S_254 => {
                _fp_value = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x37479c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_256;
            }
            C2Rust_Block_6::S_256 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_258;
            }
            C2Rust_Block_6::S_258 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_6 = C2Rust_Block_6::S_265;
            }
            C2Rust_Block_6::S_265 => {
                _t = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_267;
            }
            C2Rust_Block_6::S_267 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_269;
            }
            C2Rust_Block_6::S_269 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = _t;
                c2rust_current_block_6 = C2Rust_Block_6::S_273;
            }
            C2Rust_Block_6::S_273 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = ldexp(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize] as ::core::ffi::c_int,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_275;
            }
            C2Rust_Block_6::S_275 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_277;
            }
            C2Rust_Block_6::S_277 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_280;
            }
            C2Rust_Block_6::S_280 => {
                _t_0 = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_286;
            }
            C2Rust_Block_6::S_286 => {
                _fp_value_0 = _t_0;
                c2rust_current_block_6 = C2Rust_Block_6::S_288;
            }
            C2Rust_Block_6::S_288 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_290;
            }
            C2Rust_Block_6::S_290 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_6 = C2Rust_Block_6::S_298;
            }
            C2Rust_Block_6::S_298 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_300;
            }
            C2Rust_Block_6::S_300 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x37478c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x37478c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x37478c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x37478c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_6 = C2Rust_Block_6::S_302;
            }
            C2Rust_Block_6::S_302 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_304;
            }
            C2Rust_Block_6::S_304 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_306;
            }
            C2Rust_Block_6::S_306 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_308;
            }
            C2Rust_Block_6::S_308 => {
                _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_310;
            }
            C2Rust_Block_6::S_310 => {
                if _fa & 0x1 as uint32_t == 0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_312;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_319;
                }
            }
            C2Rust_Block_6::S_312 => {
                c2rust_current_block_6 = C2Rust_Block_6::S_408;
            }
            C2Rust_Block_6::S_319 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x3747ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_double,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_double,
                                >(
                                    (0x3747ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ),
                    )
                };
                c2rust_current_block_6 = C2Rust_Block_6::S_408;
            }
            C2Rust_Block_6::S_327 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-142 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_333;
            }
            C2Rust_Block_6::S_333 => {
                _fp_value_1 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x374794 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_335;
            }
            C2Rust_Block_6::S_335 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_337;
            }
            C2Rust_Block_6::S_337 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_6 = C2Rust_Block_6::S_344;
            }
            C2Rust_Block_6::S_344 => {
                _t_1 = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_346;
            }
            C2Rust_Block_6::S_346 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_348;
            }
            C2Rust_Block_6::S_348 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = _t_1;
                c2rust_current_block_6 = C2Rust_Block_6::S_352;
            }
            C2Rust_Block_6::S_352 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = ldexp(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize] as ::core::ffi::c_int,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_354;
            }
            C2Rust_Block_6::S_354 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_356;
            }
            C2Rust_Block_6::S_356 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_359;
            }
            C2Rust_Block_6::S_359 => {
                _t_2 = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_6 = C2Rust_Block_6::S_365;
            }
            C2Rust_Block_6::S_365 => {
                _fp_value_2 = _t_2;
                c2rust_current_block_6 = C2Rust_Block_6::S_367;
            }
            C2Rust_Block_6::S_367 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_369;
            }
            C2Rust_Block_6::S_369 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                c2rust_current_block_6 = C2Rust_Block_6::S_377;
            }
            C2Rust_Block_6::S_377 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_379;
            }
            C2Rust_Block_6::S_379 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x374784 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x374784 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x374784 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x374784 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_6 = C2Rust_Block_6::S_381;
            }
            C2Rust_Block_6::S_381 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_383;
            }
            C2Rust_Block_6::S_383 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_385;
            }
            C2Rust_Block_6::S_385 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_387;
            }
            C2Rust_Block_6::S_387 => {
                _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_389;
            }
            C2Rust_Block_6::S_389 => {
                if _fa & 0x41 as uint32_t != 0 {
                    c2rust_current_block_6 = C2Rust_Block_6::S_408;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_398;
                }
            }
            C2Rust_Block_6::S_398 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x3747a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_double,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_double,
                                >(
                                    (0x3747a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ),
                    )
                };
                c2rust_current_block_6 = C2Rust_Block_6::S_408;
            }
            C2Rust_Block_6::S_408 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_6 = C2Rust_Block_6::S_410;
            }
            C2Rust_Block_6::S_410 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_412;
            }
            C2Rust_Block_6::S_412 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_422;
            }
            C2Rust_Block_6::S_422 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_6 = C2Rust_Block_6::S_424;
            }
            C2Rust_Block_6::S_424 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_426;
            }
            C2Rust_Block_6::S_426 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_432;
            }
            C2Rust_Block_6::S_432 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-148 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_434;
            }
            C2Rust_Block_6::S_434 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                c2rust_current_block_6 = C2Rust_Block_6::S_436;
            }
            C2Rust_Block_6::S_436 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_438;
            }
            C2Rust_Block_6::S_438 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_440;
            }
            C2Rust_Block_6::S_440 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_442;
            }
            C2Rust_Block_6::S_442 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-138 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ebx),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_444;
            }
            C2Rust_Block_6::S_444 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_446;
            }
            C2Rust_Block_6::S_446 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_448;
            }
            C2Rust_Block_6::S_448 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_450;
            }
            C2Rust_Block_6::S_450 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_452;
            }
            C2Rust_Block_6::S_452 => {
                if _fa != _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_516;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_461;
                }
            }
            C2Rust_Block_6::S_461 => {
                (*__gamepkg_tls_g_df) = 0 as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_463;
            }
            C2Rust_Block_6::S_463 => {
                (*__gamepkg_tls_g_esi) = ebp.wrapping_add(8 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_465;
            }
            C2Rust_Block_6::S_465 => {
                (*__gamepkg_tls_g_edi) = ebp
                    .wrapping_add(-134 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_467;
            }
            C2Rust_Block_6::S_467 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_469;
            }
            C2Rust_Block_6::S_469 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_471;
            }
            C2Rust_Block_6::S_471 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_473;
            }
            C2Rust_Block_6::S_473 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_475;
            }
            C2Rust_Block_6::S_475 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_477;
            }
            C2Rust_Block_6::S_477 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_479;
            }
            C2Rust_Block_6::S_479 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_481;
            }
            C2Rust_Block_6::S_481 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_483;
            }
            C2Rust_Block_6::S_483 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_485;
            }
            C2Rust_Block_6::S_485 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_487;
            }
            C2Rust_Block_6::S_487 => {
                if _fa == _fb {
                    c2rust_current_block_6 = C2Rust_Block_6::S_516;
                } else {
                    c2rust_current_block_6 = C2Rust_Block_6::S_496;
                }
            }
            C2Rust_Block_6::S_496 => {
                (*__gamepkg_tls_g_esi) = ebp.wrapping_add(0x10 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_498;
            }
            C2Rust_Block_6::S_498 => {
                (*__gamepkg_tls_g_edi) = ebp
                    .wrapping_add(-126 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_500;
            }
            C2Rust_Block_6::S_500 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_502;
            }
            C2Rust_Block_6::S_502 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_504;
            }
            C2Rust_Block_6::S_504 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_506;
            }
            C2Rust_Block_6::S_506 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_508;
            }
            C2Rust_Block_6::S_508 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_510;
            }
            C2Rust_Block_6::S_510 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(
                        (if (*__gamepkg_tls_g_df) != 0 {
                            -(4 as ::core::ffi::c_int as int32_t)
                        } else {
                            4 as ::core::ffi::c_int as int32_t
                        }) as uint32_t,
                    );
                c2rust_current_block_6 = C2Rust_Block_6::S_516;
            }
            C2Rust_Block_6::S_516 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(-118 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_518;
            }
            C2Rust_Block_6::S_518 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_520;
            }
            C2Rust_Block_6::S_520 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-142 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_522;
            }
            C2Rust_Block_6::S_522 => {
                (*__gamepkg_tls_g_ebx) = ebp
                    .wrapping_add(-164 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_528;
            }
            C2Rust_Block_6::S_528 => {
                _pv_1 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_6 = C2Rust_Block_6::S_530;
            }
            C2Rust_Block_6::S_530 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_532;
            }
            C2Rust_Block_6::S_532 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_542;
            }
            C2Rust_Block_6::S_542 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_544;
            }
            C2Rust_Block_6::S_544 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_546;
            }
            C2Rust_Block_6::S_546 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_552;
            }
            C2Rust_Block_6::S_552 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-148 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_554;
            }
            C2Rust_Block_6::S_554 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xe as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_556;
            }
            C2Rust_Block_6::S_556 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t)
                    as uint8_t as int8_t as int32_t as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_562;
            }
            C2Rust_Block_6::S_562 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_6 = C2Rust_Block_6::S_564;
            }
            C2Rust_Block_6::S_564 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_566;
            }
            C2Rust_Block_6::S_566 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_576;
            }
            C2Rust_Block_6::S_576 => {
                _pv_4 = 0x24973c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_578;
            }
            C2Rust_Block_6::S_578 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_580;
            }
            C2Rust_Block_6::S_580 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_586;
            }
            C2Rust_Block_6::S_586 => {
                sub_0024BC71();
                c2rust_current_block_6 = C2Rust_Block_6::S_592;
            }
            C2Rust_Block_6::S_592 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_594;
            }
            C2Rust_Block_6::S_594 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_596;
            }
            C2Rust_Block_6::S_596 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_598;
            }
            C2Rust_Block_6::S_598 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_600;
            }
            C2Rust_Block_6::S_600 => {
                _fas = _fa as int32_t;
                c2rust_current_block_6 = C2Rust_Block_6::S_606;
            }
            C2Rust_Block_6::S_606 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_608;
            }
            C2Rust_Block_6::S_608 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_618;
            }
            C2Rust_Block_6::S_618 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_620;
            }
            C2Rust_Block_6::S_620 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_6 = C2Rust_Block_6::S_630;
            }
            C2Rust_Block_6::S_630 => {
                _fp_value_3 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(-118 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_6 = C2Rust_Block_6::S_632;
            }
            C2Rust_Block_6::S_632 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_6 = C2Rust_Block_6::S_634;
            }
            C2Rust_Block_6::S_634 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
                c2rust_current_block_6 = C2Rust_Block_6::S_161;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249749() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xfffffd30 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xfffffd30 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x24975e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024977C();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_control_word),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0xfd as ::core::ffi::c_int) as uint8_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-712 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_4: uint32_t = 0x249774 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_002499B0();
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_5: uint32_t = 0x249779 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_002495FB();
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024977C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xfffffff4 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xfffffff4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                (ebp.wrapping_add(0xe as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff0000 as uint32_t
        | ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
            as ::core::ffi::c_int & 0x7ff0 as ::core::ffi::c_int) as uint16_t
            as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
        & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
        & 0xffff as uint32_t;
    _fb = 0x7ff0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fbs = _fb as int16_t as int32_t;
    's_169: {
        's_151: {
            if _fa != _fb {
                break 's_151;
            }
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_ebx) & 0xffff as uint32_t) as uint16_t
                    as ::core::ffi::c_int | 0x7fff as ::core::ffi::c_int) as uint16_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_ebx) & 0xffff as uint32_t) as uint16_t as uint32_t
                & 0xffff as uint32_t;
            _fas = _fa as int16_t as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    (ebp.wrapping_add(-2 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ((*__gamepkg_tls_g_ebx) & 0xffff as uint32_t) as uint16_t,
            );
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _c: uint32_t = 0xb as ::core::ffi::c_int as uint32_t
                & 31 as uint32_t;
            's_123: {
                if !(_c != 0 && _c < 32 as uint32_t) {
                    break 's_123;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << _c
                    | (*__gamepkg_tls_g_ebx) >> (32 as uint32_t).wrapping_sub(_c);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-6 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-10 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ebx),
            );
            let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (ebp.wrapping_add(-10 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_double;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
            break 's_169;
        }
        let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            ::core::ffi::c_double,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    }
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002498B8() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || 0.0f64 != 0.0f64
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] < 0.0f64 {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] > 0.0f64 {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-159 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_104: {
        if _fa != _fb {
            break 's_104;
        }
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3c66b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
            | ((((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t as ::core::ffi::c_int
                | ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                    as uint8_t as ::core::ffi::c_int) as uint8_t as uint32_t)
                << 8 as ::core::ffi::c_int;
        _fa = ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
            as uint8_t as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        's_96: {
            if _fa == 0 as uint32_t {
                break 's_96;
            }
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-144 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        4 as uint8_t,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00249AB6();
}
#[no_mangle]
pub unsafe extern "C" fn sub_002498E9() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x3c66b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-144 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        3 as uint8_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249906() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value: ::core::ffi::c_double = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x3c66d2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_double;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
            != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-159 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_93: {
        if _fa == _fb {
            break 's_93;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_002498B8();
        return;
    }
    let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value_1: ::core::ffi::c_double = _t_0;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = recomp_frndint(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        (*__gamepkg_tls_g_fp_control_word),
    );
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || 0.0f64 != 0.0f64
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] < 0.0f64 {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] > 0.0f64 {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-159 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    let mut _t_1: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t_1;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            - (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                - (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize],
        )
    };
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || 0.0f64 != 0.0f64
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] < 0.0f64 {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] > 0.0f64 {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = exp2(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    ) - 1.0f64;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249949() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value: ::core::ffi::c_double = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = recomp_frndint(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        (*__gamepkg_tls_g_fp_control_word),
    );
    (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
            != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    {
        2 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        -1 as ::core::ffi::c_int
    } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
        > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize]
    {
        1 as ::core::ffi::c_int
    } else {
        0 as ::core::ffi::c_int
    };
    (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp) == 2 as ::core::ffi::c_int {
        0x4500 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
        0x100 as ::core::ffi::c_uint
    } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
        0 as ::core::ffi::c_uint
    } else {
        0x4000 as ::core::ffi::c_uint
    }) as uint16_t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
    's_127: {
        's_135: {
            if _fa & 0x40 as uint32_t == 0 {
                break 's_135;
            }
            let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            let mut _fp_value_0: ::core::ffi::c_double = _t_0;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
            {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3c66e6 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
            } else {
                recomp_fp_round24(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x3c66e6 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                )
            };
            let mut _t_1: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            let mut _fp_value_1: ::core::ffi::c_double = _t_1;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = recomp_frndint(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                (*__gamepkg_tls_g_fp_control_word),
            );
            (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize]
                != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
            {
                2 as ::core::ffi::c_int
            } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize]
            {
                -1 as ::core::ffi::c_int
            } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize]
            {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            };
            (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                == 2 as ::core::ffi::c_int
            {
                0x4500 as ::core::ffi::c_uint
            } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                0x100 as ::core::ffi::c_uint
            } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                0 as ::core::ffi::c_uint
            } else {
                0x4000 as ::core::ffi::c_uint
            }) as uint16_t;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                    | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                    as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
            's_121: {
                if _fa & 0x40 as uint32_t == 0 {
                    break 's_121;
                }
                (*__gamepkg_tls_g_eax) = 2 as uint32_t;
                break 's_127;
            }
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            break 's_127;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002499B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fb = 5 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_69: {
        's_63: {
            if _fa != _fb {
                break 's_63;
            }
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff0000 as uint32_t
                | ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff00ff as uint32_t
                | ((((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    | 2 as ::core::ffi::c_int) as uint8_t as uint32_t)
                    << 8 as ::core::ffi::c_int;
            _fa = ((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff00ff as uint32_t
                | ((((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0xfe as ::core::ffi::c_int) as uint8_t as uint32_t)
                    << 8 as ::core::ffi::c_int;
            _fa = ((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
                | 0x3f as ::core::ffi::c_int as uint8_t as uint32_t;
            break 's_69;
        }
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff0000 as uint32_t
            | 0x133f as ::core::ffi::c_int as uint16_t as uint32_t;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-162 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ebx) & 0xffff as uint32_t) as uint16_t,
    );
    (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-162 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = 0x3c672c as uint32_t;
    (*__gamepkg_tls_g_fp_cc) = recomp_fxam(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-148 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-144 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint8_t,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-159 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ((((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int)
            << 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as int8_t as int32_t
            >> (1 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t
            as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ROL8(
            ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
            1 as ::core::ffi::c_int,
        ) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ebx)
                    .wrapping_add(
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as uint32_t,
                    ) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
        as int8_t as int32_t as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0x404 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_edx);
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_155: {
        if !_fn.is_none() {
            break 's_155;
        }
        _fn = recomp_lookup(_va);
    }
    's_161: {
        if !_fn.is_none() {
            break 's_161;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_188: {
        's_167: {
            if _fn.is_some() {
                break 's_167;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_188;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249A17() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    _fa = ::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0xe as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xff as uint32_t;
    _fb = 5 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_69: {
        's_63: {
            if _fa != _fb {
                break 's_63;
            }
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff0000 as uint32_t
                | ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        (ebp.wrapping_add(-164 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff00ff as uint32_t
                | ((((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    | 2 as ::core::ffi::c_int) as uint8_t as uint32_t)
                    << 8 as ::core::ffi::c_int;
            _fa = ((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff00ff as uint32_t
                | ((((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0xfe as ::core::ffi::c_int) as uint8_t as uint32_t)
                    << 8 as ::core::ffi::c_int;
            _fa = ((*__gamepkg_tls_g_ebx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
                | 0x3f as ::core::ffi::c_int as uint8_t as uint32_t;
            break 's_69;
        }
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffff0000 as uint32_t
            | 0x133f as ::core::ffi::c_int as uint16_t as uint32_t;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-162 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ebx) & 0xffff as uint32_t) as uint16_t,
    );
    (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-162 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = 0x3c672c as uint32_t;
    (*__gamepkg_tls_g_fp_cc) = recomp_fxam(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-148 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-144 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint8_t,
    );
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-159 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_fp_cc) = recomp_fxam(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(-160 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            << 11 as ::core::ffi::c_int
            | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t,
    );
    let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t_0;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
        | (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                (ebp.wrapping_add(-159 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t) << 8 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
        | (((((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
            as uint8_t as ::core::ffi::c_int) << 1 as ::core::ffi::c_int) as uint8_t
            as uint32_t) << 8 as ::core::ffi::c_int;
    _fa = ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
        | ((((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
            as uint8_t as int8_t as int32_t
            >> (1 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t
            as uint8_t as uint32_t) << 8 as ::core::ffi::c_int;
    _fa = ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
        | (ROL8(
            ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t,
            1 as ::core::ffi::c_int,
        ) as uint32_t) << 8 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_ecx) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
            as uint8_t as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ebx)
                    .wrapping_add(
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as uint32_t,
                    ) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff00ff as uint32_t
        | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t)
            << 8 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ((((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int)
            << 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as int8_t as int32_t
            >> (1 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t
            as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ROL8(
            ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
            1 as ::core::ffi::c_int,
        ) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ebx)
                    .wrapping_add(
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as uint32_t,
                    ) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff00ff as uint32_t
        | (((((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
            as uint8_t as ::core::ffi::c_int) << 1 as ::core::ffi::c_int) as uint8_t
            as uint32_t) << 8 as ::core::ffi::c_int;
    _fa = ((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff00ff as uint32_t
        | (((((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
            as uint8_t as ::core::ffi::c_int) << 1 as ::core::ffi::c_int) as uint8_t
            as uint32_t) << 8 as ::core::ffi::c_int;
    _fa = ((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
        as uint8_t as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            | ((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t)
                as uint8_t as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
        as int8_t as int32_t as uint32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0x404 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_edx);
    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add((*__gamepkg_tls_g_eax));
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _va: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _fn: recomp_func_t = recomp_lookup_manual(_va);
    's_223: {
        if !_fn.is_none() {
            break 's_223;
        }
        _fn = recomp_lookup(_va);
    }
    's_229: {
        if !_fn.is_none() {
            break 's_229;
        }
        _fn = recomp_lookup_kernel(_va);
    }
    's_256: {
        's_235: {
            if _fn.is_some() {
                break 's_235;
            }
            recomp_icall_fail_log(_va);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            break 's_256;
        }
        _fn.expect("non-null function pointer")();
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249AA8() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249ABD() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    let mut _fp_value: ::core::ffi::c_double = 1.0f64;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249B69() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            (ebp.wrapping_add(-144 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint8_t,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            | ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249B73() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
            | ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int) as uint8_t as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    's_39: {
        if _fa == 0 as uint32_t {
            break 's_39;
        }
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249B7C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xffffffe0 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xffffffe0 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00249B9C();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249B93() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    _fb = 0xffffffe0 as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xffffffe0 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = ebp.wrapping_add(8 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x249bbc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_0024BC71();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_double,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    _fa = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xffff as uint32_t;
    _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fbs = _fb as int16_t as int32_t;
    's_185: {
        if _fa == _fb {
            break 's_185;
        }
        (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249B9C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = ebp.wrapping_add(8 as uint32_t);
    (*__gamepkg_tls_g_ecx) = ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x249bbc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024BC71();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_double,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    _fa = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xffff as uint32_t;
    _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fbs = _fb as int16_t as int32_t;
    's_151: {
        if _fa == _fb {
            break 's_151;
        }
        (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249BD0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    let mut _fp_value: ::core::ffi::c_double = _t;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = recomp_frndint(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        (*__gamepkg_tls_g_fp_control_word),
    );
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            - (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                - (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize],
        )
    };
    let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = _t_0;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = exp2(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    ) - 1.0f64;
    let mut _fp_value_0: ::core::ffi::c_double = 1.0f64;
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize]
                + (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        )
    };
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = ldexp(
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] as ::core::ffi::c_int,
    );
    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top) + 1 as ::core::ffi::c_int)
        as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
        as usize];
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249BE5() {
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0x300 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) | 0x7f as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(6 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t,
    );
    (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(6 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249BFC() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0x80000 as uint32_t & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_45: {
        if _fa == _fb {
            break 's_45;
        }
        (*__gamepkg_tls_g_eax) = 7 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
        as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
    {
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            + ::core::ptr::read_volatile::<
                ::core::ffi::c_double,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_double,
                >(
                    (0x3747b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
    } else {
        recomp_fp_round24(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                + ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
        )
    };
    (*__gamepkg_tls_g_eax) = 1 as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249C15() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7ff00000 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x7ff00000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_47: {
        if _fa != _fb {
            break 's_47;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0xa as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0x7fff0000 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(6 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _c: uint32_t = 0xb as ::core::ffi::c_int as uint32_t & 31 as uint32_t;
        's_107: {
            if !(_c != 0 && _c < 32 as uint32_t) {
                break 's_107;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) << _c
                | (*__gamepkg_tls_g_ecx) >> (32 as uint32_t).wrapping_sub(_c);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) << 0xb as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        let mut _fp_value_0: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
        _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xa as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0 as uint32_t & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
        ::core::ffi::c_double,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
        .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
        as ::core::ffi::c_int;
    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249C58() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7ff00000 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x7ff00000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_51: {
        if _fa == _fb {
            break 's_51;
        }
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249C6E() {
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint16_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint16_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as uint32_t & 0xffff as uint32_t;
    _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fbs = _fb as int16_t as int32_t;
    's_45: {
        if _fa == _fb {
            break 's_45;
        }
        (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249C7B() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
        | ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
        & 0xffff as uint32_t;
    _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
    _fas = _fa as int16_t as int32_t;
    _fbs = _fb as int16_t as int32_t;
    's_121: {
        if _fa == _fb {
            break 's_121;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint16_t
                as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
            & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        's_111: {
            if _fa == 0 as uint32_t {
                break 's_111;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                    | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                    as uint32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint16_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
                & 0xffff as uint32_t;
            _fas = _fa as int16_t as int32_t;
            if _fa == 0 as uint32_t {
                break 's_111;
            }
            (*__gamepkg_tls_g_eax) = 8 as uint32_t;
            let mut _pv: uint32_t = 0x249c9e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv,
            );
            sub_00249B93();
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249CA5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7ff00000 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_00249CCD();
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249CB9() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_double,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x7ff00000 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_131: {
        's_258: {
            if _fa == 0 as uint32_t {
                break 's_258;
            }
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0x7ff00000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_337: {
                if _fa == _fb {
                    break 's_337;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                _fas = _fa as int16_t as int32_t;
                _fbs = _fb as int16_t as int32_t;
                's_238: {
                    if _fa == _fb {
                        break 's_238;
                    }
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffff0000 as uint32_t
                        | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                            as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int)
                            as uint16_t as uint32_t;
                    _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as uint32_t & 0xffff as uint32_t;
                    _fas = _fa as int16_t as int32_t;
                    's_228: {
                        if _fa != 0 as uint32_t {
                            break 's_228;
                        }
                        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                            & 0xffff0000 as uint32_t
                            | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                                & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                                | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint)
                                as uint16_t as uint32_t;
                        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                            & 0xffff0000 as uint32_t
                            | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                                as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int)
                                as uint16_t as uint32_t;
                        _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                            as uint32_t & 0xffff as uint32_t;
                        _fas = _fa as int16_t as int32_t;
                        if _fa == 0 as uint32_t {
                            break 's_228;
                        }
                        (*__gamepkg_tls_g_eax) = 8 as uint32_t;
                        break 's_131;
                    }
                    (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
                        uint16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint16_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                }
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            let mut _fp_value_1: ::core::ffi::c_double = ::core::ptr::read_volatile::<
                ::core::ffi::c_double,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_double,
                >(
                    (0x3747d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
            let mut _t_1: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize];
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize] = _t_1;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = ldexp(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] as ::core::ffi::c_int,
            );
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            let mut _t_2: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            let mut _fp_value_2: ::core::ffi::c_double = _t_2;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
            );
            (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize]
                != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                || ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                    != ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
            {
                2 as ::core::ffi::c_int
            } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                < ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
            {
                -1 as ::core::ffi::c_int
            } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                > ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
            {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            };
            (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                == 2 as ::core::ffi::c_int
            {
                0x4500 as ::core::ffi::c_uint
            } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                0x100 as ::core::ffi::c_uint
            } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                0 as ::core::ffi::c_uint
            } else {
                0x4000 as ::core::ffi::c_uint
            }) as uint16_t;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                    | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                    as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
            (*__gamepkg_tls_g_eax) = 3 as uint32_t;
            if _fa & 0x41 as uint32_t != 0 {
                break 's_131;
            }
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
            {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3747e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
            } else {
                recomp_fp_round24(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x3747e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                )
            };
            break 's_131;
        }
        let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            ::core::ffi::c_double,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_double,
            >(
                (0x3747e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
        let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize];
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = _t;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = ldexp(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize] as ::core::ffi::c_int,
        );
        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint & 7 as ::core::ffi::c_uint)
            as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize];
        let mut _fp_value_0: ::core::ffi::c_double = _t_0;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
        );
        (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
            as usize] != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            || ::core::ptr::read_volatile::<
                ::core::ffi::c_double,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_double,
                >(
                    (0x3747d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
                != ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
        {
            2 as ::core::ffi::c_int
        } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            < ::core::ptr::read_volatile::<
                ::core::ffi::c_double,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_double,
                >(
                    (0x3747d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
        {
            -1 as ::core::ffi::c_int
        } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
            > ::core::ptr::read_volatile::<
                ::core::ffi::c_double,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_double,
                >(
                    (0x3747d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            )
        {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
        (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
            == 2 as ::core::ffi::c_int
        {
            0x4500 as ::core::ffi::c_uint
        } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
            0x100 as ::core::ffi::c_uint
        } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
            0 as ::core::ffi::c_uint
        } else {
            0x4000 as ::core::ffi::c_uint
        }) as uint16_t;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
        (*__gamepkg_tls_g_eax) = 4 as uint32_t;
        if _fa & 0x1 as uint32_t == 0 {
            break 's_131;
        }
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
            as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
        {
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                * ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
        } else {
            recomp_fp_round24(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3747f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
            )
        };
    }
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0x1d as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_152: {
        if _fa != _fb {
            break 's_152;
        }
        let mut _pv_0: uint32_t = 0x249d03 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_00249B7C();
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv: uint32_t = 0x249cfc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00249B93();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249CCD() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0x7ff00000 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_92: {
        's_35: {
            if _fa != _fb {
                break 's_35;
            }
            let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
                ::core::ffi::c_double,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_double,
                >(
                    (0x3747d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
            let mut _t: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize];
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize] = _t;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = ldexp(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] as ::core::ffi::c_int,
            );
            (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                & 7 as ::core::ffi::c_uint) as usize] = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            let mut _t_0: ::core::ffi::c_double = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize];
            let mut _fp_value_0: ::core::ffi::c_double = _t_0;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = fabs(
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
            );
            (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                as usize]
                != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                || ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                    != ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
            {
                2 as ::core::ffi::c_int
            } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                < ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
            {
                -1 as ::core::ffi::c_int
            } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                > ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3747c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
            {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            };
            (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                == 2 as ::core::ffi::c_int
            {
                0x4500 as ::core::ffi::c_uint
            } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                0x100 as ::core::ffi::c_uint
            } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                0 as ::core::ffi::c_uint
            } else {
                0x4000 as ::core::ffi::c_uint
            }) as uint16_t;
            (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                as ::core::ffi::c_uint)
                .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                as ::core::ffi::c_int;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                    | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                    as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int & 0xff as uint32_t;
            (*__gamepkg_tls_g_eax) = 3 as uint32_t;
            if _fa & 0x41 as uint32_t != 0 {
                break 's_92;
            }
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
            {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    * ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x3747e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
            } else {
                recomp_fp_round24(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x3747e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                )
            };
            break 's_92;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
            | ::core::ptr::read_volatile::<
                uint16_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
            & 0xffff as uint32_t;
        _fb = 0x27f as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        _fbs = _fb as int16_t as int32_t;
        's_199: {
            if _fa == _fb {
                break 's_199;
            }
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint16_t
                    as uint32_t;
            _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t as uint32_t
                & 0xffff as uint32_t;
            _fas = _fa as int16_t as int32_t;
            's_189: {
                if _fa != 0 as uint32_t {
                    break 's_189;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                        as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint16_t
                        as uint32_t;
                _fa = ((*__gamepkg_tls_g_eax) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                _fas = _fa as int16_t as int32_t;
                if _fa == 0 as uint32_t {
                    break 's_189;
                }
                (*__gamepkg_tls_g_eax) = 8 as uint32_t;
                break 's_92;
            }
            (*__gamepkg_tls_g_fp_control_word) = ::core::ptr::read_volatile::<
                uint16_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0x1d as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_113: {
        if _fa != _fb {
            break 's_113;
        }
        let mut _pv_0: uint32_t = 0x249d03 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        sub_00249B7C();
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv: uint32_t = 0x249cfc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00249B93();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249D5C() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _fp_value_3: ::core::ffi::c_double = 0.;
    let mut _pv_11: uint32_t = 0;
    enum C2Rust_Block_35 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_46,
        S_48,
        S_50,
        S_60,
        S_62,
        S_64,
        S_74,
        S_76,
        S_78,
        S_88,
        S_90,
        S_92,
        S_102,
        S_104,
        S_106,
        S_112,
        S_114,
        S_116,
        S_118,
        S_124,
        S_126,
        S_128,
        S_134,
        S_140,
        S_142,
        S_144,
        S_146,
        S_152,
        S_154,
        S_164,
        S_166,
        S_172,
        S_185,
        S_187,
        S_189,
        S_199,
        S_201,
        S_203,
        S_213,
        S_215,
        S_217,
        S_223,
        S_225,
        S_227,
        S_229,
        S_235,
        S_237,
        S_239,
        S_245,
        S_255,
        S_257,
        S_259,
        S_265,
        S_267,
        S_269,
        S_271,
        S_277,
        S_279,
        S_289,
        S_291,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_320,
        S_322,
        S_324,
        S_334,
        S_336,
        S_338,
        S_344,
        S_350,
        S_352,
        S_354,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_374,
        S_376,
        S_378,
        S_384,
        S_394,
        S_396,
        S_398,
        S_408,
        S_410,
        S_416,
        S_418,
        S_420,
        S_422,
        S_428,
        S_430,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_459,
        S_461,
        S_463,
        S_473,
        S_475,
        S_481,
        S_487,
        S_489,
        S_495,
        S_497,
        S_503,
        S_505,
        S_507,
        S_509,
        S_511,
        S_513,
        S_515,
        S_517,
        S_523,
        S_525,
        S_531,
        S_533,
        S_539,
        S_541,
        S_543,
        S_545,
        S_551,
        S_553,
        S_559,
        S_561,
    }
    let mut c2rust_current_block_35: C2Rust_Block_35;
    c2rust_current_block_35 = C2Rust_Block_35::S_0;
    loop {
        match c2rust_current_block_35 {
            C2Rust_Block_35::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_2;
            }
            C2Rust_Block_35::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_35 = C2Rust_Block_35::S_4;
            }
            C2Rust_Block_35::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_6;
            }
            C2Rust_Block_35::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_8;
            }
            C2Rust_Block_35::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_26;
            }
            C2Rust_Block_35::S_26 => {
                _pv = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_28;
            }
            C2Rust_Block_35::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_30;
            }
            C2Rust_Block_35::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_36;
            }
            C2Rust_Block_35::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_35 = C2Rust_Block_35::S_38;
            }
            C2Rust_Block_35::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_40;
            }
            C2Rust_Block_35::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_46;
            }
            C2Rust_Block_35::S_46 => {
                _pv_0 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_48;
            }
            C2Rust_Block_35::S_48 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_50;
            }
            C2Rust_Block_35::S_50 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_60;
            }
            C2Rust_Block_35::S_60 => {
                _pv_1 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_62;
            }
            C2Rust_Block_35::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_64;
            }
            C2Rust_Block_35::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_74;
            }
            C2Rust_Block_35::S_74 => {
                _fp_value = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_76;
            }
            C2Rust_Block_35::S_76 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_78;
            }
            C2Rust_Block_35::S_78 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_35 = C2Rust_Block_35::S_88;
            }
            C2Rust_Block_35::S_88 => {
                _pv_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_90;
            }
            C2Rust_Block_35::S_90 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_92;
            }
            C2Rust_Block_35::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_102;
            }
            C2Rust_Block_35::S_102 => {
                _pv_3 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_104;
            }
            C2Rust_Block_35::S_104 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_106;
            }
            C2Rust_Block_35::S_106 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_112;
            }
            C2Rust_Block_35::S_112 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_114;
            }
            C2Rust_Block_35::S_114 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_116;
            }
            C2Rust_Block_35::S_116 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_118;
            }
            C2Rust_Block_35::S_118 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_124;
            }
            C2Rust_Block_35::S_124 => {
                _pv_4 = 0x249d6e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_126;
            }
            C2Rust_Block_35::S_126 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_128;
            }
            C2Rust_Block_35::S_128 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_134;
            }
            C2Rust_Block_35::S_134 => {
                sub_00244D08();
                c2rust_current_block_35 = C2Rust_Block_35::S_140;
            }
            C2Rust_Block_35::S_140 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 0x90 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_142;
            }
            C2Rust_Block_35::S_142 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_144;
            }
            C2Rust_Block_35::S_144 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_146;
            }
            C2Rust_Block_35::S_146 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_152;
            }
            C2Rust_Block_35::S_152 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_154;
            }
            C2Rust_Block_35::S_154 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_164;
            }
            C2Rust_Block_35::S_164 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_166;
            }
            C2Rust_Block_35::S_166 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_172;
            }
            C2Rust_Block_35::S_172 => {
                if _fa != _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_539;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_185;
                }
            }
            C2Rust_Block_35::S_185 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_187;
            }
            C2Rust_Block_35::S_187 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_189;
            }
            C2Rust_Block_35::S_189 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_35 = C2Rust_Block_35::S_199;
            }
            C2Rust_Block_35::S_199 => {
                _pv_5 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_201;
            }
            C2Rust_Block_35::S_201 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_203;
            }
            C2Rust_Block_35::S_203 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_213;
            }
            C2Rust_Block_35::S_213 => {
                _pv_6 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_215;
            }
            C2Rust_Block_35::S_215 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_217;
            }
            C2Rust_Block_35::S_217 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_223;
            }
            C2Rust_Block_35::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_225;
            }
            C2Rust_Block_35::S_225 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_227;
            }
            C2Rust_Block_35::S_227 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_229;
            }
            C2Rust_Block_35::S_229 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_235;
            }
            C2Rust_Block_35::S_235 => {
                _pv_7 = 0x249d81 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_237;
            }
            C2Rust_Block_35::S_237 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_239;
            }
            C2Rust_Block_35::S_239 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_245;
            }
            C2Rust_Block_35::S_245 => {
                sub_00247577();
                c2rust_current_block_35 = C2Rust_Block_35::S_255;
            }
            C2Rust_Block_35::S_255 => {
                _fp_value_1 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_257;
            }
            C2Rust_Block_35::S_257 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_259;
            }
            C2Rust_Block_35::S_259 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_35 = C2Rust_Block_35::S_265;
            }
            C2Rust_Block_35::S_265 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_35 = C2Rust_Block_35::S_267;
            }
            C2Rust_Block_35::S_267 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_269;
            }
            C2Rust_Block_35::S_269 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_271;
            }
            C2Rust_Block_35::S_271 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_277;
            }
            C2Rust_Block_35::S_277 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_279;
            }
            C2Rust_Block_35::S_279 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_289;
            }
            C2Rust_Block_35::S_289 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_291;
            }
            C2Rust_Block_35::S_291 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_297;
            }
            C2Rust_Block_35::S_297 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_299;
            }
            C2Rust_Block_35::S_299 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x44 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_301;
            }
            C2Rust_Block_35::S_301 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_303;
            }
            C2Rust_Block_35::S_303 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_305;
            }
            C2Rust_Block_35::S_305 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_307;
            }
            C2Rust_Block_35::S_307 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_35 = C2Rust_Block_35::S_539;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_320;
                }
            }
            C2Rust_Block_35::S_320 => {
                _fp_value_2 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_322;
            }
            C2Rust_Block_35::S_322 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_324;
            }
            C2Rust_Block_35::S_324 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                c2rust_current_block_35 = C2Rust_Block_35::S_334;
            }
            C2Rust_Block_35::S_334 => {
                _pv_8 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_336;
            }
            C2Rust_Block_35::S_336 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_338;
            }
            C2Rust_Block_35::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_344;
            }
            C2Rust_Block_35::S_344 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        * ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x3b1808 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            * ::core::ptr::read_volatile::<
                                ::core::ffi::c_double,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_double,
                                >(
                                    (0x3b1808 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ),
                    )
                };
                c2rust_current_block_35 = C2Rust_Block_35::S_350;
            }
            C2Rust_Block_35::S_350 => {
                _pv_9 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_352;
            }
            C2Rust_Block_35::S_352 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_354;
            }
            C2Rust_Block_35::S_354 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_360;
            }
            C2Rust_Block_35::S_360 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_362;
            }
            C2Rust_Block_35::S_362 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_364;
            }
            C2Rust_Block_35::S_364 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_366;
            }
            C2Rust_Block_35::S_366 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_368;
            }
            C2Rust_Block_35::S_368 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_374;
            }
            C2Rust_Block_35::S_374 => {
                _pv_10 = 0x249da5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_376;
            }
            C2Rust_Block_35::S_376 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_378;
            }
            C2Rust_Block_35::S_378 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_384;
            }
            C2Rust_Block_35::S_384 => {
                sub_00247577();
                c2rust_current_block_35 = C2Rust_Block_35::S_394;
            }
            C2Rust_Block_35::S_394 => {
                _fp_value_3 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_396;
            }
            C2Rust_Block_35::S_396 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_398;
            }
            C2Rust_Block_35::S_398 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
                c2rust_current_block_35 = C2Rust_Block_35::S_408;
            }
            C2Rust_Block_35::S_408 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_410;
            }
            C2Rust_Block_35::S_410 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_416;
            }
            C2Rust_Block_35::S_416 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        != (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_35 = C2Rust_Block_35::S_418;
            }
            C2Rust_Block_35::S_418 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_420;
            }
            C2Rust_Block_35::S_420 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_422;
            }
            C2Rust_Block_35::S_422 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_428;
            }
            C2Rust_Block_35::S_428 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_430;
            }
            C2Rust_Block_35::S_430 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_436;
            }
            C2Rust_Block_35::S_436 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_438;
            }
            C2Rust_Block_35::S_438 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x44 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_440;
            }
            C2Rust_Block_35::S_440 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_442;
            }
            C2Rust_Block_35::S_442 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_444;
            }
            C2Rust_Block_35::S_444 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_446;
            }
            C2Rust_Block_35::S_446 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_35 = C2Rust_Block_35::S_503;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_459;
                }
            }
            C2Rust_Block_35::S_459 => {
                _pv_11 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_461;
            }
            C2Rust_Block_35::S_461 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_463;
            }
            C2Rust_Block_35::S_463 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_473;
            }
            C2Rust_Block_35::S_473 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_475;
            }
            C2Rust_Block_35::S_475 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_481;
            }
            C2Rust_Block_35::S_481 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_487;
            }
            C2Rust_Block_35::S_487 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_489;
            }
            C2Rust_Block_35::S_489 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_495;
            }
            C2Rust_Block_35::S_495 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_497;
            }
            C2Rust_Block_35::S_497 => return,
            C2Rust_Block_35::S_503 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_505;
            }
            C2Rust_Block_35::S_505 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_507;
            }
            C2Rust_Block_35::S_507 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_509;
            }
            C2Rust_Block_35::S_509 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_35 = C2Rust_Block_35::S_511;
            }
            C2Rust_Block_35::S_511 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_513;
            }
            C2Rust_Block_35::S_513 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_515;
            }
            C2Rust_Block_35::S_515 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_517;
            }
            C2Rust_Block_35::S_517 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_523;
            }
            C2Rust_Block_35::S_523 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_525;
            }
            C2Rust_Block_35::S_525 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_531;
            }
            C2Rust_Block_35::S_531 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_533;
            }
            C2Rust_Block_35::S_533 => return,
            C2Rust_Block_35::S_539 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_541;
            }
            C2Rust_Block_35::S_541 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_543;
            }
            C2Rust_Block_35::S_543 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_545;
            }
            C2Rust_Block_35::S_545 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_551;
            }
            C2Rust_Block_35::S_551 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_553;
            }
            C2Rust_Block_35::S_553 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_559;
            }
            C2Rust_Block_35::S_559 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_561;
            }
            C2Rust_Block_35::S_561 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249DC1() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_cc = unsafe { gamepkg_tls_g_fp_cc() };
    let __gamepkg_tls_g_fp_cmp = unsafe { gamepkg_tls_g_fp_cmp() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_0: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _fp_value_1: ::core::ffi::c_double = 0.;
    let mut _fp_value_2: ::core::ffi::c_double = 0.;
    let mut _fp_value_3: ::core::ffi::c_double = 0.;
    let mut _fp_value_4: ::core::ffi::c_double = 0.;
    let mut _fp_value_5: ::core::ffi::c_double = 0.;
    let mut _fp_value_6: ::core::ffi::c_double = 0.;
    let mut _fp_value_7: ::core::ffi::c_double = 0.;
    let mut _fp_value_8: ::core::ffi::c_double = 0.;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _fp_value_9: ::core::ffi::c_double = 0.;
    let mut _fp_value_10: ::core::ffi::c_double = 0.;
    let mut _t: ::core::ffi::c_double = 0.;
    let mut _fp_value_11: ::core::ffi::c_double = 0.;
    let mut _fp_value_12: ::core::ffi::c_double = 0.;
    let mut _fp_value_13: ::core::ffi::c_double = 0.;
    let mut _fp_value_14: ::core::ffi::c_double = 0.;
    let mut _fp_value_15: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_36 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_46,
        S_48,
        S_50,
        S_60,
        S_62,
        S_64,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_105,
        S_111,
        S_113,
        S_115,
        S_117,
        S_119,
        S_121,
        S_123,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_149,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_163,
        S_172,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_211,
        S_213,
        S_215,
        S_221,
        S_223,
        S_225,
        S_227,
        S_229,
        S_231,
        S_233,
        S_241,
        S_243,
        S_245,
        S_247,
        S_249,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_298,
        S_304,
        S_306,
        S_308,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_351,
        S_353,
        S_355,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_407,
        S_409,
        S_411,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_446,
        S_448,
        S_450,
        S_466,
        S_468,
        S_470,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_507,
        S_509,
        S_511,
        S_527,
        S_529,
        S_531,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_560,
        S_562,
        S_564,
        S_566,
        S_568,
        S_581,
        S_583,
        S_585,
        S_595,
        S_597,
        S_599,
        S_609,
        S_611,
        S_613,
        S_619,
        S_621,
        S_623,
        S_625,
        S_631,
        S_633,
        S_635,
        S_641,
        S_651,
        S_653,
        S_655,
        S_665,
        S_667,
        S_673,
        S_675,
        S_677,
        S_683,
        S_685,
        S_691,
        S_693,
        S_695,
        S_697,
        S_699,
        S_701,
        S_703,
        S_712,
        S_714,
        S_716,
        S_718,
        S_724,
        S_726,
        S_728,
        S_734,
        S_743,
        S_749,
        S_752,
        S_758,
        S_760,
        S_762,
        S_770,
        S_772,
        S_774,
        S_786,
        S_788,
        S_790,
        S_796,
        S_798,
        S_800,
        S_802,
        S_804,
        S_806,
        S_808,
        S_810,
        S_812,
        S_821,
        S_823,
        S_825,
        S_827,
        S_829,
        S_842,
        S_844,
        S_846,
        S_862,
        S_864,
        S_866,
        S_882,
        S_884,
        S_886,
        S_896,
        S_902,
        S_904,
        S_910,
        S_916,
        S_918,
        S_928,
        S_930,
        S_936,
        S_938,
    }
    let mut c2rust_current_block_36: C2Rust_Block_36;
    c2rust_current_block_36 = C2Rust_Block_36::S_0;
    loop {
        match c2rust_current_block_36 {
            C2Rust_Block_36::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_2;
            }
            C2Rust_Block_36::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_36 = C2Rust_Block_36::S_4;
            }
            C2Rust_Block_36::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_6;
            }
            C2Rust_Block_36::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_8;
            }
            C2Rust_Block_36::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_26;
            }
            C2Rust_Block_36::S_26 => {
                _pv = ebp;
                c2rust_current_block_36 = C2Rust_Block_36::S_28;
            }
            C2Rust_Block_36::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_30;
            }
            C2Rust_Block_36::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_36;
            }
            C2Rust_Block_36::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_36 = C2Rust_Block_36::S_38;
            }
            C2Rust_Block_36::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_36 = C2Rust_Block_36::S_40;
            }
            C2Rust_Block_36::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_36 = C2Rust_Block_36::S_46;
            }
            C2Rust_Block_36::S_46 => {
                _fp_value = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_48;
            }
            C2Rust_Block_36::S_48 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_50;
            }
            C2Rust_Block_36::S_50 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_36 = C2Rust_Block_36::S_60;
            }
            C2Rust_Block_36::S_60 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_36 = C2Rust_Block_36::S_62;
            }
            C2Rust_Block_36::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_64;
            }
            C2Rust_Block_36::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_70;
            }
            C2Rust_Block_36::S_70 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_72;
            }
            C2Rust_Block_36::S_72 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_74;
            }
            C2Rust_Block_36::S_74 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_76;
            }
            C2Rust_Block_36::S_76 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_78;
            }
            C2Rust_Block_36::S_78 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_80;
            }
            C2Rust_Block_36::S_80 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_82;
            }
            C2Rust_Block_36::S_82 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_84;
            }
            C2Rust_Block_36::S_84 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_86;
            }
            C2Rust_Block_36::S_86 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_88;
            }
            C2Rust_Block_36::S_88 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 5 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_90;
            }
            C2Rust_Block_36::S_90 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_92;
            }
            C2Rust_Block_36::S_92 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_94;
            }
            C2Rust_Block_36::S_94 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_96;
            }
            C2Rust_Block_36::S_96 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_36 = C2Rust_Block_36::S_111;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_105;
                }
            }
            C2Rust_Block_36::S_105 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_36 = C2Rust_Block_36::S_111;
            }
            C2Rust_Block_36::S_111 => {
                (*__gamepkg_tls_g_eax) = 0x7ff00000 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_113;
            }
            C2Rust_Block_36::S_113 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_115;
            }
            C2Rust_Block_36::S_115 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_117;
            }
            C2Rust_Block_36::S_117 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_119;
            }
            C2Rust_Block_36::S_119 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_121;
            }
            C2Rust_Block_36::S_121 => {
                (*__gamepkg_tls_g_ecx) = 0xfff00000 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_123;
            }
            C2Rust_Block_36::S_123 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_241;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_132;
                }
            }
            C2Rust_Block_36::S_132 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_134;
            }
            C2Rust_Block_36::S_134 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_136;
            }
            C2Rust_Block_36::S_136 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_138;
            }
            C2Rust_Block_36::S_138 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_140;
            }
            C2Rust_Block_36::S_140 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_367;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_149;
                }
            }
            C2Rust_Block_36::S_149 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_151;
            }
            C2Rust_Block_36::S_151 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_153;
            }
            C2Rust_Block_36::S_153 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_155;
            }
            C2Rust_Block_36::S_155 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_157;
            }
            C2Rust_Block_36::S_157 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_159;
            }
            C2Rust_Block_36::S_159 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_161;
            }
            C2Rust_Block_36::S_161 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_163;
            }
            C2Rust_Block_36::S_163 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_180;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_172;
                }
            }
            C2Rust_Block_36::S_172 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_446;
            }
            C2Rust_Block_36::S_180 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_182;
            }
            C2Rust_Block_36::S_182 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_184;
            }
            C2Rust_Block_36::S_184 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_186;
            }
            C2Rust_Block_36::S_186 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_188;
            }
            C2Rust_Block_36::S_188 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 5 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_190;
            }
            C2Rust_Block_36::S_190 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_192;
            }
            C2Rust_Block_36::S_192 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_194;
            }
            C2Rust_Block_36::S_194 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_196;
            }
            C2Rust_Block_36::S_196 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_198;
            }
            C2Rust_Block_36::S_198 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) == 0 {
                    c2rust_current_block_36 = C2Rust_Block_36::S_507;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_211;
                }
            }
            C2Rust_Block_36::S_211 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3c64b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_213;
            }
            C2Rust_Block_36::S_213 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_215;
            }
            C2Rust_Block_36::S_215 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_36 = C2Rust_Block_36::S_221;
            }
            C2Rust_Block_36::S_221 => {
                (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_223;
            }
            C2Rust_Block_36::S_223 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_225;
            }
            C2Rust_Block_36::S_225 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_227;
            }
            C2Rust_Block_36::S_227 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                c2rust_current_block_36 = C2Rust_Block_36::S_229;
            }
            C2Rust_Block_36::S_229 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_231;
            }
            C2Rust_Block_36::S_231 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_233;
            }
            C2Rust_Block_36::S_233 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_902;
            }
            C2Rust_Block_36::S_241 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x14 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_243;
            }
            C2Rust_Block_36::S_243 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_245;
            }
            C2Rust_Block_36::S_245 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_247;
            }
            C2Rust_Block_36::S_247 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_249;
            }
            C2Rust_Block_36::S_249 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_367;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_258;
                }
            }
            C2Rust_Block_36::S_258 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_260;
            }
            C2Rust_Block_36::S_260 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_262;
            }
            C2Rust_Block_36::S_262 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_264;
            }
            C2Rust_Block_36::S_264 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_266;
            }
            C2Rust_Block_36::S_266 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_367;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_275;
                }
            }
            C2Rust_Block_36::S_275 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_277;
            }
            C2Rust_Block_36::S_277 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_279;
            }
            C2Rust_Block_36::S_279 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_281;
            }
            C2Rust_Block_36::S_281 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_283;
            }
            C2Rust_Block_36::S_283 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_285;
            }
            C2Rust_Block_36::S_285 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_287;
            }
            C2Rust_Block_36::S_287 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_289;
            }
            C2Rust_Block_36::S_289 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_320;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_298;
                }
            }
            C2Rust_Block_36::S_298 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_304;
            }
            C2Rust_Block_36::S_304 => {
                _fp_value_1 = 0.0f64;
                c2rust_current_block_36 = C2Rust_Block_36::S_306;
            }
            C2Rust_Block_36::S_306 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_308;
            }
            C2Rust_Block_36::S_308 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_1;
                c2rust_current_block_36 = C2Rust_Block_36::S_896;
            }
            C2Rust_Block_36::S_320 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_322;
            }
            C2Rust_Block_36::S_322 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_324;
            }
            C2Rust_Block_36::S_324 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_326;
            }
            C2Rust_Block_36::S_326 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_328;
            }
            C2Rust_Block_36::S_328 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 5 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_330;
            }
            C2Rust_Block_36::S_330 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_332;
            }
            C2Rust_Block_36::S_332 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_334;
            }
            C2Rust_Block_36::S_334 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_336;
            }
            C2Rust_Block_36::S_336 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_338;
            }
            C2Rust_Block_36::S_338 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_36 = C2Rust_Block_36::S_211;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_351;
                }
            }
            C2Rust_Block_36::S_351 => {
                _fp_value_2 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3c64a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_353;
            }
            C2Rust_Block_36::S_353 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_355;
            }
            C2Rust_Block_36::S_355 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_2;
                c2rust_current_block_36 = C2Rust_Block_36::S_902;
            }
            C2Rust_Block_36::S_367 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_369;
            }
            C2Rust_Block_36::S_369 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_371;
            }
            C2Rust_Block_36::S_371 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_373;
            }
            C2Rust_Block_36::S_373 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_375;
            }
            C2Rust_Block_36::S_375 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_377;
            }
            C2Rust_Block_36::S_377 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_543;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_386;
                }
            }
            C2Rust_Block_36::S_386 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_388;
            }
            C2Rust_Block_36::S_388 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_390;
            }
            C2Rust_Block_36::S_390 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_392;
            }
            C2Rust_Block_36::S_392 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_394;
            }
            C2Rust_Block_36::S_394 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_910;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_407;
                }
            }
            C2Rust_Block_36::S_407 => {
                _fp_value_3 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_409;
            }
            C2Rust_Block_36::S_409 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_411;
            }
            C2Rust_Block_36::S_411 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_3;
                c2rust_current_block_36 = C2Rust_Block_36::S_417;
            }
            C2Rust_Block_36::S_417 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_419;
            }
            C2Rust_Block_36::S_419 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_421;
            }
            C2Rust_Block_36::S_421 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_423;
            }
            C2Rust_Block_36::S_423 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_425;
            }
            C2Rust_Block_36::S_425 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_427;
            }
            C2Rust_Block_36::S_427 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_429;
            }
            C2Rust_Block_36::S_429 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_431;
            }
            C2Rust_Block_36::S_431 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_433;
            }
            C2Rust_Block_36::S_433 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_466;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_446;
                }
            }
            C2Rust_Block_36::S_446 => {
                _fp_value_4 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3c64a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_448;
            }
            C2Rust_Block_36::S_448 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_450;
            }
            C2Rust_Block_36::S_450 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_4;
                c2rust_current_block_36 = C2Rust_Block_36::S_896;
            }
            C2Rust_Block_36::S_466 => {
                _fp_value_5 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_468;
            }
            C2Rust_Block_36::S_468 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_470;
            }
            C2Rust_Block_36::S_470 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_5;
                c2rust_current_block_36 = C2Rust_Block_36::S_476;
            }
            C2Rust_Block_36::S_476 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_478;
            }
            C2Rust_Block_36::S_478 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_480;
            }
            C2Rust_Block_36::S_480 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_482;
            }
            C2Rust_Block_36::S_482 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_484;
            }
            C2Rust_Block_36::S_484 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 5 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_486;
            }
            C2Rust_Block_36::S_486 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_488;
            }
            C2Rust_Block_36::S_488 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_490;
            }
            C2Rust_Block_36::S_490 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_492;
            }
            C2Rust_Block_36::S_492 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_494;
            }
            C2Rust_Block_36::S_494 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_36 = C2Rust_Block_36::S_527;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_507;
                }
            }
            C2Rust_Block_36::S_507 => {
                _fp_value_6 = 0.0f64;
                c2rust_current_block_36 = C2Rust_Block_36::S_509;
            }
            C2Rust_Block_36::S_509 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_511;
            }
            C2Rust_Block_36::S_511 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_6;
                c2rust_current_block_36 = C2Rust_Block_36::S_902;
            }
            C2Rust_Block_36::S_527 => {
                _fp_value_7 = 1.0f64;
                c2rust_current_block_36 = C2Rust_Block_36::S_529;
            }
            C2Rust_Block_36::S_529 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_531;
            }
            C2Rust_Block_36::S_531 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_7;
                c2rust_current_block_36 = C2Rust_Block_36::S_902;
            }
            C2Rust_Block_36::S_543 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_545;
            }
            C2Rust_Block_36::S_545 => {
                _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_547;
            }
            C2Rust_Block_36::S_547 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_549;
            }
            C2Rust_Block_36::S_549 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_551;
            }
            C2Rust_Block_36::S_551 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_910;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_560;
                }
            }
            C2Rust_Block_36::S_560 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_562;
            }
            C2Rust_Block_36::S_562 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_564;
            }
            C2Rust_Block_36::S_564 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_566;
            }
            C2Rust_Block_36::S_566 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_568;
            }
            C2Rust_Block_36::S_568 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_910;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_581;
                }
            }
            C2Rust_Block_36::S_581 => {
                _fp_value_8 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_583;
            }
            C2Rust_Block_36::S_583 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_585;
            }
            C2Rust_Block_36::S_585 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_8;
                c2rust_current_block_36 = C2Rust_Block_36::S_595;
            }
            C2Rust_Block_36::S_595 => {
                _pv_1 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_36 = C2Rust_Block_36::S_597;
            }
            C2Rust_Block_36::S_597 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_599;
            }
            C2Rust_Block_36::S_599 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_609;
            }
            C2Rust_Block_36::S_609 => {
                _pv_2 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_36 = C2Rust_Block_36::S_611;
            }
            C2Rust_Block_36::S_611 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_613;
            }
            C2Rust_Block_36::S_613 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_619;
            }
            C2Rust_Block_36::S_619 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_621;
            }
            C2Rust_Block_36::S_621 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_623;
            }
            C2Rust_Block_36::S_623 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_36 = C2Rust_Block_36::S_625;
            }
            C2Rust_Block_36::S_625 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_36 = C2Rust_Block_36::S_631;
            }
            C2Rust_Block_36::S_631 => {
                _pv_3 = 0x249eba as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_633;
            }
            C2Rust_Block_36::S_633 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_635;
            }
            C2Rust_Block_36::S_635 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_641;
            }
            C2Rust_Block_36::S_641 => {
                sub_00249D5C();
                c2rust_current_block_36 = C2Rust_Block_36::S_651;
            }
            C2Rust_Block_36::S_651 => {
                _fp_value_9 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_653;
            }
            C2Rust_Block_36::S_653 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_655;
            }
            C2Rust_Block_36::S_655 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_9;
                c2rust_current_block_36 = C2Rust_Block_36::S_665;
            }
            C2Rust_Block_36::S_665 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_667;
            }
            C2Rust_Block_36::S_667 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_673;
            }
            C2Rust_Block_36::S_673 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_675;
            }
            C2Rust_Block_36::S_675 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_677;
            }
            C2Rust_Block_36::S_677 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_683;
            }
            C2Rust_Block_36::S_683 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_685;
            }
            C2Rust_Block_36::S_685 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_691;
            }
            C2Rust_Block_36::S_691 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_36 = C2Rust_Block_36::S_693;
            }
            C2Rust_Block_36::S_693 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_695;
            }
            C2Rust_Block_36::S_695 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0x41 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_697;
            }
            C2Rust_Block_36::S_697 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_699;
            }
            C2Rust_Block_36::S_699 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_701;
            }
            C2Rust_Block_36::S_701 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_703;
            }
            C2Rust_Block_36::S_703 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_786;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_712;
                }
            }
            C2Rust_Block_36::S_712 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_714;
            }
            C2Rust_Block_36::S_714 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_716;
            }
            C2Rust_Block_36::S_716 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_718;
            }
            C2Rust_Block_36::S_718 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_724;
            }
            C2Rust_Block_36::S_724 => {
                _fp_value_10 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3c64a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_726;
            }
            C2Rust_Block_36::S_726 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_728;
            }
            C2Rust_Block_36::S_728 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_10;
                c2rust_current_block_36 = C2Rust_Block_36::S_734;
            }
            C2Rust_Block_36::S_734 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_749;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_743;
                }
            }
            C2Rust_Block_36::S_743 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = -(*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize];
                c2rust_current_block_36 = C2Rust_Block_36::S_749;
            }
            C2Rust_Block_36::S_749 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_752;
            }
            C2Rust_Block_36::S_752 => {
                _t = (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize];
                c2rust_current_block_36 = C2Rust_Block_36::S_758;
            }
            C2Rust_Block_36::S_758 => {
                _fp_value_11 = _t;
                c2rust_current_block_36 = C2Rust_Block_36::S_760;
            }
            C2Rust_Block_36::S_760 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_762;
            }
            C2Rust_Block_36::S_762 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_11;
                c2rust_current_block_36 = C2Rust_Block_36::S_770;
            }
            C2Rust_Block_36::S_770 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_772;
            }
            C2Rust_Block_36::S_772 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_774;
            }
            C2Rust_Block_36::S_774 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_910;
            }
            C2Rust_Block_36::S_786 => {
                _fp_value_12 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_788;
            }
            C2Rust_Block_36::S_788 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_790;
            }
            C2Rust_Block_36::S_790 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_12;
                c2rust_current_block_36 = C2Rust_Block_36::S_796;
            }
            C2Rust_Block_36::S_796 => {
                (*__gamepkg_tls_g_fp_cmp) = if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                    as usize]
                    != (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    || ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                        != ::core::ptr::read_volatile::<
                            ::core::ffi::c_double,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_double,
                            >(
                                (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                {
                    2 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    < ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    -1 as ::core::ffi::c_int
                } else if (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    > ::core::ptr::read_volatile::<
                        ::core::ffi::c_double,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_double,
                        >(
                            (0x36c0e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    )
                {
                    1 as ::core::ffi::c_int
                } else {
                    0 as ::core::ffi::c_int
                };
                c2rust_current_block_36 = C2Rust_Block_36::S_798;
            }
            C2Rust_Block_36::S_798 => {
                (*__gamepkg_tls_g_fp_cc) = (if (*__gamepkg_tls_g_fp_cmp)
                    == 2 as ::core::ffi::c_int
                {
                    0x4500 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) < 0 as ::core::ffi::c_int {
                    0x100 as ::core::ffi::c_uint
                } else if (*__gamepkg_tls_g_fp_cmp) > 0 as ::core::ffi::c_int {
                    0 as ::core::ffi::c_uint
                } else {
                    0x4000 as ::core::ffi::c_uint
                }) as uint16_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_800;
            }
            C2Rust_Block_36::S_800 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_802;
            }
            C2Rust_Block_36::S_802 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    | (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) << 11 as ::core::ffi::c_int
                        | (*__gamepkg_tls_g_fp_cc) as ::core::ffi::c_uint) as uint16_t
                        as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_804;
            }
            C2Rust_Block_36::S_804 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 5 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_806;
            }
            C2Rust_Block_36::S_806 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_808;
            }
            C2Rust_Block_36::S_808 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_810;
            }
            C2Rust_Block_36::S_810 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_812;
            }
            C2Rust_Block_36::S_812 => {
                if recomp_parity8(_fa.wrapping_sub(_fb)) != 0 {
                    c2rust_current_block_36 = C2Rust_Block_36::S_882;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_821;
                }
            }
            C2Rust_Block_36::S_821 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_823;
            }
            C2Rust_Block_36::S_823 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_825;
            }
            C2Rust_Block_36::S_825 => {
                _fas = _fa as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_827;
            }
            C2Rust_Block_36::S_827 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_36 = C2Rust_Block_36::S_829;
            }
            C2Rust_Block_36::S_829 => {
                if _fa != _fb {
                    c2rust_current_block_36 = C2Rust_Block_36::S_862;
                } else {
                    c2rust_current_block_36 = C2Rust_Block_36::S_842;
                }
            }
            C2Rust_Block_36::S_842 => {
                _fp_value_13 = ::core::ptr::read_volatile::<
                    ::core::ffi::c_double,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        (0x3c64c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_844;
            }
            C2Rust_Block_36::S_844 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_846;
            }
            C2Rust_Block_36::S_846 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_13;
                c2rust_current_block_36 = C2Rust_Block_36::S_749;
            }
            C2Rust_Block_36::S_862 => {
                _fp_value_14 = 0.0f64;
                c2rust_current_block_36 = C2Rust_Block_36::S_864;
            }
            C2Rust_Block_36::S_864 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_866;
            }
            C2Rust_Block_36::S_866 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_14;
                c2rust_current_block_36 = C2Rust_Block_36::S_749;
            }
            C2Rust_Block_36::S_882 => {
                _fp_value_15 = 1.0f64;
                c2rust_current_block_36 = C2Rust_Block_36::S_884;
            }
            C2Rust_Block_36::S_884 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_886;
            }
            C2Rust_Block_36::S_886 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_15;
                c2rust_current_block_36 = C2Rust_Block_36::S_896;
            }
            C2Rust_Block_36::S_896 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x18 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_902;
            }
            C2Rust_Block_36::S_902 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_double,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize],
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_904;
            }
            C2Rust_Block_36::S_904 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_36 = C2Rust_Block_36::S_910;
            }
            C2Rust_Block_36::S_910 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_36 = C2Rust_Block_36::S_916;
            }
            C2Rust_Block_36::S_916 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_918;
            }
            C2Rust_Block_36::S_918 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_928;
            }
            C2Rust_Block_36::S_928 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_36 = C2Rust_Block_36::S_930;
            }
            C2Rust_Block_36::S_930 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_936;
            }
            C2Rust_Block_36::S_936 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_36 = C2Rust_Block_36::S_938;
            }
            C2Rust_Block_36::S_938 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249F13() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x249f20 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024B189();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_420: {
        if _fa == _fb {
            break 's_420;
        }
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0x3c6150 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_161: {
            's_114: {
                if _fa == _fb {
                    break 's_114;
                }
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                _fb = 0x3c6170 as ::core::ffi::c_int as uint32_t
                    & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa != _fb {
                    break 's_420;
                }
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                break 's_161;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41d2a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x41d2a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                )
                .wrapping_add(1 as uint32_t),
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x41d2a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        _fa = (::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0x10c as ::core::ffi::c_int) as uint32_t
            & 0xffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        _fbs = _fb as int16_t as int32_t;
        if _fa != _fb {
            break 's_420;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax)
            .wrapping_mul(4 as uint32_t)
            .wrapping_add(0x41d4c0 as uint32_t);
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_ebx) = 0x1000 as uint32_t;
        's_356: {
            's_342: {
                if _fa != _fb {
                    break 's_342;
                }
                let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ebx);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                let mut _pv_5: uint32_t = 0x249f63 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                sub_0024419D();
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                if _fa != _fb {
                    break 's_342;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x14 as uint32_t);
                let mut _pv_6: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                break 's_356;
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edi),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edi),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ebx),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_ebx),
            );
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (::core::ptr::read_volatile::<
                uint16_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint16_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int | 0x1102 as ::core::ffi::c_int) as uint16_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint16_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint16_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xffff as uint32_t;
        _fas = _fa as int16_t as int32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249F9B() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_158: {
        if _fa == _fb {
            break 's_158;
        }
        let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 0x10 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_146: {
            if _fa == _fb {
                break 's_146;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0x249fb3 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_002453B1();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0xee as ::core::ffi::c_int) as uint8_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00249FC5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x500 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x249fcf as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024419D();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_81: {
        if _fa == _fb {
            break 's_81;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x76b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x76b800 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0x20 as uint32_t,
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax).wrapping_add(0x500 as uint32_t);
        loop {
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa >= _fb {
                break;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0xffffffff as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                0 as uint8_t,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(5 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                0xa as uint8_t,
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x76b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add(0x28 as uint32_t);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = 0x500 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add(0x500 as uint32_t);
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        loop {
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x76b820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_eax));
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = 0x28 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add(0x28 as uint32_t);
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0x78 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                0xc1 as uint8_t,
            );
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                >= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break;
            }
        }
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A02A() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0x10 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x3747f8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24a036 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    let mut _pv_2: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_3: uint32_t = 0x24a042 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_002486AE();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    let mut _pv_4: uint32_t = 3 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    loop {
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-32 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_esi),
        );
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x76b938 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t))
                    as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_383: {
            if _fa == _fb {
                break 's_383;
            }
            _fa = (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int & 0x83 as ::core::ffi::c_int) as uint32_t
                & 0xff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_306: {
                if _fa == _fb {
                    break 's_306;
                }
                let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_6: uint32_t = 0x24a06c as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                sub_00245A3D();
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t
                    & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa == _fb {
                    break 's_306;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            }
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                < if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_383;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_7: uint32_t = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_8: uint32_t = 0x24a087 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            sub_002440A5();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x76b934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_esi).wrapping_mul(4 as uint32_t))
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_edi),
            );
        }
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) | 0xffffffff as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_9: uint32_t = 0x24a09c as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_0024A0A5();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_10: uint32_t = 0x24a0a4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A0A5() {
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24a0ac as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_002485FC();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A0AE() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x24a0b3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00248347();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A0B7() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x24a0bc as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_00248347();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A0C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24a0c6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_00248347();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_66: loop {
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi)
                    .wrapping_mul(8 as uint32_t)
                    .wrapping_add(0x3c6768 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_188: {
            if _fa == _fb {
                break 's_188;
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 0x2d as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa < _fb {
                continue 's_66;
            }
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 0x13 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_228: {
                if _fa < _fb {
                    break 's_228;
                }
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fb = 0x24 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa > _fb {
                    break 's_228;
                }
                let mut _pv_1: uint32_t = 0x24a0ed as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                sub_00248347();
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xd as uint32_t,
                );
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 0xbc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_308: {
                if _fa < _fb {
                    break 's_308;
                }
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fb = 0xca as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if _fa > _fb {
                    break 's_308;
                }
                let mut _pv_3: uint32_t = 0x24a11c as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                sub_00248347();
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    8 as uint32_t,
                );
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            let mut _pv_4: uint32_t = 0x24a12a as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            sub_00248347();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                0x16 as uint32_t,
            );
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        let mut _pv_2: uint32_t = 0x24a0fb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_00248347();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi)
                    .wrapping_mul(8 as uint32_t)
                    .wrapping_add(0x3c676c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A133() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x24a13e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_0024BDDD();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_101: {
        if _fa == _fb {
            break 's_101;
        }
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x24a165 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        sub_001D120E();
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fb = 0xffffffff as ::core::ffi::c_uint as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_290: {
            's_280: {
                if _fa != _fb {
                    break 's_280;
                }
                let mut _pv_9: uint32_t = 0x24a171 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                sub_001D192B();
                break 's_290;
            }
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_403: {
            's_365: {
                if _fa == _fb {
                    break 's_365;
                }
                let mut _pv_10: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                let mut _pv_11: uint32_t = 0x24a17f as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                sub_0024A0C0();
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                break 's_403;
            }
            (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) & 0x1f as uint32_t;
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = ((*__gamepkg_tls_g_ecx) as int32_t
                >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_ecx)
                        .wrapping_mul(4 as uint32_t)
                        .wrapping_add(0x76b820 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx)
                .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t))
                .wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0xfd as ::core::ffi::c_int) as uint8_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_2: uint32_t = 0x24a149 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_0024A0AE();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        9 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A1A5() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x374808 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24a1b1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b800 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_93: {
        if _fa >= _fb {
            break 's_93;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
            >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax)
            .wrapping_mul(4 as uint32_t)
            .wrapping_add(0x76b820 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x1f as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
            .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) << 3 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_esi))
                    .wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_144: {
            if _fa == _fb {
                break 's_144;
            }
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_3: uint32_t = 0x24a1e2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            sub_0024BE1E();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_esi))
                        .wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                & 0xff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_381: {
                's_315: {
                    if _fa == _fb {
                        break 's_315;
                    }
                    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ebx);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    (*__gamepkg_tls_g_ebp) = ebp;
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    let mut _pv_7: uint32_t = 0x24a1fc as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    sub_0024A133();
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    break 's_381;
                }
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_8: uint32_t = 0x24a209 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                sub_0024A0AE();
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    9 as uint32_t,
                );
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_9: uint32_t = 0x24a214 as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                sub_0024A0B7();
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0xffffffff as uint32_t,
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0xffffffff as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_10: uint32_t = 0x24a224 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            sub_0024A22C();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            sub_0024A24A();
            return;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_0024A234();
        return;
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024A234();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A229() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024A22C();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A22C() {
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24a232 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024BEBE();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A234() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0x24a239 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_0024A0AE();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        9 as uint32_t,
    );
    let mut _pv_0: uint32_t = 0x24a244 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024A0B7();
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0 as uint32_t,
    );
    _fa = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24a24f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A24A() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv: uint32_t = 0x24a24f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    sub_002447BF();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A250() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    enum C2Rust_Block_51 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_93,
        S_95,
        S_97,
        S_105,
        S_111,
        S_113,
        S_115,
        S_121,
        S_123,
        S_125,
        S_127,
        S_129,
        S_131,
        S_133,
        S_139,
        S_141,
        S_143,
        S_149,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_182,
        S_184,
        S_186,
        S_196,
        S_198,
        S_200,
        S_210,
        S_212,
        S_214,
        S_224,
        S_226,
        S_228,
        S_234,
        S_236,
        S_242,
        S_244,
        S_246,
        S_252,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_454,
        S_463,
        S_465,
        S_467,
        S_469,
        S_471,
        S_473,
        S_475,
        S_481,
        S_483,
        S_485,
        S_491,
        S_497,
        S_499,
        S_501,
        S_511,
        S_513,
        S_515,
        S_521,
        S_527,
        S_529,
        S_531,
        S_537,
        S_543,
        S_545,
        S_547,
        S_553,
        S_555,
        S_561,
        S_563,
        S_565,
        S_571,
        S_577,
        S_579,
        S_581,
        S_583,
        S_585,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_623,
        S_625,
        S_627,
        S_629,
        S_631,
        S_633,
        S_635,
        S_637,
        S_639,
        S_641,
        S_643,
        S_645,
        S_647,
        S_649,
        S_664,
        S_666,
        S_672,
        S_674,
        S_676,
        S_682,
        S_688,
        S_694,
        S_696,
        S_698,
        S_704,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_723,
        S_725,
        S_727,
        S_729,
        S_731,
        S_744,
        S_746,
        S_748,
        S_758,
        S_760,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_783,
        S_785,
        S_791,
        S_793,
        S_795,
        S_801,
        S_807,
        S_809,
        S_811,
        S_817,
        S_819,
        S_821,
        S_827,
        S_833,
        S_845,
        S_847,
        S_849,
        S_855,
        S_861,
        S_863,
        S_865,
        S_875,
        S_877,
        S_879,
        S_889,
        S_891,
        S_893,
        S_903,
        S_905,
        S_907,
        S_913,
        S_915,
        S_921,
        S_923,
        S_925,
        S_931,
        S_937,
        S_939,
        S_941,
        S_943,
        S_945,
        S_954,
        S_956,
        S_958,
        S_966,
        S_968,
        S_974,
        S_976,
        S_978,
        S_984,
        S_990,
        S_1002,
        S_1004,
        S_1006,
        S_1012,
        S_1014,
        S_1020,
        S_1022,
        S_1024,
        S_1030,
        S_1040,
        S_1042,
        S_1054,
        S_1056,
        S_1058,
        S_1060,
        S_1062,
        S_1064,
        S_1073,
        S_1075,
        S_1077,
        S_1079,
        S_1081,
        S_1083,
        S_1092,
        S_1094,
        S_1096,
        S_1104,
        S_1106,
        S_1112,
        S_1114,
        S_1116,
        S_1122,
        S_1128,
        S_1130,
        S_1132,
        S_1138,
        S_1140,
        S_1142,
        S_1148,
        S_1154,
        S_1160,
        S_1162,
        S_1164,
        S_1172,
        S_1174,
        S_1176,
        S_1178,
        S_1180,
        S_1190,
        S_1192,
        S_1202,
        S_1204,
        S_1218,
        S_1220,
        S_1226,
        S_1232,
        S_1234,
        S_1240,
        S_1242,
    }
    let mut c2rust_current_block_51: C2Rust_Block_51;
    c2rust_current_block_51 = C2Rust_Block_51::S_0;
    loop {
        match c2rust_current_block_51 {
            C2Rust_Block_51::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_2;
            }
            C2Rust_Block_51::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_51 = C2Rust_Block_51::S_4;
            }
            C2Rust_Block_51::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_51 = C2Rust_Block_51::S_6;
            }
            C2Rust_Block_51::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_8;
            }
            C2Rust_Block_51::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_26;
            }
            C2Rust_Block_51::S_26 => {
                _pv = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_28;
            }
            C2Rust_Block_51::S_28 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_30;
            }
            C2Rust_Block_51::S_30 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_36;
            }
            C2Rust_Block_51::S_36 => {
                ebp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_51 = C2Rust_Block_51::S_38;
            }
            C2Rust_Block_51::S_38 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_40;
            }
            C2Rust_Block_51::S_40 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_42;
            }
            C2Rust_Block_51::S_42 => {
                _fb = 0x41c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_44;
            }
            C2Rust_Block_51::S_44 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_46;
            }
            C2Rust_Block_51::S_46 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x41c as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_48;
            }
            C2Rust_Block_51::S_48 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_50;
            }
            C2Rust_Block_51::S_50 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_56;
            }
            C2Rust_Block_51::S_56 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_58;
            }
            C2Rust_Block_51::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_60;
            }
            C2Rust_Block_51::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_66;
            }
            C2Rust_Block_51::S_66 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_68;
            }
            C2Rust_Block_51::S_68 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_70;
            }
            C2Rust_Block_51::S_70 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_72;
            }
            C2Rust_Block_51::S_72 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_74;
            }
            C2Rust_Block_51::S_74 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_76;
            }
            C2Rust_Block_51::S_76 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_78;
            }
            C2Rust_Block_51::S_78 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_80;
            }
            C2Rust_Block_51::S_80 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_82;
            }
            C2Rust_Block_51::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_84;
            }
            C2Rust_Block_51::S_84 => {
                if _fa != _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_105;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_93;
                }
            }
            C2Rust_Block_51::S_93 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_95;
            }
            C2Rust_Block_51::S_95 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_97;
            }
            C2Rust_Block_51::S_97 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1218;
            }
            C2Rust_Block_51::S_105 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_111;
            }
            C2Rust_Block_51::S_111 => {
                _pv_1 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_51 = C2Rust_Block_51::S_113;
            }
            C2Rust_Block_51::S_113 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_115;
            }
            C2Rust_Block_51::S_115 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_121;
            }
            C2Rust_Block_51::S_121 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_123;
            }
            C2Rust_Block_51::S_123 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x1f as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_125;
            }
            C2Rust_Block_51::S_125 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_127;
            }
            C2Rust_Block_51::S_127 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_129;
            }
            C2Rust_Block_51::S_129 => {
                (*__gamepkg_tls_g_ebx) = ((*__gamepkg_tls_g_ebx) as int32_t
                    >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_131;
            }
            C2Rust_Block_51::S_131 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_133;
            }
            C2Rust_Block_51::S_133 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_139;
            }
            C2Rust_Block_51::S_139 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_51 = C2Rust_Block_51::S_141;
            }
            C2Rust_Block_51::S_141 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_143;
            }
            C2Rust_Block_51::S_143 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_149;
            }
            C2Rust_Block_51::S_149 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
                c2rust_current_block_51 = C2Rust_Block_51::S_151;
            }
            C2Rust_Block_51::S_151 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x76b820 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_153;
            }
            C2Rust_Block_51::S_153 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_155;
            }
            C2Rust_Block_51::S_155 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    << 3 as ::core::ffi::c_int;
                c2rust_current_block_51 = C2Rust_Block_51::S_157;
            }
            C2Rust_Block_51::S_157 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_159;
            }
            C2Rust_Block_51::S_159 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_161;
            }
            C2Rust_Block_51::S_161 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add((*__gamepkg_tls_g_esi))
                            .wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x20 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_163;
            }
            C2Rust_Block_51::S_163 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_165;
            }
            C2Rust_Block_51::S_165 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_167;
            }
            C2Rust_Block_51::S_167 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_169;
            }
            C2Rust_Block_51::S_169 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_272;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_182;
                }
            }
            C2Rust_Block_51::S_182 => {
                _pv_3 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_184;
            }
            C2Rust_Block_51::S_184 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_186;
            }
            C2Rust_Block_51::S_186 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_196;
            }
            C2Rust_Block_51::S_196 => {
                _pv_4 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_198;
            }
            C2Rust_Block_51::S_198 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_200;
            }
            C2Rust_Block_51::S_200 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_210;
            }
            C2Rust_Block_51::S_210 => {
                _pv_5 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_212;
            }
            C2Rust_Block_51::S_212 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_214;
            }
            C2Rust_Block_51::S_214 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_224;
            }
            C2Rust_Block_51::S_224 => {
                _pv_6 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_226;
            }
            C2Rust_Block_51::S_226 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_228;
            }
            C2Rust_Block_51::S_228 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_234;
            }
            C2Rust_Block_51::S_234 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_236;
            }
            C2Rust_Block_51::S_236 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_242;
            }
            C2Rust_Block_51::S_242 => {
                _pv_7 = 0x24a29e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_244;
            }
            C2Rust_Block_51::S_244 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_246;
            }
            C2Rust_Block_51::S_246 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_252;
            }
            C2Rust_Block_51::S_252 => {
                sub_0024C05C();
                c2rust_current_block_51 = C2Rust_Block_51::S_258;
            }
            C2Rust_Block_51::S_258 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_260;
            }
            C2Rust_Block_51::S_260 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_262;
            }
            C2Rust_Block_51::S_262 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_264;
            }
            C2Rust_Block_51::S_264 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_266;
            }
            C2Rust_Block_51::S_266 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_272;
            }
            C2Rust_Block_51::S_272 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_274;
            }
            C2Rust_Block_51::S_274 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_276;
            }
            C2Rust_Block_51::S_276 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_278;
            }
            C2Rust_Block_51::S_278 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_esi));
                c2rust_current_block_51 = C2Rust_Block_51::S_280;
            }
            C2Rust_Block_51::S_280 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_282;
            }
            C2Rust_Block_51::S_282 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_284;
            }
            C2Rust_Block_51::S_284 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x80 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_286;
            }
            C2Rust_Block_51::S_286 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_288;
            }
            C2Rust_Block_51::S_288 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_290;
            }
            C2Rust_Block_51::S_290 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_292;
            }
            C2Rust_Block_51::S_292 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_845;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_301;
                }
            }
            C2Rust_Block_51::S_301 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_303;
            }
            C2Rust_Block_51::S_303 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_305;
            }
            C2Rust_Block_51::S_305 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_307;
            }
            C2Rust_Block_51::S_307 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_309;
            }
            C2Rust_Block_51::S_309 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_311;
            }
            C2Rust_Block_51::S_311 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_313;
            }
            C2Rust_Block_51::S_313 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_315;
            }
            C2Rust_Block_51::S_315 => {
                if _fa <= _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1054;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_324;
                }
            }
            C2Rust_Block_51::S_324 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_326;
            }
            C2Rust_Block_51::S_326 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_328;
            }
            C2Rust_Block_51::S_328 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_330;
            }
            C2Rust_Block_51::S_330 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_51 = C2Rust_Block_51::S_332;
            }
            C2Rust_Block_51::S_332 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_334;
            }
            C2Rust_Block_51::S_334 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_336;
            }
            C2Rust_Block_51::S_336 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-1052 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_338;
            }
            C2Rust_Block_51::S_338 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_344;
            }
            C2Rust_Block_51::S_344 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_346;
            }
            C2Rust_Block_51::S_346 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_348;
            }
            C2Rust_Block_51::S_348 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_350;
            }
            C2Rust_Block_51::S_350 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_352;
            }
            C2Rust_Block_51::S_352 => {
                if _fa >= _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_463;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_361;
                }
            }
            C2Rust_Block_51::S_361 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_363;
            }
            C2Rust_Block_51::S_363 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_365;
            }
            C2Rust_Block_51::S_365 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_367;
            }
            C2Rust_Block_51::S_367 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_369;
            }
            C2Rust_Block_51::S_369 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_371;
            }
            C2Rust_Block_51::S_371 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_edx) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_373;
            }
            C2Rust_Block_51::S_373 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                c2rust_current_block_51 = C2Rust_Block_51::S_375;
            }
            C2Rust_Block_51::S_375 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_377;
            }
            C2Rust_Block_51::S_377 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_379;
            }
            C2Rust_Block_51::S_379 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_381;
            }
            C2Rust_Block_51::S_381 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_383;
            }
            C2Rust_Block_51::S_383 => {
                _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_385;
            }
            C2Rust_Block_51::S_385 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_387;
            }
            C2Rust_Block_51::S_387 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_389;
            }
            C2Rust_Block_51::S_389 => {
                if _fa != _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_428;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_398;
                }
            }
            C2Rust_Block_51::S_398 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_400;
            }
            C2Rust_Block_51::S_400 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_402;
            }
            C2Rust_Block_51::S_402 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_404;
            }
            C2Rust_Block_51::S_404 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_406;
            }
            C2Rust_Block_51::S_406 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xd as uint8_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_408;
            }
            C2Rust_Block_51::S_408 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_51 = C2Rust_Block_51::S_410;
            }
            C2Rust_Block_51::S_410 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_412;
            }
            C2Rust_Block_51::S_412 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_414;
            }
            C2Rust_Block_51::S_414 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_416;
            }
            C2Rust_Block_51::S_416 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_418;
            }
            C2Rust_Block_51::S_418 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_420;
            }
            C2Rust_Block_51::S_420 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_422;
            }
            C2Rust_Block_51::S_422 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_428;
            }
            C2Rust_Block_51::S_428 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_430;
            }
            C2Rust_Block_51::S_430 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_51 = C2Rust_Block_51::S_432;
            }
            C2Rust_Block_51::S_432 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_434;
            }
            C2Rust_Block_51::S_434 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_436;
            }
            C2Rust_Block_51::S_436 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_438;
            }
            C2Rust_Block_51::S_438 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_440;
            }
            C2Rust_Block_51::S_440 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_442;
            }
            C2Rust_Block_51::S_442 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_444;
            }
            C2Rust_Block_51::S_444 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_446;
            }
            C2Rust_Block_51::S_446 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-8 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_448;
            }
            C2Rust_Block_51::S_448 => {
                _fb = 0x400 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_450;
            }
            C2Rust_Block_51::S_450 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_452;
            }
            C2Rust_Block_51::S_452 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_454;
            }
            C2Rust_Block_51::S_454 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_51 = C2Rust_Block_51::S_344;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_463;
                }
            }
            C2Rust_Block_51::S_463 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_465;
            }
            C2Rust_Block_51::S_465 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-1052 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_467;
            }
            C2Rust_Block_51::S_467 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_469;
            }
            C2Rust_Block_51::S_469 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_471;
            }
            C2Rust_Block_51::S_471 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_eax));
                c2rust_current_block_51 = C2Rust_Block_51::S_473;
            }
            C2Rust_Block_51::S_473 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_475;
            }
            C2Rust_Block_51::S_475 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_481;
            }
            C2Rust_Block_51::S_481 => {
                _pv_8 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_483;
            }
            C2Rust_Block_51::S_483 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_485;
            }
            C2Rust_Block_51::S_485 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_491;
            }
            C2Rust_Block_51::S_491 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-24 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_497;
            }
            C2Rust_Block_51::S_497 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_499;
            }
            C2Rust_Block_51::S_499 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_501;
            }
            C2Rust_Block_51::S_501 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_511;
            }
            C2Rust_Block_51::S_511 => {
                _pv_10 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_513;
            }
            C2Rust_Block_51::S_513 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_515;
            }
            C2Rust_Block_51::S_515 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_521;
            }
            C2Rust_Block_51::S_521 => {
                (*__gamepkg_tls_g_eax) = ebp
                    .wrapping_add(-1052 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_527;
            }
            C2Rust_Block_51::S_527 => {
                _pv_11 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_51 = C2Rust_Block_51::S_529;
            }
            C2Rust_Block_51::S_529 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_531;
            }
            C2Rust_Block_51::S_531 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_537;
            }
            C2Rust_Block_51::S_537 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_543;
            }
            C2Rust_Block_51::S_543 => {
                _pv_12 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add((*__gamepkg_tls_g_esi))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_545;
            }
            C2Rust_Block_51::S_545 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_547;
            }
            C2Rust_Block_51::S_547 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_553;
            }
            C2Rust_Block_51::S_553 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_555;
            }
            C2Rust_Block_51::S_555 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_561;
            }
            C2Rust_Block_51::S_561 => {
                _pv_13 = 0x24a31e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_563;
            }
            C2Rust_Block_51::S_563 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_565;
            }
            C2Rust_Block_51::S_565 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_571;
            }
            C2Rust_Block_51::S_571 => {
                sub_001D10B4();
                c2rust_current_block_51 = C2Rust_Block_51::S_577;
            }
            C2Rust_Block_51::S_577 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_579;
            }
            C2Rust_Block_51::S_579 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_581;
            }
            C2Rust_Block_51::S_581 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_583;
            }
            C2Rust_Block_51::S_583 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_585;
            }
            C2Rust_Block_51::S_585 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_664;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_594;
                }
            }
            C2Rust_Block_51::S_594 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_596;
            }
            C2Rust_Block_51::S_596 => {
                _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_598;
            }
            C2Rust_Block_51::S_598 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_600;
            }
            C2Rust_Block_51::S_600 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add((*__gamepkg_tls_g_eax)),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_602;
            }
            C2Rust_Block_51::S_602 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_604;
            }
            C2Rust_Block_51::S_604 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_606;
            }
            C2Rust_Block_51::S_606 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_608;
            }
            C2Rust_Block_51::S_608 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_610;
            }
            C2Rust_Block_51::S_610 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_612;
            }
            C2Rust_Block_51::S_612 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_614;
            }
            C2Rust_Block_51::S_614 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    < if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_51 = C2Rust_Block_51::S_694;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_623;
                }
            }
            C2Rust_Block_51::S_623 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-12 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_625;
            }
            C2Rust_Block_51::S_625 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_627;
            }
            C2Rust_Block_51::S_627 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_629;
            }
            C2Rust_Block_51::S_629 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_51 = C2Rust_Block_51::S_631;
            }
            C2Rust_Block_51::S_631 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_633;
            }
            C2Rust_Block_51::S_633 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_635;
            }
            C2Rust_Block_51::S_635 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_637;
            }
            C2Rust_Block_51::S_637 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_639;
            }
            C2Rust_Block_51::S_639 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_641;
            }
            C2Rust_Block_51::S_641 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_643;
            }
            C2Rust_Block_51::S_643 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_645;
            }
            C2Rust_Block_51::S_645 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_647;
            }
            C2Rust_Block_51::S_647 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_649;
            }
            C2Rust_Block_51::S_649 => {
                if _fa < _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_324;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_704;
                }
            }
            C2Rust_Block_51::S_664 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_666;
            }
            C2Rust_Block_51::S_666 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_672;
            }
            C2Rust_Block_51::S_672 => {
                _pv_14 = 0x24a340 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_674;
            }
            C2Rust_Block_51::S_674 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_676;
            }
            C2Rust_Block_51::S_676 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_682;
            }
            C2Rust_Block_51::S_682 => {
                sub_001D192B();
                c2rust_current_block_51 = C2Rust_Block_51::S_688;
            }
            C2Rust_Block_51::S_688 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_694;
            }
            C2Rust_Block_51::S_694 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_696;
            }
            C2Rust_Block_51::S_696 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_698;
            }
            C2Rust_Block_51::S_698 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_704;
            }
            C2Rust_Block_51::S_704 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_706;
            }
            C2Rust_Block_51::S_706 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_708;
            }
            C2Rust_Block_51::S_708 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_710;
            }
            C2Rust_Block_51::S_710 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_712;
            }
            C2Rust_Block_51::S_712 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_714;
            }
            C2Rust_Block_51::S_714 => {
                if _fa != _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1172;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_723;
                }
            }
            C2Rust_Block_51::S_723 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_725;
            }
            C2Rust_Block_51::S_725 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_727;
            }
            C2Rust_Block_51::S_727 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_729;
            }
            C2Rust_Block_51::S_729 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_731;
            }
            C2Rust_Block_51::S_731 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1054;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_744;
                }
            }
            C2Rust_Block_51::S_744 => {
                _pv_15 = 5 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_746;
            }
            C2Rust_Block_51::S_746 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_748;
            }
            C2Rust_Block_51::S_748 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_758;
            }
            C2Rust_Block_51::S_758 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_760;
            }
            C2Rust_Block_51::S_760 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_766;
            }
            C2Rust_Block_51::S_766 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_768;
            }
            C2Rust_Block_51::S_768 => {
                _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_770;
            }
            C2Rust_Block_51::S_770 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_772;
            }
            C2Rust_Block_51::S_772 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_774;
            }
            C2Rust_Block_51::S_774 => {
                if _fa != _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1002;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_783;
                }
            }
            C2Rust_Block_51::S_783 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_785;
            }
            C2Rust_Block_51::S_785 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_791;
            }
            C2Rust_Block_51::S_791 => {
                _pv_16 = 0x24a362 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_793;
            }
            C2Rust_Block_51::S_793 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_795;
            }
            C2Rust_Block_51::S_795 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_801;
            }
            C2Rust_Block_51::S_801 => {
                sub_0024A0AE();
                c2rust_current_block_51 = C2Rust_Block_51::S_807;
            }
            C2Rust_Block_51::S_807 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    9 as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_809;
            }
            C2Rust_Block_51::S_809 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_811;
            }
            C2Rust_Block_51::S_811 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_817;
            }
            C2Rust_Block_51::S_817 => {
                _pv_17 = 0x24a36d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_819;
            }
            C2Rust_Block_51::S_819 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_821;
            }
            C2Rust_Block_51::S_821 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_827;
            }
            C2Rust_Block_51::S_827 => {
                sub_0024A0B7();
                c2rust_current_block_51 = C2Rust_Block_51::S_833;
            }
            C2Rust_Block_51::S_833 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_esi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1160;
            }
            C2Rust_Block_51::S_845 => {
                _pv_18 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_51 = C2Rust_Block_51::S_847;
            }
            C2Rust_Block_51::S_847 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_849;
            }
            C2Rust_Block_51::S_849 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_855;
            }
            C2Rust_Block_51::S_855 => {
                (*__gamepkg_tls_g_ecx) = ebp
                    .wrapping_add(-24 as ::core::ffi::c_int as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_861;
            }
            C2Rust_Block_51::S_861 => {
                _pv_19 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_51 = C2Rust_Block_51::S_863;
            }
            C2Rust_Block_51::S_863 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_865;
            }
            C2Rust_Block_51::S_865 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_875;
            }
            C2Rust_Block_51::S_875 => {
                _pv_20 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_877;
            }
            C2Rust_Block_51::S_877 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_879;
            }
            C2Rust_Block_51::S_879 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_889;
            }
            C2Rust_Block_51::S_889 => {
                _pv_21 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_891;
            }
            C2Rust_Block_51::S_891 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_893;
            }
            C2Rust_Block_51::S_893 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_903;
            }
            C2Rust_Block_51::S_903 => {
                _pv_22 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_905;
            }
            C2Rust_Block_51::S_905 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_907;
            }
            C2Rust_Block_51::S_907 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_913;
            }
            C2Rust_Block_51::S_913 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_915;
            }
            C2Rust_Block_51::S_915 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_921;
            }
            C2Rust_Block_51::S_921 => {
                _pv_23 = 0x24a383 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_923;
            }
            C2Rust_Block_51::S_923 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_925;
            }
            C2Rust_Block_51::S_925 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_931;
            }
            C2Rust_Block_51::S_931 => {
                sub_001D10B4();
                c2rust_current_block_51 = C2Rust_Block_51::S_937;
            }
            C2Rust_Block_51::S_937 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_939;
            }
            C2Rust_Block_51::S_939 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_941;
            }
            C2Rust_Block_51::S_941 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_943;
            }
            C2Rust_Block_51::S_943 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_945;
            }
            C2Rust_Block_51::S_945 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_966;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_954;
                }
            }
            C2Rust_Block_51::S_954 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-24 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_956;
            }
            C2Rust_Block_51::S_956 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_958;
            }
            C2Rust_Block_51::S_958 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-16 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_704;
            }
            C2Rust_Block_51::S_966 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_968;
            }
            C2Rust_Block_51::S_968 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_974;
            }
            C2Rust_Block_51::S_974 => {
                _pv_24 = 0x24a397 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_976;
            }
            C2Rust_Block_51::S_976 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_978;
            }
            C2Rust_Block_51::S_978 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_984;
            }
            C2Rust_Block_51::S_984 => {
                sub_001D192B();
                c2rust_current_block_51 = C2Rust_Block_51::S_990;
            }
            C2Rust_Block_51::S_990 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_704;
            }
            C2Rust_Block_51::S_1002 => {
                _pv_25 = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1004;
            }
            C2Rust_Block_51::S_1004 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1006;
            }
            C2Rust_Block_51::S_1006 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1012;
            }
            C2Rust_Block_51::S_1012 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1014;
            }
            C2Rust_Block_51::S_1014 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1020;
            }
            C2Rust_Block_51::S_1020 => {
                _pv_26 = 0x24a3a4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1022;
            }
            C2Rust_Block_51::S_1022 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1024;
            }
            C2Rust_Block_51::S_1024 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1030;
            }
            C2Rust_Block_51::S_1030 => {
                sub_0024A0C0();
                c2rust_current_block_51 = C2Rust_Block_51::S_1040;
            }
            C2Rust_Block_51::S_1040 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1042;
            }
            C2Rust_Block_51::S_1042 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1160;
            }
            C2Rust_Block_51::S_1054 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1056;
            }
            C2Rust_Block_51::S_1056 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax)
                            .wrapping_add((*__gamepkg_tls_g_esi))
                            .wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 0x40 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1058;
            }
            C2Rust_Block_51::S_1058 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1060;
            }
            C2Rust_Block_51::S_1060 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1062;
            }
            C2Rust_Block_51::S_1062 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1064;
            }
            C2Rust_Block_51::S_1064 => {
                if _fa == _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1104;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1073;
                }
            }
            C2Rust_Block_51::S_1073 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1075;
            }
            C2Rust_Block_51::S_1075 => {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1077;
            }
            C2Rust_Block_51::S_1077 => {
                _fb = 0x1a as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1079;
            }
            C2Rust_Block_51::S_1079 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1081;
            }
            C2Rust_Block_51::S_1081 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1083;
            }
            C2Rust_Block_51::S_1083 => {
                if _fa != _fb {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1104;
                } else {
                    c2rust_current_block_51 = C2Rust_Block_51::S_1092;
                }
            }
            C2Rust_Block_51::S_1092 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1094;
            }
            C2Rust_Block_51::S_1094 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1096;
            }
            C2Rust_Block_51::S_1096 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1190;
            }
            C2Rust_Block_51::S_1104 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1106;
            }
            C2Rust_Block_51::S_1106 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1112;
            }
            C2Rust_Block_51::S_1112 => {
                _pv_27 = 0x24a3c1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1114;
            }
            C2Rust_Block_51::S_1114 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1116;
            }
            C2Rust_Block_51::S_1116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1122;
            }
            C2Rust_Block_51::S_1122 => {
                sub_0024A0AE();
                c2rust_current_block_51 = C2Rust_Block_51::S_1128;
            }
            C2Rust_Block_51::S_1128 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1c as uint32_t,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1130;
            }
            C2Rust_Block_51::S_1130 => {
                (*__gamepkg_tls_g_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1132;
            }
            C2Rust_Block_51::S_1132 => {
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1138;
            }
            C2Rust_Block_51::S_1138 => {
                _pv_28 = 0x24a3cc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1140;
            }
            C2Rust_Block_51::S_1140 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1142;
            }
            C2Rust_Block_51::S_1142 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1148;
            }
            C2Rust_Block_51::S_1148 => {
                sub_0024A0B7();
                c2rust_current_block_51 = C2Rust_Block_51::S_1154;
            }
            C2Rust_Block_51::S_1154 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1160;
            }
            C2Rust_Block_51::S_1160 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) | 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1162;
            }
            C2Rust_Block_51::S_1162 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1164;
            }
            C2Rust_Block_51::S_1164 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1190;
            }
            C2Rust_Block_51::S_1172 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1174;
            }
            C2Rust_Block_51::S_1174 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1176;
            }
            C2Rust_Block_51::S_1176 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_sub(
                        ::core::ptr::read_volatile::<
                            uint32_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                (ebp.wrapping_add(-20 as ::core::ffi::c_int as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                c2rust_current_block_51 = C2Rust_Block_51::S_1178;
            }
            C2Rust_Block_51::S_1178 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1180;
            }
            C2Rust_Block_51::S_1180 => {
                _fas = _fa as int32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_1190;
            }
            C2Rust_Block_51::S_1190 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1192;
            }
            C2Rust_Block_51::S_1192 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1202;
            }
            C2Rust_Block_51::S_1202 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1204;
            }
            C2Rust_Block_51::S_1204 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1218;
            }
            C2Rust_Block_51::S_1218 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1220;
            }
            C2Rust_Block_51::S_1220 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1226;
            }
            C2Rust_Block_51::S_1226 => {
                (*__gamepkg_tls_g_esp) = ebp;
                c2rust_current_block_51 = C2Rust_Block_51::S_1232;
            }
            C2Rust_Block_51::S_1232 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_51 = C2Rust_Block_51::S_1234;
            }
            C2Rust_Block_51::S_1234 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1240;
            }
            C2Rust_Block_51::S_1240 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_51 = C2Rust_Block_51::S_1242;
            }
            C2Rust_Block_51::S_1242 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A3DB() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = 0xc as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x374818 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_1: uint32_t = 0x24a3e7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00244784();
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fb = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76b800 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_93: {
        if _fa >= _fb {
            break 's_93;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
            >> (5 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint)) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax)
            .wrapping_mul(4 as uint32_t)
            .wrapping_add(0x76b820 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x1f as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax)
            .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi) << 3 as ::core::ffi::c_int;
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_esi))
                    .wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_144: {
            if _fa == _fb {
                break 's_144;
            }
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_3: uint32_t = 0x24a418 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            sub_0024BE1E();
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0 as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_esi))
                        .wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                & 0xff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
            _fas = _fa as int8_t as int32_t;
            _fbs = _fb as int8_t as int32_t;
            's_381: {
                's_315: {
                    if _fa == _fb {
                        break 's_315;
                    }
                    let mut _pv_4: uint32_t = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x10 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    let mut _pv_5: uint32_t = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ebx);
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    (*__gamepkg_tls_g_ebp) = ebp;
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    let mut _pv_7: uint32_t = 0x24a432 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    sub_0024A250();
                    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    _fbs = _fb as int32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0xc as uint32_t);
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    _fas = _fa as int32_t;
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    break 's_381;
                }
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_8: uint32_t = 0x24a43f as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                sub_0024A0AE();
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    9 as uint32_t,
                );
                (*__gamepkg_tls_g_ebp) = ebp;
                (*__gamepkg_tls_g_seh_ebp) = ebp;
                let mut _pv_9: uint32_t = 0x24a44a as ::core::ffi::c_uint as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                sub_0024A0B7();
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0 as uint32_t,
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) | 0xffffffff as uint32_t,
                );
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
            }
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) | 0xffffffff as uint32_t,
            );
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-4 as ::core::ffi::c_int as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_ebp) = ebp;
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            let mut _pv_10: uint32_t = 0x24a45a as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            sub_0024A462();
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp.wrapping_add(-28 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_seh_ebp) = ebp;
            sub_0024A480();
            return;
        }
        (*__gamepkg_tls_g_seh_ebp) = ebp;
        sub_0024A46A();
        return;
    }
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024A46A();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A45F() {
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    ebp = (*__gamepkg_tls_g_seh_ebp);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    sub_0024A462();
}
#[no_mangle]
pub unsafe extern "C" fn sub_0024A462() {
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x24a468 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    sub_0024BEBE();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
